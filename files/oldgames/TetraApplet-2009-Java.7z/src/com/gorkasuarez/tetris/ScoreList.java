/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * This ScoreList class represents the list of the game's best scores.
 * @author Gorka Suárez
 */
public class ScoreList implements Iterator<Score> {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The list of scores. */
    private Score[] scores;

    /** The current iterator's index. */
    private int index;

    //********************************************************************************
    // Private methods
    //********************************************************************************

    /**
     * Initializes the object data.
     */
    private void initObject() {
        this.scores = new Score[ScoreList.MaxScores];
        for(int i = 0; i < ScoreList.MaxScores; ++i) {
            this.scores[i] = new Score();
        }
        this.index = 0;
    }

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a ScoreList object.
     */
    public ScoreList() {
        this.initObject();
    }

    /**
     * Constructs a ScoreList object from another ScoreList object.
     * @param obj The other ScoreList object.
     */
    public ScoreList(ScoreList obj) {
        this.scores = obj.scores;
        this.index = 0;
    }

    /**
     * Adds a new score in the list.
     * @param name The name of the player.
     * @param points The number of points of the player.
     */
    public void add(String name, int points) {
        this.add(new Score(name, points));
    }

    /**
     * Adds a new score in the list.
     * @param newScore The new score to add.
     */
    public void add(Score newScore) {
        for(int i = 0; i < ScoreList.MaxScores; ++i) {
            if(this.scores[i].getPoints() <= newScore.getPoints()) {
                for(int j = (ScoreList.MaxScores - 1); j > i; --j) {
                    this.scores[j] = this.scores[j - 1];
                }
                this.scores[i] = newScore;
                return;
            }
        }
    }

    /**
     * Resets the current index of the iterator.
     */
    public void resetIndex() {
        this.index = 0;
    }

    /**
     * Gets a list's interator.
     * @return An interator of the list.
     */
    public Iterator<Score> iterator() {
        return new ScoreList(this);
    }

    /*
     * (non-Javadoc)
     * @see java.util.Iterator#hasNext()
     */
    public boolean hasNext() {
        return (this.index < ScoreList.MaxScores);
    }

    /*
     * (non-Javadoc)
     * @see java.util.Iterator#next()
     */
    public Score next() {
        Score aux = this.scores[this.index];
        this.index++;
        return aux;
    }

    /*
     * (non-Javadoc)
     * @see java.util.Iterator#remove()
     */
    public void remove() {
    }

    /**
     * Sets the data from a given string.
     * @param str The string with the data.
     */
    public void fromString(String str) {
        try {
            ArrayList<Score> data = new ArrayList<Score>();
            Score aux;
            int i = 0;

            StringTokenizer st = new StringTokenizer(str, ScoreList.Separator, false);
            while(st.hasMoreTokens() && (i < ScoreList.MaxScores)) {
                aux = new Score();
                aux.fromString(st.nextToken().trim());
                data.add(aux);
                ++i;
            }

            if(data.size() > 0) {
                Iterator<Score> it = data.iterator();
                for(i = 0; it.hasNext() && (i < ScoreList.MaxScores); ++i) {
                    this.scores[i] = it.next();
                }
                it = null;
            } else {
                this.initObject();
            }

            data = null;
            aux = null;
        } catch(Exception e) {
            System.out.println(e.getMessage());
            this.initObject();
        }
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString() {
        String aux = "";
        if(this.scores.length > 0) {
            aux += this.scores[0].toString();
            for(int i = 1; i < this.scores.length; ++i) {
                aux += (ScoreList.Separator + this.scores[i].toString());
            }
        }
        return aux;
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The separator of the list values. */
    private static final String Separator = ".";

    /** The maximum number of scores. */
    private static final int MaxScores = 8;
}