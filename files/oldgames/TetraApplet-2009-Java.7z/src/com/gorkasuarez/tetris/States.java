/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris;

import com.gorkasuarez.jagl.GameApp;
import com.gorkasuarez.tetris.state.*;

/**
 * This States class stores the states of the game.
 * @author Gorka Suárez
 */
public class States {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The intro state of the game. */
    private IntroState introState;

    /** The menu state of the game. */
    private MenuState menuState;

    /** The game state of the game. */
    private GameState gameState;

    /** The set score state of the game. */
    private SetScoreState setScoreState;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Initializes the object data.
     */
    public final void initialize(GameApp value) {
        this.introState = new IntroState(value);
        this.menuState = new MenuState(value);
        this.gameState = new GameState(value);
        this.setScoreState = new SetScoreState(value);
    }

    /**
     * Releases the object data.
     */
    public final void release() {
        this.introState = null;
        this.menuState = null;
        this.gameState = null;
        this.setScoreState = null;
    }

    /**
     * Gets the game state of the game.
     * @return The game state of the game.
     */
    public final GameState getGameState() {
        return this.gameState;
    }

    /**
     * Gets the intro state of the game.
     * @return The intro state of the game.
     */
    public final IntroState getIntroState() {
        return this.introState;
    }

    /**
     * Gets the menu state of the game.
     * @return The menu state of the game.
     */
    public final MenuState getMenuState() {
        return this.menuState;
    }

    /**
     * Gets the set score state of the game.
     * @return The set score state of the game.
     */
    public final SetScoreState getSetScoreState() {
        return this.setScoreState;
    }

    //********************************************************************************
    // Private methods
    //********************************************************************************

    /**
     * Constructs a States object.
     */
    private States() {
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The instance of this class. */
    static private States instance = null;

    /**
     * Gets the instance of this class.
     * @return The instance of this class.
     */
    static public States getInstance() {
        if(instance == null) {
            instance = new States();
        }
        return instance;
    }
}