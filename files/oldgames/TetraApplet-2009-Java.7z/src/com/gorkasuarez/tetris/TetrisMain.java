/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris;

import com.gorkasuarez.jagl.GameApp;

/**
 * This TetrisMain class represents the implementation of the GameApp class to
 * develop a Tetris game inside an applet.
 * @author Gorka Suárez
 */
public class TetrisMain extends GameApp {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The data and resources of the game. */
    private Data data;

    /** The states of the game. */
    private States states;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /*
     * (non-Javadoc)
     * @see java.applet.Applet#init()
     */
    public void init() {
        this.data = Data.getInstance();
        this.data.initialize(this);

        this.states = States.getInstance();
        this.states.initialize(this);

        this.initialize(480, 640, this.states.getIntroState());
    }

    /*
     * (non-Javadoc)
     * @see java.applet.Applet#destroy()
     */
    public void destroy() {
        this.release();
        this.data.release();
        this.states.release();
        System.gc();
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The serial version UID. */
    private static final long serialVersionUID = 2008101114L;
}
