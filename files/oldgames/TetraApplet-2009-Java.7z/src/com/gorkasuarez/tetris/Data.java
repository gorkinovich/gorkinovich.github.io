/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris;

import com.gorkasuarez.jagl.Font;
import com.gorkasuarez.jagl.GameApp;
import com.gorkasuarez.jagl.SystemFont10;
import java.awt.Image;

/**
 * This Data class stores the global data of the game.
 * @author Gorka Suárez
 */
public class Data {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The blocks textures. */
    private Image[] blocks;

    /** The backgrounds textures. */
    private Image[] backgrounds;

    /** The items textures. */
    private Image[] items;

    /** The system font. */
    private Font systemFont;

    /** The scores of the game. */
    private ScoreList scores;

    /** The game application. */
    private GameApp app;

    /** The music of the game. */
    private Music music;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Initializes the object data.
     * @param value The game application.
     */
    public final void initialize(GameApp value) {
        this.app = value;
        this.loadBlocks();
        this.loadBackgrounds();
        this.loadItems();
        this.loadFonts();
        this.loadScores();
        this.music.initialize();
    }

    /**
     * Releases the object data.
     */
    public final void release() {
        this.music.release();
        String aux = this.scores.toString();
        this.app.createCookie("com.gorkasuarez.tetris", aux, 1000);
    }

    /**
     * Gets a block texture.
     * @param index The block index.
     * @return A block texture.
     */
    public final Image getBlock(int index) {
        return this.blocks[index];
    }

    /**
     * Gets a background texture.
     * @param index The background index.
     * @return A background texture.
     */
    public final Image getBackgrounds(int index) {
        return this.backgrounds[index];
    }

    /**
     * Gets an item texture.
     * @param index The item index.
     * @return An item texture.
     */
    public final Image getItems(int index) {
        return this.items[index];
    }

    /**
     * Gets the system font.
     * @return The system font.
     */
    public Font getSystemFont() {
        return this.systemFont;
    }

    /**
     * Gets the scores of the game.
     * @return The scores of the game.
     */
    public ScoreList getScores() {
        return this.scores;
    }

    /**
     * Gets the music.
     * @return The music.
     */
    public Music getMusic() {
        return this.music;
    }

    /**
     * Gets if the music is enable or not.
     * @return True if the music is enable or not.
     */
    public boolean isMusicEnable() {
        return this.music.isMusicEnable();
    }

    /**
     * Sets if the music is enable or not.
     * @param musicEnable The new value to set.
     */
    public void setMusicEnable(boolean musicEnable) {
        this.music.setMusicEnable(musicEnable);
    }

    //********************************************************************************
    // Private methods
    //********************************************************************************

    /**
     * Constructs a Data object.
     */
    private Data() {
        this.music = new Music();
    }

    /**
     * Loads an image of the game.
     * @param path The path of the image.
     * @return The image object.
     */
    private final Image loadImage(String path) {
        Image aux = null;
        try {
            aux = this.app.getImage(this.app.getDocumentBase(), path);
        } catch(Exception e) {
            System.out.println("Unable to load file: " + path);
            System.out.println(e.getMessage());
            System.out.println();
        }
        return aux;
    }

    /**
     * Loads the blocks textures of the game.
     */
    private final void loadBlocks() {
        this.blocks = new Image[75];
        this.blocks[0] = this.loadImage("gfx/Blocks/1.DarkBlue/1.0.0.png");
        this.blocks[1] = this.loadImage("gfx/Blocks/1.DarkBlue/1.0.1.png");
        this.blocks[2] = this.loadImage("gfx/Blocks/1.DarkBlue/1.1.1.png");
        this.blocks[3] = this.loadImage("gfx/Blocks/1.DarkBlue/1.1.2.png");
        this.blocks[4] = this.loadImage("gfx/Blocks/1.DarkBlue/1.2.1.png");
        this.blocks[5] = this.loadImage("gfx/Blocks/1.DarkBlue/1.2.2.png");
        this.blocks[6] = this.loadImage("gfx/Blocks/1.DarkBlue/1.2.3.png");
        this.blocks[7] = this.loadImage("gfx/Blocks/1.DarkBlue/1.2.4.png");
        this.blocks[8] = this.loadImage("gfx/Blocks/2.Yellow/2.0.0.png");
        this.blocks[9] = this.loadImage("gfx/Blocks/2.Yellow/2.0.1.png");
        this.blocks[10] = this.loadImage("gfx/Blocks/2.Yellow/2.1.1.png");
        this.blocks[11] = this.loadImage("gfx/Blocks/2.Yellow/2.1.2.png");
        this.blocks[12] = this.loadImage("gfx/Blocks/2.Yellow/2.1.3.png");
        this.blocks[13] = this.loadImage("gfx/Blocks/2.Yellow/2.1.4.png");
        this.blocks[14] = this.loadImage("gfx/Blocks/2.Yellow/2.2.1.png");
        this.blocks[15] = this.loadImage("gfx/Blocks/2.Yellow/2.2.2.png");
        this.blocks[16] = this.loadImage("gfx/Blocks/2.Yellow/2.2.3.png");
        this.blocks[17] = this.loadImage("gfx/Blocks/2.Yellow/2.2.4.png");
        this.blocks[18] = this.loadImage("gfx/Blocks/2.Yellow/2.2.5.png");
        this.blocks[19] = this.loadImage("gfx/Blocks/2.Yellow/2.2.6.png");
        this.blocks[20] = this.loadImage("gfx/Blocks/3.Murrey/3.0.0.png");
        this.blocks[21] = this.loadImage("gfx/Blocks/3.Murrey/3.0.1.png");
        this.blocks[22] = this.loadImage("gfx/Blocks/3.Murrey/3.1.1.png");
        this.blocks[23] = this.loadImage("gfx/Blocks/3.Murrey/3.1.2.png");
        this.blocks[24] = this.loadImage("gfx/Blocks/3.Murrey/3.1.3.png");
        this.blocks[25] = this.loadImage("gfx/Blocks/3.Murrey/3.1.4.png");
        this.blocks[26] = this.loadImage("gfx/Blocks/3.Murrey/3.2.1.png");
        this.blocks[27] = this.loadImage("gfx/Blocks/3.Murrey/3.2.2.png");
        this.blocks[28] = this.loadImage("gfx/Blocks/3.Murrey/3.2.3.png");
        this.blocks[29] = this.loadImage("gfx/Blocks/3.Murrey/3.2.4.png");
        this.blocks[30] = this.loadImage("gfx/Blocks/3.Murrey/3.2.5.png");
        this.blocks[31] = this.loadImage("gfx/Blocks/3.Murrey/3.2.6.png");
        this.blocks[32] = this.loadImage("gfx/Blocks/4.Orange/4.0.0.png");
        this.blocks[33] = this.loadImage("gfx/Blocks/4.Orange/4.0.1.png");
        this.blocks[34] = this.loadImage("gfx/Blocks/4.Orange/4.1.1.png");
        this.blocks[35] = this.loadImage("gfx/Blocks/4.Orange/4.1.2.png");
        this.blocks[36] = this.loadImage("gfx/Blocks/4.Orange/4.1.3.png");
        this.blocks[37] = this.loadImage("gfx/Blocks/4.Orange/4.1.4.png");
        this.blocks[38] = this.loadImage("gfx/Blocks/4.Orange/4.2.1.png");
        this.blocks[39] = this.loadImage("gfx/Blocks/4.Orange/4.2.2.png");
        this.blocks[40] = this.loadImage("gfx/Blocks/4.Orange/4.2.3.png");
        this.blocks[41] = this.loadImage("gfx/Blocks/4.Orange/4.2.4.png");
        this.blocks[42] = this.loadImage("gfx/Blocks/5.LightBlue/5.0.0.png");
        this.blocks[43] = this.loadImage("gfx/Blocks/5.LightBlue/5.0.1.png");
        this.blocks[44] = this.loadImage("gfx/Blocks/5.LightBlue/5.1.1.png");
        this.blocks[45] = this.loadImage("gfx/Blocks/5.LightBlue/5.1.2.png");
        this.blocks[46] = this.loadImage("gfx/Blocks/5.LightBlue/5.1.3.png");
        this.blocks[47] = this.loadImage("gfx/Blocks/5.LightBlue/5.1.4.png");
        this.blocks[48] = this.loadImage("gfx/Blocks/5.LightBlue/5.2.1.png");
        this.blocks[49] = this.loadImage("gfx/Blocks/5.LightBlue/5.2.2.png");
        this.blocks[50] = this.loadImage("gfx/Blocks/5.LightBlue/5.2.3.png");
        this.blocks[51] = this.loadImage("gfx/Blocks/5.LightBlue/5.2.4.png");
        this.blocks[52] = this.loadImage("gfx/Blocks/6.Green/6.0.0.png");
        this.blocks[53] = this.loadImage("gfx/Blocks/6.Green/6.0.1.png");
        this.blocks[54] = this.loadImage("gfx/Blocks/6.Green/6.1.1.png");
        this.blocks[55] = this.loadImage("gfx/Blocks/6.Green/6.1.2.png");
        this.blocks[56] = this.loadImage("gfx/Blocks/6.Green/6.1.3.png");
        this.blocks[57] = this.loadImage("gfx/Blocks/6.Green/6.1.4.png");
        this.blocks[58] = this.loadImage("gfx/Blocks/6.Green/6.2.1.png");
        this.blocks[59] = this.loadImage("gfx/Blocks/6.Green/6.2.2.png");
        this.blocks[60] = this.loadImage("gfx/Blocks/6.Green/6.2.3.png");
        this.blocks[73] = this.loadImage("gfx/Blocks/6.Green/6.2.4.png");
        this.blocks[74] = this.loadImage("gfx/Blocks/6.Green/6.2.5.png");
        this.blocks[61] = this.loadImage("gfx/Blocks/6.Green/6.3.1.png");
        this.blocks[62] = this.loadImage("gfx/Blocks/6.Green/6.3.2.png");
        this.blocks[63] = this.loadImage("gfx/Blocks/6.Green/6.3.3.png");
        this.blocks[64] = this.loadImage("gfx/Blocks/6.Green/6.3.4.png");
        this.blocks[65] = this.loadImage("gfx/Blocks/7.Red/7.0.0.png");
        this.blocks[66] = this.loadImage("gfx/Blocks/7.Red/7.0.1.png");
        this.blocks[67] = this.loadImage("gfx/Blocks/7.Red/7.1.1.png");
        this.blocks[68] = this.loadImage("gfx/Blocks/7.Red/7.1.2.png");
        this.blocks[69] = this.loadImage("gfx/Blocks/7.Red/7.1.3.png");
        this.blocks[70] = this.loadImage("gfx/Blocks/7.Red/7.1.4.png");
        this.blocks[71] = this.loadImage("gfx/Blocks/7.Red/7.2.1.png");
        this.blocks[72] = this.loadImage("gfx/Blocks/7.Red/7.2.2.png");
    }

    /**
     * Loads the backgrounds textures of the game.
     */
    private void loadBackgrounds() {
        this.backgrounds = new Image[4];
        this.backgrounds[0] = this.loadImage("gfx/Background/Intro.png");
        this.backgrounds[1] = this.loadImage("gfx/Background/Menu.png");
        this.backgrounds[2] = this.loadImage("gfx/Background/Game.png");
        this.backgrounds[3] = this.loadImage("gfx/Background/SubMenu.png");
    }

    /**
     * Loads the items textures of the game.
     */
    private void loadItems() {
        this.items = new Image[2];
        this.items[0] = this.loadImage("gfx/Blocks/LeftArrow.png");
        this.items[1] = this.loadImage("gfx/Blocks/RightArrow.png");
    }

    /**
     * Loads the fonts of the game.
     */
    private void loadFonts() {
        Image data = this.loadImage("gfx/Font/SystemFont10.png");
        this.systemFont = new SystemFont10(data);
        this.systemFont.setScale(2);
    }

    /**
     * Loads the scores of the game.
     */
    private void loadScores() {
        this.scores = new ScoreList();
        String aux = this.app.readCookie("com.gorkasuarez.tetris");
        if(aux != null)
            this.scores.fromString(aux);
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The intro background image ID. */
    static public final int IntroBackground = 0;
    /** The menu background image ID. */
    static public final int MenuBackground = 1;
    /** The game background image ID. */
    static public final int GameBackground = 2;
    /** The submenu background image ID. */
    static public final int SubMenuBackground = 3;

    /** The left arrow image ID. */
    static public final int LeftArrowItem = 0;
    /** The right arrow image ID. */
    static public final int RightArrowItem = 1;

    /** The left arrow image ID. */
    static public final int BlockWidth = 32;
    /** The right arrow image ID. */
    static public final int BlockHeight = 32;

    /** The instance of this class. */
    static private Data instance = null;

    /**
     * Gets the instance of this class.
     * @return The instance of this class.
     */
    static public Data getInstance() {
        if(instance == null) {
            instance = new Data();
        }
        return instance;
    }
}