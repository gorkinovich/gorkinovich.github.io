/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris;

import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.MidiSystem;

public class Music implements Runnable {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The midi sequencer. */
    private Sequencer sequencer;

    /** The sounds of the game. */
    private Sequence[] sounds;

    /** The current sound playing. */
    private int currentSound;

    /** Tells if the music is enable or not. */
    private boolean musicEnable;

    /** Tells thread ends or not. */
    private boolean exit;

    /** The sound thread. */
    private Thread soundThread;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a Music object.
     */
    public Music() {
        this.sequencer = null;
        this.sounds = null;
        this.currentSound = -1;
        this.musicEnable = false;
        this.exit = false;
        this.soundThread = null;
    }

    /**
     * Initializes the object data.
     */
    public final void initialize() {
        try {
            this.sequencer = MidiSystem.getSequencer();
            this.sequencer.open();
            this.musicEnable = true;

            this.sounds = new Sequence[3];
            this.sounds[0] = this.loadSound("/snd/Mozart.448.1.mid");
            this.sounds[1] = this.loadSound("/snd/Mozart.448.2.mid");
            this.sounds[2] = this.loadSound("/snd/Mozart.448.3.mid");
            this.setCurrentSound(0);

            this.exit = false;
            this.soundThread = new Thread(this);

        } catch(Exception e) {
            this.sequencer = null;
            this.sounds = null;
            this.currentSound = -1;
            this.musicEnable = false;
            this.exit = true;
            this.soundThread = null;
        }
    }

    /**
     * Releases the object data.
     */
    public final void release() {
        this.musicEnable = false;
        this.soundThread.interrupt();
        this.exit = true;
        this.stop();
        this.sequencer = null;
        this.sounds = null;
        this.currentSound = -1;
        this.soundThread = null;
    }

    /**
     * Starts to play the music.
     */
    public final void start() {
        this.play();
        this.soundThread.start();
    }

    /**
     * Sets the current sound.
     * @param value The index of the sound.
     * @throws Exception
     */
    public final void setCurrentSound(int value) {
        if(0 <= value && value <= 2) {
            this.currentSound = value;
        } else {
            this.currentSound = 0;
        }
        try {
            this.sequencer.setSequence(this.sounds[this.currentSound]);
        } catch(Exception e) {
            this.currentSound = -1;
        }
    }

    /**
     * Plays the current sound.
     */
    public final void play() {
        try {
            this.sequencer.start();
            this.sequencer.setLoopCount(0);
        } catch(Exception e) {
            this.musicEnable = false;
        }
    }

    /**
     * Stops the current sound.
     */
    public final void stop() {
        try {
            this.sequencer.stop();
        } catch(Exception e) {
        }
    }

    /**
     * Gets if the music is enable or not.
     * @return True if the music is enable or not.
     */
    public final boolean isMusicEnable() {
        return this.musicEnable;
    }

    /**
     * Sets if the music is enable or not.
     * @param value The new value to set.
     */
    public final void setMusicEnable(boolean value) {
        this.musicEnable = value;
        if(this.musicEnable) {
            this.play();
        } else {
            this.stop();
        }
    }

    /**
     * Sets the next track of the music.
     */
    private final void setNextTrack() {
        if(this.musicEnable) {
            int aux = (this.currentSound + 1) % 3;
            this.setCurrentSound(aux);
            this.play();
        }
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    public void run() {
        while(!this.exit) {
            try {
                if(!this.sequencer.isRunning()) {
                    this.setNextTrack();
                }
                Thread.sleep(1000);
            } catch(InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    //********************************************************************************
    // Private methods
    //********************************************************************************

    /**
     * Loads a sound of the game.
     * @param path The path of the sound.
     * @return The sound object.
     */
    private final Sequence loadSound(String path) {
        Sequence aux = null;
        try {
            aux = MidiSystem.getSequence(this.getClass().getResourceAsStream(path));
        } catch(Exception e) {
            System.out.println("Unable to load file: " + path);
            System.out.println(e.getMessage());
            System.out.println();
        }
        return aux;
    }
}