/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris.state;

import com.gorkasuarez.jagl.Font;
import com.gorkasuarez.jagl.IGame;
import com.gorkasuarez.jagl.GameApp;
import com.gorkasuarez.tetris.Data;
import com.gorkasuarez.tetris.States;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.Random;

/**
 * This GameState class represents the internal logic of the game state.
 * @author Gorka Suárez
 */
public class GameState implements IGame {
    //********************************************************************************
    // Types
    //********************************************************************************

    /**
     * This enumeration represents the types of pieces in the game.
     */
    private enum PieceType {
        DarkBlue, Yellow, Murrey, Orange, LightBlue, Green, Red
    }

    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The game application. */
    private GameApp app;

    /** The general data of the game. */
    private Data data;

    /** The background image. */
    private Image background;

    /** The main font of the game. */
    private Font systemFont;

    /** The key pressed controller flag. */
    private boolean keyPressed;

    /** The special key pressed controller flag. */
    private boolean specialKeyPressed;

    /** The key pressed time mark. */
    private long keyTimeMark;

    /** The time controller. */
    private long time;

    /** The time mark. */
    private long timeMark;

    /** The maximum interval of time until move a block. */
    private long maxInterval;

    /** The current level. */
    private int level;

    /** The number of lines. */
    private int lines;

    /** The number of points. */
    private int points;

    /** The target number of lines to get to the next level. */
    private int target;

    /** The game "world". */
    private int[][] world;

    /** The next piece in the game. */
    private PieceType nextPiece;

    /** The current piece in the game. */
    private PieceType piece;

    /** The x-coordinate of the current piece. */
    private int pieceX;

    /** The y-coordinate of the current piece. */
    private int pieceY;

    /** The orientation of the current piece. */
    private int pieceOrientation;

    /** The random numbers generator. */
    private Random random;

    /** Tells if the game have end. */
    private boolean gameOver;

    /** Tells if the game is paused. */
    private boolean gamePaused;

    //********************************************************************************
    // Private methods
    //********************************************************************************

    /**
     * Initializes the game's world.
     */
    private final void initWorld() {
        int i, j;
        for(i = 0; i < GameState.worldHeight; i++) {
            for(j = 0; j < GameState.worldWidth; j++) {
                this.world[i][j] = GameState.empty;
            }
        }
    }

    /**
     * Renders the game's world.
     * @param g The specified Graphics window.
     */
    private final void renderWorld(Graphics g) {
        int i, j;
        for(i = 0; i < GameState.worldHeight; i++) {
            for(j = 0; j < GameState.worldWidth; j++) {
                if(this.world[i][j] != GameState.empty) {
                    g.drawImage(this.data.getBlock(this.world[i][j]),
                                j * Data.BlockWidth + worldStartX, i * Data.BlockHeight,
                                Data.BlockWidth, Data.BlockHeight, this.app);
                }
            }
        }
    }

    /**
     * Selects the next piece in the game.
     */
    private final void selectNextPiece() {
        switch(this.random.nextInt(7)) {
        case 0: this.nextPiece = PieceType.DarkBlue; break;
        case 1: this.nextPiece = PieceType.Yellow; break;
        case 2: this.nextPiece = PieceType.Murrey; break;
        case 3: this.nextPiece = PieceType.Orange; break;
        case 4: this.nextPiece = PieceType.LightBlue; break;
        case 5: this.nextPiece = PieceType.Green; break;
        case 6: this.nextPiece = PieceType.Red; break;
        }
    }

    /**
     * Renders the next piece.
     * @param g The specified Graphics window.
     */
    private final void renderNextPiece(Graphics g) {
        final int marginX1 = 382;
        final int marginY1 = 92;
        final int marginY2 = 76;
        final int marginX3 = 398;
        final int marginY3 = 60;

        switch(this.nextPiece) {
        case DarkBlue:
            g.drawImage(this.data.getBlock(0), marginX1, marginY1,
                        Data.BlockWidth * 2, Data.BlockHeight * 2, this.app);
            break;

        case Yellow:
            g.drawImage(this.data.getBlock(8), marginX1, marginY2,
                        Data.BlockWidth * 2, Data.BlockHeight * 3, this.app);
            break;

        case Murrey:
            g.drawImage(this.data.getBlock(20), marginX1, marginY2,
                        Data.BlockWidth * 2, Data.BlockHeight * 3, this.app);
            break;

        case Orange:
            g.drawImage(this.data.getBlock(32), marginX1, marginY2,
                        Data.BlockWidth * 2, Data.BlockHeight * 3, this.app);
            break;

        case LightBlue:
            g.drawImage(this.data.getBlock(42), marginX1, marginY2,
                        Data.BlockWidth * 2, Data.BlockHeight * 3, this.app);
            break;

        case Green:
            g.drawImage(this.data.getBlock(52), marginX1, marginY2,
                        Data.BlockWidth * 2, Data.BlockHeight * 3, this.app);
            break;

        case Red:
            g.drawImage(this.data.getBlock(65), marginX3, marginY3,
                        Data.BlockWidth, Data.BlockHeight * 4, this.app);
            break;
        }
    }

    /**
     * Gets the next piece.
     */
    private final void getNextPiece() {
        this.piece = this.nextPiece;

        switch(this.piece) {
        case DarkBlue:
            this.pieceX = 4;
            this.pieceY = 1;
            this.pieceOrientation = 1;
            break;

        case Yellow:
            this.pieceX = 4;
            this.pieceY = 1;
            this.pieceOrientation = 2;
            break;

        case Murrey:
            this.pieceX = 4;
            this.pieceY = 1;
            this.pieceOrientation = 4;
            break;

        case Orange:
            this.pieceX = 4;
            this.pieceY = 0;
            this.pieceOrientation = 2;
            break;

        case LightBlue:
            this.pieceX = 4;
            this.pieceY = 0;
            this.pieceOrientation = 2;
            break;

        case Green:
            this.pieceX = 4;
            this.pieceY = 1;
            this.pieceOrientation = 4;
            break;

        case Red:
            this.pieceX = 5;
            this.pieceY = 1;
            this.pieceOrientation = 2;
            break;
        }

        this.selectNextPiece();

        if(this.checkCollision()) {
            this.gameOver = true;
        }
    }

    /**
     * Renders the piece.
     * @param g The specified Graphics window.
     */
    private final void renderPiece(Graphics g) {
        switch(this.piece) {
        case DarkBlue:
            g.drawImage(this.data.getBlock(4),
                        this.pieceX * Data.BlockWidth + GameState.worldStartX,
                        (this.pieceY - 1) * Data.BlockHeight,
                        Data.BlockWidth, Data.BlockHeight, this.app);
            g.drawImage(this.data.getBlock(5),
                        (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                        (this.pieceY - 1) * Data.BlockHeight,
                        Data.BlockWidth, Data.BlockHeight, this.app);
            g.drawImage(this.data.getBlock(6),
                        this.pieceX * Data.BlockWidth + GameState.worldStartX,
                        this.pieceY * Data.BlockHeight,
                        Data.BlockWidth, Data.BlockHeight, this.app);
            g.drawImage(this.data.getBlock(7),
                        (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                        this.pieceY * Data.BlockHeight,
                        Data.BlockWidth, Data.BlockHeight, this.app);
            break;

        case Yellow:
            switch(this.pieceOrientation) {
            case 1:
                g.drawImage(this.data.getBlock(10),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(18),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(17),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(12),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 2:
                g.drawImage(this.data.getBlock(13),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(19),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(16),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(10),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 3:
                g.drawImage(this.data.getBlock(11),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(18),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(14),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(13),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 4:
                g.drawImage(this.data.getBlock(12),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(19),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(15),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(11),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            }
            break;

        case Murrey:
            switch(this.pieceOrientation) {
            case 1:
                g.drawImage(this.data.getBlock(22),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(30),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(28),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(25),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 2:
                g.drawImage(this.data.getBlock(25),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(31),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(26),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(23),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 3:
                g.drawImage(this.data.getBlock(23),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(30),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(27),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(24),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 4:
                g.drawImage(this.data.getBlock(24),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(31),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(29),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(22),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            }
            break;

        case Orange:
            switch(this.pieceOrientation) {
            case 1:
                g.drawImage(this.data.getBlock(34),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(41),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(38),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(35),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 2:
                g.drawImage(this.data.getBlock(37),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(40),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(39),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(36),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            }
            break;

        case LightBlue:
            switch(this.pieceOrientation) {
            case 1:
                g.drawImage(this.data.getBlock(45),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(49),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(50),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(44),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 2:
                g.drawImage(this.data.getBlock(46),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(51),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(48),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(47),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            }
            break;

        case Green:
            switch(this.pieceOrientation) {
            case 1:
                g.drawImage(this.data.getBlock(54),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(61),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(55),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(57),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 2:
                g.drawImage(this.data.getBlock(56),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(62),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(57),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(55),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 3:
                g.drawImage(this.data.getBlock(54),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(63),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(55),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(56),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 4:
                g.drawImage(this.data.getBlock(56),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(64),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(57),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(54),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            }
            break;

        case Red:
            switch(this.pieceOrientation) {
            case 1:
                g.drawImage(this.data.getBlock(67),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY - 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(71),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(71),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 1) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(68),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            (this.pieceY + 2) * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            case 2:
                g.drawImage(this.data.getBlock(69),
                            (this.pieceX - 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(72),
                            this.pieceX * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(72),
                            (this.pieceX + 1) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                g.drawImage(this.data.getBlock(70),
                            (this.pieceX + 2) * Data.BlockWidth + GameState.worldStartX,
                            this.pieceY * Data.BlockHeight,
                            Data.BlockWidth, Data.BlockHeight, this.app);
                break;
            }
            break;
        }
    }

    /**
     * Checks if the current cell collides with something.
     * @param x The x-coordinate of the cell.
     * @param y The y-coordinate of the cell.
     * @return True if there is a collision.
     */
    private final boolean checkCollision(int x, int y) {
        return (x < 0) || (x >= GameState.worldWidth) ||
               (y < 0) || (y >= GameState.worldHeight) ||
               (this.world[y][x] != GameState.empty);
    }

    /**
     * Checks if the current piece collides with something.
     * @return True if there is a collision.
     */
    private final boolean checkCollision() {
        switch(this.piece) {
        case DarkBlue:
            return checkCollision(this.pieceX, this.pieceY - 1) ||
                   checkCollision(this.pieceX + 1, this.pieceY - 1) ||
                   checkCollision(this.pieceX, this.pieceY) ||
                   checkCollision(this.pieceX + 1, this.pieceY);

        case Yellow:
            switch(this.pieceOrientation) {
            case 1:
                return checkCollision(this.pieceX, this.pieceY - 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX - 1, this.pieceY + 1);

            case 2:
                return checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX - 1, this.pieceY) ||
                       checkCollision(this.pieceX - 1, this.pieceY - 1);

            case 3:
                return checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY - 1) ||
                       checkCollision(this.pieceX + 1, this.pieceY - 1);

            case 4:
                return checkCollision(this.pieceX - 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY + 1);
            }
            break;

        case Murrey:
            switch(this.pieceOrientation) {
            case 1:
                return checkCollision(this.pieceX, this.pieceY - 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX + 1, this.pieceY + 1);

            case 2:
                return checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX - 1, this.pieceY) ||
                       checkCollision(this.pieceX - 1, this.pieceY + 1);

            case 3:
                return checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY - 1) ||
                       checkCollision(this.pieceX - 1, this.pieceY - 1);

            case 4:
                return checkCollision(this.pieceX - 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY - 1);
            }
            break;

        case Orange:
            switch(this.pieceOrientation) {
            case 1:
                return checkCollision(this.pieceX + 1, this.pieceY - 1) ||
                       checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY + 1);

            case 2:
                return checkCollision(this.pieceX + 1, this.pieceY + 1) ||
                       checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX - 1, this.pieceY);
            }
            break;

        case LightBlue:
            switch(this.pieceOrientation) {
            case 1:
                return checkCollision(this.pieceX + 1, this.pieceY + 1) ||
                       checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY - 1);

            case 2:
                return checkCollision(this.pieceX - 1, this.pieceY + 1) ||
                       checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY);
            }
            break;

        case Green:
            switch(this.pieceOrientation) {
            case 1:
                return checkCollision(this.pieceX, this.pieceY - 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX + 1, this.pieceY);

            case 2:
                return checkCollision(this.pieceX - 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY + 1);

            case 3:
                return checkCollision(this.pieceX, this.pieceY - 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX - 1, this.pieceY);

            case 4:
                return checkCollision(this.pieceX - 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY - 1);
            }
            break;

        case Red:
            switch(this.pieceOrientation) {
            case 1:
                return checkCollision(this.pieceX, this.pieceY - 1) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY + 1) ||
                       checkCollision(this.pieceX, this.pieceY + 2);

            case 2:
                return checkCollision(this.pieceX - 1, this.pieceY) ||
                       checkCollision(this.pieceX, this.pieceY) ||
                       checkCollision(this.pieceX + 1, this.pieceY) ||
                       checkCollision(this.pieceX + 2, this.pieceY);
            }
        }

        return false;
    }

    /**
     * Turns the current piece to the right.
     */
    private final void turnRight() {
        if(this.piece != PieceType.DarkBlue) {
            int aux = this.pieceOrientation;
            this.pieceOrientation++;

            switch(this.piece) {
            case Yellow:
                if(this.pieceOrientation > 4) this.pieceOrientation = 1;
                break;

            case Murrey:
                if(this.pieceOrientation > 4) this.pieceOrientation = 1;
                break;

            case Orange:
                if(this.pieceOrientation > 2) this.pieceOrientation = 1;
                break;

            case LightBlue:
                if(this.pieceOrientation > 2) this.pieceOrientation = 1;
                break;

            case Green:
                if(this.pieceOrientation > 4) this.pieceOrientation = 1;
                break;

            case Red:
                if(this.pieceOrientation > 2) this.pieceOrientation = 1;
                break;
            }

            if(this.checkCollision()) {
                this.pieceOrientation = aux;
            }
        }
    }

    /**
     * Turns the current piece to the left.
     */
    private final void turnLeft() {
        if(this.piece != PieceType.DarkBlue) {
            int aux = this.pieceOrientation;
            this.pieceOrientation--;

            switch(this.piece) {
            case Yellow:
                if(this.pieceOrientation < 1) this.pieceOrientation = 4;
                break;

            case Murrey:
                if(this.pieceOrientation < 1) this.pieceOrientation = 4;
                break;

            case Orange:
                if(this.pieceOrientation < 1) this.pieceOrientation = 2;
                break;

            case LightBlue:
                if(this.pieceOrientation < 1) this.pieceOrientation = 2;
                break;

            case Green:
                if(this.pieceOrientation < 1) this.pieceOrientation = 4;
                break;

            case Red:
                if(this.pieceOrientation < 1) this.pieceOrientation = 2;
                break;
            }

            if(this.checkCollision()) {
                this.pieceOrientation = aux;
            }
        }
    }

    /**
     * Moves the current piece to the right.
     */
    private final void moveRight() {
        int aux = this.pieceX;
        this.pieceX++;

        if(this.checkCollision()) {
            this.pieceX = aux;
        }
    }

    /**
     * Moves the current piece to the left.
     */
    private final void moveLeft() {
        int aux = this.pieceX;
        this.pieceX--;

        if(this.checkCollision()) {
            this.pieceX = aux;
        }
    }

    /**
     * Puts the current piece inside the world.
     */
    private final void putPieceIntoWorld() {
        switch(this.piece) {
        case DarkBlue:
            this.world[this.pieceY - 1][this.pieceX] = 4;
            this.world[this.pieceY - 1][this.pieceX + 1] = 5;
            this.world[this.pieceY][this.pieceX] = 6;
            this.world[this.pieceY][this.pieceX + 1] = 7;
            break;

        case Yellow:
            switch(this.pieceOrientation) {
            case 1:
                this.world[this.pieceY - 1][this.pieceX] = 10;
                this.world[this.pieceY][this.pieceX] = 18;
                this.world[this.pieceY + 1][this.pieceX] = 17;
                this.world[this.pieceY + 1][this.pieceX - 1] = 12;
                break;
            case 2:
                this.world[this.pieceY][this.pieceX + 1] = 13;
                this.world[this.pieceY][this.pieceX] = 19;
                this.world[this.pieceY][this.pieceX - 1] = 16;
                this.world[this.pieceY - 1][this.pieceX - 1] = 10;
                break;
            case 3:
                this.world[this.pieceY + 1][this.pieceX] = 11;
                this.world[this.pieceY][this.pieceX] = 18;
                this.world[this.pieceY - 1][this.pieceX] = 14;
                this.world[this.pieceY - 1][this.pieceX + 1] = 13;
                break;
            case 4:
                this.world[this.pieceY][this.pieceX - 1] = 12;
                this.world[this.pieceY][this.pieceX] = 19;
                this.world[this.pieceY][this.pieceX + 1] = 15;
                this.world[this.pieceY + 1][this.pieceX + 1] = 11;
                break;
            }
            break;

        case Murrey:
            switch(this.pieceOrientation) {
            case 1:
                this.world[this.pieceY - 1][this.pieceX] = 22;
                this.world[this.pieceY][this.pieceX] = 30;
                this.world[this.pieceY + 1][this.pieceX] = 28;
                this.world[this.pieceY + 1][this.pieceX + 1] = 25;
                break;
            case 2:
                this.world[this.pieceY][this.pieceX + 1] = 25;
                this.world[this.pieceY][this.pieceX] = 31;
                this.world[this.pieceY][this.pieceX - 1] = 26;
                this.world[this.pieceY + 1][this.pieceX - 1] = 23;
                break;
            case 3:
                this.world[this.pieceY + 1][this.pieceX] = 23;
                this.world[this.pieceY][this.pieceX] = 30;
                this.world[this.pieceY - 1][this.pieceX] = 27;
                this.world[this.pieceY - 1][this.pieceX - 1] = 24;
                break;
            case 4:
                this.world[this.pieceY][this.pieceX - 1] = 24;
                this.world[this.pieceY][this.pieceX] = 31;
                this.world[this.pieceY][this.pieceX + 1] = 29;
                this.world[this.pieceY - 1][this.pieceX + 1] = 22;
                break;
            }
            break;

        case Orange:
            switch(this.pieceOrientation) {
            case 1:
                this.world[this.pieceY - 1][this.pieceX + 1] = 34;
                this.world[this.pieceY][this.pieceX + 1] = 41;
                this.world[this.pieceY][this.pieceX] = 38;
                this.world[this.pieceY + 1][this.pieceX] = 35;
                break;
            case 2:
                this.world[this.pieceY + 1][this.pieceX + 1] = 37;
                this.world[this.pieceY + 1][this.pieceX] = 40;
                this.world[this.pieceY][this.pieceX] = 39;
                this.world[this.pieceY][this.pieceX - 1] = 36;
                break;
            }
            break;

        case LightBlue:
            switch(this.pieceOrientation) {
            case 1:
                this.world[this.pieceY + 1][this.pieceX + 1] = 45;
                this.world[this.pieceY][this.pieceX + 1] = 49;
                this.world[this.pieceY][this.pieceX] = 50;
                this.world[this.pieceY - 1][this.pieceX] = 44;
                break;
            case 2:
                this.world[this.pieceY + 1][this.pieceX - 1] = 46;
                this.world[this.pieceY + 1][this.pieceX] = 51;
                this.world[this.pieceY][this.pieceX] = 48;
                this.world[this.pieceY][this.pieceX + 1] = 47;
                break;
            }
            break;

        case Green:
            switch(this.pieceOrientation) {
            case 1:
                this.world[this.pieceY - 1][this.pieceX] = 54;
                this.world[this.pieceY][this.pieceX] = 61;
                this.world[this.pieceY + 1][this.pieceX] = 55;
                this.world[this.pieceY][this.pieceX + 1] = 57;
                break;
            case 2:
                this.world[this.pieceY][this.pieceX - 1] = 56;
                this.world[this.pieceY][this.pieceX] = 62;
                this.world[this.pieceY][this.pieceX + 1] = 57;
                this.world[this.pieceY + 1][this.pieceX] = 55;
                break;
            case 3:
                this.world[this.pieceY - 1][this.pieceX] = 54;
                this.world[this.pieceY][this.pieceX] = 63;
                this.world[this.pieceY + 1][this.pieceX] = 55;
                this.world[this.pieceY][this.pieceX - 1] = 56;
                break;
            case 4:
                this.world[this.pieceY][this.pieceX - 1] = 56;
                this.world[this.pieceY][this.pieceX] = 64;
                this.world[this.pieceY][this.pieceX + 1] = 57;
                this.world[this.pieceY - 1][this.pieceX] = 54;
                break;
            }
            break;

        case Red:
            switch(this.pieceOrientation) {
            case 1:
                this.world[this.pieceY - 1][this.pieceX] = 67;
                this.world[this.pieceY][this.pieceX] = 71;
                this.world[this.pieceY + 1][this.pieceX] = 71;
                this.world[this.pieceY + 2][this.pieceX] = 68;
                break;
            case 2:
                this.world[this.pieceY][this.pieceX - 1] = 69;
                this.world[this.pieceY][this.pieceX] = 72;
                this.world[this.pieceY][this.pieceX + 1] = 72;
                this.world[this.pieceY][this.pieceX + 2] = 70;
                break;
            }
            break;
        }
    }

    /**
     * Checks if a line have been made.
     * @param line The line we want to check.
     * @return True if the line have been made.
     */
    private final boolean checkLine(int line) {
        for(int i = 0; i < GameState.worldWidth; i++) {
            if(this.world[line][i] == GameState.empty)
                return false;
        }
        return true;
    }

    /**
     * Checks the upper cell to a given one.
     * @param i The y-coordinate of the cell.
     * @param j The x-coordinate of the cell.
     */
    private final void checkUpperCell(int i, int j) {
        switch(this.world[i - 1][j]) {
        //DarkBlue
        case 4: this.world[i - 1][j] = 2; break;
        case 5: this.world[i - 1][j] = 3; break;

        //Yellow
        case 10: this.world[i - 1][j] = 9; break;
        case 14: this.world[i - 1][j] = 12; break;
        case 15: this.world[i - 1][j] = 13; break;
        case 18: this.world[i - 1][j] = 11; break;

        //Murrey
        case 22: this.world[i - 1][j] = 21; break;
        case 26: this.world[i - 1][j] = 24; break;
        case 27: this.world[i - 1][j] = 25; break;
        case 30: this.world[i - 1][j] = 23; break;

        //Orange
        case 34: this.world[i - 1][j] = 33; break;
        case 38: this.world[i - 1][j] = 36; break;
        case 39: this.world[i - 1][j] = 37; break;

        //LightBlue
        case 44: this.world[i - 1][j] = 43; break;
        case 48: this.world[i - 1][j] = 46; break;
        case 49: this.world[i - 1][j] = 47; break;

        //Green
        case 54: this.world[i - 1][j] = 53; break;
        case 61: this.world[i - 1][j] = 58; break;
        case 62: this.world[i - 1][j] = 60; break;
        case 63: this.world[i - 1][j] = 59; break;
        case 73: this.world[i - 1][j] = 56; break;
        case 74: this.world[i - 1][j] = 57; break;

        //Red
        case 67: this.world[i - 1][j] = 66; break;
        case 71: this.world[i - 1][j] = 68; break;
        }
    }

    /**
     * Checks the bottom cell to a given one.
     * @param i The y-coordinate of the cell.
     * @param j The x-coordinate of the cell.
     */
    private final void checkBottomCell(int i, int j) {
        switch(this.world[i + 1][j]) {
        //DarkBlue
        case 6: this.world[i + 1][j] = 2; break;
        case 7: this.world[i + 1][j] = 3; break;

        //Yellow
        case 11: this.world[i + 1][j] = 9; break;
        case 16: this.world[i + 1][j] = 12; break;
        case 17: this.world[i + 1][j] = 13; break;
        case 18: this.world[i + 1][j] = 10; break;

        //Murrey
        case 23: this.world[i + 1][j] = 21; break;
        case 28: this.world[i + 1][j] = 24; break;
        case 29: this.world[i + 1][j] = 25; break;
        case 30: this.world[i + 1][j] = 22; break;

        //Orange
        case 35: this.world[i + 1][j] = 33; break;
        case 40: this.world[i + 1][j] = 36; break;
        case 41: this.world[i + 1][j] = 37; break;

        //LightBlue
        case 45: this.world[i + 1][j] = 43; break;
        case 50: this.world[i + 1][j] = 46; break;
        case 51: this.world[i + 1][j] = 47; break;

        //Green
        case 55: this.world[i + 1][j] = 53; break;
        case 58: this.world[i + 1][j] = 56; break;
        case 59: this.world[i + 1][j] = 57; break;
        case 61: this.world[i + 1][j] = 73; break;
        case 63: this.world[i + 1][j] = 74; break;
        case 64: this.world[i + 1][j] = 60; break;

        //Red
        case 68: this.world[i + 1][j] = 66; break;
        case 71: this.world[i + 1][j] = 67; break;
        }
    }

    /**
     * Erases a line of the world.
     * @param line The line we want to erase.
     */
    private final void eraseLine(int line) {
        int i, j;

        if(line < 1) {
            for(i = 0; i < GameState.worldWidth; i++) {
                this.checkBottomCell(line, i);
            }
        } else if(line > 18) {
            for(i = 0; i < GameState.worldWidth; i++) {
                this.checkUpperCell(line, i);
            }
        } else {
            for(i = 0; i < GameState.worldWidth; i++) {
                this.checkUpperCell(line, i);
                this.checkBottomCell(line, i);
            }
        }

        for(i = line; i > 0; i--) {
            for(j = 0; j < GameState.worldWidth; j++) {
                this.world[i][j] = this.world[i - 1][j];
            }
        }

        for(j = 0; j < GameState.worldWidth; j++) {
            this.world[0][j] = GameState.empty;
        }
    }

    /**
     * Checks if the player have made some lines.
     */
    private final void checkLines() {
        int numLinesErased = 0;
        int accumPoints = 0;

        for(int i = 0; i < GameState.worldHeight; i++) {
            if(this.checkLine(i)) {
                this.eraseLine(i);
                numLinesErased++;
                accumPoints += GameState.linePoints[this.level - 1];
            }
        }

        if(numLinesErased >= 4) {
            accumPoints *= 2;
        }

        this.lines += numLinesErased;
        this.points += accumPoints;

        if(this.lines > this.target) {
            this.level++;
            this.maxInterval = GameState.maxIntervals[this.level - 1];
            this.target += GameState.maxLines[this.level - 1];
        }
    }

    /**
     * Moves down the current piece.
     */
    private final void moveDown() {
        int aux = this.pieceY;
        this.pieceY++;

        if(this.checkCollision()) {
            this.pieceY = aux;
            this.putPieceIntoWorld();
            this.checkLines();
            this.getNextPiece();
        }
    }

    /**
     * Moves the current piece to the bottom.
     */
    private final void fallDown() {
        int aux;
        do{
            aux = this.pieceY;
            this.pieceY++;
        } while(!this.checkCollision());

        this.pieceY = aux;
        this.putPieceIntoWorld();
        this.checkLines();
        this.getNextPiece();
    }

    /**
     * Exits the game state.
     */
    private final void exitGameState() {
        States.getInstance().getSetScoreState().setPoints(this.points);
        this.app.setState(States.getInstance().getSetScoreState());
    }

    /**
     * Sets to true the key pressed controller.
     */
    private final void setKeyPressed() {
        this.keyPressed = true;
        this.keyTimeMark = System.currentTimeMillis();
    }

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a GameState object.
     * @param value The game application.
     */
    public GameState(GameApp value) {
        this.app = value;
        this.background = null;
        this.systemFont = null;
        this.level = 1;
        this.world = new int[GameState.worldHeight][GameState.worldWidth];
        this.random = new Random();
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#initialize()
     */
    public final void initialize() {
        this.data = Data.getInstance();
        this.background = this.data.getBackgrounds(Data.GameBackground);
        this.systemFont = this.data.getSystemFont();
        this.setKeyPressed();
        this.time = 0;
        this.timeMark = System.currentTimeMillis();
        this.maxInterval = GameState.maxIntervals[this.level - 1];
        this.lines = 0;
        this.points = 0;
        this.target = GameState.maxLines[this.level - 1];
        this.initWorld();
        this.selectNextPiece();
        this.getNextPiece();
        this.gameOver = false;
        this.gamePaused = false;
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#release()
     */
    public final void release() {
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#render(java.awt.Graphics)
     */
    public final void render(Graphics g) {
        g.drawImage(this.background, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);

        this.systemFont.drawLineWithScale(390, 350, String.valueOf(this.level), g, this.app);
        this.systemFont.drawLineWithScale(366, 450, String.valueOf(this.lines), g, this.app);
        this.systemFont.drawLineWithScale(360, 550, String.valueOf(this.points), g, this.app);

        if(this.gameOver) {
            this.systemFont.drawLineWithScale(119, 300, "Game Over", g, this.app);
        } else {
            this.renderWorld(g);
            this.renderPiece(g);
            this.renderNextPiece(g);
            if(this.gamePaused) {
                this.systemFont.drawLineWithScale(380, 220, "Game", g, this.app);
                this.systemFont.drawLineWithScale(370, 252, "Paused", g, this.app);
            }
        }
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#logic()
     */
    public final void logic() {
        if(this.gameOver) {
            if(!this.keyPressed) {
                if(this.app.isAnyKeyPressed()) {
                    this.exitGameState();
                }
            } else if(!this.app.isAnyKeyPressed()) {
                this.keyPressed = false;
            }

        } else {
            if(!this.gamePaused) {
                this.time += (System.currentTimeMillis() - this.timeMark);
                this.timeMark = System.currentTimeMillis();

                if(!this.keyPressed) {
                    if(this.app.getKey(KeyEvent.VK_LEFT)) {
                        this.moveLeft();
                        this.setKeyPressed();
                    } else if(this.app.getKey(KeyEvent.VK_RIGHT)) {
                        this.moveRight();
                        this.setKeyPressed();
                    }

                    if(this.app.getKey(KeyEvent.VK_DOWN)) {
                        this.moveDown();
                        this.setKeyPressed();
                    }
                } else if(!this.app.isAnyKeyPressed() ||
                          ((System.currentTimeMillis() - this.keyTimeMark) > GameState.maxKeyInterval)) {
                    this.keyPressed = false;
                }

                if(!this.specialKeyPressed) {
                    if(this.app.getKey(KeyEvent.VK_A) || this.app.getKey(KeyEvent.VK_SPACE)) {
                        this.turnRight();
                        this.specialKeyPressed = true;
                    } else if(this.app.getKey(KeyEvent.VK_D) || this.app.getKey(KeyEvent.VK_UP)) {
                        this.turnLeft();
                        this.specialKeyPressed = true;
                    }

                    if(this.app.getKey(KeyEvent.VK_X)) {
                        this.fallDown();
                        this.specialKeyPressed = true;
                    }

                    if(this.app.getKey(KeyEvent.VK_P)) {
                        this.gamePaused = true;
                        this.specialKeyPressed = true;
                    }
                } else if(!this.app.isAnyKeyPressed()) {
                    this.specialKeyPressed = false;
                }

                if(this.time >= this.maxInterval) {
                    this.moveDown();
                    this.time = 0;
                }
            } else {
                if(!this.specialKeyPressed) {
                    if(this.app.getKey(KeyEvent.VK_P)) {
                        this.gamePaused = false;
                        this.specialKeyPressed = true;
                    }
                } else if(!this.app.isAnyKeyPressed()) {
                    this.specialKeyPressed = false;
                }
            }
        }
    }

    /**
     * Sets the game in easy mode.
     */
    public final void setEasy() {
        this.level = 1;
    }

    /**
     * Sets the game in normal mode.
     */
    public final void setNormal() {
        this.level = 5;
    }

    /**
     * Sets the game in hard mode.
     */
    public final void setHard() {
        this.level = 10;
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The height of the game's world. */
    private static final int worldHeight = 20;
    /** The width of the game's world. */
    private static final int worldWidth = 10;

    /** The x-coordinate when the world starts. */
    private static final int worldStartX = 16;
    /** The value of an empty cell in the world. */
    private static final int empty = -1;

    /** The maximum intervals of time allowed to repeat a key stroke. */
    private static final long maxKeyInterval = 200;

    /** The maximum intervals of time allowed. */
    private static final long[] maxIntervals = { 1000, 950, 900, 850, 800, 750, 700,
        650, 600, 550, 500, 450, 400, 350, 300, 250, 200, 150, 100, 50};

    /** The numbers of lines to pass to the next level. */
    private static final int[] maxLines = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 22, 24, 26, 28, 30, 32, 37, 42, 101};

    /** The numbers of points the player receives when makes a line. */
    private static final int[] linePoints = { 1, 2, 3, 4, 5, 6, 8, 10, 12, 14,
        16, 32, 48, 64, 128, 192, 256, 512, 768, 1024};
}