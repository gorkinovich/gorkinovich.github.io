/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris.state;

import com.gorkasuarez.jagl.Font;
import com.gorkasuarez.jagl.GameApp;
import com.gorkasuarez.jagl.IGame;
import com.gorkasuarez.tetris.Data;
import com.gorkasuarez.tetris.Score;
import com.gorkasuarez.tetris.States;
import com.gorkasuarez.tetris.consts.Menu;
import com.gorkasuarez.tetris.consts.NewGame;
import com.gorkasuarez.tetris.consts.Scores;
import com.gorkasuarez.tetris.consts.Options;
import com.gorkasuarez.tetris.consts.Credits;
import com.gorkasuarez.tetris.consts.Help;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.Iterator;

/**
 * This MenuState class represents the internal logic of the menu state.
 * @author Gorka Suárez
 */
public class MenuState implements IGame {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The game application. */
    private GameApp app;

    /** The background image. */
    private Image background;

    /** The other background image. */
    private Image subBackground;

    /** The left arrow image. */
    private Image leftArrow;

    /** The right arrow image. */
    private Image rightArrow;

    /** The main font of the game. */
    private Font systemFont;

    /** The substate of the menu. */
    private int substate;

    /** The current selected option. */
    private int selOption;

    /** The key pressed controller flag. */
    private boolean keyPressed;

    /** A flag to start the music only at the beginning. */
    private boolean firstTime;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a MenuState object.
     * @param value The game application.
     */
    public MenuState(GameApp value) {
        this.app = value;
        this.background = null;
        this.subBackground = null;
        this.leftArrow = null;
        this.rightArrow = null;
        this.systemFont = null;
        this.firstTime = true;
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#initialize()
     */
    public void initialize() {
        Data data = Data.getInstance();
        this.background = data.getBackgrounds(Data.MenuBackground);
        this.subBackground = data.getBackgrounds(Data.SubMenuBackground);
        this.leftArrow = data.getItems(Data.LeftArrowItem);
        this.rightArrow = data.getItems(Data.RightArrowItem);
        this.systemFont = data.getSystemFont();
        this.substate = MenuState.MenuSubstate;
        this.selOption = Menu.NewGameOption;
        this.keyPressed = true;

        if(this.firstTime) {
            data.getMusic().start();
            this.firstTime = false;
        }
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#release()
     */
    public void release() {
        this.background = null;
        this.subBackground = null;
        this.leftArrow = null;
        this.rightArrow = null;
        this.systemFont = null;
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#render(java.awt.Graphics)
     */
    public void render(Graphics g) {
        switch(this.substate) {
        //****************************************************************************
        case MenuState.MenuSubstate:
            g.drawImage(this.background, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);

            g.drawImage(this.leftArrow, Menu.LeftArrowX, Menu.LeftArrowY,
                        Menu.LeftArrowWidth, Menu.LeftArrowHeight, this.app);
            g.drawImage(this.rightArrow, Menu.RightArrowX, Menu.RightArrowY,
                        Menu.RightArrowWidth, Menu.RightArrowHeight, this.app);

            switch(this.selOption) {
            case Menu.NewGameOption:
                this.systemFont.drawLineWithScale(Menu.OptStrX1, Menu.OptStrY, "New Game", g, this.app);
                break;

            case Menu.ScoresOption:
                this.systemFont.drawLineWithScale(Menu.OptStrX2, Menu.OptStrY, "Scores", g, this.app);
                break;

            case Menu.OptionsOption:
                this.systemFont.drawLineWithScale(Menu.OptStrX3, Menu.OptStrY, "Options", g, this.app);
                break;

            case Menu.CreditsOption:
                this.systemFont.drawLineWithScale(Menu.OptStrX4, Menu.OptStrY, "Credits", g, this.app);
                break;

            case Menu.HelpOption:
                this.systemFont.drawLineWithScale(Menu.OptStrX5, Menu.OptStrY, "Help", g, this.app);
                break;
            }
            break;

        //****************************************************************************
        case MenuState.NewGameSubstate:
            g.drawImage(this.subBackground, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);

            this.systemFont.drawLineWithScale(NewGame.TitleStrX, NewGame.TitleStrY,
                                              "Choose your level:", g, this.app);

            this.systemFont.drawLineWithScale(NewGame.OptStrX1, NewGame.OptStrY1, "Easy", g, this.app);
            this.systemFont.drawLineWithScale(NewGame.OptStrX2, NewGame.OptStrY2, "Normal", g, this.app);
            this.systemFont.drawLineWithScale(NewGame.OptStrX3, NewGame.OptStrY3, "Hard", g, this.app);
            this.systemFont.drawLineWithScale(NewGame.OptStrX4, NewGame.OptStrY4, "Cancel", g, this.app);

            switch(this.selOption) {
            case NewGame.EasyOption:
                g.drawImage(this.leftArrow, NewGame.LeftArrowX1, NewGame.LeftArrowY1,
                            NewGame.LeftArrowWidth, NewGame.LeftArrowHeight, this.app);
                g.drawImage(this.rightArrow, NewGame.RightArrowX1, NewGame.RightArrowY1,
                            NewGame.RightArrowWidth, NewGame.RightArrowHeight, this.app);
                break;

            case NewGame.NormalOption:
                g.drawImage(this.leftArrow, NewGame.LeftArrowX2, NewGame.LeftArrowY2,
                            NewGame.LeftArrowWidth, NewGame.LeftArrowHeight, this.app);
                g.drawImage(this.rightArrow, NewGame.RightArrowX2, NewGame.RightArrowY2,
                            NewGame.RightArrowWidth, NewGame.RightArrowHeight, this.app);

                break;

            case NewGame.HardOption:
                g.drawImage(this.leftArrow, NewGame.LeftArrowX3, NewGame.LeftArrowY3,
                            NewGame.LeftArrowWidth, NewGame.LeftArrowHeight, this.app);
                g.drawImage(this.rightArrow, NewGame.RightArrowX3, NewGame.RightArrowY3,
                            NewGame.RightArrowWidth, NewGame.RightArrowHeight, this.app);
                break;

            case NewGame.ReturnOption:
                g.drawImage(this.leftArrow, NewGame.LeftArrowX4, NewGame.LeftArrowY4,
                            NewGame.LeftArrowWidth, NewGame.LeftArrowHeight, this.app);
                g.drawImage(this.rightArrow, NewGame.RightArrowX4, NewGame.RightArrowY4,
                            NewGame.RightArrowWidth, NewGame.RightArrowHeight, this.app);
                break;
            }
            break;

        //****************************************************************************
        case MenuState.ScoresSubstate:
            g.drawImage(this.subBackground, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);

            Iterator<Score> it = Data.getInstance().getScores().iterator();
            Score aux;
            int w;
            String points;
            int y = Scores.StartY;

            while(it.hasNext()) {
                aux = it.next();
                this.systemFont.drawLineWithScale(Scores.StartX1, y, aux.getName(), g, this.app);
                points = String.valueOf(aux.getPoints());
                w = this.systemFont.getLineWidthWithScale(points);
                this.systemFont.drawLineWithScale(Scores.StartX2 - w, y, points, g, this.app);
                y += Scores.Separation;
            }
            break;

        //****************************************************************************
        case MenuState.OptionsSubstate:
            g.drawImage(this.subBackground, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);

            this.systemFont.drawLineWithScale(Options.StrX1, Options.StrY, "Music", g, this.app);
            if(Data.getInstance().isMusicEnable()) {
                this.systemFont.drawLineWithScale(Options.StrX2, Options.StrY, "On", g, this.app);
            } else {
                this.systemFont.drawLineWithScale(Options.StrX2, Options.StrY, "Off", g, this.app);
            }
            break;

        //****************************************************************************
        case MenuState.CreditsSubstate:
            g.drawImage(this.subBackground, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);

            this.systemFont.drawLineWithScale(Credits.StrX1, Credits.StrY1,
                                              "Programming & Graphics", g, this.app);
            this.systemFont.drawLineWithScale(Credits.StrX2, Credits.StrY2,
                                              "by Gorka Suárez García", g, this.app);

            this.systemFont.drawLineWithScale(Credits.StrX3, Credits.StrY3,
                                              "St Basils cathedral photo", g, this.app);
            this.systemFont.drawLineWithScale(Credits.StrX4, Credits.StrY4,
                                              "by David Crawshaw", g, this.app);

            this.systemFont.drawLineWithScale(Credits.StrX5, Credits.StrY5,
                                              "Mozart's K.448 midi", g, this.app);
            this.systemFont.drawLineWithScale(Credits.StrX6, Credits.StrY6,
                                              "by Hansjakob Heldstab", g, this.app);

            break;

        //************************************************************************
        case MenuState.HelpSubstate:
            g.drawImage(this.subBackground, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);

            this.systemFont.drawLineWithScale(Help.StrX1, Help.StrY1, "Move Left:", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX1, Help.StrY2, "Move Right:", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX1, Help.StrY3, "Turn Left:", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX1, Help.StrY4, "Turn Right:", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX1, Help.StrY5, "Down:", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX1, Help.StrY6, "Fall:", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX1, Help.StrY7, "Pause:", g, this.app);

            this.systemFont.drawLineWithScale(Help.StrX2, Help.StrY1, "    Left", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX2, Help.StrY2, "   Right", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX2, Help.StrY3, "A & Space", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX2, Help.StrY4, "  D & Up", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX2, Help.StrY5, "   Down", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX2, Help.StrY6, "      X", g, this.app);
            this.systemFont.drawLineWithScale(Help.StrX2, Help.StrY7, "      P", g, this.app);

            break;
        }
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#logic()
     */
    public void logic() {
        if(!this.keyPressed) {
            switch(this.substate) {
            //************************************************************************
            case MenuState.MenuSubstate:
                if(this.app.getKey(GameApp.KeyFire) || this.app.getKey(KeyEvent.VK_ENTER)) {
                    this.keyPressed = true;
                    switch(this.selOption) {
                    case Menu.NewGameOption:
                        this.substate = MenuState.NewGameSubstate;
                        this.selOption = NewGame.EasyOption;
                        break;

                    case Menu.ScoresOption:
                        this.substate = MenuState.ScoresSubstate;
                        break;

                    case Menu.OptionsOption:
                        this.substate = MenuState.OptionsSubstate;
                        break;

                    case Menu.CreditsOption:
                        this.substate = MenuState.CreditsSubstate;
                        break;

                    case Menu.HelpOption:
                        this.substate = MenuState.HelpSubstate;
                        break;
                    }

                } else if(this.app.getKey(GameApp.KeyLeft)) {
                    this.keyPressed = true;
                    if(this.selOption > Menu.NewGameOption){
                        this.selOption--;
                    } else {
                        this.selOption = Menu.HelpOption;
                    }

                } else if(this.app.getKey(GameApp.KeyRight)) {
                    this.keyPressed = true;
                    if(this.selOption < Menu.HelpOption) {
                        this.selOption++;
                    } else {
                        this.selOption = Menu.NewGameOption;
                    }
                }
                break;

            //************************************************************************
            case MenuState.NewGameSubstate:
                if(this.app.getKey(GameApp.KeyFire) || this.app.getKey(KeyEvent.VK_ENTER)) {
                    this.keyPressed = true;
                    switch(this.selOption) {
                    case NewGame.EasyOption:
                        States.getInstance().getGameState().setEasy();
                        this.app.setState(States.getInstance().getGameState());
                        break;

                    case NewGame.NormalOption:
                        States.getInstance().getGameState().setNormal();
                        this.app.setState(States.getInstance().getGameState());
                        break;

                    case NewGame.HardOption:
                        States.getInstance().getGameState().setHard();
                        this.app.setState(States.getInstance().getGameState());
                        break;

                    case NewGame.ReturnOption:
                        this.substate = MenuState.MenuSubstate;
                        this.selOption = Menu.NewGameOption;
                        break;
                    }

                } else if(this.app.getKey(GameApp.KeyUp)) {
                    this.keyPressed = true;
                    if(this.selOption > NewGame.EasyOption) {
                        this.selOption--;
                    } else {
                        this.selOption = NewGame.ReturnOption;
                    }

                } else if(this.app.getKey(GameApp.KeyDown)) {
                    this.keyPressed = true;
                    if(this.selOption < NewGame.ReturnOption) {
                        this.selOption++;
                    } else {
                        this.selOption = NewGame.EasyOption;
                    }
                }
                break;

            //************************************************************************
            case MenuState.OptionsSubstate:
                if(this.app.getKey(GameApp.KeyFire) || this.app.getKey(KeyEvent.VK_ENTER)) {
                    this.keyPressed = true;
                    this.substate = MenuState.MenuSubstate;

                } else if(this.app.getKey(GameApp.KeyLeft)) {
                    this.keyPressed = true;
                    Data.getInstance().setMusicEnable(!Data.getInstance().isMusicEnable());

                } else if(this.app.getKey(GameApp.KeyRight)) {
                    this.keyPressed = true;
                    Data.getInstance().setMusicEnable(!Data.getInstance().isMusicEnable());
                }
                break;

            //************************************************************************
            case MenuState.ScoresSubstate:
            case MenuState.CreditsSubstate:
            case MenuState.HelpSubstate:
                if(this.app.getKey(GameApp.KeyFire) || this.app.getKey(KeyEvent.VK_ENTER)) {
                    this.keyPressed = true;
                    this.substate = MenuState.MenuSubstate;
                }
                break;
            }
        } else if(!this.app.isAnyKeyPressed()) {
            this.keyPressed = false;
        }
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The menu substate ID. */
    private static final int MenuSubstate = 0;
    /** The new game substate ID. */
    private static final int NewGameSubstate = 1;
    /** The scores substate ID. */
    private static final int ScoresSubstate = 2;
    /** The options substate ID. */
    private static final int OptionsSubstate = 3;
    /** The credits substate ID. */
    private static final int CreditsSubstate = 4;
    /** The help substate ID. */
    private static final int HelpSubstate = 5;
}