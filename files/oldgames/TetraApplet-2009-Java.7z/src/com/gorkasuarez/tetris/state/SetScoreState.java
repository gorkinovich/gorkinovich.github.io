/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris.state;

import com.gorkasuarez.jagl.Font;
import com.gorkasuarez.jagl.GameApp;
import com.gorkasuarez.jagl.IGame;
import com.gorkasuarez.tetris.Data;
import com.gorkasuarez.tetris.States;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;

/**
 * This SetScoreState class represents the internal logic of the set score state.
 * @author Gorka Suárez
 */
public class SetScoreState implements IGame {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The game application. */
    private GameApp app;

    /** The background image. */
    private Image background;

    /** The main font of the game. */
    private Font systemFont;

    /** The key pressed controller flag. */
    private boolean keyPressed;

    /** The time controller. */
    private long time;

    /** The time mark. */
    private long timeMark;

    /** The key pressed controller flag. */
    private boolean showUnderscore;

    /** The name of the player. */
    private String name;

    /** The number of points of the player. */
    private int points;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a SetScoreState object.
     * @param value The game application.
     */
    public SetScoreState(GameApp value) {
        this.app = value;
        this.background = null;
        this.systemFont = null;
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#initialize()
     */
    public void initialize() {
        Data data = Data.getInstance();
        this.background = data.getBackgrounds(Data.SubMenuBackground);
        this.systemFont = data.getSystemFont();
        this.keyPressed = true;
        this.time = 0;
        this.timeMark = System.currentTimeMillis();
        this.showUnderscore = true;
        this.name = "";
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#release()
     */
    public void release() {
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#render(java.awt.Graphics)
     */
    public void render(Graphics g) {
        g.drawImage(this.background, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);
        this.systemFont.drawLineWithScale(MsgX, MsgY, "Write your name:", g, this.app);
        if(this.showUnderscore) {
            this.systemFont.drawLineWithScale(InpX, InpY, this.name + "_", g, this.app);
        } else {
            this.systemFont.drawLineWithScale(InpX, InpY, this.name, g, this.app);
        }
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#logic()
     */
    public void logic() {
        this.time += (System.currentTimeMillis() - this.timeMark);
        if(this.time >= SetScoreState.MaxInterval) {
            this.showUnderscore = !this.showUnderscore;
            this.time = 0;
        }

        if(!this.keyPressed) {
            int size = this.name.length();

            if(SetScoreState.MaxNameSize > size) {
                if(this.app.getKey(KeyEvent.VK_A)) {
                    this.name += "A";
                } else if(this.app.getKey(KeyEvent.VK_B)) {
                    this.name += "B";
                } else if(this.app.getKey(KeyEvent.VK_C)) {
                    this.name += "C";
                } else if(this.app.getKey(KeyEvent.VK_D)) {
                    this.name += "D";
                } else if(this.app.getKey(KeyEvent.VK_E)) {
                    this.name += "E";
                } else if(this.app.getKey(KeyEvent.VK_F)) {
                    this.name += "F";
                } else if(this.app.getKey(KeyEvent.VK_G)) {
                    this.name += "G";
                } else if(this.app.getKey(KeyEvent.VK_H)) {
                    this.name += "H";
                } else if(this.app.getKey(KeyEvent.VK_I)) {
                    this.name += "I";
                } else if(this.app.getKey(KeyEvent.VK_J)) {
                    this.name += "J";
                } else if(this.app.getKey(KeyEvent.VK_K)) {
                    this.name += "K";
                } else if(this.app.getKey(KeyEvent.VK_L)) {
                    this.name += "L";
                } else if(this.app.getKey(KeyEvent.VK_M)) {
                    this.name += "M";
                } else if(this.app.getKey(KeyEvent.VK_N)) {
                    this.name += "N";
                } else if(this.app.getKey(KeyEvent.VK_O)) {
                    this.name += "O";
                } else if(this.app.getKey(KeyEvent.VK_P)) {
                    this.name += "P";
                } else if(this.app.getKey(KeyEvent.VK_Q)) {
                    this.name += "Q";
                } else if(this.app.getKey(KeyEvent.VK_R)) {
                    this.name += "R";
                } else if(this.app.getKey(KeyEvent.VK_S)) {
                    this.name += "S";
                } else if(this.app.getKey(KeyEvent.VK_T)) {
                    this.name += "T";
                } else if(this.app.getKey(KeyEvent.VK_U)) {
                    this.name += "U";
                } else if(this.app.getKey(KeyEvent.VK_V)) {
                    this.name += "V";
                } else if(this.app.getKey(KeyEvent.VK_W)) {
                    this.name += "W";
                } else if(this.app.getKey(KeyEvent.VK_X)) {
                    this.name += "X";
                } else if(this.app.getKey(KeyEvent.VK_Y)) {
                    this.name += "Y";
                } else if(this.app.getKey(KeyEvent.VK_Z)) {
                    this.name += "Z";
                } else if(this.app.getKey(KeyEvent.VK_0)) {
                    this.name += "0";
                } else if(this.app.getKey(KeyEvent.VK_1)) {
                    this.name += "1";
                } else if(this.app.getKey(KeyEvent.VK_2)) {
                    this.name += "2";
                } else if(this.app.getKey(KeyEvent.VK_3)) {
                    this.name += "3";
                } else if(this.app.getKey(KeyEvent.VK_4)) {
                    this.name += "4";
                } else if(this.app.getKey(KeyEvent.VK_5)) {
                    this.name += "5";
                } else if(this.app.getKey(KeyEvent.VK_6)) {
                    this.name += "6";
                } else if(this.app.getKey(KeyEvent.VK_7)) {
                    this.name += "7";
                } else if(this.app.getKey(KeyEvent.VK_8)) {
                    this.name += "8";
                } else if(this.app.getKey(KeyEvent.VK_9)) {
                    this.name += "9";
                }
            }

            if(this.app.getKey(KeyEvent.VK_BACK_SPACE)) {
                if(this.name.length() > 0) {
                    this.name = this.name.substring(0, size - 1);
                }
            } else if(this.app.getKey(KeyEvent.VK_ENTER)) {
                Data.getInstance().getScores().add(this.name, this.points);
                this.app.setState(States.getInstance().getMenuState());
            }

            if(size != this.name.length()) {
                this.keyPressed = true;
            }

        } else if(!this.app.isAnyKeyPressed()) {
            this.keyPressed = false;
        }

        this.timeMark = System.currentTimeMillis();
    }

    /**
     * Gets the name of the player.
     * @return The name of the player.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name of the player.
     * @param name The name of the player.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the number of points of the player.
     * @return The number of points of the player.
     */
    public int getPoints() {
        return this.points;
    }

    /**
     * Sets the number of points of the player.
     * @param points The number of points of the player.
     */
    public void setPoints(int points) {
        this.points = points;
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The x-coordinate of the message line. */
    public static final int MsgX = 128;
    /** The x-coordinate of the input line. */
    public static final int InpX = 120;
    /** The y-coordinate of the message line. */
    public static final int MsgY = 220;
    /** The x-coordinate of the input line. */
    public static final int InpY = 300;

    /** The maximum interval of time allowed in input blinking. */
    public static final int MaxInterval = 500;
    /** The maximum size of the name string. */
    public static final int MaxNameSize = 10;
}