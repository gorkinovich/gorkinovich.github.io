/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris.state;

import com.gorkasuarez.jagl.GameApp;
import com.gorkasuarez.jagl.IGame;
import com.gorkasuarez.tetris.Data;
import com.gorkasuarez.tetris.States;
import java.awt.Graphics;
import java.awt.Image;

/**
 * This IntroState class represents the internal logic of the intro state.
 * @author Gorka Suárez
 */
public class IntroState implements IGame {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The game application. */
    private GameApp app;

    /** The background image. */
    private Image background;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a IntroState object.
     * @param value The game application.
     */
    public IntroState(GameApp value) {
        this.app = value;
        this.background = null;
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#initialize()
     */
    public void initialize() {
        this.background = Data.getInstance().getBackgrounds(Data.IntroBackground);
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#release()
     */
    public void release() {
        this.background = null;
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#render(java.awt.Graphics)
     */
    public void render(Graphics g) {
        g.drawImage(this.background, 0, 0, this.app.getWidth(), this.app.getHeight(), this.app);
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IGame#logic()
     */
    public void logic() {
        if(this.app.isAnyKeyPressed()) {
            this.app.setState(States.getInstance().getMenuState());
        }
    }
}