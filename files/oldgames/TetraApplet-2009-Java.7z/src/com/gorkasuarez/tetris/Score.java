/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris;

import java.util.StringTokenizer;

/**
 * This Score class represents a player's game score.
 * @author Gorka Suárez
 */
public class Score {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The name of the player. */
    private String name;

    /** The number of points of the player. */
    private int points;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a Score object.
     */
    public Score() {
        this.name = "------";
        this.points = 0;
    }

    /**
     * Constructs a Score object.
     * @param name The name of the player.
     * @param points The number of points of the player.
     */
    public Score(String name, int points) {
        this.name = name;
        this.points = points;
    }

    /**
     * Gets the name of the player.
     * @return The name of the player.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name of the player.
     * @param name The name of the player.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the number of points of the player.
     * @return The number of points of the player.
     */
    public int getPoints() {
        return this.points;
    }

    /**
     * Sets the number of points of the player.
     * @param points The number of points of the player.
     */
    public void setPoints(int points) {
        this.points = points;
    }

    /**
     * Sets the data from a given string.
     * @param str The string with the data.
     */
    public void fromString(String str) {
        try {
            StringTokenizer st = new StringTokenizer(str, Score.Separator, false);
            this.name = st.nextToken().trim();
            this.points = Integer.parseInt(st.nextToken().trim());
        } catch(Exception e) {
            this.name = "------";
            this.points = 0;
        }
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return (this.name + Score.Separator + String.valueOf(this.points));
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The separator of the score's data. */
    private static final String Separator = ":";
}