/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris.consts;

/**
 * This Menu class stores the menu screen constants.
 * @author Gorka Suárez
 */
public abstract class Menu {
    /** New game option ID. */
    public static final int NewGameOption = 0;
    /** Scores option ID. */
    public static final int ScoresOption = 1;
    /** Options option ID. */
    public static final int OptionsOption = 2;
    /** Credits option ID. */
    public static final int CreditsOption = 3;
    /** Help option ID. */
    public static final int HelpOption = 4;

    /** The x-coordinate of the new game option string. */
    public static final int OptStrX1 = 170;
    /** The x-coordinate of the scores option string. */
    public static final int OptStrX2 = 195;
    /** The x-coordinate of the options option string. */
    public static final int OptStrX3 = 190;
    /** The x-coordinate of the credits option string. */
    public static final int OptStrX4 = 194;
    /** The x-coordinate of the help option string. */
    public static final int OptStrX5 = 210;
    /** The y-coordinate of the option string. */
    public static final int OptStrY = 300;

    /** The x-coordinate of the left arrow. */
    public static final int LeftArrowX = 130;
    /** The y-coordinate of the left arrow. */
    public static final int LeftArrowY = 304;
    /** The width of the left arrow. */
    public static final int LeftArrowWidth = 24;
    /** The height of the left arrow. */
    public static final int LeftArrowHeight = 24;

    /** The x-coordinate of the right arrow. */
    public static final int RightArrowX = 326;
    /** The y-coordinate of the right arrow. */
    public static final int RightArrowY = 304;
    /** The width of the right arrow. */
    public static final int RightArrowWidth = 24;
    /** The height of the right arrow. */
    public static final int RightArrowHeight = 24;
}