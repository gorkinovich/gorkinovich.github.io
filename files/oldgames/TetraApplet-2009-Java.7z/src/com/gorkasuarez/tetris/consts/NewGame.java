/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris.consts;

/**
 * This NewGame class stores the new game screen constants.
 * @author Gorka Suárez
 */
public abstract class NewGame {
    /** Easy option ID. */
    public static final int EasyOption = 0;
    /** Normal option ID. */
    public static final int NormalOption = 1;
    /** Hard option ID. */
    public static final int HardOption = 2;
    /** Return option ID. */
    public static final int ReturnOption = 3;

    /** The x-coordinate of the title string. */
    public static final int TitleStrX = 118;
    /** The y-coordinate of the title string. */
    public static final int TitleStrY = 150;

    /** The x-coordinate of the easy option string. */
    public static final int OptStrX1 = 207;
    /** The x-coordinate of the normal option string. */
    public static final int OptStrX2 = 193;
    /** The x-coordinate of the hard option string. */
    public static final int OptStrX3 = 209;
    /** The x-coordinate of the return option string. */
    public static final int OptStrX4 = 196;
    /** The y-coordinate of the easy option string. */
    public static final int OptStrY1 = 250;
    /** The y-coordinate of the normal option string. */
    public static final int OptStrY2 = 300;
    /** The y-coordinate of the hard option string. */
    public static final int OptStrY3 = 350;
    /** The y-coordinate of the return option string. */
    public static final int OptStrY4 = 450;

    /** The x-coordinate of the left arrow when the easy option is selected. */
    public static final int LeftArrowX1 = 130;
    /** The x-coordinate of the left arrow when the normal option is selected. */
    public static final int LeftArrowX2 = 130;
    /** The x-coordinate of the left arrow when the hard option is selected. */
    public static final int LeftArrowX3 = 130;
    /** The x-coordinate of the left arrow when the return option is selected. */
    public static final int LeftArrowX4 = 130;
    /** The y-coordinate of the left arrow when the easy option is selected. */
    public static final int LeftArrowY1 = 254;
    /** The y-coordinate of the left arrow when the normal option is selected. */
    public static final int LeftArrowY2 = 304;
    /** The y-coordinate of the left arrow when the hard option is selected. */
    public static final int LeftArrowY3 = 354;
    /** The y-coordinate of the left arrow when the return option is selected. */
    public static final int LeftArrowY4 = 454;
    /** The width of the left arrow. */
    public static final int LeftArrowWidth = 24;
    /** The height of the left arrow. */
    public static final int LeftArrowHeight = 24;

    /** The x-coordinate of the right arrow when the easy option is selected. */
    public static final int RightArrowX1 = 326;
    /** The x-coordinate of the right arrow when the normal option is selected. */
    public static final int RightArrowX2 = 326;
    /** The x-coordinate of the right arrow when the hard option is selected. */
    public static final int RightArrowX3 = 326;
    /** The x-coordinate of the right arrow when the return option is selected. */
    public static final int RightArrowX4 = 326;
    /** The y-coordinate of the right arrow when the easy option is selected. */
    public static final int RightArrowY1 = 254;
    /** The y-coordinate of the right arrow when the normal option is selected. */
    public static final int RightArrowY2 = 304;
    /** The y-coordinate of the right arrow when the hard option is selected. */
    public static final int RightArrowY3 = 354;
    /** The y-coordinate of the right arrow when the return option is selected. */
    public static final int RightArrowY4 = 454;
    /** The width of the right arrow. */
    public static final int RightArrowWidth = 24;
    /** The height of the right arrow. */
    public static final int RightArrowHeight = 24;
}