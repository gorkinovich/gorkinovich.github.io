/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.tetris.consts;

/**
 * This Help class stores the help screen constants.
 * @author Gorka Suárez
 */
public abstract class Help {
    /** The x-coordinate of the column 1. */
    public static final int StrX1 = 100;
    /** The x-coordinate of the column 2. */
    public static final int StrX2 = 280;

    /** The y-coordinate of the line 1. */
    public static final int StrY1 = 154;
    /** The y-coordinate of the line 2. */
    public static final int StrY2 = 204;
    /** The y-coordinate of the line 3. */
    public static final int StrY3 = 254;
    /** The y-coordinate of the line 4. */
    public static final int StrY4 = 304;
    /** The y-coordinate of the line 5. */
    public static final int StrY5 = 354;
    /** The y-coordinate of the line 6. */
    public static final int StrY6 = 404;
    /** The y-coordinate of the line 7. */
    public static final int StrY7 = 454;
}