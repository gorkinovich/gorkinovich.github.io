/**
 * Java Applet Game Library: A library for 2D games.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.jagl;

import java.awt.Image;

/**
 * This SystemFont10 class represents an implementation of the Font class to use
 * inside an applet the System font, with size 10.
 * @author Gorka Suárez
 */
public class SystemFont10 extends Font {
    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a SystemFont10 object.
     * @param data The bitmap with the representation of the font.
     */
    public SystemFont10(Image data) {
        super(data, 4, 16);
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.Font#configRects()
     */
    public void configRects() {
        /*
         *  ! " # $ % & ' ( ) * + , - . / 0 1 2 3 4 5 6 7 8 9 : ; < = > ? @ A B C
         * D E F G H I J K L M N O P Q R S T U V W X Y Z [ \ ] ^ _ ` a b c d e f
         * g h i j k l m n o p q r s t u v w x y z { | } ~ ¡ ª ¬ ´ · º ¿ Á Ç É Í
         * Ñ Ó Ú á ç é í ñ ó ú
         */
        int[] w = { 4, 6, 8, 8, 11, 9, 4, 4, 4, 6, 8, 4, 4, 4, 4, 8, 8, 8, 8,
                8, 8, 8, 8, 8, 8, 4, 4, 8, 8, 8, 8, 14, 8, 10, 9, 10, 9, 8, 10,
                10, 4, 7, 9, 8, 12, 10, 10, 9, 10, 10, 9, 8, 10, 8, 14, 9, 10,
                9, 4, 4, 4, 5, 8, 5, 8, 8, 7, 8, 8, 4, 8, 8, 4, 4, 7, 4, 12, 8,
                8, 8, 8, 5, 8, 4, 8, 8, 10, 8, 8, 8, 5, 4, 5, 5, 4, 5, 8, 5, 4,
                5, 8, 8, 9, 9, 4, 10, 10, 10, 8, 7, 8, 4, 8, 8, 8 };
        final int h = 16;
        for(int i = 0; i < Font.MaxChars; ++i) {
            super.setRect(i, w[i], h);
        }
        super.updateRects();
    }
}