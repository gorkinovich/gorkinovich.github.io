/**
 * Java Applet Game Library: A library for 2D games.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.jagl;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;

/**
 * This Font class represents the internal logic of a font to render text inside
 * an applet. This font must be able to be used on english games and spanish
 * games as well. The list of characters supported are: ! " # $ % & ' ( ) * + , - . /
 * 0 1 2 3 4 5 6 7 8 9 : ; < = > ? &#64; A B C D E F G H I J K L M N O P Q R S T
 * U V W X Y Z [ \ ] ^ _ ` a b c d e f g h i j k l m n o p q r s t u v w x y z { | } ~ ¡
 * ª ¬ ´ · º ¿ Á Ç É Í Ñ Ó Ú á ç é í ñ ó ú
 *
 * @author Gorka Suárez
 */
public abstract class Font {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The rectangles for each character inside the bitmap. */
    private Rect[] rects;

    /** The bitmap with the font. */
    private Image data;

    /** The width of the space character. */
    private int spaceWidth;

    /** The maximum font's height value. */
    private int height;

    /** The scale factor to render the font. */
    private int scale;

    //********************************************************************************
    // Private methods
    //********************************************************************************

    /**
     * Converts a char into an index position to find it inside the bitmap data.
     * @param c The char we want to convert.
     * @return The index position of the char or Font.CharNonAvailable if the
     *         char is not found.
     */
    protected int charToIndex(char c) {
        int v = (int) c;
        // Checking if the char int value is between character ! and character ~.
        if(33 <= v && v <= 126) {
            return v - 33;
        } else {
            // Checking if the char int value is one of these characters.
            switch(c) {
            case '¡':
                return 94;
            case 'ª':
                return 95;
            case '¬':
                return 96;
            case '´':
                return 97;
            case '·':
                return 98;
            case 'º':
                return 99;
            case '¿':
                return 100;
            case 'Á':
                return 101;
            case 'Ç':
                return 102;
            case 'É':
                return 103;
            case 'Í':
                return 104;
            case 'Ñ':
                return 105;
            case 'Ó':
                return 106;
            case 'Ú':
                return 107;
            case 'á':
                return 108;
            case 'ç':
                return 109;
            case 'é':
                return 110;
            case 'í':
                return 111;
            case 'ñ':
                return 112;
            case 'ó':
                return 113;
            case 'ú':
                return 114;
            }
        }
        return Font.CharNonAvailable;
    }

    /**
     * Sets the width and the height of one rect.
     * @param index The index of the rect.
     * @param w The width of the rect.
     * @param h The height of the rect.
     */
    protected void setRect(int index, int w, int h) {
        this.rects[index] = new Rect(0, 0, w, h);
    }

    /**
     * Calculates the (x, y) coordinates for each rect, using the current width
     * and height, given by the user.
     */
    protected void updateRects() {
        int x = 0;
        // For each rect inside the rects array.
        for(int i = 0; i < Font.MaxChars; ++i) {
            // First, we set the X-coordinate with the x counter variable.
            this.rects[i].setX(x);
            // And second, we add the width to the x counter. With these we'll
            // calculate the next X-coordinate of the next rect.
            x += this.rects[i].getWidth();
        }
    }

    /**
     * This function is called by the constructor to configure the array of
     * rects inside the class, to be able to locate the characters inside the
     * bitmap.
     */
    protected abstract void configRects();

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a Font object.
     * @param data The bitmap with the representation of the font.
     * @param spaceWidth The width of the space character.
     * @param height The height of the font.
     */
    public Font(Image data, int spaceWidth, int height) {
        this.rects = new Rect[Font.MaxChars];
        this.data = data;
        this.spaceWidth = spaceWidth;
        this.height = height;
        this.scale = 1;
        this.configRects();
    }

    /**
     * Gets the width of a string with the current font.
     * @param line The string.
     * @return The width of the string.
     */
    public int getLineWidth(String line) {
        int maxw = 0, w = 0, c;

        // For each character inside the string.
        for(int i = 0; i < line.length(); ++i) {
            // First, we try to get the index for that character.
            c = this.charToIndex(line.charAt(i));
            if(c != Font.CharNonAvailable) {
                // If we get an index, we'll add the width of that character
                // to the w counter variable.
                w += this.rects[c].getWidth();
            } else {
                // Else, we'll check if the character is a \n character, to start a
                // new line. Any other case we'll handle that character as an space.
                if(line.charAt(i) != '\n')
                    w += this.spaceWidth;
                else
                    w = 0;
            }
            // After check the current character, we'll check if the current width is
            // longer than the maximum width. If true, we'll set the new maximum width
            // with the value of the w counter variable.
            if(w > maxw)
                maxw = w;
        }

        return maxw;
    }

    /**
     * Gets the width of a string with the current scaled font.
     * @param line The string.
     * @return The width of the string.
     */
    public int getLineWidthWithScale(String line) {
        return this.getLineWidth(line) * this.scale;
    }

    /**
     * Gets the maximum height of the font.
     * @return The maximum height of the font.
     */
    public int getHeight() {
        return this.height;
    }

    /**
     * Gets the scale factor of the font.
     * @return The scale factor of the font.
     */
    public int getScale() {
        return this.scale;
    }

    /**
     * Sets the scale factor of the font.
     * @param scale The scale factor of the font.
     */
    public void setScale(int scale) {
        if(scale > 0)
            this.scale = scale;
    }

    /**
     * Draw a string into an (x, y) coordinates inside the screen of the applet,
     * with the current font.
     * @param x The X-coordinate.
     * @param y The Y-coordinate.
     * @param line The string.
     * @param g The specified Graphics window.
     * @param observer The image observer window.
     */
    public void drawLine(int x, int y, String line, Graphics g, ImageObserver observer) {
        int incx = 0, incy = 0, c, cx, cy, cw, ch;

        // For each character inside the string.
        for(int i = 0; i < line.length(); ++i) {
            // First, we try to get the index for that character.
            c = this.charToIndex(line.charAt(i));
            if(c != Font.CharNonAvailable) {
                // If we get an index, we'll get the data from the character's rect.
                cx = this.rects[c].getX();
                cy = this.rects[c].getY();
                cw = this.rects[c].getWidth();
                ch = this.rects[c].getHeight();
                // And then we'll draw the character in the right coordinates.
                g.drawImage(this.data, x + incx, y + incy, x + incx + cw, y + incy +
                            ch, cx, cy, cx + cw, cy + ch, observer);
                incx += cw;
            } else {
                // Else, we'll check if the character is a \n character, to start a
                // new line. Any other case we'll handle that character as an space.
                if(line.charAt(i) != '\n') {
                    incx += this.spaceWidth;
                } else {
                    incx = 0;
                    incy += this.height;
                }
            }
        }
    }

    /**
     * Draw a string into an (x, y) coordinates inside the screen of the applet,
     * with the current scaled font.
     * @param x The X-coordinate.
     * @param y The Y-coordinate.
     * @param line The string.
     * @param g The specified Graphics window.
     * @param observer The image observer window.
     */
    public void drawLineWithScale(int x, int y, String line, Graphics g, ImageObserver observer) {
        int incx = 0, incy = 0, c, cx, cy, cw, ch;

        // For each character inside the string.
        for(int i = 0; i < line.length(); ++i) {
            // First, we try to get the index for that character.
            c = this.charToIndex(line.charAt(i));
            if(c != Font.CharNonAvailable) {
                // If we get an index, we'll get the data from the character's rect.
                cx = this.rects[c].getX();
                cy = this.rects[c].getY();
                cw = this.rects[c].getWidth();
                ch = this.rects[c].getHeight();
                // And then we'll draw the character in the right coordinates.
                g.drawImage(this.data, x + incx, y + incy, x + incx + cw * this.scale,
                            y + incy + ch * this.scale, cx, cy, cx + cw, cy + ch, observer);
                incx += cw * this.scale;
            } else {
                // Else, we'll check if the character is a \n character, to start a
                // new line. Any other case we'll handle that character as an space.
                if(line.charAt(i) != '\n') {
                    incx += this.spaceWidth * this.scale;
                } else {
                    incx = 0;
                    incy += this.height * this.scale;
                }
            }
        }
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /**
     * Maximum number of characters suported in this class.
     */
    public static final int MaxChars = 115;

    /**
     * Id for the "Character Non Available" error when you try to convert a char
     * into and index inside the array of rects.
     */
    protected static final int CharNonAvailable = -1;
}