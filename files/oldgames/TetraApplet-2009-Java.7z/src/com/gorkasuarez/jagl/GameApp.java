/**
 * Java Applet Game Library: A library for 2D games.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.jagl;

import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.StringTokenizer;
import netscape.javascript.JSException;
import netscape.javascript.JSObject;

/**
 * This GameApp class represents the internal logic of a game inside an applet.
 * The user will need only to implement the init method and call the initialize
 * method to make this works correctly.
 * @author Gorka Suárez
 */
public class GameApp extends Applet implements KeyListener, Runnable, IFSM {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The applet's back buffer. */
    private Image doubleBuffer;

    /** The applet's back buffer Graphics window. */
    private Graphics doubleBufferGraphics;

    /** The current state of the game. */
    private IGame state;

    /** The current state of the input's keys. */
    private boolean[] keys;

    /** The game thread. */
    private Thread gameThread;

    /** The main loop's end condition. */
    private boolean exit;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs an GameApp object.
     */
    public GameApp() {
        this.doubleBuffer = null;
        this.doubleBufferGraphics = null;
        this.state = null;
        this.keys = new boolean[GameApp.maxKeys];
    }

    /**
     * Initializes the game application data.
     * @param width The width of the screen.
     * @param height The height of the screen.
     * @param gameState The current game state.
     */
    public final void initialize(int width, int height, IGame gameState) {
        this.resize(width, height);

        this.setFocusTraversalKeysEnabled(false);
        this.addKeyListener(this);

        this.doubleBuffer = this.createImage(width, height);
        if(this.doubleBuffer != null) {
            this.doubleBufferGraphics = this.doubleBuffer.getGraphics();
        }

        this.setState(gameState);

        this.exit = false;
        this.gameThread = new Thread(this);
        this.gameThread.start();
    }

    /**
     * Releases the game application data.
     */
    public final void release() {
        this.state.release();

        this.exit = true;
        this.gameThread.interrupt();

        this.gameThread = null;
        this.doubleBuffer = null;
        this.doubleBufferGraphics = null;
        this.state = null;
        this.keys = null;
    }

    /**
     * Gets the state of a key.
     * @param key The key.
     * @return The state of the key and it will be true if the key is pressed.
     */
    public final boolean getKey(int key) {
        return this.keys[key];
    }

    /**
     * Checks if any key is pressed.
     * @return True if any key is pressed.
     */
    public final boolean isAnyKeyPressed() {
        for(int i = 0; i < GameApp.maxKeys; ++i) {
            if(this.keys[i])
                return true;
        }
        return false;
    }

    /**
     * Creates a cookie to save some data.
     * @param name The name of the cookie.
     * @param value The value to save.
     * @param days The number of days that will be alive.
     */
    public void createCookie(String name, String value, long days) {
        try {
            JSObject win = JSObject.getWindow(this);
            long time = days * 24 * 60 * 60 * 1000;
            String cmd = "var date = new Date();" + "date.setTime(date.getTime() + " +
                         String.valueOf(time) + ");" + "date.toGMTString();";
            String expires = "; expires=" + (String) win.eval(cmd);
            value = (String) win.eval("escape('" + value + "');");
            win.eval("document.cookie = '" + name + "=" + value + expires + "; path=/';");
        } catch(JSException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Creates a cookie to save some data.
     * @param name The name of the cookie.
     * @param value The value to save.
     */
    public void createCookie(String name, String value) {
        try {
            JSObject win = JSObject.getWindow(this);
            value = (String) win.eval("escape('" + value + "');");
            win.eval("document.cookie = '" + name + "=" + value + "; path=/';");
        } catch(JSException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Reads a cookie to get some data.
     * @param name The name of the cookie.
     * @return The saved value.
     */
    public String readCookie(String name) {
        try {
            JSObject win = JSObject.getWindow(this);
            StringTokenizer st = new StringTokenizer((String) win.eval("document.cookie"), ";", false);
            String line, value;
            int eqpos;
            while(st.hasMoreTokens()) {
                line = st.nextToken().trim();
                eqpos = line.indexOf('=');
                if(line.substring(0, eqpos).compareTo(name) == 0) {
                    value = line.substring(eqpos + 1, line.length());
                    value = (String) win.eval("unescape('" + value + "');");
                    System.out.println(value);
                }
            }
        } catch(JSException ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    /**
     * Erase a cookie from the web-browser.
     * @param name The name of the cookie.
     */
    public void eraseCookie(String name) {
        createCookie(name, "", -1);
    }

    //********************************************************************************
    // Public methods from Applet
    //********************************************************************************

    /*
     * (non-Javadoc)
     * @see java.applet.Applet#init()
     */
    public void init() {
    }

    /*
     * (non-Javadoc)
     * @see java.applet.Applet#destroy()
     */
    public void destroy() {
    }

    /*
     * (non-Javadoc)
     * @see java.awt.Container#paint(java.awt.Graphics)
     */
    public final void paint(Graphics g) {
        this.state.render(g);
    }

    /*
     * (non-Javadoc)
     * @see java.awt.Container#update(java.awt.Graphics)
     */
    public final void update(Graphics g) {
        try {
            if(this.doubleBuffer != null) {
                this.paint(this.doubleBufferGraphics);
                g.drawImage(this.doubleBuffer, 0, 0, null);
            } else {
                this.paint(g);
            }
        } catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

    //********************************************************************************
    // Public methods from KeyListener
    //********************************************************************************

    /*
     * (non-Javadoc)
     * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
     */
    public final void keyPressed(KeyEvent e) {
        this.keys[e.getKeyCode()] = true;
    }

    /*
     * (non-Javadoc)
     * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
     */
    public final void keyReleased(KeyEvent e) {
        this.keys[e.getKeyCode()] = false;
    }

    /*
     * (non-Javadoc)
     * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
     */
    public final void keyTyped(KeyEvent e) {
    }

    //********************************************************************************
    // Public methods from Runnable
    //********************************************************************************

    /*
     * (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    public final void run() {
        long time = 0, start = 0;
        while(!this.exit) {
            start = System.currentTimeMillis();
            this.repaint();
            this.state.logic();
            time = System.currentTimeMillis() - start;
            if(GameApp.maxInterval - time > 0) {
                try {
                    Thread.sleep(GameApp.maxInterval - time);
                } catch(InterruptedException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
    }

    //********************************************************************************
    // Public methods from IFSM
    //********************************************************************************

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IFSM#getState()
     */
    public final IGame getState() {
        return this.state;
    }

    /*
     * (non-Javadoc)
     * @see com.gorkasuarez.jagl.IFSM#setState(com.gorkasuarez.jagl.IGame)
     */
    public final void setState(IGame value) {
        if(this.state != null)
            this.state.release();
        this.state = value;
        if(this.state != null)
            this.state.initialize();
    }

    //********************************************************************************
    // Static
    //********************************************************************************

    /** The up key's value. */
    public static final int KeyUp = KeyEvent.VK_UP;
    /** The down key's value. */
    public static final int KeyDown = KeyEvent.VK_DOWN;
    /** The left key's value. */
    public static final int KeyLeft = KeyEvent.VK_LEFT;
    /** The right key's value. */
    public static final int KeyRight = KeyEvent.VK_RIGHT;
    /** The fire key's value. */
    public static final int KeyFire = KeyEvent.VK_SPACE;

    /** The 1 key's value. */
    public static final int KeyNum1 = KeyEvent.VK_1;
    /** The 2 key's value. */
    public static final int KeyNum2 = KeyEvent.VK_2;
    /** The 3 key's value. */
    public static final int KeyNum3 = KeyEvent.VK_3;
    /** The 4 key's value. */
    public static final int KeyNum4 = KeyEvent.VK_Q;
    /** The 5 key's value. */
    public static final int KeyNum5 = KeyEvent.VK_W;
    /** The 6 key's value. */
    public static final int KeyNum6 = KeyEvent.VK_E;
    /** The 7 key's value. */
    public static final int KeyNum7 = KeyEvent.VK_A;
    /** The 8 key's value. */
    public static final int KeyNum8 = KeyEvent.VK_S;
    /** The 9 key's value. */
    public static final int KeyNum9 = KeyEvent.VK_D;
    /** The * key's value. */
    public static final int KeyStar = KeyEvent.VK_Z;
    /** The 0 key's value. */
    public static final int KeyNum0 = KeyEvent.VK_X;
    /** The # key's value. */
    public static final int KeyPound = KeyEvent.VK_C;

    /** The maximum interval of time allowed in the main loop. */
    private static final long maxInterval = 40;
    /** The maximum number of keys in the input device. */
    private static final int maxKeys = 256;

    /** The serial version UID. */
    private static final long serialVersionUID = 2008101920L;
}