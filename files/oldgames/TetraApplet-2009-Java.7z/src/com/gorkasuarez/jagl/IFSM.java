/**
 * Java Applet Game Library: A library for 2D games.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.jagl;

/**
 * Implementing this interface allows an object to be a Finite State Machine.
 * @author Gorka Suárez
 */
public interface IFSM {
    /**
     * Gets the current state inside the game.
     * @return The current state.
     */
    IGame getState();

    /**
     * Sets a new state inside the game.
     * @param value The new state.
     */
    void setState(IGame value);
}