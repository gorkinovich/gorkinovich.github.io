/**
 * Java Applet Game Library: A library for 2D games.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.jagl;

import java.awt.Graphics;

/**
 * Implementing this interface allows an object to be a state inside a game.
 * @author Gorka Suárez
 */
public interface IGame {
    /**
     * Initializes the resources of the state.
     */
    void initialize();

    /**
     * Releases the resoures of the state.
     */
    void release();

    /**
     * The render function of the state.
     * @param g The specified Graphics window.
     */
    void render(Graphics g);

    /**
     * The logic function of the state.
     */
    void logic();
}