/**
 * Java Applet Game Library: A library for 2D games.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */
package com.gorkasuarez.jagl;

/**
 * This Rect class represents the internal logic of a rectangle in a 2D space.
 * @author Gorka Suárez
 */
public class Rect {
    //********************************************************************************
    // Properties
    //********************************************************************************

    /** The X-coordinate of the rect area. */
    private int x;

    /** The Y-coordinate of the rect area. */
    private int y;

    /** The width of the rect area. */
    private int width;

    /** The height of the rect area. */
    private int height;

    //********************************************************************************
    // Public methods
    //********************************************************************************

    /**
     * Constructs a Rect object.
     */
    public Rect() {
        this.x = 0;
        this.y = 0;
        this.width = 0;
        this.height = 0;
    }

    /**
     * Constructs a Rect object.
     * @param x The X-coordinate of the rect.
     * @param y The Y-coordinate of the rect.
     * @param width The width of the rect.
     * @param height The height of the rect.
     */
    public Rect(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    /**
     * Gets the height of the rect.
     * @return The height of the rect.
     */
    public final int getHeight() {
        return this.height;
    }

    /**
     * Sets the height of the rect.
     * @param height The height of the rect.
     */
    public final void setHeight(int height) {
        this.height = height;
    }

    /**
     * Gets the width of the rect.
     * @return The width of the rect.
     */
    public final int getWidth() {
        return this.width;
    }

    /**
     * Sets the width of the rect.
     * @param width The width of the rect.
     */
    public final void setWidth(int width) {
        this.width = width;
    }

    /**
     * Gets the X-coordinate of the rect.
     * @return The X-coordinate of the rect.
     */
    public final int getX() {
        return this.x;
    }

    /**
     * Sets the X-coordinate of the rect.
     * @param x The X-coordinate of the rect.
     */
    public final void setX(int x) {
        this.x = x;
    }

    /**
     * Gets the Y-coordinate of the rect.
     * @return The Y-coordinate of the rect.
     */
    public final int getY() {
        return this.y;
    }

    /**
     * Sets the Y-coordinate of the rect.
     * @param y The Y-coordinate of the rect.
     */
    public final void setY(int y) {
        this.y = y;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + height;
        result = PRIME * result + width;
        result = PRIME * result + x;
        result = PRIME * result + y;
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if(this == obj) return true;
        if(obj == null) return false;
        if(getClass() != obj.getClass()) return false;
        final Rect other = (Rect) obj;
        if(height != other.height) return false;
        if(width != other.width) return false;
        if(x != other.x) return false;
        if(y != other.y) return false;
        return true;
    }
}