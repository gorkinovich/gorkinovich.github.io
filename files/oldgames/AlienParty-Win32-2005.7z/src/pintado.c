//******************************************************************************************
// Alien Party is a space 2D shooter videogame.
// Copyright (C) 2005  Gorka Su�rez Garc�a
//
// pintado.c is part of Alien Party.
// 
// Alien Party is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// Alien Party is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Alien Party; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//******************************************************************************************
#include "invaders.h"
#include "pintado.h"
#include "system.h"
#include "teclas.h"
//******************************************************************************************
// Rutinas de la parte gr�fica.
//******************************************************************************************
void Renderizado (tNucleo * Nucleo)
{
	tDisparo * aux = Nucleo->Partida.Disparos;
	SDL_Rect destino;
	int i;
	char auxcad[30];

	//--------------------------------------------------------------------------------------
	// Pintamos todos los disparos actuales en la lista de disparos.
	//--------------------------------------------------------------------------------------
	while(aux != NULL)
	{
		//----------------------------------------------------------------------------------
		// Inicializamos la regi�n destino, de la textura de disparos.
		//----------------------------------------------------------------------------------
		destino.x = aux->x; // Posici�n x actual.
		destino.y = aux->y; // Posici�n y actual.
		destino.w = Nucleo->Texturas.Disparos[aux->tex].w; // Ancho de la textura.
		destino.h = Nucleo->Texturas.Disparos[aux->tex].h; // Alto de la textura.

		//----------------------------------------------------------------------------------
		// Pegamos la textura espec�fica al tipo de disparo que es.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgDisparos, &destino,
					&(Nucleo->Texturas.Disparos[aux->tex]));

		//----------------------------------------------------------------------------------
		// Seleccionamos el siguiente disparo.
		//----------------------------------------------------------------------------------
		aux = aux->sig;
	}

	//--------------------------------------------------------------------------------------
	// Pintamos todas las naves que est�n vivas, empezando por la del jugador.
	//--------------------------------------------------------------------------------------
	destino.x = Nucleo->Partida.Naves[0].x; // Posici�n x actual.
	destino.y = Nucleo->Partida.Naves[0].y; // Posici�n y actual.
	destino.w = Nucleo->Texturas.Malosos[Nucleo->Partida.Naves[0].tex].w; // Ancho de la textura.
	destino.h = Nucleo->Texturas.Malosos[Nucleo->Partida.Naves[0].tex].h; // Alto de la textura.

	PonerImagen(Nucleo, Nucleo->Texturas.imgSpike, &destino, NULL);

	//--------------------------------------------------------------------------------------
	// Recorremos el array de las naves, para pintarlas.
	//--------------------------------------------------------------------------------------
	for(i = 1; i < MAXNAV; i++)
	{
		//----------------------------------------------------------------------------------
		// Solo se pintar�n las naves enemigas que est�n vivas.
		//----------------------------------------------------------------------------------
		if(Nucleo->Partida.Naves[i].vida > 0)
		{
			destino.x = Nucleo->Partida.Naves[i].x; // Posici�n x actual.
			destino.y = Nucleo->Partida.Naves[i].y; // Posici�n y actual.
			destino.w = Nucleo->Texturas.Malosos[Nucleo->Partida.Naves[i].tex].w; // Ancho de la textura.
			destino.h = Nucleo->Texturas.Malosos[Nucleo->Partida.Naves[i].tex].h; // Alto de la textura.

			PonerImagen(Nucleo, Nucleo->Texturas.imgMalosos, &destino,
						&(Nucleo->Texturas.Malosos[Nucleo->Partida.Naves[i].tex]));
		}
	}
	
	//--------------------------------------------------------------------------------------
	// Pintamos el miserable HUD, que consiste en el marcador de punto y el de vida.
	//--------------------------------------------------------------------------------------
	sprintf(auxcad, "Puntos %10d", Nucleo->Partida.Puntos);
	PintarCadena(Nucleo, 2, 64, 576, auxcad);

	if(Nucleo->Partida.Naves[0].vida > 0)
		sprintf(auxcad, "Vida %3d", Nucleo->Partida.Naves[0].vida);
	else
		sprintf(auxcad, "Vida %3d", 0);
	PintarCadena(Nucleo, 2, 664, 576, auxcad);
}
//******************************************************************************************
void PintarPantalla (tNucleo * Nucleo)
{
	int i;
	char auxcad[30];

	//--------------------------------------------------------------------------------------
	// Dependiendo del estado se pintar� una cosa u otra.
	//--------------------------------------------------------------------------------------
	switch(Nucleo->Partida.EstadoDelJuego)
	{
	//--------------------------------------------------------------------------------------
	// Estado de Men� de nueva partida.
	//--------------------------------------------------------------------------------------
	case ESTMNU:
		//----------------------------------------------------------------------------------
		// Pintamos el fondo.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgMenu, NULL, NULL);

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Nueva Partida, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[0])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion01,
						&(Nucleo->Texturas.Opciones[0]), NULL);
		}

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Opciones, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[1])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion02,
						&(Nucleo->Texturas.Opciones[1]), NULL);
		}

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Puntuaciones, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[2])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion03,
						&(Nucleo->Texturas.Opciones[2]), NULL);
		}

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Salir, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[3])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion04,
						&(Nucleo->Texturas.Opciones[3]), NULL);
		}

		break;
	
	//--------------------------------------------------------------------------------------
	// Estado de Juego.
	//--------------------------------------------------------------------------------------
	case ESTJUG:
		//----------------------------------------------------------------------------------
		// Pintamos el fondo.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgFondo, NULL, NULL);

		//----------------------------------------------------------------------------------
		// Renderizamos la escena sobre el fondo.
		//----------------------------------------------------------------------------------
		Renderizado(Nucleo);

		break;
	
	//--------------------------------------------------------------------------------------
	// Estado de Pantalla de opciones.
	//--------------------------------------------------------------------------------------
	case ESTOPC:
		//----------------------------------------------------------------------------------
		// Pintamos el fondo.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgPuntuaciones, NULL, NULL);

		//----------------------------------------------------------------------------------
		// Pintamos un texto con la ayuda del juego.
		//----------------------------------------------------------------------------------
		PintarCadena(Nucleo, 1, 350, 130, "Opciones");

		PintarCadena(Nucleo, 1, 180, 180, "Como este juego es una mierda no tiene opciones");
		PintarCadena(Nucleo, 1, 180, 200, "Por eso aqui van las instrucciones de su manejo");
		PintarCadena(Nucleo, 1, 180, 240, "Flecha derecha");
		PintarCadena(Nucleo, 1, 390, 240, "Te desplaza a la derecha");
		PintarCadena(Nucleo, 1, 180, 260, "Flecha izquierda");
		PintarCadena(Nucleo, 1, 390, 260, "Te desplaza a la izquierda");
		PintarCadena(Nucleo, 1, 180, 280, "Espacio");
		PintarCadena(Nucleo, 1, 390, 280, "Para el disparo");
		PintarCadena(Nucleo, 1, 180, 320, "Escape");
		PintarCadena(Nucleo, 1, 390, 320, "Para ver el menu");

		PintarCadena(Nucleo, 1, 300, 450, "Pulsa escape para salir");

		break;
	
	//--------------------------------------------------------------------------------------
	// Estado de Pantalla de puntuaciones.
	//--------------------------------------------------------------------------------------
	case ESTPUN:
		//----------------------------------------------------------------------------------
		// Pintamos el fondo.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgPuntuaciones, NULL, NULL);
		
		//----------------------------------------------------------------------------------
		// Pintamos el listado de las puntuaciones.
		//----------------------------------------------------------------------------------
		PintarCadena(Nucleo, 1, 350, 130, "Puntuaciones");

		for(i = 0; i < MAXPUN; i++)
		{
			PintarCadena(Nucleo, 1, 250, 180 + (i * 20), Nucleo->Puntuaciones[i].nombre);
			sprintf(auxcad, "%10d", Nucleo->Puntuaciones[i].puntos);
			PintarCadena(Nucleo, 1, 480, 180 + (i * 20), auxcad);
		}
		
		PintarCadena(Nucleo, 1, 300, 450, "Pulsa escape para salir");

		break;
	
	//--------------------------------------------------------------------------------------
	// Estado de Men� de continuaci�n de partida.
	//--------------------------------------------------------------------------------------
	case ESTCON:
		//----------------------------------------------------------------------------------
		// Pintamos el fondo.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgMenu, NULL, NULL);
		
		//----------------------------------------------------------------------------------
		// Pintamos encima del bot�n de Nueva Partida, el de Continuar Partida.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion05, &(Nucleo->Texturas.Opciones[0]), NULL);

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Continuar Partida, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[0])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion06,
						&(Nucleo->Texturas.Opciones[0]), NULL);
		}

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Opciones, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[1])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion02,
						&(Nucleo->Texturas.Opciones[1]), NULL);
		}

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Puntuaciones, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[2])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion03,
						&(Nucleo->Texturas.Opciones[2]), NULL);
		}

		//----------------------------------------------------------------------------------
		// Si el rat�n est� sobre el bot�n de Salir, lo iluminamos.
		//----------------------------------------------------------------------------------
		if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[3])))
		{
			PonerImagen(Nucleo, Nucleo->Texturas.imgOpcion04,
						&(Nucleo->Texturas.Opciones[3]), NULL);
		}

		break;

	//--------------------------------------------------------------------------------------
	// Estado de Pantalla para meter el nombre.
	//--------------------------------------------------------------------------------------
	case ESTNOM:
		//----------------------------------------------------------------------------------
		// Pintamos el fondo.
		//----------------------------------------------------------------------------------
		PonerImagen(Nucleo, Nucleo->Texturas.imgPuntuaciones, NULL, NULL);

		//----------------------------------------------------------------------------------
		// Pintamos el mensaje para el usuario, y lo que lleva metido en el nombre.
		//----------------------------------------------------------------------------------
		PintarCadena(Nucleo, 1, 320, 130, "Fin de la partida");

		PintarCadena(Nucleo, 1, 180, 180, "Pon tu nombre y dale al enter");
		PintarCadena(Nucleo, 1, 200, 240, Nucleo->Partida.Nombre);

		break;
	}

	//--------------------------------------------------------------------------------------
	// Actualizaci�n de la pantalla.
	//--------------------------------------------------------------------------------------
	ActualizarPantalla(Nucleo);
}
//******************************************************************************************
// Fin pintado.c
//******************************************************************************************
