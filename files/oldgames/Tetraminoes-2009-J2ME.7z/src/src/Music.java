/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import javax.microedition.media.*;

public class Music implements Runnable {
    //********************************************************************************
    // Properties
    //********************************************************************************

    public Player[] Sounds;
    public int CurrentSound;
    public boolean MusicEnable;
    public boolean Exit;

    //********************************************************************************
    //  methods
    //********************************************************************************

    /*
     * Constructs a Music object.
     */
    public Music() {
        try {
            MusicEnable = false;
            Sounds = new Player[3];
            Sounds[0] = LoadSound("/snd/Mozart.448.1.mid");
            Sounds[1] = LoadSound("/snd/Mozart.448.2.mid");
            Sounds[2] = LoadSound("/snd/Mozart.448.3.mid");
            SetCurrentSound(0);
            Exit = false;
        } catch(Exception e) {
            Sounds = null;
            CurrentSound = -1;
            MusicEnable = false;
            Exit = true;
        }
    }

    /*
     * Releases the music content and ends the thread execution.
     */
    public final void Release() {
        MusicEnable = false;
        Exit = true;
        Stop();
        Sounds = null;
        CurrentSound = -1;
    }

    /*
     * Sets the current sound to be played the next time you call Play() method.
     */
    public final void SetCurrentSound(int value) {
        if(0 <= value && value <= 2) {
            CurrentSound = value;
        } else {
            CurrentSound = 0;
        }
    }

    /*
     * Plays the current selected sound.
     */
    public final void Play() {
        try {
            Sounds[CurrentSound].start();
        } catch(Exception e) {
            MusicEnable = false;
        }
    }

    /*
     * Stops the current selected sound.
     */
    public final void Stop() {
        try {
            Sounds[CurrentSound].stop();
        } catch(Exception e) {
        }
    }

    /*
     * Sets if the music is enabled or not.
     */
    public final void SetMusicEnable(boolean value) {
        MusicEnable = value;
        if(MusicEnable) {
            this.Play();
        } else {
            this.Stop();
        }
    }

    /*
     * This method is the main function of the sound thread. This just checks if
     * the current sound have stop and gets the next song to play it. Because
     * we don't want to kill the CPU, we'll make the thread to sleep 1 second
     * each executed loop in it.
     */
    public void run() {
        while(Exit) {
            try {
                if(MusicEnable && Sounds[CurrentSound].getState() != Player.STARTED) {
                    int aux = (CurrentSound + 1) % 3;
                    this.SetCurrentSound(aux);
                    this.Play();
                }
                Thread.sleep(1000);
            } catch(InterruptedException e) {
            }
        }
    }

    /*
     * Loads a sound from the JAR file of the game.
     */
    private final Player LoadSound(String path) {
        Player aux = null;
        try {
            aux = Manager.createPlayer(getClass().getResourceAsStream(path), "audio/midi");
        } catch(Exception e) {
            System.out.println(e.getMessage());
        }
        return aux;
    }
}
