/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public final class AppMIDlet extends MIDlet {
    //********************************************************************************
    // Properties
    //********************************************************************************

    public static AppMIDlet Application;
    public static TetrisGame Game;
    public static Display MainDisplay;
    public static Thread AppThread;

    //********************************************************************************
    // Methods
    //********************************************************************************

    /*
     * Constructs a AppMIDlet object.
     */
    public AppMIDlet() {
        Application = null;
        Game = null;
        MainDisplay = null;
        AppThread = null;
    }

    /*
     * This method is called when the midlet starts, so this is the main
     * entry to the game. This just configures the main display and creates
     * the class that contains the game.
     */
    protected void startApp() throws MIDletStateChangeException {
        Application = this;
        MainDisplay = Display.getDisplay(this);

        if(Game == null) {
            Game = new TetrisGame();
            AppThread = new Thread(Game);
            AppThread.start();
        }

        MainDisplay.setCurrent(Game);
    }

    /*
     * This method is called when the midlet is paused.
     */
    protected void pauseApp() {
    }

    /*
     * This method is called when the midlet is going to be destroyed,
     * so we'll release the game data and save the scores.
     */
    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
        TetrisGame.Release();
        MainDisplay.setCurrent(null);
        notifyDestroyed();
    }
}
