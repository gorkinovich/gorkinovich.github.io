/**
 * Tetraminoes, it's a clone of the clasic game of Alexey Pajitnov.
 * Copyright (C) 2009  Gorka Suárez
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.rms.*;
import java.io.IOException;
import java.util.Random;

public final class TetrisGame extends GameCanvas implements Runnable {
    //********************************************************************************
    // Constants
    //********************************************************************************

    // Input
    public static final int KeyNum0  = 0x00001;
    public static final int KeyNum1  = 0x00002;
    public static final int KeyNum2  = 0x00004;
    public static final int KeyNum3  = 0x00008;
    public static final int KeyNum4  = 0x00010;
    public static final int KeyNum5  = 0x00020;
    public static final int KeyNum6  = 0x00040;
    public static final int KeyNum7  = 0x00080;
    public static final int KeyNum8  = 0x00100;
    public static final int KeyNum9  = 0x00200;
    public static final int KeyPound = 0x00400;
    public static final int KeyStar  = 0x00800;
    public static final int KeyFire  = 0x01000;
    public static final int KeyUp    = 0x02000;
    public static final int KeyDown  = 0x04000;
    public static final int KeyLeft  = 0x08000;
    public static final int KeyRight = 0x10000;

    // Display
    public static final int MaxFrameTime = 40;

    // Textures
    public static final int BlockWidth = 16;
    public static final int BlockHeight = 16;

    // Font
    public static final int MaxChars = 115;
    public static final int CharNonAvailable = -1;

    // Scores
    public static final char ListSeparator = '.';
    private static final char FieldSeparator = ':';
    public static final byte MaxScores = 8;

    // Graphics
    public static final int DefaultAnchor = Graphics.TOP|Graphics.LEFT;

    // States
    public static final byte GameState = 0;
    public static final byte IntroState = 1;
    public static final byte MenuState = 2;
    public static final byte SetScoreState = 3;

    // Sub-states
    private static final byte MenuSubstate = 0;
    private static final byte NewGameSubstate = 1;
    private static final byte ScoresSubstate = 2;
    private static final byte OptionsSubstate = 3;
    private static final byte CreditsSubstate = 4;
    private static final byte HelpSubstate = 5;

    // Menu options
    public static final byte NewGameOption = 0;
    public static final byte ScoresOption = 1;
    public static final byte OptionsOption = 2;
    public static final byte CreditsOption = 3;
    public static final byte HelpOption = 4;

    // New game options
    public static final int EasyOption = 0;
    public static final int NormalOption = 1;
    public static final int HardOption = 2;
    public static final int ReturnOption = 3;

    // World
    private static final int WorldHeight = 20;
    private static final int WorldWidth = 10;
    private static final int WorldStartX = 8;
    private static final int Empty = -1;

    // Game logic
    private static final long MaxKeyInterval = 100;
    private static final long[] MaxIntervals = { 1000, 950, 900, 850, 800, 750, 700,
        650, 600, 550, 500, 450, 400, 350, 300, 250, 200, 150, 100, 50};
    private static final int[] MaxLines = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 22, 24, 26, 28, 30, 32, 37, 42, 101};
    private static final int[] LinePoints = { 1, 2, 3, 4, 5, 6, 8, 10, 12, 14,
        16, 32, 48, 64, 128, 192, 256, 512, 768, 1024};

    // Pieces
    private static final byte DarkBlue = 0;
    private static final byte Yellow = 1;
    private static final byte Murrey = 2;
    private static final byte Orange = 3;
    private static final byte LightBlue = 4;
    private static final byte Green = 5;
    private static final byte Red = 6;

    // Set score
    public static final int MaxBlinkInterval = 500;
    public static final int MaxNameSize = 10;

    //********************************************************************************
    // Properties
    //********************************************************************************

    // General
    public static boolean Pause;
    public static int KeyboardState;
    public static boolean Exit;
    public static byte State;

    // Textures
    public static Image[] Blocks;
    public static Image IntroBackground;
    public static Image MenuBackground;
    public static Image GameBackground;
    public static Image SubMenuBackground;
    public static Image LeftArrowItem;
    public static Image RightArrowItem;

    // Scores
    public static String[] ScoreNames;
    public static int[] ScorePoints;
    public static int RecordHandler;

    // Sound
    public static Thread SoundThread;
    public static Music SoundMusic;

    // Font
    public static int[] FontRectsX;
    public static int[] FontRectsW;
    public static Image FontData;
    public static int FontSpaceWidth;
    public static int FontHeight;

    // Logic
    public static byte SubState;
    public static byte SelOption;
    public static boolean KeyPressed;
    public static boolean SpecialKeyPressed;

    // Time
    public static long KeyTimeMark;
    public static long Time;
    public static long TimeMark;
    public static long MaxInterval;

    // Set score
    public static boolean ShowUnderscore;
    public static String Name;

    // Game
    public static int Level;
    public static int Lines;
    public static int Points;
    public static int Target;
    public static String LevelString;
    public static String LinesString;
    public static String PointsString;

    // World
    public static byte[][] World;

    // Pieces
    public static byte NextPiece;
    public static byte Piece;
    public static byte PieceX;
    public static byte PieceY;
    public static byte Orientation;

    // Other
    public static Random Rnd;
    public static boolean GameOver;
    public static boolean GamePaused;
    public static char SelectedChar;

    //********************************************************************************
    // TetrisGame
    //********************************************************************************

    /*
     * Constructs a TetrisGame object.
     */
    protected TetrisGame() {
        super(false);
        setFullScreenMode(true);
        Pause = false;
        RecordHandler = -1;
    }

    /*
     * This initializes the game at the beginning. Sets the state, the world, the
     * input and other things. And loads the textures, the font stuff, the scores
     * and the sound.
     */
    public final static void Initialize()
    {
        State = IntroState;
        Exit = false;
        KeyboardState = 0;

        InitializeBlocks();
        InitializeBackgrounds();
        InitializeItems();
        InitializeScores();
        InitializeFont();

        SoundMusic = new Music();
        SoundThread = new Thread(SoundMusic);

        World = new byte[WorldHeight][WorldWidth];
        Rnd = new Random();
    }

    /*
     * This is called when the application is destroyed, so we'll interrupt the
     * sound thread, release the sound stuff and save the scores.
     */
    public final static void Release() {
        SoundThread.interrupt();
        SoundMusic.Release();
        SaveScores();
    }

    /*
     * Loadas an image from the JAR file of the game.
     */
    public final static Image LoadImage(String path)
    {
        try {
            return Image.createImage(path);
        } catch(IOException e) {
            System.out.println(e.getMessage());
            Exit = true;
            return null;
        }
    }

    /*
     * This is called when the mobile set a pause signal, but I haven't
     * used this at all in the end, so is useless in some way. Maybe this
     * will make a bug in the game logic, I don't know.
     */
    protected final void hideNotify() {
        Pause = true;
        System.gc();
    }

    /*
     * This is called when the mobile set a unpause signal, but I haven't
     * used this at all in the end, so is useless in some way. Maybe this
     * will make a bug in the game logic, I don't know.
     */
    protected final void showNotify() {
        Pause = false;
        System.gc();
    }

    /*
     * This is called when the mobile changes the size screen of the game.
     * Is usefull when you need to control multiple resolutions, but this
     * isn't my case. This game only supports 240x320, but if you want to
     * make your life totally painfull, you can try to add more supported
     * resolutions to this game.
     */
    protected final void sizeChanged(int w, int h) {
    }

    //********************************************************************************
    // Input
    //********************************************************************************

    /*
     * Each time you press a key in any crappy mobile, this method will be called.
     * So I have used this to register which key is pressed or not when the logic
     * of the game is called.
     */
    protected final void keyPressed(int key) {
        KeyboardState |= KeyCode(key);
    }

    /*
     * Each time you release a key in any crappy mobile, this method will be called.
     * So I have used this to register which key is pressed or not when the logic
     * of the game is called.
     */
    protected final void keyReleased(int key) {
        KeyboardState &= (~KeyCode(key));
    }

    /*
     * I use this to convert the GameCanvas key code into something more usefull
     * to me, instead using an array of integers. This allows me to save some bytes.
     */
    public final static int KeyCode(int key) {
        switch(key) {
            case Canvas.KEY_NUM0:  return KeyNum0;
            case Canvas.KEY_NUM1:  return KeyNum1;
            case Canvas.KEY_NUM2:  return KeyNum2;
            case Canvas.KEY_NUM3:  return KeyNum3;
            case Canvas.KEY_NUM4:  return KeyNum4;
            case Canvas.KEY_NUM5:  return KeyNum5;
            case Canvas.KEY_NUM6:  return KeyNum6;
            case Canvas.KEY_NUM7:  return KeyNum7;
            case Canvas.KEY_NUM8:  return KeyNum8;
            case Canvas.KEY_NUM9:  return KeyNum9;
            case Canvas.KEY_POUND: return KeyPound;
            case Canvas.KEY_STAR:  return KeyStar;
        }
        switch(AppMIDlet.Game.getGameAction(key)) {
            case Canvas.FIRE:  return KeyFire;
            case Canvas.UP:    return KeyUp;
            case Canvas.DOWN:  return KeyDown;
            case Canvas.RIGHT: return KeyRight;
            case Canvas.LEFT:  return KeyLeft;
        }
        return 0;
    }

    /*
     * This method is used each time the game needs to know if a key is pressed.
     */
    public final static boolean IsKeyDown(int key) {
        return ((KeyboardState & key) != 0);
    }

    /*
     * This method is used each time the game needs to know if any key is pressed.
     */
    public final static boolean IsAnyKeyDown() {
        return (KeyboardState != 0);
    }

    //********************************************************************************
    // Runnable
    //********************************************************************************

    /*
     * This method is the main function of the game thread. First initializes the
     * properties we're going to use. And then will make a loop, where the game
     * is going send the paint signal to the JVM first, and then will execute
     * the logic of the game. After that to avoid to kill the CPU, we'll make
     * the thread to sleep some milliseconds each executed loop.
     */
    public final void run() {
        long time = 0, start = 0;
        Initialize();
        System.gc();

        while(!Exit) {
            start = System.currentTimeMillis();
            repaint();
            serviceRepaints();
            Logic();
            time = MaxFrameTime - (System.currentTimeMillis() - start);
            if(time > 0) {
                try {
                    Thread.sleep(time);
                } catch(InterruptedException e) {
                }
            }
        }
    }

    //********************************************************************************
    // Data
    //********************************************************************************

    /*
     * Loads all the textures of the blocks.
     */
    public final static void InitializeBlocks() {
        Blocks = new Image[75];
        Blocks[0] = LoadImage("/gfx/Blocks/1.DarkBlue/1.0.0.png");
        Blocks[1] = LoadImage("/gfx/Blocks/1.DarkBlue/1.0.1.png");
        Blocks[2] = LoadImage("/gfx/Blocks/1.DarkBlue/1.1.1.png");
        Blocks[3] = LoadImage("/gfx/Blocks/1.DarkBlue/1.1.2.png");
        Blocks[4] = LoadImage("/gfx/Blocks/1.DarkBlue/1.2.1.png");
        Blocks[5] = LoadImage("/gfx/Blocks/1.DarkBlue/1.2.2.png");
        Blocks[6] = LoadImage("/gfx/Blocks/1.DarkBlue/1.2.3.png");
        Blocks[7] = LoadImage("/gfx/Blocks/1.DarkBlue/1.2.4.png");
        Blocks[8] = LoadImage("/gfx/Blocks/2.Yellow/2.0.0.png");
        Blocks[9] = LoadImage("/gfx/Blocks/2.Yellow/2.0.1.png");
        Blocks[10] = LoadImage("/gfx/Blocks/2.Yellow/2.1.1.png");
        Blocks[11] = LoadImage("/gfx/Blocks/2.Yellow/2.1.2.png");
        Blocks[12] = LoadImage("/gfx/Blocks/2.Yellow/2.1.3.png");
        Blocks[13] = LoadImage("/gfx/Blocks/2.Yellow/2.1.4.png");
        Blocks[14] = LoadImage("/gfx/Blocks/2.Yellow/2.2.1.png");
        Blocks[15] = LoadImage("/gfx/Blocks/2.Yellow/2.2.2.png");
        Blocks[16] = LoadImage("/gfx/Blocks/2.Yellow/2.2.3.png");
        Blocks[17] = LoadImage("/gfx/Blocks/2.Yellow/2.2.4.png");
        Blocks[18] = LoadImage("/gfx/Blocks/2.Yellow/2.2.5.png");
        Blocks[19] = LoadImage("/gfx/Blocks/2.Yellow/2.2.6.png");
        Blocks[20] = LoadImage("/gfx/Blocks/3.Murrey/3.0.0.png");
        Blocks[21] = LoadImage("/gfx/Blocks/3.Murrey/3.0.1.png");
        Blocks[22] = LoadImage("/gfx/Blocks/3.Murrey/3.1.1.png");
        Blocks[23] = LoadImage("/gfx/Blocks/3.Murrey/3.1.2.png");
        Blocks[24] = LoadImage("/gfx/Blocks/3.Murrey/3.1.3.png");
        Blocks[25] = LoadImage("/gfx/Blocks/3.Murrey/3.1.4.png");
        Blocks[26] = LoadImage("/gfx/Blocks/3.Murrey/3.2.1.png");
        Blocks[27] = LoadImage("/gfx/Blocks/3.Murrey/3.2.2.png");
        Blocks[28] = LoadImage("/gfx/Blocks/3.Murrey/3.2.3.png");
        Blocks[29] = LoadImage("/gfx/Blocks/3.Murrey/3.2.4.png");
        Blocks[30] = LoadImage("/gfx/Blocks/3.Murrey/3.2.5.png");
        Blocks[31] = LoadImage("/gfx/Blocks/3.Murrey/3.2.6.png");
        Blocks[32] = LoadImage("/gfx/Blocks/4.Orange/4.0.0.png");
        Blocks[33] = LoadImage("/gfx/Blocks/4.Orange/4.0.1.png");
        Blocks[34] = LoadImage("/gfx/Blocks/4.Orange/4.1.1.png");
        Blocks[35] = LoadImage("/gfx/Blocks/4.Orange/4.1.2.png");
        Blocks[36] = LoadImage("/gfx/Blocks/4.Orange/4.1.3.png");
        Blocks[37] = LoadImage("/gfx/Blocks/4.Orange/4.1.4.png");
        Blocks[38] = LoadImage("/gfx/Blocks/4.Orange/4.2.1.png");
        Blocks[39] = LoadImage("/gfx/Blocks/4.Orange/4.2.2.png");
        Blocks[40] = LoadImage("/gfx/Blocks/4.Orange/4.2.3.png");
        Blocks[41] = LoadImage("/gfx/Blocks/4.Orange/4.2.4.png");
        Blocks[42] = LoadImage("/gfx/Blocks/5.LightBlue/5.0.0.png");
        Blocks[43] = LoadImage("/gfx/Blocks/5.LightBlue/5.0.1.png");
        Blocks[44] = LoadImage("/gfx/Blocks/5.LightBlue/5.1.1.png");
        Blocks[45] = LoadImage("/gfx/Blocks/5.LightBlue/5.1.2.png");
        Blocks[46] = LoadImage("/gfx/Blocks/5.LightBlue/5.1.3.png");
        Blocks[47] = LoadImage("/gfx/Blocks/5.LightBlue/5.1.4.png");
        Blocks[48] = LoadImage("/gfx/Blocks/5.LightBlue/5.2.1.png");
        Blocks[49] = LoadImage("/gfx/Blocks/5.LightBlue/5.2.2.png");
        Blocks[50] = LoadImage("/gfx/Blocks/5.LightBlue/5.2.3.png");
        Blocks[51] = LoadImage("/gfx/Blocks/5.LightBlue/5.2.4.png");
        Blocks[52] = LoadImage("/gfx/Blocks/6.Green/6.0.0.png");
        Blocks[53] = LoadImage("/gfx/Blocks/6.Green/6.0.1.png");
        Blocks[54] = LoadImage("/gfx/Blocks/6.Green/6.1.1.png");
        Blocks[55] = LoadImage("/gfx/Blocks/6.Green/6.1.2.png");
        Blocks[56] = LoadImage("/gfx/Blocks/6.Green/6.1.3.png");
        Blocks[57] = LoadImage("/gfx/Blocks/6.Green/6.1.4.png");
        Blocks[58] = LoadImage("/gfx/Blocks/6.Green/6.2.1.png");
        Blocks[59] = LoadImage("/gfx/Blocks/6.Green/6.2.2.png");
        Blocks[60] = LoadImage("/gfx/Blocks/6.Green/6.2.3.png");
        Blocks[73] = LoadImage("/gfx/Blocks/6.Green/6.2.4.png");
        Blocks[74] = LoadImage("/gfx/Blocks/6.Green/6.2.5.png");
        Blocks[61] = LoadImage("/gfx/Blocks/6.Green/6.3.1.png");
        Blocks[62] = LoadImage("/gfx/Blocks/6.Green/6.3.2.png");
        Blocks[63] = LoadImage("/gfx/Blocks/6.Green/6.3.3.png");
        Blocks[64] = LoadImage("/gfx/Blocks/6.Green/6.3.4.png");
        Blocks[65] = LoadImage("/gfx/Blocks/7.Red/7.0.0.png");
        Blocks[66] = LoadImage("/gfx/Blocks/7.Red/7.0.1.png");
        Blocks[67] = LoadImage("/gfx/Blocks/7.Red/7.1.1.png");
        Blocks[68] = LoadImage("/gfx/Blocks/7.Red/7.1.2.png");
        Blocks[69] = LoadImage("/gfx/Blocks/7.Red/7.1.3.png");
        Blocks[70] = LoadImage("/gfx/Blocks/7.Red/7.1.4.png");
        Blocks[71] = LoadImage("/gfx/Blocks/7.Red/7.2.1.png");
        Blocks[72] = LoadImage("/gfx/Blocks/7.Red/7.2.2.png");
    }

    /*
     *  Loads all the textures of the backgrounds.
     */
    public final static void InitializeBackgrounds() {
        IntroBackground = LoadImage("/gfx/Background/Intro.png");
        MenuBackground = LoadImage("/gfx/Background/Menu.png");
        GameBackground = LoadImage("/gfx/Background/Game.png");
        SubMenuBackground = LoadImage("/gfx/Background/SubMenu.png");
    }

    /*
     *  Loads all the textures of the items.
     */
    public final static void InitializeItems() {
        LeftArrowItem = LoadImage("/gfx/Blocks/LeftArrow.png");
        RightArrowItem = LoadImage("/gfx/Blocks/RightArrow.png");
    }

    /*
     * Initializes the scores and tries to load the previous saved ones.
     */
    public final static void InitializeScores() {
        ScoreNames = new String[MaxScores];
        ScorePoints = new int[MaxScores];
        for(int i = 0; i < MaxScores; i++) {
            ScoreNames[i] = "------";
            ScorePoints[i] = 0;
        }
        LoadScores();
    }

    /*
     * This just loads the scores from a file. Because the RMS api it's quite horrible,
     * I needed to seek the first record ID to save and load the right scores.
     */
    public final static void LoadScores() {
        try {
            RecordStore rs = RecordStore.openRecordStore("Tetraminoes.Scores", true);
            RecordEnumeration re = rs.enumerateRecords(null, null, false);
            if(re.hasNextElement()) {
                RecordHandler = re.nextRecordId();
                byte[] buffer = rs.getRecord(RecordHandler);
                String str = new String(buffer);
                ScoresFromString(str);
            } else {
                RecordHandler = -1;
            }
            rs.closeRecordStore();
        } catch(Exception e) {
            System.out.println(e.getMessage());
        }

    }

    /*
     * This just saves the scores into a file. The first time you execute the game
     * there is no saved file, so the RecordHandler will be -1 and you just open
     * the new file, add the record in the first place you have and close the file.
     * But after that execution, the next ones, the game will recieve a record ID,
     * so it will be able to save the scores in the same place they were saved it
     * the last time.
     */
    public final static void SaveScores() {
        try {
            RecordStore rs = RecordStore.openRecordStore("Tetraminoes.Scores", true);
            String str = ScoresToString();
            byte[] buffer = str.getBytes();
            if(RecordHandler != -1) {
                rs.setRecord(RecordHandler, buffer, 0, buffer.length);
            } else {
                rs.addRecord(buffer, 0, buffer.length);
            }
            rs.closeRecordStore();
        } catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /*
     * Adds a new score to the list, but only when this new one is equal
     * or better than the others inside the list.
     */
    public final static void AddScore(String name, int points) {
        for(int i = 0; i < MaxScores; ++i) {
            if(ScorePoints[i] <= points) {
                for(int j = (MaxScores - 1); j > i; --j) {
                    ScoreNames[j] = ScoreNames[j - 1];
                    ScorePoints[j] = ScorePoints[j - 1];
                }
                ScoreNames[i] = name;
                ScorePoints[i] = points;
                return;
            }
        }
    }

    /*
     * Gets the score data from a string.
     */
    public final static void ScoreFromString(int index, String str) {
        for(int i = 0; i < str.length(); i++) {
            if(str.charAt(i) == FieldSeparator) {
                ScoreNames[index] = str.substring(0, i);
                ScorePoints[index] = Integer.parseInt(str.substring(i + 1, str.length()));
                return;
            }
        }
    }

    /*
     * Gets the score list data from a string. This is used when the scores
     * are loaded from a file.
     */
    public final static void ScoresFromString(String str) {
        int aux = 0, index = 0;
        for(int i = 0; i < str.length() && index < MaxScores; i++) {
            if(str.charAt(i) == ListSeparator) {
                ScoreFromString(index, str.substring(aux, i));
                aux = i + 1; index++;
            }
        }
        if(index < MaxScores) {
            ScoreFromString(index, str.substring(aux, str.length()));
        }
    }

    /*
     * Transforms the score list to a string. This is used when the scores
     * are saved into a file.
     */
    public final static String ScoresToString() {
        String aux = "";
        if(ScoreNames.length > 0 && ScorePoints.length > 0 &&
           ScoreNames.length == ScorePoints.length) {
            aux += (ScoreNames[0] + FieldSeparator + String.valueOf(ScorePoints[0]));
            for(int i = 1; i < ScoreNames.length; ++i) {
                aux += (ListSeparator + ScoreNames[i] +
                        FieldSeparator + String.valueOf(ScorePoints[i]));
            }
        }
        return aux;
    }

    //********************************************************************************
    // Font
    //********************************************************************************

    /*
     * Loads the texture and set the inner data of the font.
     */
    public final static void InitializeFont() {
        FontRectsX = new int[MaxChars];
        FontRectsW = new int[MaxChars];

        FontData = LoadImage("/gfx/Font/SystemFont10.png");
        FontSpaceWidth = 4;
        FontHeight = 16;

        int[] w = { 4, 6, 8, 8, 11, 9, 4, 4, 4, 6, 8, 4, 4, 4, 4, 8, 8, 8, 8,
                8, 8, 8, 8, 8, 8, 4, 4, 8, 8, 8, 8, 14, 8, 10, 9, 10, 9, 8, 10,
                10, 4, 7, 9, 8, 12, 10, 10, 9, 10, 10, 9, 8, 10, 8, 14, 9, 10,
                9, 4, 4, 4, 5, 8, 5, 8, 8, 7, 8, 8, 4, 8, 8, 4, 4, 7, 4, 12, 8,
                8, 8, 8, 5, 8, 4, 8, 8, 10, 8, 8, 8, 5, 4, 5, 5, 4, 5, 8, 5, 4,
                5, 8, 8, 9, 9, 4, 10, 10, 10, 8, 7, 8, 4, 8, 8, 8 };

        for(int i = 0; i < MaxChars; ++i) {
            FontRectsX[i] = 0;
            FontRectsW[i] = w[i];
        }

        int x = 0;
        for(int i = 0; i < MaxChars; ++i) {
            FontRectsX[i] = x;
            x += FontRectsW[i];
        }
    }

    /*
     * Transforms a char value into an integer index, used to locate
     * the position of that character into the font texture.
     */
    public final static int CharToIndex(char c) {
        int v = (int) c;
        if(33 <= v && v <= 126) {
            return v - 33;
        } else {
            switch(c) {
            case '¡': return 94;
            case 'ª': return 95;
            case '¬': return 96;
            case '´': return 97;
            case '·': return 98;
            case 'º': return 99;
            case '¿': return 100;
            case 'Á': return 101;
            case 'Ç': return 102;
            case 'É': return 103;
            case 'Í': return 104;
            case 'Ñ': return 105;
            case 'Ó': return 106;
            case 'Ú': return 107;
            case 'á': return 108;
            case 'ç': return 109;
            case 'é': return 110;
            case 'í': return 111;
            case 'ñ': return 112;
            case 'ó': return 113;
            case 'ú': return 114;
            }
        }
        return CharNonAvailable;
    }

    /*
     * Gets the width of a line inside a string.
     */
    public final static int GetLineWidth(String line) {
        int maxw = 0, w = 0, c;
        for(int i = 0; i < line.length(); ++i) {
            c = CharToIndex(line.charAt(i));
            if(c != CharNonAvailable) {
                w += FontRectsW[c];
            } else {
                if(line.charAt(i) != '\n')
                    w += FontSpaceWidth;
                else
                    w = 0;
            }
            if(w > maxw) maxw = w;
        }
        return maxw;
    }

    /*
     * Draws a line on the screen.
     */
    public final static void DrawLine(int x, int y, String line, Graphics g) {
        int incx = 0, incy = 0, c;
        for(int i = 0; i < line.length(); ++i) {
            c = CharToIndex(line.charAt(i));
            if(c != CharNonAvailable) {
                g.drawRegion(FontData, FontRectsX[c], 0, FontRectsW[c], FontHeight,
                             Sprite.TRANS_NONE, x + incx, y + incy, DefaultAnchor);
                incx += FontRectsW[c];
            } else {
                if(line.charAt(i) != '\n') {
                    incx += FontSpaceWidth;
                } else {
                    incx = 0; incy += FontHeight;
                }
            }
        }
    }

    /*
     * Draws a character on the screen.
     */
    public final static void DrawChar(int x, int y, char character, Graphics g) {
        int c = CharToIndex(character);
        if(c != CharNonAvailable) {
            g.drawRegion(FontData, FontRectsX[c], 0, FontRectsW[c], FontHeight,
                         Sprite.TRANS_NONE, x, y, DefaultAnchor);
        }
    }

    //********************************************************************************
    // Render
    //********************************************************************************

    /*
     * This is the main render method.
     */
    public final void paint(Graphics g) {
      try{
          switch(State) {
          case IntroState:
              g.drawImage(IntroBackground, 0, 0, DefaultAnchor);
              break;

          case MenuState:
              switch(SubState) {
              //**********************************************************************
              case MenuSubstate:
                  g.drawImage(MenuBackground, 0, 0, DefaultAnchor);

                  DrawLine(85, 125, "New Game", g);
                  DrawLine(97, 150, "Scores", g);
                  DrawLine(95, 175, "Options", g);
                  DrawLine(97, 200, "Credits", g);
                  DrawLine(105, 225, "Help", g);

                  switch(SelOption) {
                  case NewGameOption:
                      g.drawImage(RightArrowItem, 63, 127, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 165, 127, DefaultAnchor);
                      break;
                  case ScoresOption:
                      g.drawImage(RightArrowItem, 63, 152, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 165, 152, DefaultAnchor);
                      break;
                  case OptionsOption:
                      g.drawImage(RightArrowItem, 63, 177, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 165, 177, DefaultAnchor);
                      break;
                  case CreditsOption:
                      g.drawImage(RightArrowItem, 63, 202, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 165, 202, DefaultAnchor);
                      break;
                  case HelpOption:
                      g.drawImage(RightArrowItem, 63, 227, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 165, 227, DefaultAnchor);
                      break;
                  }
                  break;

              //**********************************************************************
              case NewGameSubstate:
                  g.drawImage(SubMenuBackground, 0, 0, DefaultAnchor);
                  DrawLine(59, 75, "Choose your level:", g);

                  DrawLine(103, 125, "Easy", g);
                  DrawLine(96, 150, "Normal", g);
                  DrawLine(104, 175, "Hard", g);
                  DrawLine(98, 225, "Cancel", g);

                  switch(SelOption) {
                  case EasyOption:
                      g.drawImage(RightArrowItem, 65, 127, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 163, 127, DefaultAnchor);
                      break;
                  case NormalOption:
                      g.drawImage(RightArrowItem, 65, 152, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 163, 152, DefaultAnchor);
                      break;
                  case HardOption:
                      g.drawImage(RightArrowItem, 65, 177, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 163, 177, DefaultAnchor);
                      break;
                  case ReturnOption:
                      g.drawImage(RightArrowItem, 65, 227, DefaultAnchor);
                      g.drawImage(LeftArrowItem, 163, 227, DefaultAnchor);
                      break;
                  }
                  break;

              //**********************************************************************
              case ScoresSubstate:
                  g.drawImage(SubMenuBackground, 0, 0, DefaultAnchor);
                  DrawLine(97, 42, "Scores", g);

                  String points;
                  int y = 76;
                  final int separation = 21;
                  for(int i = 0; i < MaxScores; i++) {
                      DrawLine(45, y, ScoreNames[i], g);
                      points = String.valueOf(ScorePoints[i]);
                      DrawLine(195 - GetLineWidth(points), y, points, g);
                      y += separation;
                  }
                  break;

              //**********************************************************************
              case OptionsSubstate:
                  g.drawImage(SubMenuBackground, 0, 0, DefaultAnchor);
                  DrawLine(95, 42, "Options", g);

                  DrawLine(70, 152, "Music", g);
                  if(SoundMusic.MusicEnable) {
                      DrawLine(160, 152, "On", g);
                  } else {
                      DrawLine(160, 152, "Off", g);
                  }
                  break;

              //**********************************************************************
              case CreditsSubstate:
                  g.drawImage(SubMenuBackground, 0, 0, DefaultAnchor);
                  DrawLine(97, 42, "Credits", g);

                  DrawLine(39, 76, "Programming & Graphics", g);
                  DrawLine(43, 97, "by Gorka Suárez García", g);

                  DrawLine(38, 139, "St Basils cathedral photo", g);
                  DrawLine(56, 160, "by David Crawshaw", g);

                  DrawLine(55, 202, "Mozart's K.448 midi", g);
                  DrawLine(44, 223, "by Hansjakob Heldstab", g);
                  break;

              //**********************************************************************
              case HelpSubstate:
                  g.drawImage(SubMenuBackground, 0, 0, DefaultAnchor);
                  DrawLine(105, 42, "Help", g);

                  DrawLine(50, 110, "Move:", g);
                  DrawLine(50, 135, "Turn:", g);
                  DrawLine(50, 160, "Down:", g);
                  DrawLine(50, 185, "Fall:", g);
                  DrawLine(50, 210, "Pause:", g);

                  DrawLine(150, 110, "4 & 6", g);
                  DrawLine(162, 135, "5", g);
                  DrawLine(162, 160, "8", g);
                  DrawLine(162, 185, "0", g);
                  DrawLine(162, 210, "#", g);
                  break;
              }
              break;

          case SetScoreState:
              g.drawImage(SubMenuBackground, 0, 0, DefaultAnchor);
              DrawLine(64, 110, "Write your name:", g);
              if(ShowUnderscore && Name.length() < MaxNameSize) {
                  DrawLine(60, 150, Name, g);
                  DrawChar(60 + GetLineWidth(Name), 150, SelectedChar, g);
              } else {
                  DrawLine(60, 150, Name, g);
              }
              break;

          case GameState:
              g.drawImage(GameBackground, 0, 0, DefaultAnchor);
              DrawLine(195, 175, LevelString, g);
              DrawLine(183, 225, LinesString, g);
              DrawLine(180, 275, PointsString, g);
              if(GameOver) {
                  DrawLine(59, 150, "Game Over", g);
              } else {
                  RenderWorld(g);
                  RenderPiece(g);
                  RenderNextPiece(g);
                  if(GamePaused) {
                      DrawLine(190, 110, "Game", g);
                      DrawLine(185, 126, "Paused", g);
                  }
              }
              break;
          }
      }catch(Exception e){
      }
    }

    //********************************************************************************
    // Logic
    //********************************************************************************

    /*
     * This is the main logic method.
     */
    public final static void Logic() {
        switch(State) {
        case IntroState:
            if(IsAnyKeyDown()) {
                // Goes to the main menu and initializes it.
                State = MenuState;
                SubState = MenuSubstate;
                SelOption = NewGameOption;
                KeyPressed = true;
                SoundThread.start();
            }
            break;

        case MenuState:
            if(!KeyPressed) {
                switch(SubState) {
                //********************************************************************
                case MenuSubstate:
                    if(IsKeyDown(KeyFire) || IsKeyDown(KeyNum5)) {
                        // Goes to the current selected sub-menu.
                        KeyPressed = true;
                        switch(SelOption) {
                        case NewGameOption:
                            SubState = NewGameSubstate;
                            SelOption = EasyOption;
                            break;
                        case ScoresOption:
                            SubState = ScoresSubstate;
                            break;
                        case OptionsOption:
                            SubState = OptionsSubstate;
                            break;
                        case CreditsOption:
                            SubState = CreditsSubstate;
                            break;
                        case HelpOption:
                            SubState = HelpSubstate;
                            break;
                        }
                    } else if(IsKeyDown(KeyUp) || IsKeyDown(KeyNum2)) {
                        // Select previous option.
                        KeyPressed = true;
                        if(SelOption > NewGameOption){
                            SelOption--;
                        } else {
                            SelOption = HelpOption;
                        }
                    } else if(IsKeyDown(KeyDown) || IsKeyDown(KeyNum8)) {
                        // Select next option.
                        KeyPressed = true;
                        if(SelOption < HelpOption) {
                            SelOption++;
                        } else {
                            SelOption = NewGameOption;
                        }
                    }
                    break;

                //********************************************************************
                case NewGameSubstate:
                    if(IsKeyDown(KeyFire) || IsKeyDown(KeyNum5)) {
                        KeyPressed = true;
                        boolean changeToGameState = false;
                        switch(SelOption) {
                        case EasyOption:
                            // Starts an easy game.
                            Level = 1;
                            changeToGameState = true;
                            break;
                        case NormalOption:
                            // Starts an normal game.
                            Level = 5;
                            changeToGameState = true;
                            break;
                        case HardOption:
                            // Starts an hard game.
                            Level = 10;
                            changeToGameState = true;
                            break;
                        case ReturnOption:
                            // Returns to the main menu.
                            SubState = MenuSubstate;
                            SelOption = NewGameOption;
                            break;
                        }
                        if(changeToGameState) {
                            // Initializes the game state.
                            State = GameState;
                            KeyPressed = true;
                            SpecialKeyPressed = true;
                            KeyTimeMark = System.currentTimeMillis();
                            Time = 0;
                            TimeMark = System.currentTimeMillis();
                            MaxInterval = MaxIntervals[Level - 1];
                            Lines = 0;
                            Points = 0;
                            Target = MaxLines[Level - 1];
                            InitWorld();
                            NextPiece = (byte)Rnd.nextInt(7);
                            GetNextPiece();
                            GameOver = false;
                            LevelString = String.valueOf(Level);
                            LinesString = String.valueOf(Lines);
                            PointsString = String.valueOf(Points);
                        }
                    } else if(IsKeyDown(KeyUp) || IsKeyDown(KeyNum2)) {
                        // Select previous option.
                        KeyPressed = true;
                        if(SelOption > EasyOption) {
                            SelOption--;
                        } else {
                            SelOption = ReturnOption;
                        }
                    } else if(IsKeyDown(KeyDown) || IsKeyDown(KeyNum8)) {
                        // Select next option.
                        KeyPressed = true;
                        if(SelOption < ReturnOption) {
                            SelOption++;
                        } else {
                            SelOption = EasyOption;
                        }
                    }
                    break;

                //********************************************************************
                case OptionsSubstate:
                    if(IsKeyDown(KeyFire) || IsKeyDown(KeyNum5)) {
                        // Returns to the main menu.
                        KeyPressed = true;
                        SubState = MenuSubstate;
                    } else if(IsKeyDown(KeyLeft) || IsKeyDown(KeyNum4) ||
                              IsKeyDown(KeyRight) || IsKeyDown(KeyNum6)) {
                        // Changes if the music is enabled or not.
                        KeyPressed = true;
                        SoundMusic.SetMusicEnable(!SoundMusic.MusicEnable);
                    }
                    break;

                //********************************************************************
                case ScoresSubstate:
                case CreditsSubstate:
                case HelpSubstate:
                    if(IsKeyDown(KeyFire) || IsKeyDown(KeyNum5)) {
                        // Returns to the main menu.
                        KeyPressed = true;
                        SubState = MenuSubstate;
                    }
                    break;
                }
            } else if(!IsAnyKeyDown()) {
                KeyPressed = false;
            }
            break;

        case SetScoreState:
            // This time control is used to make blink the selected character.
            Time += (System.currentTimeMillis() - TimeMark);
            if(Time >= MaxBlinkInterval) {
                ShowUnderscore = !ShowUnderscore;
                Time = 0;
            }
            if(!KeyPressed) {
                if(IsKeyDown(KeyUp)) {
                    // Select the previous character in the list.
                    if(Name.length() < MaxNameSize) {
                        KeyPressed = true;
                        if(('A' < SelectedChar && SelectedChar <= 'Z') ||
                           ('0' < SelectedChar && SelectedChar <= '9')) {
                            SelectedChar--;
                        } else if(SelectedChar == 'A') {
                            SelectedChar = '9';
                        } else if(SelectedChar == '0') {
                            SelectedChar = 'Z';
                        }
                    }
                } else if(IsKeyDown(KeyDown)) {
                    // Select the next character in the list.
                    if(Name.length() < MaxNameSize) {
                        KeyPressed = true;
                        if(('A' <= SelectedChar && SelectedChar < 'Z') ||
                           ('0' <= SelectedChar && SelectedChar < '9')) {
                            SelectedChar++;
                        } else if(SelectedChar == 'Z') {
                            SelectedChar = '0';
                        } else if(SelectedChar == '9') {
                            SelectedChar = 'A';
                        }
                    }
                } else if(IsKeyDown(KeyLeft)) {
                    // Erase the last character from the name.
                    if(Name.length() > 0) {
                        KeyPressed = true;
                        Name = Name.substring(0, Name.length() - 1);
                    }
                } else if(IsKeyDown(KeyRight)) {
                    // Adss the selected character to the name.
                    if(Name.length() < MaxNameSize) {
                        KeyPressed = true;
                        Name += SelectedChar;
                        SelectedChar = 'A';
                    }
                } else if(IsKeyDown(KeyFire)) {
                    if(Name.length() > 0) {
                        // Adds the new score and goes to the main menu.
                        KeyPressed = true;
                        AddScore(Name, Points);
                        State = MenuState;
                        SubState = MenuSubstate;
                        SelOption = NewGameOption;
                    }
                }
            } else if(!IsAnyKeyDown()) {
                KeyPressed = false;
            }
            TimeMark = System.currentTimeMillis();
            break;

        case GameState:
            if(GameOver) {
                // If the game is over, we'll wait to the next key pressed
                // to goes to the set score state.
                if(!KeyPressed) {
                    if(IsAnyKeyDown()) {
                        // Initializes the set score state.
                        State = SetScoreState;
                        KeyPressed = true;
                        Time = 0;
                        TimeMark = System.currentTimeMillis();
                        ShowUnderscore = true;
                        Name = "";
                        SelectedChar = 'A';
                    }
                } else if(!IsAnyKeyDown()) {
                    KeyPressed = false;
                }
            } else {
                if(!GamePaused) {
                    // When the game isn't paused, we'll control the time
                    // because pieces must go falling after some time.
                    Time += (System.currentTimeMillis() - TimeMark);
                    TimeMark = System.currentTimeMillis();

                    // Here we'll control the move left, right and down controls.
                    // We'll use the key pressed flag to avoid a lot of movements,
                    // but we also have to check how much time we have passed
                    // pressing the key, to allow some key pressed repetition.
                    if(!KeyPressed) {
                        if(IsKeyDown(KeyLeft) || IsKeyDown(KeyNum4)) {
                            MoveLeft();
                            KeyPressed = true;
                            KeyTimeMark = System.currentTimeMillis();
                        } else if(IsKeyDown(KeyRight) || IsKeyDown(KeyNum6)) {
                            MoveRight();
                            KeyPressed = true;
                            KeyTimeMark = System.currentTimeMillis();
                        }
                        if(IsKeyDown(KeyNum8) || IsKeyDown(KeyDown)) {
                            MoveDown();
                            KeyPressed = true;
                            KeyTimeMark = System.currentTimeMillis();
                        }
                    } else if(!IsAnyKeyDown() ||
                              (System.currentTimeMillis() - KeyTimeMark) > MaxKeyInterval) {
                        KeyPressed = false;
                    }

                    // Here we'll control the turn left and right, fall down and pause
                    // controls. We'll use the special key pressed flag to avoid any
                    // repetition, because we don't want to repeat any of this actions.
                    if(!SpecialKeyPressed) {
                        if(IsKeyDown(KeyNum3) || IsKeyDown(KeyNum5) || IsKeyDown(KeyFire)) {
                            TurnRight();
                            SpecialKeyPressed = true;
                        } else if(IsKeyDown(KeyNum1) || IsKeyDown(KeyNum2) || IsKeyDown(KeyUp)) {
                            TurnLeft();
                            SpecialKeyPressed = true;
                        }
                        if(IsKeyDown(KeyNum0)) {
                            FallDown();
                            SpecialKeyPressed = true;
                        }
                        if(IsKeyDown(KeyPound)) {
                            GamePaused = true;
                            SpecialKeyPressed = true;
                        }
                    } else if(!IsAnyKeyDown()) {
                        SpecialKeyPressed = false;
                    }

                    // And here after some time, the game move down the pice and
                    // start again the time process.
                    if(Time >= MaxInterval) {
                        MoveDown();
                        Time = 0;
                    }
                } else {
                    // When the game is paused, we'll check if the player press
                    // the right key to get back to the game.
                    if(!SpecialKeyPressed) {
                        if(IsKeyDown(KeyPound)) {
                            GamePaused = false;
                            SpecialKeyPressed = true;
                        }
                    } else if(!IsAnyKeyDown()) {
                        SpecialKeyPressed = false;
                    }
                }
            }
            break;
        }
    }

    //********************************************************************************
    // Game
    //********************************************************************************

    /*
     * Initializes the world data.
     */
    public final static void InitWorld() {
        int i, j;
        for(i = 0; i < WorldHeight; i++) {
            for(j = 0; j < WorldWidth; j++) {
                World[i][j] = Empty;
            }
        }
    }

    /*
     * Renders the world on the screen.
     */
    public final static void RenderWorld(Graphics g) {
        int i, j;
        for(i = 0; i < WorldHeight; i++) {
            for(j = 0; j < WorldWidth; j++) {
                if(World[i][j] != Empty) {
                    g.drawImage(Blocks[World[i][j]], j * BlockWidth + WorldStartX,
                                i * BlockHeight, DefaultAnchor);
                }
            }
        }
    }

    /*
     * Renders the next piece on the screen.
     */
    public final static void RenderNextPiece(Graphics g) {
        final int mx1 = 191;
        final int my1 = 46;
        final int my2 = 38;
        final int mx3 = 199;
        final int my3 = 30;

        switch(NextPiece) {
        case DarkBlue: g.drawImage(Blocks[0], mx1, my1, DefaultAnchor); break;
        case Yellow: g.drawImage(Blocks[8], mx1, my2, DefaultAnchor); break;
        case Murrey: g.drawImage(Blocks[20], mx1, my2, DefaultAnchor); break;
        case Orange: g.drawImage(Blocks[32], mx1, my2, DefaultAnchor); break;
        case LightBlue: g.drawImage(Blocks[42], mx1, my2, DefaultAnchor); break;
        case Green: g.drawImage(Blocks[52], mx1, my2, DefaultAnchor); break;
        case Red: g.drawImage(Blocks[65], mx3, my3, DefaultAnchor); break;
        }
    }

    /*
     * Gets the next piece as the current one and choose a new next piece.
     */
    public final static void GetNextPiece() {
        Piece = NextPiece;
        switch(Piece) {
        case DarkBlue: PieceX = 4; PieceY = 1; Orientation = 1; break;
        case Yellow: PieceX = 4; PieceY = 1; Orientation = 2; break;
        case Murrey: PieceX = 4; PieceY = 1; Orientation = 4; break;
        case Orange: PieceX = 4; PieceY = 0; Orientation = 2; break;
        case LightBlue: PieceX = 4; PieceY = 0; Orientation = 2; break;
        case Green: PieceX = 4; PieceY = 1; Orientation = 4; break;
        case Red: PieceX = 5; PieceY = 1; Orientation = 2; break;
        }
        NextPiece = (byte)Rnd.nextInt(7);
        if(CheckCollision()) GameOver = true;
    }

    /*
     * Renders the current piece on the screen.
     */
    public final static void RenderPiece(Graphics g) {
        switch(Piece) {
        case DarkBlue:
            g.drawImage(Blocks[4], PieceX * BlockWidth + WorldStartX,
                        (PieceY - 1) * BlockHeight, DefaultAnchor);
            g.drawImage(Blocks[5], (PieceX + 1) * BlockWidth + WorldStartX,
                        (PieceY - 1) * BlockHeight, DefaultAnchor);
            g.drawImage(Blocks[6], PieceX * BlockWidth + WorldStartX,
                        PieceY * BlockHeight, DefaultAnchor);
            g.drawImage(Blocks[7], (PieceX + 1) * BlockWidth + WorldStartX,
                        PieceY * BlockHeight, DefaultAnchor);
            break;

        case Yellow:
            switch(Orientation) {
            case 1:
                g.drawImage(Blocks[10], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[18], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[17], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[12], (PieceX - 1) * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                break;
            case 2:
                g.drawImage(Blocks[13], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[19], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[16], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[10], (PieceX - 1) * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                break;
            case 3:
                g.drawImage(Blocks[11], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[18], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[14], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[13], (PieceX + 1) * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                break;
            case 4:
                g.drawImage(Blocks[12], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[19],PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[15], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[11], (PieceX + 1) * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                break;
            }
            break;

        case Murrey:
            switch(Orientation) {
            case 1:
                g.drawImage(Blocks[22], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[30], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[28], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[25], (PieceX + 1) * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                break;
            case 2:
                g.drawImage(Blocks[25], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[31], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[26], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[23], (PieceX - 1) * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                break;
            case 3:
                g.drawImage(Blocks[23], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[30], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[27], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[24], (PieceX - 1) * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                break;
            case 4:
                g.drawImage(Blocks[24], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[31], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[29], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[22], (PieceX + 1) * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                break;
            }
            break;

        case Orange:
            switch(Orientation) {
            case 1:
                g.drawImage(Blocks[34], (PieceX + 1) * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[41], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[38], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[35], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                break;
            case 2:
                g.drawImage(Blocks[37], (PieceX + 1) * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[40], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[39], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[36], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                break;
            }
            break;

        case LightBlue:
            switch(Orientation) {
            case 1:
                g.drawImage(Blocks[45], (PieceX + 1) * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[49], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[50], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[44], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                break;
            case 2:
                g.drawImage(Blocks[46], (PieceX - 1) * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[51], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[48], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[47], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                break;
            }
            break;

        case Green:
            switch(Orientation) {
            case 1:
                g.drawImage(Blocks[54], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[61], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[55], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[57], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                break;
            case 2:
                g.drawImage(Blocks[56], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[62], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[57], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[55], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                break;
            case 3:
                g.drawImage(Blocks[54], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[63], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[55], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[56], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                break;
            case 4:
                g.drawImage(Blocks[56], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[64], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[57], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[54], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                break;
            }
            break;

        case Red:
            switch(Orientation) {
            case 1:
                g.drawImage(Blocks[67], PieceX * BlockWidth + WorldStartX,
                            (PieceY - 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[71], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[71], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 1) * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[68], PieceX * BlockWidth + WorldStartX,
                            (PieceY + 2) * BlockHeight, DefaultAnchor);
                break;
            case 2:
                g.drawImage(Blocks[69], (PieceX - 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[72], PieceX * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[72], (PieceX + 1) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                g.drawImage(Blocks[70], (PieceX + 2) * BlockWidth + WorldStartX,
                            PieceY * BlockHeight, DefaultAnchor);
                break;
            }
            break;
        }
    }

    /*
     * Checks a cell collision.
     */
    public final static boolean CheckCollision(int x, int y) {
        return (x < 0) || (x >= WorldWidth) ||
               (y < 0) || (y >= WorldHeight) ||
               (World[y][x] != Empty);
    }

    /*
     * Checks the current piece collision.
     */
    public final static boolean CheckCollision() {
        switch(Piece) {
        case DarkBlue:
            return CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX + 1, PieceY - 1) ||
                   CheckCollision(PieceX, PieceY) || CheckCollision(PieceX + 1, PieceY);
        case Yellow:
            switch(Orientation) {
            case 1:
                return CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX, PieceY + 1) || CheckCollision(PieceX - 1, PieceY + 1);
            case 2:
                return CheckCollision(PieceX + 1, PieceY) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX - 1, PieceY) || CheckCollision(PieceX - 1, PieceY - 1);
            case 3:
                return CheckCollision(PieceX, PieceY + 1) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX + 1, PieceY - 1);
            case 4:
                return CheckCollision(PieceX - 1, PieceY) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX + 1, PieceY) || CheckCollision(PieceX + 1, PieceY + 1);
            }
            break;
        case Murrey:
            switch(Orientation) {
            case 1:
                return CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX, PieceY + 1) || CheckCollision(PieceX + 1, PieceY + 1);
            case 2:
                return CheckCollision(PieceX + 1, PieceY) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX - 1, PieceY) || CheckCollision(PieceX - 1, PieceY + 1);
            case 3:
                return CheckCollision(PieceX, PieceY + 1) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX - 1, PieceY - 1);
            case 4:
                return CheckCollision(PieceX - 1, PieceY) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX + 1, PieceY) || CheckCollision(PieceX + 1, PieceY - 1);
            }
            break;
        case Orange:
            switch(Orientation) {
            case 1:
                return CheckCollision(PieceX + 1, PieceY - 1) || CheckCollision(PieceX + 1, PieceY) ||
                       CheckCollision(PieceX, PieceY) || CheckCollision(PieceX, PieceY + 1);
            case 2:
                return CheckCollision(PieceX + 1, PieceY + 1) || CheckCollision(PieceX, PieceY + 1) ||
                       CheckCollision(PieceX, PieceY) || CheckCollision(PieceX - 1, PieceY);
            }
            break;
        case LightBlue:
            switch(Orientation) {
            case 1:
                return CheckCollision(PieceX + 1, PieceY + 1) || CheckCollision(PieceX + 1, PieceY) ||
                       CheckCollision(PieceX, PieceY) || CheckCollision(PieceX, PieceY - 1);
            case 2:
                return CheckCollision(PieceX - 1, PieceY + 1) || CheckCollision(PieceX, PieceY + 1) ||
                       CheckCollision(PieceX, PieceY) || CheckCollision(PieceX + 1, PieceY);
            }
            break;
        case Green:
            switch(Orientation) {
            case 1:
                return CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX, PieceY + 1) || CheckCollision(PieceX + 1, PieceY);
            case 2:
                return CheckCollision(PieceX - 1, PieceY) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX + 1, PieceY) || CheckCollision(PieceX, PieceY + 1);
            case 3:
                return CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX, PieceY + 1) || CheckCollision(PieceX - 1, PieceY);
            case 4:
                return CheckCollision(PieceX - 1, PieceY) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX + 1, PieceY) || CheckCollision(PieceX, PieceY - 1);
            }
            break;
        case Red:
            switch(Orientation) {
            case 1:
                return CheckCollision(PieceX, PieceY - 1) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX, PieceY + 1) || CheckCollision(PieceX, PieceY + 2);
            case 2:
                return CheckCollision(PieceX - 1, PieceY) || CheckCollision(PieceX, PieceY) ||
                       CheckCollision(PieceX + 1, PieceY) || CheckCollision(PieceX + 2, PieceY);
            }
        }
        return false;
    }

    /*
     * Turns to the right the piece and checks the collisions.
     */
    public final static void TurnRight() {
        if(Piece != DarkBlue) {
            byte aux = Orientation; Orientation++;
            switch(Piece) {
            case Yellow: if(Orientation > 4) { Orientation = 1; } break;
            case Murrey: if(Orientation > 4) { Orientation = 1; } break;
            case Orange: if(Orientation > 2) { Orientation = 1; } break;
            case LightBlue: if(Orientation > 2) { Orientation = 1; } break;
            case Green: if(Orientation > 4) { Orientation = 1; } break;
            case Red: if(Orientation > 2) { Orientation = 1; } break;
            }
            if(CheckCollision()) { Orientation = aux; }
        }
    }

    /*
     * Turns to the left the piece and checks the collisions.
     */
    public final static void TurnLeft() {
        if(Piece != DarkBlue) {
            byte aux = Orientation; Orientation--;
            switch(Piece) {
            case Yellow: if(Orientation < 1) { Orientation = 4; } break;
            case Murrey: if(Orientation < 1) { Orientation = 4; } break;
            case Orange: if(Orientation < 1) { Orientation = 2; } break;
            case LightBlue: if(Orientation < 1) { Orientation = 2; } break;
            case Green: if(Orientation < 1) { Orientation = 4; } break;
            case Red: if(Orientation < 1) { Orientation = 2; } break;
            }
            if(CheckCollision()) { Orientation = aux; }
        }
    }

    /*
     * Move to the right the piece and checks the collisions.
     */
    public final static void MoveRight() {
        byte aux = PieceX; PieceX++;
        if(CheckCollision()) { PieceX = aux; }
    }

    /*
     * Move to the left the piece and checks the collisions.
     */
    public final static void MoveLeft() {
        byte aux = PieceX; PieceX--;
        if(CheckCollision()) { PieceX = aux; }
    }

    /*
     * Puts the current piece into the world. This is called when the
     * piece can't go more deeper into the world.
     */
    public final static void PutPieceIntoWorld() {
        switch(Piece) {
        case DarkBlue:
            World[PieceY - 1][PieceX] = 4; World[PieceY - 1][PieceX + 1] = 5;
            World[PieceY][PieceX] = 6; World[PieceY][PieceX + 1] = 7;
            break;
        case Yellow:
            switch(Orientation) {
            case 1:
                World[PieceY - 1][PieceX] = 10; World[PieceY][PieceX] = 18;
                World[PieceY + 1][PieceX] = 17; World[PieceY + 1][PieceX - 1] = 12;
                break;
            case 2:
                World[PieceY][PieceX + 1] = 13; World[PieceY][PieceX] = 19;
                World[PieceY][PieceX - 1] = 16; World[PieceY - 1][PieceX - 1] = 10;
                break;
            case 3:
                World[PieceY + 1][PieceX] = 11; World[PieceY][PieceX] = 18;
                World[PieceY - 1][PieceX] = 14; World[PieceY - 1][PieceX + 1] = 13;
                break;
            case 4:
                World[PieceY][PieceX - 1] = 12; World[PieceY][PieceX] = 19;
                World[PieceY][PieceX + 1] = 15; World[PieceY + 1][PieceX + 1] = 11;
                break;
            }
            break;
        case Murrey:
            switch(Orientation) {
            case 1:
                World[PieceY - 1][PieceX] = 22; World[PieceY][PieceX] = 30;
                World[PieceY + 1][PieceX] = 28; World[PieceY + 1][PieceX + 1] = 25;
                break;
            case 2:
                World[PieceY][PieceX + 1] = 25; World[PieceY][PieceX] = 31;
                World[PieceY][PieceX - 1] = 26; World[PieceY + 1][PieceX - 1] = 23;
                break;
            case 3:
                World[PieceY + 1][PieceX] = 23; World[PieceY][PieceX] = 30;
                World[PieceY - 1][PieceX] = 27; World[PieceY - 1][PieceX - 1] = 24;
                break;
            case 4:
                World[PieceY][PieceX - 1] = 24; World[PieceY][PieceX] = 31;
                World[PieceY][PieceX + 1] = 29; World[PieceY - 1][PieceX + 1] = 22;
                break;
            }
            break;
        case Orange:
            switch(Orientation) {
            case 1:
                World[PieceY - 1][PieceX + 1] = 34; World[PieceY][PieceX + 1] = 41;
                World[PieceY][PieceX] = 38; World[PieceY + 1][PieceX] = 35;
                break;
            case 2:
                World[PieceY + 1][PieceX + 1] = 37; World[PieceY + 1][PieceX] = 40;
                World[PieceY][PieceX] = 39; World[PieceY][PieceX - 1] = 36;
                break;
            }
            break;
        case LightBlue:
            switch(Orientation) {
            case 1:
                World[PieceY + 1][PieceX + 1] = 45; World[PieceY][PieceX + 1] = 49;
                World[PieceY][PieceX] = 50; World[PieceY - 1][PieceX] = 44;
                break;
            case 2:
                World[PieceY + 1][PieceX - 1] = 46; World[PieceY + 1][PieceX] = 51;
                World[PieceY][PieceX] = 48; World[PieceY][PieceX + 1] = 47;
                break;
            }
            break;
        case Green:
            switch(Orientation) {
            case 1:
                World[PieceY - 1][PieceX] = 54; World[PieceY][PieceX] = 61;
                World[PieceY + 1][PieceX] = 55; World[PieceY][PieceX + 1] = 57;
                break;
            case 2:
                World[PieceY][PieceX - 1] = 56; World[PieceY][PieceX] = 62;
                World[PieceY][PieceX + 1] = 57; World[PieceY + 1][PieceX] = 55;
                break;
            case 3:
                World[PieceY - 1][PieceX] = 54; World[PieceY][PieceX] = 63;
                World[PieceY + 1][PieceX] = 55; World[PieceY][PieceX - 1] = 56;
                break;
            case 4:
                World[PieceY][PieceX - 1] = 56; World[PieceY][PieceX] = 64;
                World[PieceY][PieceX + 1] = 57; World[PieceY - 1][PieceX] = 54;
                break;
            }
            break;
        case Red:
            switch(Orientation) {
            case 1:
                World[PieceY - 1][PieceX] = 67; World[PieceY][PieceX] = 71;
                World[PieceY + 1][PieceX] = 71; World[PieceY + 2][PieceX] = 68;
                break;
            case 2:
                World[PieceY][PieceX - 1] = 69; World[PieceY][PieceX] = 72;
                World[PieceY][PieceX + 1] = 72; World[PieceY][PieceX + 2] = 70;
                break;
            }
            break;
        }
    }

    /*
     * Cheks if a line is completly.
     */
    public final static boolean CheckLine(int line) {
        for(int i = 0; i < WorldWidth; i++) {
            if(World[line][i] == Empty)
                return false;
        }
        return true;
    }

    /*
     * Checks and change the upper cell when we have to erase one.
     */
    public final static void CheckUpperCell(int i, int j) {
        switch(World[i - 1][j]) {
        //DarkBlue
        case 4: World[i - 1][j] = 2; break;
        case 5: World[i - 1][j] = 3; break;
        //Yellow
        case 10: World[i - 1][j] = 9; break;
        case 14: World[i - 1][j] = 12; break;
        case 15: World[i - 1][j] = 13; break;
        case 18: World[i - 1][j] = 11; break;
        //Murrey
        case 22: World[i - 1][j] = 21; break;
        case 26: World[i - 1][j] = 24; break;
        case 27: World[i - 1][j] = 25; break;
        case 30: World[i - 1][j] = 23; break;
        //Orange
        case 34: World[i - 1][j] = 33; break;
        case 38: World[i - 1][j] = 36; break;
        case 39: World[i - 1][j] = 37; break;
        //LightBlue
        case 44: World[i - 1][j] = 43; break;
        case 48: World[i - 1][j] = 46; break;
        case 49: World[i - 1][j] = 47; break;
        //Green
        case 54: World[i - 1][j] = 53; break;
        case 61: World[i - 1][j] = 58; break;
        case 62: World[i - 1][j] = 60; break;
        case 63: World[i - 1][j] = 59; break;
        case 73: World[i - 1][j] = 56; break;
        case 74: World[i - 1][j] = 57; break;
        //Red
        case 67: World[i - 1][j] = 66; break;
        case 71: World[i - 1][j] = 68; break;
        }
    }

    /*
     * Checks and change the bottom cell when we have to erase one.
     */
    private final static void CheckBottomCell(int i, int j) {
        switch(World[i + 1][j]) {
        //DarkBlue
        case 6: World[i + 1][j] = 2; break;
        case 7: World[i + 1][j] = 3; break;
        //Yellow
        case 11: World[i + 1][j] = 9; break;
        case 16: World[i + 1][j] = 12; break;
        case 17: World[i + 1][j] = 13; break;
        case 18: World[i + 1][j] = 10; break;
        //Murrey
        case 23: World[i + 1][j] = 21; break;
        case 28: World[i + 1][j] = 24; break;
        case 29: World[i + 1][j] = 25; break;
        case 30: World[i + 1][j] = 22; break;
        //Orange
        case 35: World[i + 1][j] = 33; break;
        case 40: World[i + 1][j] = 36; break;
        case 41: World[i + 1][j] = 37; break;
        //LightBlue
        case 45: World[i + 1][j] = 43; break;
        case 50: World[i + 1][j] = 46; break;
        case 51: World[i + 1][j] = 47; break;
        //Green
        case 55: World[i + 1][j] = 53; break;
        case 58: World[i + 1][j] = 56; break;
        case 59: World[i + 1][j] = 57; break;
        case 61: World[i + 1][j] = 73; break;
        case 63: World[i + 1][j] = 74; break;
        case 64: World[i + 1][j] = 60; break;
        //Red
        case 68: World[i + 1][j] = 66; break;
        case 71: World[i + 1][j] = 67; break;
        }
    }

    /*
     * Erases a selected completed line.
     */
    public final static void EraseLine(int line) {
        int i, j;
        // First, clear the upper and bottom lines.
        if(line < 1) {
            for(i = 0; i < WorldWidth; i++) {
                CheckBottomCell(line, i);
            }
        } else if(line > 18) {
            for(i = 0; i < WorldWidth; i++) {
                CheckUpperCell(line, i);
            }
        } else {
            for(i = 0; i < WorldWidth; i++) {
                CheckUpperCell(line, i);
                CheckBottomCell(line, i);
            }
        }
        // And then move down all the upper lines.
        for(i = line; i > 0; i--) {
            for(j = 0; j < WorldWidth; j++) {
                World[i][j] = World[i - 1][j];
            }
        }
        for(j = 0; j < WorldWidth; j++) {
            World[0][j] = Empty;
        }
    }

    /*
     * Checks all the lines in the world to update the score.
     */
    public final static void CheckLines() {
        int numLinesErased = 0;
        int accumPoints = 0;
        // First, find the completed lines to erase them.
        for(int i = 0; i < WorldHeight; i++) {
            if(CheckLine(i)) {
                EraseLine(i);
                numLinesErased++;
                accumPoints += LinePoints[Level - 1];
            }
        }
        // When we erase 4 lines, a special bonus is set.
        if(numLinesErased >= 4) {
            accumPoints *= 2;
        }
        // And here we'll update the score.
        Lines += numLinesErased;
        Points += accumPoints;
        LinesString = String.valueOf(Lines);
        PointsString = String.valueOf(Points);
        // If the number of lines are greater than the target,
        // we'll get to the next level.
        if(Lines > Target) {
            Level++;
            MaxInterval = MaxIntervals[Level - 1];
            Target += MaxLines[Level - 1];
            LevelString = String.valueOf(Level);
        }
    }

    /*
     * Move down the piece and checks the collisions.
     */
    public final static void MoveDown() {
        byte aux = PieceY; PieceY++;
        if(CheckCollision()) {
            PieceY = aux;
            PutPieceIntoWorld();
            CheckLines();
            GetNextPiece();
        }
    }

    /*
     * This makes fall down a piece into the bottom of the world.
     */
    public final static void FallDown() {
        byte aux;
        do{
            aux = PieceY; PieceY++;
        } while(!CheckCollision());
        PieceY = aux;
        PutPieceIntoWorld();
        CheckLines();
        GetNextPiece();
    }
}
