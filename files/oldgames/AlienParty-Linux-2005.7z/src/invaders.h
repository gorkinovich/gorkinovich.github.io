//******************************************************************************************
// Alien Party is a space 2D shooter videogame.
// Copyright (C) 2005  Gorka Su�rez Garc�a
//
// invaders.h is part of Alien Party.
// 
// Alien Party is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// Alien Party is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Alien Party; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//******************************************************************************************
#ifndef _INVADERS_H_
#define _INVADERS_H_
//******************************************************************************************
#ifdef WIN32
#pragma comment (lib, "SDL.lib")
#pragma comment (lib, "SDLmain.lib")
#endif
//******************************************************************************************
#include <SDL/SDL.h>
//------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

//******************************************************************************************
// Constantes
//******************************************************************************************
#define TRUE   1 // Constante para indicar Cierto.
#define FALSE  0 // Constante para indicar Falso.
#define FAIL  -1 // Constante para indicar Fallo.
//------------------------------------------------------------------------------------------
#define STREQU 0
//------------------------------------------------------------------------------------------
#define BOTON_IZQUIERDO 1
#define BOTON_CENTRAL   2
#define BOTON_DERECHO   3
#define RUEDA_ARRIBA    4
#define RUEDA_ABAJO     5
//------------------------------------------------------------------------------------------
#define CCROSA 0x00FF00FF
//------------------------------------------------------------------------------------------
#define MAXNAM 11 // Tama�o m�ximo de los nombres de los jugadores.
#define MAXPUN 10 // Tama�o m�ximo de la tabla de puntuaciones.
#define MAXNAV 33 // N�mero m�ximo de naves en la pantalla.
//------------------------------------------------------------------------------------------
#define MAXMAL  2 // N�mero de texturas de los enemigos.
#define MAXDIS  8 // N�mero de texturas de los disparos.
#define MAXFNT 37 // N�mero de caracteres de la fuente.
#define MAXOPC  4 // N�mero de texturas de las opciones.
//------------------------------------------------------------------------------------------
#define ESTMNU 0 // Estado de Men� de nueva partida.
#define ESTJUG 1 // Estado de Juego.
#define ESTOPC 2 // Estado de Pantalla de opciones.
#define ESTPUN 3 // Estado de Pantalla de puntuaciones.
#define ESTSAL 4 // Estado de Salida del juego.
#define ESTCON 5 // Estado de Men� de continuaci�n de partida.
#define ESTNOM 6 // Estado de Pantalla para meter el nombre.
//------------------------------------------------------------------------------------------
#define VIVO   1 // El jugador est� vivo.
#define MUERTO 0 // El jugador est� muerto.
//------------------------------------------------------------------------------------------
#define DSPENE 0 // Disparo del enemigo. Van hacia abajo.
#define DSPJUG 1 // Disparo del jugador. Van hacia arriba.
//------------------------------------------------------------------------------------------
#define LASER1 0 // Laser verde.
#define LASER2 2 // Laser rojo.
#define BOMBA1 4 // Bomba para abajo.
#define BOMBA2 5 // Bomba para arriba.
#define RAYOE1 6 // Rayo de Energia.
#define RAYOE2 7 // Rayo de Energia.
//------------------------------------------------------------------------------------------
#define TMPMIN 40
#define TMPMAX 50
//------------------------------------------------------------------------------------------
#define DIRIZQ 0 // Direcci�n izquierda.
#define DIRDER 1 // Direcci�n derecha.
#define MAXDIR 2 // N�mero m�ximo de direcciones.
//------------------------------------------------------------------------------------------
#define DESNAV 8 // N�mero de pixels que se pueden desplazar las naves en un tick.
#define DESDIS 8 // N�mero de pixels que se pueden desplazar los disparos en un tick.
//------------------------------------------------------------------------------------------
#define PAREDDE 672 // M�ximo x para el jugador.
#define PAREDIZ  64 // M�nimo x para el jugador.
#define PAREDD2 680 // M�ximo x para los enemigos.
#define PAREDI2  56 // M�nimo x para los enemigos.
#define PAREDAR  16 // M�nimo y para las entidades.
#define PAREDAB 536 // M�ximo y para las entidades.
//------------------------------------------------------------------------------------------
#define CNTMAXINI  25 // CuentaMax inicial para una nueva partida.
#define JUGXINI   368 // Coordenada X inicial del jugador.
#define JUGYINI   504 // Coordenada Y inicial del jugador.
#define JUGVIDINI 100 // Vida inicial del jugador.
#define JUGTEXINI   0 // Textura del jugador.
#define JUGFRCINI   0 // Frecuencia de disparo del jugador.
//------------------------------------------------------------------------------------------
#define ENEXBASE   88 // Coordenada X base del enemigo.
#define ENEYBASE   64 // Coordenada Y base del enemigo.
#define ENEXSEP    80 // Separaci�n en el eje X entre enemigos.
#define ENEYSEP    80 // Separaci�n en el eje Y entre enemigos.
#define ENEVIDINI  10 // Vida inicial del enemigo.
#define ENFTEXINI   0 // Textura del enemigo f�cil.
#define ENDTEXINI   1 // Textura del enemigo dif�cil.
#define ENFFRCINI  16 // Frecuencia de disparo del enemigo f�cil.
#define ENDFRCINI  32 // Frecuencia de disparo del enemigo dif�cil.
//------------------------------------------------------------------------------------------
#define DISLAXBASI  4 // Coordenada X base para el disparo laser a la izquierda.
#define DISLAXBASD 52 // Coordenada X base para el disparo laser a la derecha.
#define DISLAYBASE 16 // Coordenada Y base para el disparo laser del enemigo.
#define DISLAYBASJ 16 // Coordenada Y base para el disparo laser del jugador.
#define DISLADANYO 20 // Da�o m�ximo del disparo con arma laser.
//------------------------------------------------------------------------------------------
#define NAVESANCHO 64 // Ancho de las naves.
#define NAVESALTO  64 // Alto de las naves.
#define NAVESALTOE 32 // Altura donde es efectiva las colisiones.

//******************************************************************************************
// Tipos
//******************************************************************************************
typedef struct
{
	int x;  //Coordenada absoluta X
	int y;  //Coordenada absoluta Y
	int rx; //Coordenada relativa X
	int ry; //Coordenada relativa Y
	int lb; //Estado del boton izquierdo
	int cb; //Estado del boton central
	int rb; //Estado del boton derecho
	int wu; //Indica si la rueda del raton se ha movido hacia arriba
	int wd; //Indica si la rueda del raton se ha movido hacia abajo
} tMouseState;
//------------------------------------------------------------------------------------------
typedef struct
{
	char nombre[MAXNAM]; // Mombre del jugador.
	int  puntos;         // Puntuaci�n del jugador.
} tPuntuacion;
//------------------------------------------------------------------------------------------
typedef struct
{
	int x, y; // Coordenadas.
	int vida; // Energ�a o vida.
	int tex;  // Textura.
	int arma; // Tipo de arma.
	int frec; // Frecuencia con la que dispara, expresada con un porcentaje.
} tNave;
//------------------------------------------------------------------------------------------
typedef struct tNodoDisp
{
	int x, y;  // Coordenadas.
	int danyo; // Nivel de da�o que ejerce.
	int vel;   // Velocidad.
	int tex;   // Textura.
	int bando; // Disparo efectuado por quien.

	struct tNodoDisp * ant;
	struct tNodoDisp * sig;
} tDisparo;
//------------------------------------------------------------------------------------------
typedef struct
{
	//--------------------------------------------------------------------------------------
	// Texturas del juego.
	//--------------------------------------------------------------------------------------
	SDL_Surface * imgMenu;
	SDL_Surface * imgPuntuaciones;
	SDL_Surface * imgFondo;
	SDL_Surface * imgOpcion01;
	SDL_Surface * imgOpcion02;
	SDL_Surface * imgOpcion03;
	SDL_Surface * imgOpcion04;
	SDL_Surface * imgOpcion05;
	SDL_Surface * imgOpcion06;
	SDL_Surface * imgSpike;
	SDL_Surface * imgMalosos;
	SDL_Surface * imgDisparos;

	//--------------------------------------------------------------------------------------
	// Regiones dentro de las texturas.
	//--------------------------------------------------------------------------------------
	SDL_Rect Malosos[MAXMAL];
	SDL_Rect Disparos[MAXDIS];
	SDL_Rect Opciones[MAXOPC];
} tTexturas;
//------------------------------------------------------------------------------------------
typedef struct
{
	//--------------------------------------------------------------------------------------
	// Texturas de las fuentes.
	//--------------------------------------------------------------------------------------
	SDL_Surface * imgFuente01;
	SDL_Surface * imgFuente02;

	//--------------------------------------------------------------------------------------
	// Vector con la posici�n de cada letra en la fuente.
	//--------------------------------------------------------------------------------------
	SDL_Rect Fuente[MAXFNT];
} tFuentes;
//------------------------------------------------------------------------------------------
typedef struct
{
	//--------------------------------------------------------------------------------------
	// Datos de las naves.
	//--------------------------------------------------------------------------------------
	tNave Naves[MAXNAV]; // Naves en la partida.
	tDisparo * Disparos; // Disparos en la partida.

	int  Direccion; // Direcci�n hacia donde se dirigen actualmente las naves.

	//--------------------------------------------------------------------------------------
	// Seguimiento del tiempo.
	//--------------------------------------------------------------------------------------
	int  TiempoAcumulado; // Tiempo acumulado entre un tick de la l�gica y el siguiente.

	int  CuentaMax; // N�mero m�ximo de ticks antes del siguiente movimiento de los enemigos.
	int  CuentaAct; // N�mero actual de ticks antes del siguiente movimiento de los enemigos.

	//--------------------------------------------------------------------------------------
	// Estado del juego y la partida.
	//--------------------------------------------------------------------------------------
	int  EstadoDelJuego; // Estado del juego.
	int  EstadoJugador;  // Estado de la partida.

	//--------------------------------------------------------------------------------------
	// Datos del jugador.
	//--------------------------------------------------------------------------------------
	char Nombre[MAXNAM]; // Nombre del jugador actual.
	int  Puntos;         // Puntuaci�n del jugador actual.
} tPartida;
//------------------------------------------------------------------------------------------
typedef struct
{
	//--------------------------------------------------------------------------------------
	// Buffer de principal de la pantalla.
	//--------------------------------------------------------------------------------------
	SDL_Surface * BufferPantalla;

	//--------------------------------------------------------------------------------------
	// Datos de la entrada.
	//--------------------------------------------------------------------------------------
	Uint8 *     Teclado;
	tMouseState Raton;
	
	//--------------------------------------------------------------------------------------
	// Datos del juego.
	//--------------------------------------------------------------------------------------
	tTexturas Texturas; // Texturas del juego.
	tFuentes Fuentes;   // Fuentes del juego.
	tPartida Partida;   // Datos de la partida.

	//--------------------------------------------------------------------------------------
	// Puntuaciones m�ximas.
	//--------------------------------------------------------------------------------------
	tPuntuacion Puntuaciones[MAXPUN];
} tNucleo;

//******************************************************************************************
#endif
//******************************************************************************************
// Fin invaders.h
//******************************************************************************************
