/*-------------------------------------------------------------------------------*
 * Gusano e Version Beta 1.3 - Es el juego cl�sico de la serpiente.              *
 * Copyright (C) 2001  Gorka Su�rez Garc�a                                       *
 *                                                                               *
 * This program is free software; you can redistribute it and/or                 *
 * modify it under the terms of the GNU General Public License                   *
 * as published by the Free Software Foundation; either version 2                *
 * of the License, or (at your option) any later version.                        *
 *                                                                               *
 * This program is distributed in the hope that it will be useful,               *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 *
 * GNU General Public License for more details.                                  *
 *                                                                               *
 * You should have received a copy of the GNU General Public License             *
 * along with this program; if not, write to the Free Software                   *
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.   *
 *-------------------------------------------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif
/*--------------------------------------------------------------------------*/
/* Librerias:
 */
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <dos.h>
/*--------------------------------------------------------------------------*/
/* Constantes de direcci�n:
 */
#define N   1
#define E   2
#define S   3
#define W   4
/* Constantes de las teclas:
 */
#define DE    77
#define IZ    75
#define ESC   27
/* Constantes de Pant:
 */
#define IMG      0
#define TCOLOR   1
#define BCOLOR   2
/* Skins:
 */
#define GUSANOSKIN   '*'
#define TOMATESKIN   'O'
/* Constantes l�gicas:
 */
#define SI   1
#define NO   0
/* Constantes de los colores:
 */
#define NEGRO             0
#define AZUL              1
#define VERDE             2
#define CYAN              3
#define ROJO              4
#define ROSA              5
#define MARRON            6
#define GRISBRILLANTE     7
#define GRISOSCURO        8
#define AZULBRILLANTE     9
#define VERDEBRILLANTE   10
#define CYANBRILLANTE    11
#define ROJOBRILLANTE    12
#define ROSABRILLANTE    13
#define AMARILLO         14
#define BLANCO           15
#define BLANCOGRIS       16

#define TIEMPOMAXMENS 20

/* Constantes del tiempo:
 */
#define TIEMPOFACIL  200
#define TIEMPONORMAL 150
#define TIEMPOCHUNGO 100
/*--------------------------------------------------------------------------*/
/* Estructuras:
 */
typedef struct Cacho{
   int x;
   int y;
   struct Cacho * Siguiente;
}Cacho;
/*--------------------------------------------------------------------------*/
/*
 */
char Pant[3][20][70];
Cacho *Gusano;
Cacho *Final;
int NumTomates;
int Vivo;
int Mirando;
int Puntuacion;
int TiempoMens;
int Mensaje;
int Tiempo;
/*--------------------------------------------------------------------------*/
/*
 */
void Pausa(void)
{
 printf("\n\n");
 printf("Pulsa una tecla para continuar...");
 getch();
}

void Memerr(void)
{
 textcolor(BLANCOGRIS);
 textbackground(NEGRO);
 clrscr();
 printf("\aError por falta de memoria!!!\n");
 printf("El programa se cerrara.\n");
 Pausa();
 exit(-1);
}
/*--------------------------------------------------------------------------*/
/*
 */
void PseudoMenu(void)
{
 Tiempo = NO;
 clrscr();
 textcolor(AMARILLO);
 textbackground(AZUL);
 cprintf("                                                                               "); printf("\n");
 cprintf("       Bienvenido al juego del gusano e!!!                                     "); printf("\n");
 cprintf("       ===================================                                     "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 cprintf("  Esto es muy f�cil. e, el gusano mascota de Pi, tiene que                     "); printf("\n");
 cprintf("  comerse a los tomates malignos de Chanquete el Malote.                       "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 cprintf("  Para ello no deber�, chocar contra la pared electrificada.                   "); printf("\n");
 cprintf("  Se puede mover a la derecha o a la izquierda con las flechas,                "); printf("\n");
 cprintf("  o dejar que sigua palante, porque es un gusano muy vago, como                "); printf("\n");
 cprintf("  yo, y tambi�n, porque cuando le apresaron los zombis de                      "); printf("\n");
 cprintf("  Chanquete, le hicieron escuchar las canciones de Tamara.                     "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 cprintf("  Que te sea leve !!!sauj sauj sauj                                            "); printf("\n");
 cprintf("  Gorka Su�rez Garc�a, 5-12-2000.                                              "); printf("\n");
 cprintf("  (Mejorado el 11-11-2001, Version Beta 1.3)                                   "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 cprintf("  Pulsa para Facil: 1, Normal: 2, Chungo: 3                                    "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 cprintf("                                                                               "); printf("\n");
 do{
    switch(getch())
    {
     case '1':
	Tiempo = TIEMPOFACIL;
	break;
     case '2':
	Tiempo = TIEMPONORMAL;
	break;
     case '3':
	Tiempo = TIEMPOCHUNGO;
	break;
     case 0:
	if(getch() == ESC) exit(0);
    }
 }while(!Tiempo);
}
/*--------------------------------------------------------------------------*/
/* Pinta un caracter en la pantalla.
 */
void Print(char Car, int TC, int BC)
{
 textcolor(TC);
 textbackground(BC);
 cprintf("%c", Car);
}

void PonMens(void)
{
 textcolor(AMARILLO);
 textbackground(NEGRO);
 switch(Mensaje)
 {
  case 1:
     cprintf("Se un matxote y enfrentate a tu destino...                                          ");
     break;
  case 2:
     cprintf("Prueba otra tecla, kesta ta ataska...                                               ");
     break;
  case 3:
     cprintf("No se que decir!!!                                                                  ");
     break;
  case 4:
     cprintf("Peperrr!!!                                                                          ");
     break;
  case 5:
     cprintf("No cambie, no cambieee, no cambieeeee...                                            ");
     break;
  case 6:
     cprintf("Jaich!!!                                                                            ");
     break;
  case 7:
     cprintf("Tito... Tito...                                                                     ");
     break;
  case 8:
     cprintf("Se\xA4or X                                                                             ");
     break;
  case 9:
     cprintf("Cuidado e...                                                                        ");
     break;
  case 10:
     cprintf("Confiamos en ti e...                                                                ");
     break;
  case 11:
     cprintf("Vine de Andorra...                                                                  ");
     break;
  case 12:
     cprintf("Pozi!!!                                                                             ");
     break;
 }
 printf("\n");
}
/*--------------------------------------------------------------------------*/
/* Vuelca el buffer al monitor.
 */
void VerPant(void)
{
 register i, j;

 gotoxy(1,1);
 for(i = 0; i < 20; i++)
 {
  for(j = 0; j < 70; j++)
     Print(Pant[IMG][i][j], (int)Pant[TCOLOR][i][j], (int)Pant[BCOLOR][i][j]);
  printf("\n");
 }

 if(TiempoMens == TIEMPOMAXMENS)
 {
  gotoxy(1,21);
  PonMens();
 }
 textcolor(AMARILLO);
 textbackground(NEGRO);
 gotoxy(1,22);
 cprintf("Puntuaci�n: %d", Puntuacion);
}
/*--------------------------------------------------------------------------*/
/* Modulos de iniciaci�n y finalizaci�n del juego:
 */
void InitPant(void)
{
 register i, j;

 Pant[IMG][0][0] = '\xC9';
 Pant[TCOLOR][0][0] = NEGRO;
 Pant[BCOLOR][0][0] = ROJO;

 for(j = 1; j < 69; j++)
 {
  Pant[IMG][0][j] = '\xCD';
  Pant[TCOLOR][0][j] = NEGRO;
  Pant[BCOLOR][0][j] = ROJO;
 }

 Pant[IMG][0][69] = '\xBB';
 Pant[TCOLOR][0][69] = NEGRO;
 Pant[BCOLOR][0][69] = ROJO;


 for(i = 1; i < 19; i++)
 {
  Pant[IMG][i][0] = '\xBA';
  Pant[TCOLOR][i][0] = NEGRO;
  Pant[BCOLOR][i][0] = ROJO;

  for(j = 1; j < 69; j++)
  {
   Pant[IMG][i][j] = ' ';
   Pant[TCOLOR][i][j] = NEGRO;
   Pant[BCOLOR][i][j] = BLANCOGRIS;
  }

   Pant[IMG][i][69] = '\xBA';
   Pant[TCOLOR][i][69] = NEGRO;
   Pant[BCOLOR][i][69] = ROJO;
 }


 Pant[IMG][19][0] = '\xC8';
 Pant[TCOLOR][19][0] = NEGRO;
 Pant[BCOLOR][19][0] = ROJO;

 for(j = 1; j < 69; j++)
 {
  Pant[IMG][19][j] = '\xCD';
  Pant[TCOLOR][19][j] = NEGRO;
  Pant[BCOLOR][19][j] = ROJO;
 }

 Pant[IMG][19][69] = '\xBC';
 Pant[TCOLOR][19][69] = NEGRO;
 Pant[BCOLOR][19][69] = ROJO;
}

void AnadirCacho(int nx, int ny)
{
 Cacho *Sig;

 Final->Siguiente = (Cacho *) malloc(sizeof(Cacho));
 if(!Final->Siguiente) Memerr();
 Sig = Final->Siguiente;
 Sig->x = nx;
 Sig->y = ny;
 Final = Sig;
 Final->Siguiente = NULL;
}                             

void InitGusano(void)
{
 register i;

 Gusano = (Cacho *) malloc(sizeof(Cacho));
 if(!Gusano) Memerr();
 Final = Gusano;
 Final->x = 30;
 Final->y = 10;
 Final->Siguiente = NULL;
 Pant[IMG][Final->y][Final->x] = GUSANOSKIN;
 Pant[TCOLOR][Final->y][Final->x] = VERDE;
 Pant[BCOLOR][Final->y][Final->x] = NEGRO;

 for(i = 0; i < 3; i++)
 {
  AnadirCacho(Final->x + 1, Final->y);
  Pant[IMG][Final->y][Final->x] = GUSANOSKIN;
  Pant[TCOLOR][Final->y][Final->x] = VERDE;
  Pant[BCOLOR][Final->y][Final->x] = NEGRO;
 }
}

void InitJuego(void)
{
 InitPant();
 InitGusano();
 Vivo = SI;
 Mirando = N;
 NumTomates = 0;
 Puntuacion = 0;
 TiempoMens = 0;
}

void FinJuego(void)
{
 Final = Gusano;
 while(Gusano)
 {
  Gusano = Gusano->Siguiente;
  free(Final);
  Final = Gusano;
 }
}
/*--------------------------------------------------------------------------*/
/* M�dulo que mete los tomates malignos:
 */
void MeterTomates(void)
{
 int Repetir, x, y;
 register i;
 randomize();
 for(i = 0; i < 4; i++)
 {
  do{
     Repetir = NO;
     x = random(69) + 1;
     y = random(19) + 1;
     if(Pant[IMG][y][x] != ' ')
        Repetir = SI;
  }while(Repetir);
  Pant[IMG][y][x] = TOMATESKIN;
  Pant[TCOLOR][y][x] = ROJO;
  Pant[BCOLOR][y][x] = NEGRO;
  NumTomates++;
 }
}                      
/*--------------------------------------------------------------------------*/
/* M�dulos p� manej� er gusano:
 */
void Avanzar(int incx, int incy)
{
 int x, x2, y, y2;
 Final = Gusano;
 while(Final->Siguiente)
 {
  Final = Final->Siguiente;
 }
 Pant[IMG][Final->y][Final->x] = ' ';
 Pant[TCOLOR][Final->y][Final->x] = NEGRO;
 Pant[BCOLOR][Final->y][Final->x] = BLANCOGRIS;

 Final = Gusano;
 if(Final)
 {
  x = Final->x + incx;
  y = Final->y + incy;
 }
 while(Final)
 {
  x2 = Final->x;
  y2 = Final->y;
  Final->x = x;
  Final->y = y;
  x = x2;
  y = y2;
  Final = Final->Siguiente;
 }
 Pant[IMG][Gusano->y][Gusano->x] = GUSANOSKIN;
 Pant[TCOLOR][Gusano->y][Gusano->x] = VERDE;
 Pant[BCOLOR][Gusano->y][Gusano->x] = NEGRO;
}

void Crecer(int x, int y)
{
 Cacho *aux = (Cacho *) malloc(sizeof(Cacho));
 if(!aux) Memerr();
 aux->x = x;
 aux->y = y;
 aux->Siguiente = Gusano;
 Gusano = aux;
 Pant[IMG][Gusano->y][Gusano->x] = GUSANOSKIN;
 Pant[TCOLOR][Gusano->y][Gusano->x] = VERDE;
 Pant[BCOLOR][Gusano->y][Gusano->x] = NEGRO;
 NumTomates--;
 Puntuacion++;
}

void Mover(int incx, int incy)
{
 switch(Pant[IMG][Gusano->y + incy][Gusano->x + incx])
 {
  case ' ':
     Avanzar(incx, incy);
     break;
  case TOMATESKIN:
     Crecer(Gusano->x + incx, Gusano->y + incy);
     break;
  default:
     Vivo = NO;
 }
}

void MoverGusano(void)
{
 switch(Mirando)
 {
  case N:
     Mover(-1, 0);
     break;
  case E:
     Mover(0, 1);
     break;
  case S:
     Mover(1, 0);
     break;
  case W:
     Mover(0, -1);
     break;
 }
}

void PadondeVas(void)
{
 int Tecla = 0;
 int Salir, Tecla_pulsada;
 clock_t T1;
 T1 = clock() + (Tiempo * CLK_TCK) / 1000;
 do{
    Tecla_pulsada = NO;
    if(kbhit() && !Tecla_pulsada)
    {
       Tecla_pulsada = SI;
       Tecla = getch();
       if(!Tecla)
	  Tecla = getch();
       switch(Tecla)
       {
	case IZ:
	   switch(Mirando)
	   {
	    case N:
	       Mirando = E;
	       break;
	    case E:
	       Mirando = S;
	       break;
	    case S:
	       Mirando = W;
	       break;
	    case W:
	       Mirando = N;
	       break;
	   }
	   break;
	case DE:
	   switch(Mirando)
	   {
            case N:
               Mirando = W;
               break;
            case E:
               Mirando = N;
               break;
            case S:
	       Mirando = E;
	       break;
            case W:
               Mirando = S;
               break;
           }
           break;
        case ESC:
           Mensaje = 1;
           break;
        default:
           Mensaje = 2;
       }
    }
    Salir = (clock() >= T1); /*|| Tecla_pulsada);*/
 }while(!Salir);
}

void UsarGusano(void)
{
 PadondeVas();
 MoverGusano();
}
/*--------------------------------------------------------------------------*/
/*
 */
void MandarMens(void)
{
 int mens;

 if(TiempoMens <= 0)
 {                                      
  TiempoMens = TIEMPOMAXMENS;
  randomize();
  mens = random(11) + 2;
  if(mens != 2)
  {
   Mensaje = mens;
  }
  else
  {
   Mensaje = 0;
  }
 }
 else
 {
  TiempoMens--;
 }
}
/*--------------------------------------------------------------------------*/
/*
 */
void Fin(void)
{
 int i = 4;
 textcolor(AMARILLO);
 textbackground(ROSA);
 gotoxy(2, i);
 cprintf("                                                                    ");
 i++;
 gotoxy(2, i);
 cprintf("   Pobre e, pero todo el mundo ha de morir algun d�a, no?           ");
 i++;
 gotoxy(2, i);
 cprintf("   La proxima vez se mas habil, pecadorrr!!!                        ");
 i++;
 gotoxy(2, i);
 if(Puntuacion < 1)
    cprintf("   Tienes %d puntos, yo que tu me cambiaba de identidad por honor.   ", Puntuacion);
 else if(Puntuacion < 10)
    cprintf("   Tu catastr�fica puntuaci�n ha sido: %d                            ", Puntuacion);
 else if(Puntuacion < 20)
    cprintf("   Tu cutre puntuaci�n ha sido: %d                                  ", Puntuacion);
 else if(Puntuacion < 30)
    cprintf("   Tu mediocre puntuaci�n ha sido: %d                               ", Puntuacion);
 else if(Puntuacion < 40)
    cprintf("   Tu puntuaci�n ha sido: %d                                        ", Puntuacion);
 else if(Puntuacion < 60)
    cprintf("   Tu puntuaci�n de viciado ha sido: %d                             ", Puntuacion);
 else if(Puntuacion < 70)
    cprintf("   Tu puntuaci�n de super-viciado ha sido: %d                       ", Puntuacion);
 else if(Puntuacion < 80)
    cprintf("   Tu puntuaci�n de mega-viciator ha sido: %d                       ", Puntuacion);
 else if(Puntuacion < 90)
    cprintf("   Tu puntuaci�n de ultra-viciator-plus-plus ha sido: %d            ", Puntuacion);
 else if(Puntuacion < 100)
    cprintf("   Tu puntuaci�n de super-mega-ultra-viciator++ ha sido: %d         ", Puntuacion);
 else
    cprintf("   Tu puntuaci�n de Master-Viciator ha sido: %d                    ", Puntuacion);
 i++;
 gotoxy(2, i);
 cprintf("                                                                    ");
 i = 23;
 sleep(1);
 textcolor(BLANCO);
 textbackground(NEGRO);
 gotoxy(1, i);
 cprintf("Pulsa una ENTER para salir...");
 while(getch() != 13);
}
/*--------------------------------------------------------------------------*/
/*
 */
void Jugar(void)               
{
 int Salir;
 textcolor(BLANCO);
 textbackground(NEGRO);
 clrscr();
 InitJuego();
 VerPant();
 gotoxy(10,10);
 textcolor(ROSA);
 textbackground(NEGRO);
 cprintf("Pulsa una tecla para empezar el martirio...");
 gotoxy(10,12);
 cprintf("Si te arrepientes pulsa ESC para salirte...");

 getch();
 do{
    if(!NumTomates)
    MeterTomates();
    MandarMens();
    VerPant();
    UsarGusano();
    Salir = (!Vivo);
 }while(!Salir);

 Fin();
 FinJuego();
}
/*--------------------------------------------------------------------------*/
/* Main del programa:
 */
void main(void)
{
 _setcursortype(_NOCURSOR);
 PseudoMenu();
 Jugar();
 _setcursortype(_NORMALCURSOR);
}
/*--------------------------------------------------------------------------*
 *   Fin del Gusano e.                                                       *
 *--------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif
