//--------------------------------------------------------------------------------
// Lessman's Pong - Juego del pong para m�viles.
// Copyright (C) 2006  Gorka Su�rez Garc�a
//
// "Lessman's Pong" is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// "Lessman's Pong" is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with "Lessman's Pong"; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//--------------------------------------------------------------------------------
import javax.microedition.lcdui.*;
import java.io.IOException;
//--------------------------------------------------------------------------------
// Clase Pong, que contendr� el juego en s�.
//--------------------------------------------------------------------------------
class Pong
{
    //----------------------------------------------------------------------------
    // Constantes de la clase.
    //----------------------------------------------------------------------------
    public static final short WIDTH_EMULATOR  = 240;
    public static final short HEIGHT_EMULATOR = 309;
    
    public static final short MINWIDTH  = 128;
    public static final short MINHEIGHT = 128;
    
    public static final short X_MARGINSEP  =  2;
    public static final short X_SEPARATION = 10;
    public static final short Y_SEPARATION = 10;
    
    public static final short TXT_XSEP = 5;
    public static final short TXT_YSEP = 4;
    
    public static final short ITEM_PAL_POSX =  0;
    public static final short ITEM_PAL_POSY =  0;
    public static final short ITEM_PAL_POSW =  6;
    public static final short ITEM_PAL_POSH = 32;
    public static final short ITEM_PAL_HALF = 16;
    
    public static final short ITEM_BALL_POSX = 15;
    public static final short ITEM_BALL_POSY =  4;
    public static final short ITEM_BALL_POSW =  7;
    public static final short ITEM_BALL_POSH =  7;
    public static final short ITEM_BALL_CNTR =  3;
    
    public static final short ITEM_GUY_POSX =  9;
    public static final short ITEM_GUY_POSY = 13;
    public static final short ITEM_GUY_POSW = 11;
    public static final short ITEM_GUY_POSH = 17;
    
    public static final short ITEM_VBAREND_POSX = 7;
    public static final short ITEM_VBAREND_POSY = 0;
    public static final short ITEM_VBAREND_POSW = 1;
    public static final short ITEM_VBAREND_POSH = 3;
    
    public static final short ITEM_VBAR_POSX = 8;
    public static final short ITEM_VBAR_POSY = 0;
    public static final short ITEM_VBAR_POSW = 1;
    public static final short ITEM_VBAR_POSH = 3;
    
    public static final short ITEM_HBAR_POSX = 7;
    public static final short ITEM_HBAR_POSY = 7;
    public static final short ITEM_HBAR_POSW = 3;
    public static final short ITEM_HBAR_POSH = 1;
    
    public static final short ITEM_CORNER_UPLE_POSX = 7;
    public static final short ITEM_CORNER_UPLE_POSY = 4;
    public static final short ITEM_CORNER_UPLE_POSW = 3;
    public static final short ITEM_CORNER_UPLE_POSH = 3;
    
    public static final short ITEM_CORNER_UPRI_POSX = 11;
    public static final short ITEM_CORNER_UPRI_POSY =  4;
    public static final short ITEM_CORNER_UPRI_POSW =  3;
    public static final short ITEM_CORNER_UPRI_POSH =  3;
    
    public static final short ITEM_CORNER_DOLE_POSX = 7;
    public static final short ITEM_CORNER_DOLE_POSY = 8;
    public static final short ITEM_CORNER_DOLE_POSW = 3;
    public static final short ITEM_CORNER_DOLE_POSH = 3;
    
    public static final short ITEM_CORNER_DORI_POSX = 11;
    public static final short ITEM_CORNER_DORI_POSY =  8;
    public static final short ITEM_CORNER_DORI_POSW =  3;
    public static final short ITEM_CORNER_DORI_POSH =  3;
    
    public static final short PANEL_HEIGHT   = 20;
    public static final int   PANEL_BGCOLOR  = 0x00C0C0C0;
    public static final int   PANEL_FGCOLOR  = 0x00FFFFFF;
    
    public static final short INIT_BALL_VELX = 4;
    public static final short INIT_BALL_VELY = 4;
    
    public static final short MIN_BALL_VELX = 3;
    public static final short MAX_BALL_VELX = 7;
    public static final short MAX_BALL_VELY = 5;
    
    public static final short PLAYER_VEL = 4;
    
    public static final byte GAMESTATE_MENU     = 0;
    public static final byte GAMESTATE_NEWGAME  = 1;
    public static final byte GAMESTATE_OPTIONS  = 2;
    public static final byte GAMESTATE_CREDITS  = 3;
    public static final byte GAMESTATE_EXIT     = 4;
    public static final byte GAMESTATE_GAME     = 5;
    public static final byte GAMESTATE_PLAYWIN  = 6;
    public static final byte GAMESTATE_MACHWIN  = 7;
    public static final byte GAMESTATE_EXITGAME = 8;
    public static final byte GAMESTATE_NONEWIN  = 9;
    
    public static final byte MAINMENU_NEWGAME = 0;
    public static final byte MAINMENU_OPTIONS = 1;
    public static final byte MAINMENU_CREDITS = 2;
    public static final byte MAINMENU_EXIT    = 4;
    
    public static final byte NEWGAME_EASY   = 0;
    public static final byte NEWGAME_NORMAL = 1;
    public static final byte NEWGAME_HARD   = 2;
    public static final byte NEWGAME_EXIT   = 3;
    
    public static final byte OPTIONS_MAXIMUN = 0;
    public static final byte OPTIONS_128X128 = 1;
    public static final byte OPTIONS_176X208 = 2;
    public static final byte OPTIONS_176X220 = 3;
    public static final byte OPTIONS_EXIT    = 4;
    
    public static final byte EXIT_YES = 0;
    public static final byte EXIT_NO  = 1;
    
    //----------------------------------------------------------------------------
    // Variables est�ticas de la clase.
    //----------------------------------------------------------------------------
    public static Graphics g;
    public static Image Backg;
    public static Image Items;
    
    public static short Width;
    public static short Height;
    
    public static short i;
    public static short j;
    
    //----------------------------------------------------------------------------
    // Variables est�ticas relacionadas con las medidas de las cosas.
    //----------------------------------------------------------------------------
    public static short BackgMaxCol;
    public static short BackgMaxRow;
    public static short BackgMaxRowOpt;
    
    public static short CourtMinX;
    public static short CourtMaxX;
    public static short CourtMinY;
    public static short CourtMaxY;
    
    public static short UpBarX;
    public static short UpBarY;
    public static short UpBarW;
    
    public static short DownPanelX;
    public static short DownPanelY;
    public static short DownPanelW;
    public static short DownPanelH;
    
    public static Font PanelTextFont;
    
    public static int DownRectX;
    public static int DownRectY;
    public static int DownRectW;
    public static int DownRectH;
    
    public static short PlayerTextX;
    public static short PlayerTextY;
    public static short MachineTextX;
    public static short MachineTextY;
        
    public static Font MenuMainTitle;
    public static Font MenuMainText;
    public static Font MenuSubTitle;
    
    //----------------------------------------------------------------------------
    // Variables est�ticas relacionadas con la l�gica del men�.
    //----------------------------------------------------------------------------
    public static byte MainMenuSelOpt;
    public static byte NewGameSelOpt;
    public static byte OptMenuSelOpt;
    public static byte ExitSelOpt;
    public static byte ExitGameSelOpt;
    
    public static boolean MenuBlock;
    
    //----------------------------------------------------------------------------
    // Variables est�ticas relacionadas con la l�gica del juego.
    //----------------------------------------------------------------------------
    public static short PlayerX;
    public static short PlayerY;
    public static short MachineX;
    public static short MachineY;
    public static short BallX;
    public static short BallY;
    
    public static short BallVelX;
    public static short BallVelY;
    
    public static short PlayerPoints;
    public static short MachinePoints;
    
    public static String PlayerPointsTxt;
    public static String MachinePointsTxt;
    
    public static short MachinePalMargin;
    public static short MachineBallMargin;
    
    public static byte GameState;
    
    //----------------------------------------------------------------------------
    // Funci�n para inicializar el Pong.
    //----------------------------------------------------------------------------
    public final static void Init (Graphics screen, int w, int h)
    {
        try{
            g = screen;
            
            Backg = Image.createImage("/gfx/Backg.png");
            Items = Image.createImage("/gfx/Items.png");
            
            ChangeScreenSize(w, h);
            NewGame();
            
            GameState      = GAMESTATE_MENU;
            MainMenuSelOpt = MAINMENU_NEWGAME;
            NewGameSelOpt  = NEWGAME_NORMAL;
            OptMenuSelOpt  = OPTIONS_MAXIMUN;
            ExitSelOpt     = EXIT_NO;
            ExitGameSelOpt = EXIT_NO;
            
            MenuBlock = false;
            
            MenuMainTitle = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD | Font.STYLE_UNDERLINED, Font.SIZE_LARGE);
            MenuMainText  = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_MEDIUM);
            MenuSubTitle  = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD | Font.STYLE_UNDERLINED, Font.SIZE_MEDIUM);
            
        } catch (IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
    
    //----------------------------------------------------------------------------
    // Funci�n para cambiar el ancho y alto del juego.
    //----------------------------------------------------------------------------
    public final static void ChangeScreenSize (int w, int h)
    {
        //------------------------------------------------------------------------
        // Tomamos el ancho y alto de la pantalla.
        //------------------------------------------------------------------------
        Width  = (short) w;
        Height = (short) h;
            
        //------------------------------------------------------------------------
        // Calculamos el n�mero de celdas del fondo.
        //------------------------------------------------------------------------
        BackgMaxCol = (short) (w / Backg.getWidth());
        BackgMaxRow = (short) (h / Backg.getHeight());
        
        if(w != (BackgMaxCol * Backg.getWidth()))  BackgMaxCol++;
        if(h != (BackgMaxRow * Backg.getHeight())) BackgMaxRow++;
        
        for(i = 0; i < BackgMaxRow; i++)
            for(j = 0; j < BackgMaxCol; j++)
                g.drawImage(Backg, j * Backg.getWidth(), i * Backg.getHeight(),
                            Graphics.TOP|Graphics.LEFT);
        
        if(Height > MINHEIGHT)
        {
            BackgMaxRowOpt = (short) ((((Width * 3) / 4) / Backg.getHeight()) - 1);
        }
        else
        {
            BackgMaxRowOpt = BackgMaxRow;
        }
        
        //------------------------------------------------------------------------
        // Calculamos la posici�n y dimensi�n de la barra superior.
        //------------------------------------------------------------------------
        UpBarX = X_SEPARATION / 2 ;
        UpBarY = Y_SEPARATION - ITEM_VBAREND_POSH;
        UpBarW = (short) (Width - UpBarX);
        
        //------------------------------------------------------------------------
        // Calculamos la posici�n y dimensi�n del panel inferior.
        //------------------------------------------------------------------------
        DownPanelX = UpBarX;
        DownPanelY = (short) (Height - (ITEM_CORNER_UPLE_POSH * 2) -
                             (Y_SEPARATION / 2) - PANEL_HEIGHT);
        
        int CourtMaxHeight = (int) (((Width * 3) / 4) -
                                    (ITEM_CORNER_UPLE_POSH * 2) -
                                    (Y_SEPARATION / 2) - PANEL_HEIGHT);
        
        if((Height > MINHEIGHT) && (DownPanelY > CourtMaxHeight))
            DownPanelY = (short) CourtMaxHeight;
            
        DownPanelW = (short) ((UpBarW + 1) - ITEM_CORNER_UPLE_POSW);
        DownPanelH = (short) (PANEL_HEIGHT + (ITEM_CORNER_UPLE_POSH * 2) + DownPanelY );
        
        DownRectX = (DownPanelX + ITEM_CORNER_UPLE_POSW);
        DownRectY = (DownPanelY + ITEM_CORNER_UPLE_POSH);
        DownRectW = (DownPanelW - DownRectX);
        DownRectH = (DownPanelH - DownRectY);
        
        PlayerTextX  = (short) (DownRectX + TXT_XSEP);
        PlayerTextY  = (short) (DownRectY + TXT_YSEP);
        MachineTextX = (short) (DownRectX + DownRectW - TXT_XSEP);
        MachineTextY = (short) PlayerTextY;
        
        if(Width > MINWIDTH)
            PanelTextFont = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
        else
            PanelTextFont = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);
        
        //------------------------------------------------------------------------
        // Calculamos el tama�o de la cancha.
        //------------------------------------------------------------------------
        CourtMinX = X_SEPARATION;
        CourtMaxX = (short) (Width - X_SEPARATION);
        CourtMinY = Y_SEPARATION + 1;
        CourtMaxY = (short) (DownPanelY - 1);
    }
    
    //----------------------------------------------------------------------------
    // Funci�n para cambiar la dificultad del juego.
    //----------------------------------------------------------------------------
    public final static void SetDificulty (byte level)
    {
        if(level == NEWGAME_EASY)
        {
            MachinePalMargin = 10;
            MachineBallMargin = (short) (Width * 60 / 100);
        }
        else if(level == NEWGAME_NORMAL)
        {
            MachinePalMargin = 9;
            MachineBallMargin = (short) (Width * 50 / 100);
        }
        else if(level == NEWGAME_HARD)
        {
            MachinePalMargin = 8;
            MachineBallMargin = (short) (Width * 40 / 100);
        }
    }
    
    //----------------------------------------------------------------------------
    // Funci�n para iniciar una nueva partida del juego.
    //----------------------------------------------------------------------------
    public final static void NewGame ()
    {
        PlayerX = X_SEPARATION;
        PlayerY = (short) ((CourtMaxY + CourtMinY) / 2 - ITEM_PAL_HALF);
        
        MachineX = (short) (Width - X_SEPARATION - ITEM_PAL_POSW);
        MachineY = PlayerY;
        
        PlayerPoints  = 0;
        MachinePoints = 0;
        
        PlayerPointsTxt  = "Jugador: " + PlayerPoints;
        MachinePointsTxt = "M�quina: " + MachinePoints;
        
        NewBall();
        
        BallVelX = (short) (-INIT_BALL_VELX);
        BallVelY = (short) (-INIT_BALL_VELY);
        
        g.setFont(PanelTextFont);
    }
    
    //----------------------------------------------------------------------------
    // Funci�n para iniciar un nuevo saque.
    //----------------------------------------------------------------------------
    public final static void NewBall ()
    {
        BallX = (short) ((PlayerX + MachineX) / 2);
        BallY = (short) ((CourtMaxY + CourtMinY) / 2 - (ITEM_BALL_POSH / 2));
        
        if(BallVelX < 0)
            BallVelX = (short) (-INIT_BALL_VELX);
        else
            BallVelX = (short) INIT_BALL_VELX;
            
        if(BallVelY < 0)
            BallVelY = (short) (-INIT_BALL_VELY);
        else
            BallVelY = (short) INIT_BALL_VELY;
    }
    
    //----------------------------------------------------------------------------
    // Funci�n que ejecuta la l�gica.
    //----------------------------------------------------------------------------
    public final static void Logic ()
    {
        //------------------------------------------------------------------------
        // En el estado del juego mandamos a llamar al m�todo GameLogic().
        //------------------------------------------------------------------------
        if(GameState == GAMESTATE_GAME)
        {
            GameLogic();
            return;
        }
        
        //------------------------------------------------------------------------
        // Esto evita que haya.
        //------------------------------------------------------------------------
        if(MenuBlock && Input.IsAnyKeyDown())
            return;
        else
            MenuBlock = false;
        
        //------------------------------------------------------------------------
        // Comprobamos la l�gica de la secci�n.
        //------------------------------------------------------------------------
        switch(GameState)
        {
            case GAMESTATE_MENU:
                switch(MainMenuSelOpt)
                {
                    case MAINMENU_NEWGAME:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            MainMenuSelOpt = MAINMENU_EXIT;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            MainMenuSelOpt = MAINMENU_OPTIONS;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_NEWGAME;
                            MenuBlock = true;
                        }
                        break;
                        
                    case MAINMENU_OPTIONS:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            MainMenuSelOpt = MAINMENU_NEWGAME;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            MainMenuSelOpt = MAINMENU_CREDITS;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_OPTIONS;
                            MenuBlock = true;
                        }
                        break;
                        
                    case MAINMENU_CREDITS:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            MainMenuSelOpt = MAINMENU_OPTIONS;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            MainMenuSelOpt = MAINMENU_EXIT;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_CREDITS;
                            MenuBlock = true;
                        }
                        break;
                        
                    case MAINMENU_EXIT:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            MainMenuSelOpt = MAINMENU_CREDITS;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            MainMenuSelOpt = MAINMENU_NEWGAME;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_EXIT;
                            MenuBlock = true;
                        }
                        break;
                }
                break;
                
            case GAMESTATE_NEWGAME:
                switch(NewGameSelOpt)
                {
                    case NEWGAME_EASY:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            NewGameSelOpt = NEWGAME_EXIT;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            NewGameSelOpt = NEWGAME_NORMAL;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            SetDificulty(NEWGAME_EASY);
                            NewGame();
                            GameState = GAMESTATE_GAME;
                            MenuBlock = true;
                        }
                        break;
                        
                    case NEWGAME_NORMAL:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            NewGameSelOpt = NEWGAME_EASY;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            NewGameSelOpt = NEWGAME_HARD;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            SetDificulty(NEWGAME_NORMAL);
                            NewGame();
                            GameState = GAMESTATE_GAME;
                            MenuBlock = true;
                        }
                        break;
                        
                    case NEWGAME_HARD:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            NewGameSelOpt = NEWGAME_NORMAL;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            NewGameSelOpt = NEWGAME_EXIT;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            SetDificulty(NEWGAME_HARD);
                            NewGame();
                            GameState = GAMESTATE_GAME;
                            MenuBlock = true;
                        }
                        break;
                        
                    case NEWGAME_EXIT:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            NewGameSelOpt = NEWGAME_HARD;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            NewGameSelOpt = NEWGAME_EASY;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_MENU;
                            MenuBlock = true;
                        }
                        break;
                }
                break;
                
            case GAMESTATE_OPTIONS:
                switch(OptMenuSelOpt)
                {
                    case OPTIONS_MAXIMUN:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            OptMenuSelOpt = OPTIONS_EXIT;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            OptMenuSelOpt = OPTIONS_128X128;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            ChangeScreenSize(AppMIDlet.MainScreen.getWidth(), 
                                AppMIDlet.MainScreen.getHeight());
                            MenuBlock = true;
                        }
                        break;
                        
                    case OPTIONS_128X128:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            OptMenuSelOpt = OPTIONS_MAXIMUN;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            OptMenuSelOpt = OPTIONS_176X208;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            g.setColor(0x00000000);
                            g.fillRect(0, 0, AppMIDlet.MainScreen.getWidth(),
                                AppMIDlet.MainScreen.getHeight());
                            ChangeScreenSize(128, 128);
                            MenuBlock = true;
                        }
                        break;
                        
                    case OPTIONS_176X208:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            OptMenuSelOpt = OPTIONS_128X128;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            OptMenuSelOpt = OPTIONS_176X220;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            g.setColor(0x00000000);
                            g.fillRect(0, 0, AppMIDlet.MainScreen.getWidth(),
                                AppMIDlet.MainScreen.getHeight());
                            ChangeScreenSize(176, 208);
                            MenuBlock = true;
                        }
                        break;
                        
                    case OPTIONS_176X220:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            OptMenuSelOpt = OPTIONS_176X208;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            OptMenuSelOpt = OPTIONS_EXIT;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            g.setColor(0x00000000);
                            g.fillRect(0, 0, AppMIDlet.MainScreen.getWidth(),
                                AppMIDlet.MainScreen.getHeight());
                            ChangeScreenSize(176, 220);
                            MenuBlock = true;
                        }
                        break;
                        
                    case OPTIONS_EXIT:
                        if(Input.IsKeyDown(Input.KEY_UP))
                        {
                            OptMenuSelOpt = OPTIONS_176X220;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_DOWN))
                        {
                            OptMenuSelOpt = OPTIONS_MAXIMUN;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_MENU;
                            MenuBlock = true;
                        }
                        break;
                }
                break;
                
            case GAMESTATE_CREDITS:
                if(Input.IsKeyDown(Input.KEY_FIRE))
                {
                    GameState = GAMESTATE_MENU;
                    MenuBlock = true;
                }
                break;
                
            case GAMESTATE_EXIT:
                switch(ExitSelOpt)
                {
                    case EXIT_YES:
                        if(Input.IsKeyDown(Input.KEY_RIGHT))
                        {
                            ExitSelOpt = EXIT_NO;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            AppMIDlet.Application.destroyApp(false);
                            MenuBlock = true;
                        }
                        break;
                        
                    case EXIT_NO:
                        if(Input.IsKeyDown(Input.KEY_LEFT))
                        {
                            ExitSelOpt = EXIT_YES;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_MENU;
                            MenuBlock = true;
                        }
                        break;
                }
                break;
                
            case GAMESTATE_EXITGAME:
                switch(ExitGameSelOpt)
                {
                    case EXIT_YES:
                        if(Input.IsKeyDown(Input.KEY_RIGHT))
                        {
                            ExitGameSelOpt = EXIT_NO;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            if(PlayerPoints > MachinePoints)
                                GameState = GAMESTATE_PLAYWIN;
                            else if (PlayerPoints == MachinePoints)
                                GameState = GAMESTATE_NONEWIN;
                            else
                                GameState = GAMESTATE_MACHWIN;
                                
                            MenuBlock = true;
                        }
                        break;
                        
                    case EXIT_NO:
                        if(Input.IsKeyDown(Input.KEY_LEFT))
                        {
                            ExitGameSelOpt = EXIT_YES;
                            MenuBlock = true;
                        }
                        else if(Input.IsKeyDown(Input.KEY_FIRE))
                        {
                            GameState = GAMESTATE_GAME;
                            MenuBlock = true;
                        }
                        break;
                }
                break;
                
            case GAMESTATE_PLAYWIN:
                if(Input.IsKeyDown(Input.KEY_FIRE))
                {
                    GameState = GAMESTATE_MENU;
                    MenuBlock = true;
                }
                break;
                
            case GAMESTATE_MACHWIN:
                if(Input.IsKeyDown(Input.KEY_FIRE))
                {
                    GameState = GAMESTATE_MENU;
                    MenuBlock = true;
                }
                break;
                
            case GAMESTATE_NONEWIN:
                if(Input.IsKeyDown(Input.KEY_FIRE))
                {
                    GameState = GAMESTATE_MENU;
                    MenuBlock = true;
                }
                break;
        }
    }
    
    //----------------------------------------------------------------------------
    // Funci�n que ejecuta el renderizado de la partida.
    //----------------------------------------------------------------------------
    public final static void Render ()
    {
        //------------------------------------------------------------------------
        // En el estado del juego mandamos a llamar al m�todo GameRender().
        //------------------------------------------------------------------------
        if(GameState == GAMESTATE_GAME)
        {
            GameRender();
            return;
        }
        
        //------------------------------------------------------------------------
        // Pintamos el fondo.
        //------------------------------------------------------------------------
        for(i = 0; i < BackgMaxRow; i++)
            for(j = 0; j < BackgMaxCol; j++)
                g.drawImage(Backg, j * Backg.getWidth(), i * Backg.getHeight(),
                            Graphics.TOP|Graphics.LEFT);
            
        //------------------------------------------------------------------------
        // Pintamos el contenido de la secci�n.
        //------------------------------------------------------------------------
        switch(GameState)
        {
            case GAMESTATE_MENU:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuMainTitle);
                g.drawString("Lessman's Pong", (Width / 2), 5, Graphics.TOP|Graphics.HCENTER);
                
                g.setFont(MenuMainText);
                
                i = 35;
                j = 20;
                
                if(MainMenuSelOpt == MAINMENU_NEWGAME)
                    g.drawString("> Nueva partida <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Nueva partida", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                
                i += j;
                
                if(MainMenuSelOpt == MAINMENU_OPTIONS)
                    g.drawString("> Opciones <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Opciones", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);

                i += j;
                
                if(MainMenuSelOpt == MAINMENU_CREDITS)
                    g.drawString("> Cr�ditos <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Cr�ditos", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);

                i += (j + 5);
                
                if(MainMenuSelOpt == MAINMENU_EXIT)
                    g.drawString("> Salir <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Salir", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                break;
                
            case GAMESTATE_NEWGAME:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuSubTitle);
                g.drawString("Nueva partida", (Width / 2), 5, Graphics.TOP|Graphics.HCENTER);
                
                g.setFont(MenuMainText);
                
                i = 30;
                j = 20;
                
                if(NewGameSelOpt == NEWGAME_EASY)
                    g.drawString("> F�cil <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("F�cil", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                
                i += j;
                
                if(NewGameSelOpt == NEWGAME_NORMAL)
                    g.drawString("> Normal <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Normal", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);

                i += j;
                
                if(NewGameSelOpt == NEWGAME_HARD)
                    g.drawString("> Dif�cil <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Dif�cil", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);

                i += (j + 5);
                
                if(NewGameSelOpt == NEWGAME_EXIT)
                    g.drawString("> Volver <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Volver", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                break;
                
            case GAMESTATE_OPTIONS:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuSubTitle);
                g.drawString("Opciones", (Width / 2), 5, Graphics.TOP|Graphics.HCENTER);
                
                g.setFont(MenuMainText);
                
                i = 30;
                j = 20;
                
                if(OptMenuSelOpt == OPTIONS_MAXIMUN)
                    g.drawString("> M�xima <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("M�xima", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                
                i += j;
                
                if(OptMenuSelOpt == OPTIONS_128X128)
                    g.drawString("> 128x128 <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("128x128", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);

                i += j;
                
                if(OptMenuSelOpt == OPTIONS_176X208)
                    g.drawString("> 176x208 <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("176x208", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);

                i += j;
                
                if(OptMenuSelOpt == OPTIONS_176X220)
                    g.drawString("> 176x220 <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("176x220", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);

                i += (j + 3);
                
                if(OptMenuSelOpt == OPTIONS_EXIT)
                    g.drawString("> Volver <", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("Volver", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                break;
                
            case GAMESTATE_CREDITS:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuSubTitle);
                g.drawString("Cr�ditos", (Width / 2), 5, Graphics.TOP|Graphics.HCENTER);
                
                g.setFont(MenuMainText);
                
                i = 30;
                j = 20;
                
                g.drawString("Programaci�n/gr�ficos:", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                
                i += j;
                
                g.drawString("Gorka Su�rez Garc�a", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                
                i += (j + 3);
                
                g.drawString("Pulsa una tecla...", (Width / 2), i, Graphics.TOP|Graphics.HCENTER);
                break;
                
            case GAMESTATE_EXIT:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuMainText);
                g.drawString("�Deseas salir del juego?", (Width / 2), 10, Graphics.TOP|Graphics.HCENTER);
                
                if(ExitSelOpt == EXIT_YES)
                    g.drawString("> S� <", (Width / 4), 30, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("S�", (Width / 4), 30, Graphics.TOP|Graphics.HCENTER);
                
                if(ExitSelOpt == EXIT_NO)
                    g.drawString("> No <", (Width * 3 / 4), 30, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("No", (Width * 3 / 4), 30, Graphics.TOP|Graphics.HCENTER);

                break;
                
            case GAMESTATE_EXITGAME:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuMainText);
                g.drawString("�Salir de la partida?", (Width / 2), 10, Graphics.TOP|Graphics.HCENTER);
                
                if(ExitGameSelOpt == EXIT_YES)
                    g.drawString("> S� <", (Width / 4), 30, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("S�", (Width / 4), 30, Graphics.TOP|Graphics.HCENTER);
                
                if(ExitGameSelOpt == EXIT_NO)
                    g.drawString("> No <", (Width * 3 / 4), 30, Graphics.TOP|Graphics.HCENTER);
                else
                    g.drawString("No", (Width * 3 / 4), 30, Graphics.TOP|Graphics.HCENTER);

                break;
                
            case GAMESTATE_PLAYWIN:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuSubTitle);
                g.drawString("Has ganado", (Width / 2), 5, Graphics.TOP|Graphics.HCENTER);
                
                g.setFont(MenuMainText);
                
                g.drawString("Pulsa una tecla...", (Width / 2), 40, Graphics.TOP|Graphics.HCENTER);
                break;
                
            case GAMESTATE_MACHWIN:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuSubTitle);
                g.drawString("Has perdido", (Width / 2), 5, Graphics.TOP|Graphics.HCENTER);
                
                g.setFont(MenuMainText);
                
                g.drawString("Pulsa una tecla...", (Width / 2), 40, Graphics.TOP|Graphics.HCENTER);
                break;
                
            case GAMESTATE_NONEWIN:
                g.setColor(0x00FFFFFF);
                g.setFont(MenuSubTitle);
                g.drawString("Has empatado", (Width / 2), 5, Graphics.TOP|Graphics.HCENTER);
                
                g.setFont(MenuMainText);
                
                g.drawString("Pulsa una tecla...", (Width / 2), 40, Graphics.TOP|Graphics.HCENTER);
                break;
        }
        
        //------------------------------------------------------------------------
        // Mandamos a actualizar la pantalla.
        //------------------------------------------------------------------------
        AppMIDlet.MainScreen.flushGraphics();
    }
    
    //----------------------------------------------------------------------------
    // Funci�n que ejecuta la l�gica del juego.
    //----------------------------------------------------------------------------
    public final static void GameLogic ()
    {
        if(Input.IsKeyDown(Input.KEY_NUM1))
        {
            if(MenuBlock == false)
            {
                GameState = GAMESTATE_EXITGAME;
                ExitGameSelOpt = EXIT_NO;
                MenuBlock = true;
                return;
            }
        }
        else
        {
            MenuBlock = false;
        }
        
        //------------------------------------------------------------------------
        // Gesti�n del jugador.
        //------------------------------------------------------------------------
        if((PlayerY > CourtMinY) && Input.IsKeyDown(Input.KEY_UP))
        {
            PlayerY -= PLAYER_VEL;
            
            if(PlayerY < CourtMinY)
                PlayerY = CourtMinY;
        }
        
        if((PlayerY < (CourtMaxY - ITEM_PAL_POSH)) && Input.IsKeyDown(Input.KEY_DOWN))
        {
            PlayerY += PLAYER_VEL;
            
            if(PlayerY > (CourtMaxY - ITEM_PAL_POSH))
                PlayerY = (short) (CourtMaxY - ITEM_PAL_POSH);
        }
        
        //------------------------------------------------------------------------
        // Gesti�n de la bola.
        //------------------------------------------------------------------------
        BallX += BallVelX;
        BallY += BallVelY;
        
        if(BallY < CourtMinY)
        {
            BallY = CourtMinY;
            BallVelY = (short) -BallVelY;
        }
        else if(BallY > (CourtMaxY - ITEM_BALL_POSH))
        {
            BallY = (short) (CourtMaxY - ITEM_BALL_POSH);
            BallVelY = (short) -BallVelY;
        }
        
        if((PlayerY <= (BallY + ITEM_BALL_CNTR)) &&
           ((BallY + ITEM_BALL_CNTR) < (PlayerY + ITEM_PAL_POSH)))
        {
            if(BallX <= (CourtMinX + ITEM_PAL_POSW))
            {
                if(BallVelX < 0)
                {
                    if((BallY + ITEM_BALL_CNTR) < (PlayerY + ITEM_PAL_HALF))
                    {
                        i = (short) ((BallY + ITEM_BALL_CNTR - PlayerY) * 1000 / ITEM_PAL_HALF);
                        
                        BallVelY = (short) (MAX_BALL_VELY * i / 1000 - MAX_BALL_VELY);
                        BallVelX = (short) (MAX_BALL_VELX * i / 1000 + 1);
                        
                        if(BallVelX < MIN_BALL_VELX) BallVelX = MIN_BALL_VELX;
                    }
                    else if((BallY + ITEM_BALL_CNTR) >= (PlayerY + ITEM_PAL_HALF))
                    {
                        i = (short) ((BallY + ITEM_BALL_CNTR - PlayerY - ITEM_PAL_HALF) * 1000 / ITEM_PAL_HALF);
                        
                        BallVelY = (short) (MAX_BALL_VELY * i / 1000 + 1);
                        BallVelX = (short) (MAX_BALL_VELX - MAX_BALL_VELX * i / 1000);
                        
                        if(BallVelX < MIN_BALL_VELX) BallVelX = MIN_BALL_VELX;
                    }
                }
                BallX = (short) (CourtMinX + ITEM_PAL_POSW);
            }
        }
        else
        {
            if(BallX < (CourtMinX - X_MARGINSEP))
            {
                MachinePoints++;
                MachinePointsTxt = "M�quina: " + MachinePoints;
                
                if(MachinePoints < 10)
                    NewBall();
                else
                    GameState = GAMESTATE_MACHWIN;
            }
        }
        
        if((MachineY <= (BallY + ITEM_BALL_CNTR)) &&
           ((BallY + ITEM_BALL_CNTR) < (MachineY + ITEM_PAL_POSH)))
        {
            if(BallX >= (CourtMaxX - ITEM_BALL_POSW - ITEM_PAL_POSW))
            {
                if(BallVelX > 0)
                {
                    if((BallY + ITEM_BALL_CNTR) < (MachineY + ITEM_PAL_HALF))
                    {
                        i = (short) ((BallY + ITEM_BALL_CNTR - MachineY) * 1000 / ITEM_PAL_HALF);
                        
                        BallVelY = (short) (MAX_BALL_VELY * i / 1000 - MAX_BALL_VELY);
                        BallVelX = (short) (1 - MAX_BALL_VELX * i / 1000);
                        
                        if(BallVelX > -MIN_BALL_VELX) BallVelX = (short) -MIN_BALL_VELX;
                    }
                    else if((BallY + ITEM_BALL_CNTR) >= (MachineY + ITEM_PAL_HALF))
                    {
                        i = (short) ((BallY + ITEM_BALL_CNTR - MachineY - ITEM_PAL_HALF) * 1000 / ITEM_PAL_HALF);
                        
                        BallVelY = (short) (MAX_BALL_VELY * i / 1000 + 1);
                        BallVelX = (short) (MAX_BALL_VELX * i / 1000 - MAX_BALL_VELX);
                        
                        if(BallVelX > -MIN_BALL_VELX) BallVelX = (short) -MIN_BALL_VELX;
                    }
                }
                BallX = (short) (CourtMaxX - ITEM_BALL_POSW - ITEM_PAL_POSW);
            }
        }
        else
        {
            if((BallX + ITEM_BALL_POSW) > (CourtMaxX + X_MARGINSEP))
            {
                PlayerPoints++;
                PlayerPointsTxt = "Jugador: " + PlayerPoints;
                
                if(PlayerPoints < 10)
                    NewBall();
                else
                    GameState = GAMESTATE_PLAYWIN;
            }
        }
        
        //------------------------------------------------------------------------
        // Gesti�n de la m�quina.
        //------------------------------------------------------------------------
        if(BallVelX < 0) return;        
        if(BallX < MachineBallMargin) return;
        
        if((MachineY + ITEM_PAL_HALF - MachinePalMargin) > BallY)
        {
            MachineY -= PLAYER_VEL;
            
            if(MachineY < CourtMinY)
                MachineY = CourtMinY;
        }
        else if((MachineY + ITEM_PAL_HALF + MachinePalMargin) < (BallY + ITEM_BALL_POSH))
        {
            MachineY += PLAYER_VEL;
            
            if(MachineY > (CourtMaxY - ITEM_PAL_POSH))
                MachineY = (short) (CourtMaxY - ITEM_PAL_POSH);
        }
    }
    
    //----------------------------------------------------------------------------
    // Funci�n que ejecuta el renderizado de la partida.
    //----------------------------------------------------------------------------
    public final static void GameRender ()
    {
        //------------------------------------------------------------------------
        // Pintamos el fondo.
        //------------------------------------------------------------------------
        for(i = 0; i < BackgMaxRowOpt; i++)
            for(j = 0; j < BackgMaxCol; j++)
                g.drawImage(Backg, j * Backg.getWidth(), i * Backg.getHeight(),
                            Graphics.TOP|Graphics.LEFT);
            
        //------------------------------------------------------------------------
        // Pintamos la barra de arriba.
        //------------------------------------------------------------------------
        g.drawRegion(Items, ITEM_VBAREND_POSX, ITEM_VBAREND_POSY, ITEM_VBAREND_POSW,
                     ITEM_VBAREND_POSH, 0, UpBarX, UpBarY, Graphics.TOP|Graphics.LEFT);

        for(i = (short) (UpBarX + 1); i < UpBarW; i++)
            g.drawRegion(Items, ITEM_VBAR_POSX, ITEM_VBAR_POSY, ITEM_VBAR_POSW,
                         ITEM_VBAR_POSH, 0, i, UpBarY, Graphics.TOP|Graphics.LEFT);

        g.drawRegion(Items, ITEM_VBAREND_POSX, ITEM_VBAREND_POSY, ITEM_VBAREND_POSW,
                     ITEM_VBAREND_POSH, 0, UpBarW, UpBarY, Graphics.TOP|Graphics.LEFT);

        //------------------------------------------------------------------------
        // Pintamos las raquetas y la bola.
        //------------------------------------------------------------------------
        g.drawRegion(Items, ITEM_PAL_POSX, ITEM_PAL_POSY, ITEM_PAL_POSW,
                     ITEM_PAL_POSH, 0, PlayerX, PlayerY, Graphics.TOP|Graphics.LEFT);

        g.drawRegion(Items, ITEM_PAL_POSX, ITEM_PAL_POSY, ITEM_PAL_POSW,
                     ITEM_PAL_POSH, 0, MachineX, MachineY, Graphics.TOP|Graphics.LEFT);

        g.drawRegion(Items, ITEM_BALL_POSX, ITEM_BALL_POSY, ITEM_BALL_POSW,
                     ITEM_BALL_POSH, 0, BallX, BallY, Graphics.TOP|Graphics.LEFT);

        //------------------------------------------------------------------------
        // Pintamos el panel de abajo.
        //------------------------------------------------------------------------
        g.drawRegion(Items, ITEM_CORNER_UPLE_POSX, ITEM_CORNER_UPLE_POSY, ITEM_CORNER_UPLE_POSW,
                     ITEM_CORNER_UPLE_POSH, 0, DownPanelX, DownPanelY, Graphics.TOP|Graphics.LEFT);

        for(i = (short) DownRectX; i < DownPanelW; i++)
            g.drawRegion(Items, ITEM_VBAR_POSX, ITEM_VBAR_POSY, ITEM_VBAR_POSW,
                         ITEM_VBAR_POSH, 0, i, DownPanelY, Graphics.TOP|Graphics.LEFT);

        g.drawRegion(Items, ITEM_CORNER_UPRI_POSX, ITEM_CORNER_UPRI_POSY, ITEM_CORNER_UPRI_POSW,
                     ITEM_CORNER_UPRI_POSH, 0, DownPanelW, DownPanelY, Graphics.TOP|Graphics.LEFT);

        for(i = (short) DownRectY; i < DownPanelH; i++)
            g.drawRegion(Items, ITEM_HBAR_POSX, ITEM_HBAR_POSY, ITEM_HBAR_POSW,
                         ITEM_HBAR_POSH, 0, DownPanelX, i, Graphics.TOP|Graphics.LEFT);   

        g.setColor(PANEL_BGCOLOR);
        g.fillRect(DownRectX, DownRectY, DownRectW, DownRectH);

        for(i = (short) DownRectY; i < DownPanelH; i++)
            g.drawRegion(Items, ITEM_HBAR_POSX, ITEM_HBAR_POSY, ITEM_HBAR_POSW,
                         ITEM_HBAR_POSH, 0, DownPanelW, i, Graphics.TOP|Graphics.LEFT);

        g.drawRegion(Items, ITEM_CORNER_DOLE_POSX, ITEM_CORNER_DOLE_POSY, ITEM_CORNER_DOLE_POSW,
                     ITEM_CORNER_DOLE_POSH, 0, DownPanelX, DownPanelH, Graphics.TOP|Graphics.LEFT);

        for(i = (short) DownRectX; i < DownPanelW; i++)
            g.drawRegion(Items, ITEM_VBAR_POSX, ITEM_VBAR_POSY, ITEM_VBAR_POSW,
                         ITEM_VBAR_POSH, 0, i, DownPanelH, Graphics.TOP|Graphics.LEFT);

        g.drawRegion(Items, ITEM_CORNER_DORI_POSX, ITEM_CORNER_DORI_POSY, ITEM_CORNER_DORI_POSW,
                     ITEM_CORNER_DORI_POSH, 0, DownPanelW, DownPanelH, Graphics.TOP|Graphics.LEFT);
        
        //------------------------------------------------------------------------
        // Pintamos el contenido del panel de abajo.
        //------------------------------------------------------------------------
        g.setColor(PANEL_FGCOLOR);
        g.drawString(PlayerPointsTxt, PlayerTextX, PlayerTextY, Graphics.TOP|Graphics.LEFT);
        g.drawString(MachinePointsTxt, MachineTextX, MachineTextY, Graphics.TOP|Graphics.RIGHT);
        
        //------------------------------------------------------------------------
        // Mandamos a actualizar la pantalla.
        //------------------------------------------------------------------------
        AppMIDlet.MainScreen.flushGraphics();
    }
}
//--------------------------------------------------------------------------------
// Fin Pong.java
//--------------------------------------------------------------------------------