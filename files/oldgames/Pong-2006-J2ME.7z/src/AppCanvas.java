//--------------------------------------------------------------------------------
// Lessman's Pong - Juego del pong para m�viles.
// Copyright (C) 2006  Gorka Su�rez Garc�a
//
// "Lessman's Pong" is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// "Lessman's Pong" is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with "Lessman's Pong"; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//--------------------------------------------------------------------------------
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
//--------------------------------------------------------------------------------
// Clase AppCanvas, que contendr� el Canvas del juego.
//--------------------------------------------------------------------------------
public final class AppCanvas extends GameCanvas implements Runnable
{
    //----------------------------------------------------------------------------
    // Variables de la clase.
    //----------------------------------------------------------------------------
    private static Thread AppThread;
    private static int MaxFrameTime;
    private static boolean Finish;
    private static boolean Pause;
    
    
    //----------------------------------------------------------------------------
    // Constructor de la clase.
    //----------------------------------------------------------------------------
    public AppCanvas ()
    {
        super(false);
        setFullScreenMode(true);
    
        AppThread    = null;
        MaxFrameTime = 40;
        Pause        = false;
    }
    
    //----------------------------------------------------------------------------
    // M�todo para iniciar la ejecuci�n del juego.
    //----------------------------------------------------------------------------
    public final void start ()
    {
        AppThread = new Thread(this);
        AppThread.start();
    }
    
    //----------------------------------------------------------------------------
    // M�todo para parar la ejecuci�n del juego.
    //----------------------------------------------------------------------------
    public final void stop ()
    {
        Finish = true;
    }
    
    //----------------------------------------------------------------------------
    // M�todo invocado cuando el programa pierde el foco de la ejecuci�n.
    //----------------------------------------------------------------------------
    protected final void hideNotify()
    {
        Pause = true;
        System.gc();
    }
    
    //----------------------------------------------------------------------------
    // M�todo invocado cuando el programa vuelve a tener el foco.
    //----------------------------------------------------------------------------
    protected final void showNotify()
    {
        Pause = false;
        System.gc();
    }
    
    //----------------------------------------------------------------------------
    // M�todo con el bucle principal del juego.
    //----------------------------------------------------------------------------
    public final void run ()
    {
        long start, end;
        int duration;
        Finish = false;
        
        getGraphics().setColor(0x00000000);
        getGraphics().fillRect(0, 0, getWidth(), getHeight());
        
        Input.Init();
        Pong.Init(this.getGraphics(), getWidth(), getHeight());
        System.gc();
        
        while(!Finish)
        {
            start = System.currentTimeMillis();
         
            Pong.Logic();
            
            repaint();
            serviceRepaints();
            
            end = System.currentTimeMillis();
            
            duration = (int) (end - start);
            if(duration < MaxFrameTime)
            {
                try
                {
                    Thread.sleep(MaxFrameTime - duration);
                }
                catch(InterruptedException e)
                {
                    Finish = true;
                }
            }
        }
    }
    
    //----------------------------------------------------------------------------
    // M�todo con el que se pinta la pantalla del juego.
    //----------------------------------------------------------------------------
    public final void paint(Graphics g)
    {
        try{
            Pong.Render();
        }catch(Exception e){
        }
    }
    
    //----------------------------------------------------------------------------
    // Metodo que captura el evento de tecla pulsada.
    //----------------------------------------------------------------------------
    protected final void keyPressed (int key)
    {
        Input.KeyPressed(key);
    }
    
    //----------------------------------------------------------------------------
    // Metodo que captura el evento de tecla liberada.
    //----------------------------------------------------------------------------
    protected final void keyReleased (int key)
    {
        Input.KeyReleased(key);
    }
    
    //----------------------------------------------------------------------------
    // Metodo que captura el evento de redimensionado de la pantalla.
    //----------------------------------------------------------------------------
    protected final void sizeChanged (int w, int h)
    {
        Pong.ChangeScreenSize(w, h);
    }
}
//--------------------------------------------------------------------------------
// Fin AppCanvas.java
//--------------------------------------------------------------------------------