//--------------------------------------------------------------------------------
// Lessman's Pong - Juego del pong para m�viles.
// Copyright (C) 2006  Gorka Su�rez Garc�a
//
// "Lessman's Pong" is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// "Lessman's Pong" is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with "Lessman's Pong"; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//--------------------------------------------------------------------------------
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;
//--------------------------------------------------------------------------------
// Clase AppMIDlet, que servir� como entrada al programa.
//--------------------------------------------------------------------------------
public final class AppMIDlet extends MIDlet
{
    //----------------------------------------------------------------------------
    // Variables est�ticas de la clase.
    //----------------------------------------------------------------------------
    public static AppMIDlet Application;
    public static AppCanvas MainScreen;
    public static Display   MainDisplay;
    
    //----------------------------------------------------------------------------
    // Constructor del programa.
    //----------------------------------------------------------------------------
    public AppMIDlet ()
    {
        Application = null;
        MainScreen  = null;
        MainDisplay = null;
    }
    
    //----------------------------------------------------------------------------
    // Funci�n "main" del programa.
    //----------------------------------------------------------------------------
    public final void startApp ()
    {
        Application = this;
        MainDisplay = Display.getDisplay(this);
        
        if(MainScreen == null)
        {
            MainScreen = new AppCanvas();
            MainScreen.start();
        }
	
        MainDisplay.setCurrent(MainScreen);
    }

    //----------------------------------------------------------------------------
    // Funci�n para pausar el programa.
    //----------------------------------------------------------------------------
    public final void pauseApp ()
    {
    }
    
    //----------------------------------------------------------------------------
    // Funci�n para destruir la aplicaci�n.
    //----------------------------------------------------------------------------
    public final void destroyApp (boolean flag)
    {
        MainDisplay.setCurrent(null);
        notifyDestroyed();
    }
}
//--------------------------------------------------------------------------------
// Fin AppMIDlet.java
//--------------------------------------------------------------------------------