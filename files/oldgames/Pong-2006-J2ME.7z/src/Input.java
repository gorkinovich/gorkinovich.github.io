//--------------------------------------------------------------------------------
// Lessman's Pong - Juego del pong para m�viles.
// Copyright (C) 2006  Gorka Su�rez Garc�a
//
// "Lessman's Pong" is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// "Lessman's Pong" is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with "Lessman's Pong"; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//--------------------------------------------------------------------------------
import javax.microedition.lcdui.Canvas;
//--------------------------------------------------------------------------------
// Clase Input, que servir� para manipular la entrada del teclado.
//--------------------------------------------------------------------------------
public final class Input
{
    //----------------------------------------------------------------------------
    // Constantes de la clase.
    //----------------------------------------------------------------------------
    public static final int KEY_NUM0  = 0x00001;
    public static final int KEY_NUM1  = 0x00002;
    public static final int KEY_NUM2  = 0x00004;
    public static final int KEY_NUM3  = 0x00008;
    public static final int KEY_NUM4  = 0x00010;
    public static final int KEY_NUM5  = 0x00020;
    public static final int KEY_NUM6  = 0x00040;
    public static final int KEY_NUM7  = 0x00080;
    public static final int KEY_NUM8  = 0x00100;
    public static final int KEY_NUM9  = 0x00200;
    public static final int KEY_POUND = 0x00400;
    public static final int KEY_STAR  = 0x00800;
    public static final int KEY_FIRE  = 0x01000;
    public static final int KEY_UP    = 0x02000;
    public static final int KEY_DOWN  = 0x04000;
    public static final int KEY_LEFT  = 0x08000;
    public static final int KEY_RIGHT = 0x10000;
    
    //----------------------------------------------------------------------------
    // Variables est�ticas de la clase.
    //----------------------------------------------------------------------------
    public static int KeyboardState = 0;
    
    //----------------------------------------------------------------------------
    // Funci�n para inicializar el Input.
    //----------------------------------------------------------------------------
    public final static void Init ()
    {
        KeyboardState = 0;
    }
    
    //----------------------------------------------------------------------------
    // Devuelve el c�digo de la tecla pulsada.
    //----------------------------------------------------------------------------
    public final static int KeyCode (int key)
    {
        switch(key)
        {
            case Canvas.KEY_NUM0:  return Input.KEY_NUM0;
            case Canvas.KEY_NUM1:  return Input.KEY_NUM1;
            case Canvas.KEY_NUM2:  return Input.KEY_NUM2;
            case Canvas.KEY_NUM3:  return Input.KEY_NUM3;
            case Canvas.KEY_NUM4:  return Input.KEY_NUM4;
            case Canvas.KEY_NUM5:  return Input.KEY_NUM5;
            case Canvas.KEY_NUM6:  return Input.KEY_NUM6;
            case Canvas.KEY_NUM7:  return Input.KEY_NUM7;
            case Canvas.KEY_NUM8:  return Input.KEY_NUM8;
            case Canvas.KEY_NUM9:  return Input.KEY_NUM9;
            case Canvas.KEY_POUND: return Input.KEY_POUND;
            case Canvas.KEY_STAR:  return Input.KEY_STAR;
        }
        
        switch(AppMIDlet.MainScreen.getGameAction(key))
        {
            case Canvas.FIRE:  return Input.KEY_FIRE;
            case Canvas.UP:    return Input.KEY_UP;
            case Canvas.DOWN:  return Input.KEY_DOWN;
            case Canvas.RIGHT: return Input.KEY_RIGHT;
            case Canvas.LEFT:  return Input.KEY_LEFT;
        }
        
        return 0;
    }
    
    //----------------------------------------------------------------------------
    // Actualiza el estado del teclado cuando una tecla ha sido pulsada.
    //----------------------------------------------------------------------------
    public final static void KeyPressed (int key)
    {
        Input.KeyboardState |= Input.KeyCode(key);
    }
    
    //----------------------------------------------------------------------------
    // Actualiza el estado del teclado cuando una tecla ya no est� pulsada.
    //----------------------------------------------------------------------------
    public final static void KeyReleased (int key)
    {
        Input.KeyboardState &= (~Input.KeyCode(key));
    }
    
    //----------------------------------------------------------------------------
    // Indica si una tecla est� en particular pulsada.
    //----------------------------------------------------------------------------
    public final static boolean IsKeyDown (int key)
    {
        return ((KeyboardState & key) != 0);
    }
    
    //----------------------------------------------------------------------------
    // Indica si hay alguna tecla cualquiera pulsada.
    //----------------------------------------------------------------------------
    public final static boolean IsAnyKeyDown()
    {
        return (KeyboardState != 0);
    }
}
//--------------------------------------------------------------------------------
// Fin Input.java
//--------------------------------------------------------------------------------