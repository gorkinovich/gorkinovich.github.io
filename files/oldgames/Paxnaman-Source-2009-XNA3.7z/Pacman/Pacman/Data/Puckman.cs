﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents the Puckman entity.
    /// </summary>
    public abstract class Puckman : MovingEntity {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int numberOfSprites
        /// <summary>
        /// The number of sprites of the entity.
        /// </summary>
        protected const int numberOfSprites = 6;
        #endregion

        #region int maxFps
        /// <summary>
        /// The maximum number of frames per second of the animation.
        /// </summary>
        protected const int maxFps = 8;
        #endregion

        #region int rightSprite
        /// <summary>
        /// The id of the sprite "right".
        /// </summary>
        protected const int rightSprite = 0;
        #endregion

        #region int downSprite
        /// <summary>
        /// The id of the sprite "down".
        /// </summary>
        protected const int downSprite = 1;
        #endregion

        #region int leftSprite
        /// <summary>
        /// The id of the sprite "left".
        /// </summary>
        protected const int leftSprite = 2;
        #endregion

        #region int upSprite
        /// <summary>
        /// The id of the sprite "up".
        /// </summary>
        protected const int upSprite = 3;
        #endregion

        #region int deathSprite
        /// <summary>
        /// The id of the sprite "death".
        /// </summary>
        protected const int deathSprite = 4;
        #endregion

        #region int stopSprite
        /// <summary>
        /// The id of the sprite "stop".
        /// </summary>
        protected const int stopSprite = 5;
        #endregion

        #region long fastInterval
        /// <summary>
        /// A fast amount of time that an interval can have.
        /// </summary>
        protected const long fastInterval = 14;
        #endregion

        #region long slowInterval
        /// <summary>
        /// A slow amount of time that an interval can have.
        /// </summary>
        protected const long slowInterval = 16;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Animation[] sprites
        /// <summary>
        /// The sprites of the entity.
        /// </summary>
        protected Animation[] sprites;
        #endregion

        #region int currentSprite
        /// <summary>
        /// The current used sprite.
        /// </summary>
        protected int currentSprite;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Puckman()
        /// <summary>
        /// Constructs a new Puckman object.
        /// </summary>
        public Puckman() {
            // First, get an array of sprites.
            GameScreen render = CoreManager.Instance.Screen;
            this.sprites = new Animation[Puckman.numberOfSprites];
            // Second, set each sprite with an animation.
            this.sprites[Puckman.rightSprite] = new Animation(render, new int[] { 16, 17, 18 }, Puckman.maxFps);
            this.sprites[Puckman.downSprite] = new Animation(render, new int[] { 16, 19, 20 }, Puckman.maxFps);
            this.sprites[Puckman.leftSprite] = new Animation(render, new int[] { 16, 21, 22 }, Puckman.maxFps);
            this.sprites[Puckman.upSprite] = new Animation(render, new int[] { 16, 23, 24 }, Puckman.maxFps);
            this.sprites[Puckman.deathSprite] = new Animation(render,
                new int[] { 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36 }, Puckman.maxFps, false);
            this.sprites[Puckman.stopSprite] = new Animation(render, new int[] { 16 }, Puckman.maxFps);
            // And finally, set the current sprite.
            this.currentSprite = Puckman.stopSprite;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void SetFast()
        /// <summary>
        /// Sets the speed of the entity to fast.
        /// </summary>
        public void SetFast() {
            this.maxTimeInterval = Puckman.fastInterval;
        }
        #endregion

        #region void SetSlow()
        /// <summary>
        /// Sets the speed of the entity to slow.
        /// </summary>
        public void SetSlow() {
            this.maxTimeInterval = Puckman.slowInterval;
        }
        #endregion

        #region void setCurrentSprite(int index)
        /// <summary>
        /// Sets the current sprite of the entity.
        /// </summary>
        /// <param name="index">The current used sprite.</param>
        protected void setCurrentSprite(int index) {
            this.currentSprite = index;
            this.sprites[this.currentSprite].Reset();
        }
        #endregion

        #region void SetDirection(MovingDirection dir)
        /// <summary>
        /// Sets the direction of the entity.
        /// </summary>
        /// <param name="dir">The direction of the entity.</param>
        public override void SetDirection(MovingDirection dir) {
            this.Direction = dir;
            switch(dir) {
                case MovingDirection.Up:
                    this.setCurrentSprite(Puckman.upSprite);
                    break;
                case MovingDirection.Down:
                    this.setCurrentSprite(Puckman.downSprite);
                    break;
                case MovingDirection.Left:
                    this.setCurrentSprite(Puckman.leftSprite);
                    break;
                case MovingDirection.Right:
                    this.setCurrentSprite(Puckman.rightSprite);
                    break;
                case MovingDirection.None:
                    this.setCurrentSprite(Puckman.stopSprite);
                    break;
            }
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the Puckman inside the screen.
        /// </summary>
        public override void Draw() {
            this.sprites[this.currentSprite].Draw(this.X, this.Y);
        }
        #endregion

        #region bool IsDeathSpriteEnded()
        /// <summary>
        /// Checks if the death animation have ended.
        /// </summary>
        /// <returns>If the animation have ended returns true, otherwise false.</returns>
        public bool IsDeathSpriteEnded() {
            return this.sprites[Puckman.deathSprite].IsOnFinalFrame();
        }
        #endregion
    }
}