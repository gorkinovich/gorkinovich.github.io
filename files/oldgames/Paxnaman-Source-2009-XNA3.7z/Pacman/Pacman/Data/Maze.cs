﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 1129  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class represents the maze of the game.
    /// </summary>
    public sealed class Maze {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int Clean
        /// <summary>
        /// This is the id of the empty cells in the maze.
        /// </summary>
        public const int Clean = 93;
        #endregion

        #region int Dot
        /// <summary>
        /// This is the id of the cells with a dot inside.
        /// </summary>
        public const int Dot = 94;
        #endregion

        #region int BigDot
        /// <summary>
        /// This is the id of the cells with a big dot inside.
        /// </summary>
        public const int BigDot = 96;
        #endregion


        #region int MaximumNumberOfDots
        /// <summary>
        /// The maximum number of dots inside the maze.
        /// </summary>
        public const int MaximumNumberOfDots = 244;
        #endregion


        #region int SpriteSepX
        /// <summary>
        /// This is the separation between the sprites and the cells.
        /// </summary>
        public const int SpriteSepX = 8; //4 * 2;
        #endregion

        #region int SpriteSepY
        /// <summary>
        /// This is the separation between the sprites and the cells.
        /// </summary>
        public const int SpriteSepY = 8; //4 * 2;
        #endregion


        #region int PuckmanStartX
        /// <summary>
        /// This is start position in the x-axis of Puckman.
        /// </summary>
        public const int PuckmanStartX = 210; //105 * 2
        #endregion

        #region int PuckmanStartY
        /// <summary>
        /// This is start position in the y-axis of Puckman.
        /// </summary>
        public const int PuckmanStartY = 408; //204 * 2
        #endregion

        #region int RedGhostStartX
        /// <summary>
        /// This is start position in the x-axis of the red ghost.
        /// </summary>
        public const int RedGhostStartX = 208; //104 * 2
        #endregion

        #region int RedGhostStartY
        /// <summary>
        /// This is start position in the y-axis of the red ghost.
        /// </summary>
        public const int RedGhostStartY = 216; //108 * 2
        #endregion

        #region int PinkGhostStartX
        /// <summary>
        /// This is start position in the x-axis of the pink ghost.
        /// </summary>
        public const int PinkGhostStartX = 208; //104 * 2
        #endregion

        #region int PinkGhostStartY
        /// <summary>
        /// This is start position in the y-axis of the pink ghost.
        /// </summary>
        public const int PinkGhostStartY = 264; //132 * 2
        #endregion

        #region int BlueGhostStartX
        /// <summary>
        /// This is start position in the x-axis of the blue ghost.
        /// </summary>
        public const int BlueGhostStartX = 176; //88 * 2
        #endregion

        #region int BlueGhostStartY
        /// <summary>
        /// This is start position in the y-axis of the blue ghost.
        /// </summary>
        public const int BlueGhostStartY = 264; //132 * 2
        #endregion

        #region int BrownGhostStartX
        /// <summary>
        /// This is start position in the x-axis of the brown ghost.
        /// </summary>
        public const int BrownGhostStartX = 240; //120 * 2
        #endregion

        #region int BrownGhostStartY
        /// <summary>
        /// This is start position in the y-axis of the brown ghost.
        /// </summary>
        public const int BrownGhostStartY = 264; //132 * 2
        #endregion

        #region int FruitStartX
        /// <summary>
        /// This is start position in the x-axis of the fruit.
        /// </summary>
        public const int FruitStartX = 208; //104 * 2
        #endregion

        #region int FruitStartY
        /// <summary>
        /// This is start position in the y-axis of the fruit.
        /// </summary>
        public const int FruitStartY = 312; //156 * 2
        #endregion


        #region int GhostHouseStartX
        /// <summary>
        /// This is the start X coordinate of the ghost house area.
        /// </summary>
        public const int GhostHouseStartX = 176; // 88 * 2
        #endregion

        #region int GhostHouseStartY
        /// <summary>
        /// This is the start Y coordinate of the ghost house area.
        /// </summary>
        public const int GhostHouseStartY = 256; // 128 * 2
        #endregion

        #region int GhostHouseEndX
        /// <summary>
        /// This is the end X coordinate of the ghost house area.
        /// </summary>
        public const int GhostHouseEndX = 240; // 120 * 2
        #endregion

        #region int GhostHouseEndY
        /// <summary>
        /// This is the end Y coordinate of the ghost house area.
        /// </summary>
        public const int GhostHouseEndY = 272; // 136 * 2
        #endregion

        #region int GhostHouseCenterY
        /// <summary>
        /// This is the center Y coordinate of the ghost house area.
        /// </summary>
        public const int GhostHouseCenterY = 264; // 132 * 2
        #endregion

        #region int GhostDoorX
        /// <summary>
        /// This is the X coordinate of the ghost door area.
        /// </summary>
        public const int GhostDoorX = 208; // 104 * 2
        #endregion

        #region int GhostDoorStartY
        /// <summary>
        /// This is the start Y coordinate of the ghost door area.
        /// </summary>
        public const int GhostDoorStartY = 240; // 120 * 2
        #endregion

        #region int GhostDoorEndY
        /// <summary>
        /// This is the end Y coordinate of the ghost door area.
        /// </summary>
        public const int GhostDoorEndY = 254; // 127 * 2
        #endregion

        #region int GhostDoorLimitY
        /// <summary>
        /// This is the limit Y coordinate when the ghost is getting out the house.
        /// </summary>
        public const int GhostDoorLimitY = 216; // 108 * 2
        #endregion

        #region int GhostStartX
        /// <summary>
        /// This is the X coordinate of the ghost start point.
        /// </summary>
        public const int GhostStartX = 208; // 104 * 2
        #endregion

        #region int GhostStartY
        /// <summary>
        /// This is the Y coordinate of the ghost start point.
        /// </summary>
        public const int GhostStartY = 216; // 108 * 2
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region int[,] Data
        /// <summary>
        /// The data of the maze.
        /// </summary>
        public int[,] Data { get; private set; }
        #endregion

        #region bool DoorOpen
        /// <summary>
        /// This tells to the program if the door is open for the ghosts.
        /// </summary>
        public bool DoorOpen { get; set; }
        #endregion

        #region int NumberOfDots
        /// <summary>
        /// The number of dots inside the maze.
        /// </summary>
        public int NumberOfDots;
        #endregion

        #region int NumberOfEatedDots
        /// <summary>
        /// The number of eated dots inside the maze.
        /// </summary>
        public int NumberOfEatedDots { get { return Maze.MaximumNumberOfDots - NumberOfDots; } }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Maze()
        /// <summary>
        /// Constructs a new Maze object.
        /// </summary>
        public Maze() {
            this.Initialize();
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region Point SpriteCoordsToMaze(int x, int y)
        /// <summary>
        /// Transforms a sprite coordinates to the maze coordinates system.
        /// </summary>
        /// <param name="x">The X coordinate of the sprite.</param>
        /// <param name="y">The Y coordinate of the sprite.</param>
        /// <returns>The maze coordinates of the sprite.</returns>
        public static Point SpriteCoordsToMaze(int x, int y) {
            Point sp = new Point(x + Maze.SpriteSepX, y + Maze.SpriteSepY);
            Point coords = new Point();
            coords.X = sp.X / GameScreen.CellWidth;
            coords.Y = sp.Y / GameScreen.CellHeight;
            return coords;
        }
        #endregion

        #region bool IsGhostInsideTheHouse(Ghost ghost)
        /// <summary>
        /// Checks if a ghost is inside the house of the maze.
        /// </summary>
        /// <param name="ghost">The ghost to check.</param>
        /// <returns>If the ghost is in the house returns true, otherwise false.</returns>
        public static bool IsGhostInsideTheHouse(Ghost ghost) {
            return Maze.GhostHouseStartX <= ghost.X && ghost.X <= Maze.GhostHouseEndX &&
                   Maze.GhostHouseStartY <= ghost.Y && ghost.Y <= Maze.GhostHouseEndY;
        }
        #endregion

        #region bool IsGhostInTheStartPoint(Ghost ghost)
        /// <summary>
        /// Checks if a ghost is in the start point of the maze.
        /// </summary>
        /// <param name="ghost">The ghost to check.</param>
        /// <returns>If the ghost is in that point returns true, otherwise false.</returns>
        public static bool IsGhostInTheStartPoint(Ghost ghost) {
            return Maze.GhostStartX == ghost.X && ghost.Y == Maze.GhostStartY;
        }
        #endregion

        #region Initialize()
        /// <summary>
        /// Initializes the maze.
        /// </summary>
        public void Initialize() {
            this.Data = new int[,] {
                {093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093},
                {093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093},
                {093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093},
                {097, 101, 101, 101, 101, 101, 101, 101, 101, 101, 101, 101, 101, 109, 110, 101, 101, 101, 101, 101, 101, 101, 101, 101, 101, 101, 101, 098},
                {104, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 102},
                {104, 094, 125, 129, 129, 126, 094, 125, 129, 129, 129, 126, 094, 128, 130, 094, 125, 129, 129, 129, 126, 094, 125, 129, 129, 126, 094, 102},
                {104, 096, 128, 093, 093, 130, 094, 128, 093, 093, 093, 130, 094, 128, 130, 094, 128, 093, 093, 093, 130, 094, 128, 093, 093, 130, 096, 102},
                {104, 094, 124, 127, 127, 123, 094, 124, 127, 127, 127, 123, 094, 124, 123, 094, 124, 127, 127, 127, 123, 094, 124, 127, 127, 123, 094, 102},
                {104, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 102},
                {104, 094, 125, 129, 129, 126, 094, 125, 126, 094, 125, 129, 129, 129, 129, 129, 129, 126, 094, 125, 126, 094, 125, 129, 129, 126, 094, 102},
                {104, 094, 124, 127, 127, 123, 094, 128, 130, 094, 124, 127, 127, 132, 131, 127, 127, 123, 094, 128, 130, 094, 124, 127, 127, 123, 094, 102},
                {104, 094, 094, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 094, 094, 102},
                {100, 103, 103, 103, 103, 120, 094, 128, 133, 129, 129, 126, 093, 128, 130, 093, 125, 129, 129, 134, 130, 094, 119, 103, 103, 103, 103, 099},
                {093, 093, 093, 093, 093, 104, 094, 128, 131, 127, 127, 123, 093, 124, 123, 093, 124, 127, 127, 132, 130, 094, 102, 093, 093, 093, 093, 093},
                {093, 093, 093, 093, 093, 104, 094, 128, 130, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 128, 130, 094, 102, 093, 093, 093, 093, 093},
                {093, 093, 093, 093, 093, 104, 094, 128, 130, 093, 113, 103, 115, 121, 122, 116, 103, 114, 093, 128, 130, 094, 102, 093, 093, 093, 093, 093},
                {101, 101, 101, 101, 101, 117, 094, 124, 123, 093, 102, 093, 093, 093, 093, 093, 093, 104, 093, 124, 123, 094, 118, 101, 101, 101, 101, 101},
                {093, 093, 093, 093, 093, 093, 094, 093, 093, 093, 102, 093, 093, 093, 093, 093, 093, 104, 093, 093, 093, 094, 093, 093, 093, 093, 093, 093},
                {103, 103, 103, 103, 103, 120, 094, 125, 126, 093, 102, 093, 093, 093, 093, 093, 093, 104, 093, 125, 126, 094, 119, 103, 103, 103, 103, 103},
                {093, 093, 093, 093, 093, 104, 094, 128, 130, 093, 112, 101, 101, 101, 101, 101, 101, 111, 093, 128, 130, 094, 102, 093, 093, 093, 093, 093},
                {093, 093, 093, 093, 093, 104, 094, 128, 130, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 128, 130, 094, 102, 093, 093, 093, 093, 093},
                {093, 093, 093, 093, 093, 104, 094, 128, 130, 093, 125, 129, 129, 129, 129, 129, 129, 126, 093, 128, 130, 094, 102, 093, 093, 093, 093, 093},
                {097, 101, 101, 101, 101, 117, 094, 124, 123, 093, 124, 127, 127, 132, 131, 127, 127, 123, 093, 124, 123, 094, 118, 101, 101, 101, 101, 098},
                {104, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 102},
                {104, 094, 125, 129, 129, 126, 094, 125, 129, 129, 129, 126, 094, 128, 130, 094, 125, 129, 129, 129, 126, 094, 125, 129, 129, 126, 094, 102},
                {104, 094, 124, 127, 132, 130, 094, 124, 127, 127, 127, 123, 094, 124, 123, 094, 124, 127, 127, 127, 123, 094, 128, 131, 127, 123, 094, 102},
                {104, 096, 094, 094, 128, 130, 094, 094, 094, 094, 094, 094, 094, 093, 093, 094, 094, 094, 094, 094, 094, 094, 128, 130, 094, 094, 096, 102},
                {108, 129, 126, 094, 128, 130, 094, 125, 126, 094, 125, 129, 129, 129, 129, 129, 129, 126, 094, 125, 126, 094, 128, 130, 094, 125, 129, 107},
                {105, 127, 123, 094, 124, 123, 094, 128, 130, 094, 124, 127, 127, 132, 131, 127, 127, 123, 094, 128, 130, 094, 124, 123, 094, 124, 127, 106},
                {104, 094, 094, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 128, 130, 094, 094, 094, 094, 094, 094, 102},
                {104, 094, 125, 129, 129, 129, 129, 134, 133, 129, 129, 126, 094, 128, 130, 094, 125, 129, 129, 134, 133, 129, 129, 129, 129, 126, 094, 102},
                {104, 094, 124, 127, 127, 127, 127, 127, 127, 127, 127, 123, 094, 124, 123, 094, 124, 127, 127, 127, 127, 127, 127, 127, 127, 123, 094, 102},
                {104, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 094, 102},
                {100, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 103, 099},
                {093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093},
                {093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093, 093}
            };

            this.DoorOpen = false;
            this.NumberOfDots = Maze.MaximumNumberOfDots;
        }
        #endregion

        #region void Draw(GameScreen render)
        /// <summary>
        /// Draws the maze on the screen.
        /// </summary>
        /// <param name="render">The render engine.</param>
        public void Draw(GameScreen render) {
            for(int i = 0; i < GameScreen.NumberOfRows; i++) {
                for(int j = 0; j < GameScreen.NumberOfColums; j++) {
                    render.DrawTile(i, j, this.Data[i, j]);
                }
            }
        }
        #endregion

        #region bool isCellWalkable(int row, int col)
        /// <summary>
        /// Checks if a cell is walkable or not.
        /// </summary>
        /// <param name="row">The row of the maze.</param>
        /// <param name="col">The column of the maze.</param>
        /// <returns>If the cell is walkable returns true, otherwise false.</returns>
        private bool isCellWalkable(int row, int col) {
            return (this.Data[row, col] == Maze.Clean) ||
                   (this.Data[row, col] == Maze.Dot) ||
                   (this.Data[row, col] == Maze.BigDot);
        }
        #endregion

        #region bool CheckSpriteCoords(int x, int y)
        /// <summary>
        /// Checks if a sprite coordinates are valid or not.
        /// </summary>
        /// <param name="x">The X coordinate of the sprite.</param>
        /// <param name="y">The Y coordinate of the sprite.</param>
        /// <returns>If the coordinates are valid returns true, otherwise false.</returns>
        public bool CheckSpriteCoords(int x, int y) {
            // First, we have to get the maze coordinates.
            Point coords = Maze.SpriteCoordsToMaze(x, y);
            // Second, we check if we are inside the maze dimensions and if the cell is a
            // walkable one for the player and the entities.
            if(0 <= coords.X && coords.X < GameScreen.NumberOfColums &&
               0 <= coords.Y && coords.Y < GameScreen.NumberOfRows &&
               this.isCellWalkable(coords.Y, coords.X)) {
                // Here we obtain the coordinates of the current cell.
                int cx = coords.X * GameScreen.CellWidth;
                int cy = coords.Y * GameScreen.CellHeight;
                // Because we need it to check this:
                if(((x + SpriteSepX) == cx) && ((y + SpriteSepY) == cy)) {
                    // We're in the same coordinates, in the up-left cell's corner.
                    return true;
                } else if(((x + SpriteSepX) == cx) && ((y + SpriteSepY) != cy)) {
                    // We're in the left side of the cell, so we could be moving to up or down.
                    // So we have to check if the up and the down cell are walkable, but the up
                    // cell would be checked if we try to enter on it, se we just need only to check
                    // if we're trying to move down, to avoid to see an entity out of the right rail.
                    return this.isCellWalkable(coords.Y + 1, coords.X);
                } else if(((x + SpriteSepX) != cx) && ((y + SpriteSepY) == cy)) {
                    // We're in the up side of the cell, so we could be moving to the right or
                    // to the left. So we have to check this:
                    if(GameScreen.NumberOfColums > coords.X + 1) {
                        // If we aren't in the last column, we have to check if the right cell
                        // is walkable. Just like the up cell, the left one would be checked if
                        // we enter on it.
                        return this.isCellWalkable(coords.Y, coords.X + 1);
                    } else {
                        // If we are in the last column, we'll check if we're in the row 17
                        // and if we're in the correct y coordinate, because we can't move
                        // up or down, just to the left or to the right.
                        if(coords.Y == 17 && coords.X <= 28 &&
                           (coords.Y * GameScreen.CellHeight) == (y + SpriteSepY)) {
                            return true;
                        } else {
                            return false;
                        }
                    }
                } else {
                    return false;
                }
            } else if(coords.Y == 17) {
                // If we're out of the maze we must be in the row 17, the only place in the
                // maze that is allowed to be out of it, and we'll have to check this:
                if(coords.X >= -1 && coords.X <= 0 &&
                   (coords.Y * GameScreen.CellHeight) == (y + SpriteSepY) &&
                   x >= GameScreen.WormholeLeftX) {
                    // Here we are in the left side and we can't move to up or down, only to
                    // the left or to the right, and we must be to the right of the left
                    // wormhole X coordinate limit.
                    return true;
                } else if(coords.X <= 28 && coords.X >= 27 &&
                          (coords.Y * GameScreen.CellHeight) == (y + SpriteSepY) &&
                          x <= GameScreen.WormholeRightX) {
                    // Here we are in the right side and we can't move to up or down, only to
                    // the left or to the right, and we must be to the left of the right
                    // wormhole X coordinate limit.
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
        #endregion

        #region bool CheckGhostCoords(int x, int y)
        /// <summary>
        /// Checks if a ghost coordinates are valid or not.
        /// </summary>
        /// <param name="x">The X coordinate of the sprite.</param>
        /// <param name="y">The Y coordinate of the sprite.</param>
        /// <returns>If the coordinates are valid returns true, otherwise false.</returns>
        public bool CheckGhostCoords(int x, int y) {
            // First, we'll check if the ghost is inside the house.
            if(Maze.GhostHouseStartX <= x && x <= Maze.GhostHouseEndX &&
               Maze.GhostHouseStartY <= y && y <= Maze.GhostHouseEndY) {
                return true;
            } else {
                if(this.DoorOpen && Maze.GhostDoorX == x &&
                   Maze.GhostDoorStartY <= y && y <= Maze.GhostDoorEndY) {
                    // Second, we'll check if the ghost is crossing the door.
                    return true;
                } else if(Maze.GhostDoorX == x && Maze.GhostDoorLimitY < y &&
                          y <= Maze.GhostDoorStartY) {
                    // Third, we'll check if the ghost is out the door.
                    return true;
                } else {
                    // And finally, we'll check the rest.
                    return this.CheckSpriteCoords(x, y);
                }
            }
        }
        #endregion
    }
}