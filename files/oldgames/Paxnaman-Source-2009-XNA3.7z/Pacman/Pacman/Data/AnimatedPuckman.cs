﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents an animated Puckman entity.
    /// </summary>
    public class AnimatedPuckman : Puckman {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region MovingDirection NeededDirection
        /// <summary>
        /// This is the needed direction by the demo and it will be checked in the future,
        /// to see if the entity can move in that direction.
        /// </summary>
        public MovingDirection NeededDirection;
        #endregion

        #region bool Alive
        /// <summary>
        /// This tells the program if puckman is alive or not.
        /// </summary>
        private bool alive;

        /// <summary>
        /// This tells the program if puckman is alive or not.
        /// </summary>
        public bool Alive { get { return alive; } }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region AnimatedPuckman()
        /// <summary>
        /// Constructs a new AnimatedPuckman object.
        /// </summary>
        public AnimatedPuckman() {
            this.NeededDirection = MovingDirection.None;
            this.alive = true;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Respawn()
        /// <summary>
        /// Respawns the puckman entity.
        /// </summary>
        public void Respawn() {
            // MovingEntity data
            this.SetDirection(MovingDirection.None);
            this.ResetSpeed();
            this.SetFast();
            this.ResetTime();
            // Player data
            this.NeededDirection = MovingDirection.None;
            this.alive = true;
        }
        #endregion

        #region void Kill()
        /// <summary>
        /// Kills the puckman entity.
        /// </summary>
        public void Kill() {
            this.setCurrentSprite(Puckman.deathSprite);
            this.Direction = MovingDirection.None;
            this.alive = false;
        }
        #endregion

        #region void testNeededDirection()
        /// <summary>
        /// Tests if the entity can change the direction.
        /// </summary>
        protected void testNeededDirection() {
            // First, we'll validate the asked direction.
            if(this.Direction != this.NeededDirection) {
                // And if the direction is valid, we'll change the old one.
                if(this.testUpdateCoordinates(this.NeededDirection)) {
                    this.SetDirection(this.NeededDirection);
                }
            }
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner state of the entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public override void Update(long time) {
            if(this.Alive) {
                // When the entity is alive, we'll control the asked direction.
                this.testNeededDirection();

                // And then, we'll control the tick logic of the entity.
                this.currentTime += time;
                while(this.currentTime >= this.maxTimeInterval) {
                    this.currentTime -= this.maxTimeInterval;

                    // In every tick, we'll update the coordinates and the sprites.
                    if(this.updateCoordinates()) {
                        this.sprites[this.currentSprite].Update(this.maxTimeInterval);
                    }
                }
            } else {
                // When the entity isn't alive, we only update the sprites.
                this.sprites[this.currentSprite].Update(time);
            }
        }
        #endregion
    }
}