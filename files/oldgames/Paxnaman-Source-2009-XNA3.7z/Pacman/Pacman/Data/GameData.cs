﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents the data of the game.
    /// </summary>
    public sealed class GameData {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int MinCoins
        /// <summary>
        /// The minimum number of coins of the game.
        /// </summary>
        public const int MinCoins = 0;
        #endregion

        #region int MaxCoins
        /// <summary>
        /// The maximum number of coins of the game.
        /// </summary>
        public const int MaxCoins = 99;
        #endregion

        #region int MaxFruits
        /// <summary>
        /// The maximum number of fruits in the array.
        /// </summary>
        public const int MaxFruits = 6;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region int HighScore
        /// <summary>
        /// The highest score in the game.
        /// </summary>
        public int HighScore { get; set; }
        #endregion

        #region int Coins
        /// <summary>
        /// The inserted coins in the game.
        /// </summary>
        public int coins;

        /// <summary>
        /// The inserted coins in the game.
        /// </summary>
        public int Coins {
            get { return coins; }
            set {
                if(GameData.MinCoins <= value && value <= GameData.MaxCoins) {
                    coins = value;
                }
            }
        }
        #endregion

        #region Player Player1
        /// <summary>
        /// The data of the player 1.
        /// </summary>
        public Player Player1 { get; private set; }
        #endregion

        #region Player Player2
        /// <summary>
        /// The data of the player 2.
        /// </summary>
        public Player Player2 { get; private set; }
        #endregion

        #region int NumberOfPlayers
        /// <summary>
        /// The number of players in the game.
        /// </summary>
        public int NumberOfPlayers { get; set; }
        #endregion

        #region int PlayerTurn
        /// <summary>
        /// The current player turn.
        /// </summary>
        private int playerTurn;

        /// <summary>
        /// The current player turn.
        /// </summary>
        public int PlayerTurn {
            get { return playerTurn; }
            set {
                if(1 <= value && value <= 2) {
                    playerTurn = value;
                }
            }
        }
        #endregion

        #region FruitType[] LastFruits
        /// <summary>
        /// The list of fruits of the last or current game.
        /// </summary>
        public FruitType[] LastFruits { get; set; }
        #endregion

        #region Player Player
        /// <summary>
        /// Gets the current player.
        /// </summary>
        public Player Player {
            get {
                if(this.PlayerTurn == 1) {
                    return this.Player1;
                } else {
                    return this.Player2;
                }
            }
        }
        #endregion

        #region int Score
        /// <summary>
        /// Gets or sets the current score.
        /// </summary>
        public int Score {
            get {
                if(this.PlayerTurn == 1) {
                    return this.Player1.Score;
                } else {
                    return this.Player2.Score;
                }
            }
            set {
                if(this.PlayerTurn == 1) {
                    this.Player1.Score = value;
                } else {
                    this.Player2.Score = value;
                }
            }
        }
        #endregion

        #region int Level
        /// <summary>
        /// Gets or sets the current level.
        /// </summary>
        public int Level {
            get {
                if(this.PlayerTurn == 1) {
                    return this.Player1.Level;
                } else {
                    return this.Player2.Level;
                }
            }
            set {
                if(this.PlayerTurn == 1) {
                    this.Player1.Level = value;
                } else {
                    this.Player2.Level = value;
                }
            }
        }
        #endregion

        #region Maze Maze
        /// <summary>
        /// Gets the current maze.
        /// </summary>
        public Maze Maze {
            get {
                if(this.PlayerTurn == 1) {
                    return this.Player1.Maze;
                } else {
                    return this.Player2.Maze;
                }
            }
        }
        #endregion

        #region PlayerPuckman Puckman
        /// <summary>
        /// Gets the current avatar.
        /// </summary>
        public PlayerPuckman Puckman {
            get {
                if(this.PlayerTurn == 1) {
                    return this.Player1.Puckman;
                } else {
                    return this.Player2.Puckman;
                }
            }
        }
        #endregion

        #region int ExtraLives
        /// <summary>
        /// Gets or sets the current number of extra lives.
        /// </summary>
        public int ExtraLives {
            get {
                if(this.PlayerTurn == 1) {
                    return this.Player1.ExtraLives;
                } else {
                    return this.Player2.ExtraLives;
                }
            }
            set {
                if(this.PlayerTurn == 1) {
                    this.Player1.ExtraLives = value;
                } else {
                    this.Player2.ExtraLives = value;
                }
            }
        }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameData()
        /// <summary>
        /// Constructs a new GameData object.
        /// </summary>
        public GameData() {
            this.HighScore = 0;
            this.Coins = GameData.MinCoins;
            this.Player1 = new Player();
            this.Player2 = new Player();
            this.LastFruits = null;
            this.NumberOfPlayers = 1;
            this.PlayerTurn = 1;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void AddCoin()
        /// <summary>
        /// Adds a coin to the game.
        /// </summary>
        public void AddCoin() {
            this.Coins += 1;
        }
        #endregion

        #region void AddFruit(FruitType fruit)
        /// <summary>
        /// Adds a fruit to the last fruits array.
        /// </summary>
        /// <param name="fruit">The type of the last fruit added.</param>
        public void AddFruit(FruitType fruit) {
            if(this.LastFruits == null) {
                // When there is no array, we must create one with only one fruit.
                this.LastFruits = new FruitType[1];
                this.LastFruits[0] = fruit;

            } else {
                if(this.LastFruits.Length < GameData.MaxFruits) {
                    // If there is at least one fruit and we haven't the maximum, we'll
                    // create a new array with the current fruits, plus the last one.
                    FruitType[] aux = new FruitType[this.LastFruits.Length + 1];
                    for(int i = 0; i < this.LastFruits.Length; i++) {
                        aux[i] = this.LastFruits[i];
                    }
                    aux[this.LastFruits.Length] = fruit;
                    this.LastFruits = aux;

                } else {
                    // If we have get the maximum number of fruits inside the array, we'll
                    // erase the oldest, and add the new in the last position.
                    for(int i = 1; i < GameData.MaxFruits; i++) {
                        this.LastFruits[i - 1] = this.LastFruits[i];
                    }
                    this.LastFruits[GameData.MaxFruits - 1] = fruit;
                }
            }
        }
        #endregion

        #region void CheckHighScore()
        /// <summary>
        /// Checks if the current score is the high score.
        /// </summary>
        public void CheckHighScore() {
            if(this.Score > this.HighScore) {
                this.HighScore = this.Score;
            }
        }
        #endregion

        #region void ChangeTurn()
        /// <summary>
        /// Change the player turn.
        /// </summary>
        public void ChangeTurn() {
            if(this.PlayerTurn == 1) {
                this.PlayerTurn = 2;
            } else {
                this.PlayerTurn = 1;
            }
        }
        #endregion
    }
}