﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents a ghost entity with a sequence.
    /// </summary>
    public sealed class SequencedGhost : Ghost {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Sequence Sequence
        /// <summary>
        /// The sequence of the entity.
        /// </summary>
        public Sequence Sequence { get; set; }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region SequencedGhost()
        /// <summary>
        /// Constructs a new SequencedGhost object.
        /// </summary>
        /// <param name="type">The type of the ghost.</param>
        /// <param name="sequence">The sequence of the entity.</param>
        public SequencedGhost(GhostType type, Sequence sequence) : base(type) {
            this.Sequence = sequence;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Update(long time)
        /// <summary>
        /// Updates the inner state of the entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public override void Update(long time) {
            // First, we'll control the speed and we'll update the sprites.
            this.SpeedController(this);
            this.updateSprites(time);

            // Second, we'll control the tick logic of the entity.
            this.currentTime += time;
            while(this.currentTime >= this.maxTimeInterval) {
                this.currentTime -= this.maxTimeInterval;

                // And in every tick, we'll check the sequence, the direction and the coordinates.
                this.Sequence.Check(this);
                this.testNeededDirection();
                this.updateCoordinates();
            }
        }
        #endregion
    }
}