﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents the Super-Puckman entity.
    /// </summary>
    public sealed class SuperPuckman : MovingEntity {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int maxFps
        /// <summary>
        /// The maximum number of frames per second of the animation.
        /// </summary>
        private const int maxFps = 5;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Animation sprite
        /// <summary>
        /// The sprite of the entity.
        /// </summary>
        private Animation sprite;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region SuperPuckman()
        /// <summary>
        /// Constructs a new SuperPuckman object.
        /// </summary>
        public SuperPuckman() {
            // SuperPuckman data
            GameScreen render = CoreManager.Instance.Screen;
            this.sprite = new Animation(render, new int[] { 13, 14, 15 }, SuperPuckman.maxFps);
            // MovingEntity data
            this.Direction = MovingDirection.Right;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void SetDirection(MovingDirection dir)
        /// <summary>
        /// Sets the direction of the entity.
        /// </summary>
        /// <param name="dir">The direction of the entity.</param>
        public override void SetDirection(MovingDirection dir) {
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the Puckman inside the screen.
        /// </summary>
        public override void Draw() {
            this.sprite.Draw(this.X, this.Y);
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner state of the entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public override void Update(long time) {
            // Here we'll control the tick logic of the entity.
            this.currentTime += time;
            while(this.currentTime >= this.maxTimeInterval) {
                this.currentTime -= this.maxTimeInterval;
                // And in every tick, we'll update the sprites and the movement.
                this.sprite.Update(this.maxTimeInterval);
                this.Move();
            }
        }
        #endregion
    }
}