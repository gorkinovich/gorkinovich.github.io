﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents the player data.
    /// </summary>
    public sealed class Player {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region int Score
        /// <summary>
        /// The score of the player.
        /// </summary>
        public int Score { get; set; }
        #endregion

        #region int Level
        /// <summary>
        /// The level of the player.
        /// </summary>
        public int Level { get; set; }
        #endregion

        #region Maze Maze
        /// <summary>
        /// The maze of the player.
        /// </summary>
        public Maze Maze { get; private set; }
        #endregion

        #region PlayerPuckman Puckman
        /// <summary>
        /// The avatar of the player.
        /// </summary>
        public PlayerPuckman Puckman { get; private set; }
        #endregion

        #region int ExtraLives
        /// <summary>
        /// The extra lives of the player.
        /// </summary>
        private int extraLives;

        /// <summary>
        /// The extra lives of the player.
        /// </summary>
        public int ExtraLives {
            get { return extraLives; }
            set {
                if(0 <= value && value <= 6) {
                    extraLives = value;
                }
            }
        }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Player()
        /// <summary>
        /// Constructs a new Player object.
        /// </summary>
        public Player() {
            this.Maze = new Maze();
            this.Puckman = new PlayerPuckman();
            this.Puckman.CheckCoordinates = this.Maze.CheckSpriteCoords;
            this.NewGame();
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void NewGame()
        /// <summary>
        /// Sets the data to a new game situation.
        /// </summary>
        public void NewGame() {
            this.Score = 0;
            this.Level = 1;
            this.ExtraLives = 3;
            this.Maze.Initialize();
        }
        #endregion

        #region void NextLevel()
        /// <summary>
        /// Sets the data to a next level situation.
        /// </summary>
        public void NextLevel() {
            this.Level++;
        }
        #endregion
    }
}