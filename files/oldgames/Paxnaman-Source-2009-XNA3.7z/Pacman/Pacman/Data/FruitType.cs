﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This enumeration represents the different types of fruits.
    /// </summary>
    public enum FruitType {
        /// <summary>The id of the cherry fruit.</summary>
        Cherry,
        /// <summary>The id of the strawberry fruit.</summary>
        Strawberry,
        /// <summary>The id of the peach fruit.</summary>
        Peach,
        /// <summary>The id of the bell fruit.</summary>
        Bell,
        /// <summary>The id of the apple fruit.</summary>
        Apple,
        /// <summary>The id of the grape fruit.</summary>
        Grape,
        /// <summary>The id of the flower fruit.</summary>
        Flower,
        /// <summary>The id of the key fruit.</summary>
        Key
    }
}