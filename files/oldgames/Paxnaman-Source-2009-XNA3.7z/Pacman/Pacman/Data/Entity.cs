﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents an entity inside the game.
    /// </summary>
    public abstract class Entity {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region int X
        /// <summary>
        /// The x coordinate.
        /// </summary>
        public int X;
        #endregion

        #region int Y
        /// <summary>
        /// The y coordinate.
        /// </summary>
        public int Y;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Entity()
        /// <summary>
        /// Constructs a new Entity object.
        /// </summary>
        public Entity() {
            this.X = 0;
            this.Y = 0;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Draw()
        /// <summary>
        /// Draws the entity inside the screen.
        /// </summary>
        public abstract void Draw();
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner state of the entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public abstract void Update(long time);
        #endregion

        #region void SetCoordinates(int x, int y)
        /// <summary>
        /// Sets the new coordinates of the entity.
        /// </summary>
        /// <param name="x">The x coordinate.</param>
        /// <param name="y">The y coordinate.</param>
        public void SetCoordinates(int x, int y) {
            this.X = x;
            this.Y = y;
        }
        #endregion
    }
}