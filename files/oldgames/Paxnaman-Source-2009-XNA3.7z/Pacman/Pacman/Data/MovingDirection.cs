﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This enumeration is a list of the allowed directions of the entities.
    /// </summary>
    public enum MovingDirection {
        /// <summary>The id of the up direction.</summary>
        Up = 3,
        /// <summary>The id of the down direction.</summary>
        Down = 1,
        /// <summary>The id of the left direction.</summary>
        Left = 2,
        /// <summary>The id of the right direction.</summary>
        Right = 0,
        /// <summary>The id of the none direction.</summary>
        None = 5
    }
}