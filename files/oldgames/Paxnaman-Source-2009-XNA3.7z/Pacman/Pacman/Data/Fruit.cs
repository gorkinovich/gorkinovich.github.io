﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents a Fruit entity.
    /// </summary>
    public sealed class Fruit : Entity {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region FruitType Type
        /// <summary>
        /// The type of the fruit.
        /// </summary>
        public FruitType Type { get; set; }
        #endregion

        #region int Value
        /// <summary>
        /// The value of the fruit.
        /// </summary>
        public int Value {
            get {
                switch(Type) {
                    case FruitType.Cherry: return 100;
                    case FruitType.Strawberry: return 300;
                    case FruitType.Peach: return 500;
                    case FruitType.Apple: return 700;
                    case FruitType.Grape: return 1000;
                    case FruitType.Flower: return 2000;
                    case FruitType.Bell: return 3000;
                    case FruitType.Key: return 5000;
                    default: return 0;
                }
            }
        }
        #endregion

        #region FontSymbol Symbol
        /// <summary>
        /// The symbol of the fruit's value.
        /// </summary>
        public FontSymbol Symbol {
            get {
                switch(Type) {
                    case FruitType.Cherry: return FontSymbol.N100;
                    case FruitType.Strawberry: return FontSymbol.N300;
                    case FruitType.Peach: return FontSymbol.N500;
                    case FruitType.Apple: return FontSymbol.N700;
                    case FruitType.Grape: return FontSymbol.N1000;
                    case FruitType.Flower: return FontSymbol.N2000;
                    case FruitType.Bell: return FontSymbol.N3000;
                    case FruitType.Key: return FontSymbol.N5000;
                    default: return FontSymbol.Namco;
                }
            }
        }
        #endregion

        #region int Sprite
        /// <summary>
        /// The sprite of the fruit.
        /// </summary>
        public int Sprite {
            get {
                switch(Type) {
                    case FruitType.Cherry: return 1;
                    case FruitType.Strawberry: return 2;
                    case FruitType.Peach: return 3;
                    case FruitType.Apple: return 5;
                    case FruitType.Grape: return 6;
                    case FruitType.Flower: return 7;
                    case FruitType.Bell: return 4;
                    case FruitType.Key: return 8;
                    default: return 0;
                }
            }
        }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Fruit()
        /// <summary>
        /// Constructs a new Fruit object.
        /// </summary>
        public Fruit() {
            this.Type = FruitType.Cherry;
        }
        #endregion

        #region Fruit(FruitType type)
        /// <summary>
        /// Constructs a new Fruit object.
        /// </summary>
        /// <param name="Type">The type of the fruit.</param>
        public Fruit(FruitType type) {
            this.Type = type;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Draw()
        /// <summary>
        /// Draws the entity inside the screen.
        /// </summary>
        public override void Draw() {
            CoreManager.Instance.Screen.DrawSprite(this.X, this.Y, this.Sprite);
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner state of the entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public override void Update(long time) {
        }
        #endregion

    }
}