﻿/*
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int maxFps
        /// <summary>
        /// The maximum number of frames per second of the animation.
        /// </summary>
        private const int maxFps = 4;
        #endregion

        #region int ghostLookFps
        /// <summary>
        /// The maximum number of frames per second of the ghost look animation.
        /// </summary>
        private const int ghostLookFps = 1;
        #endregion

        #region int intermission1Sprite
        /// <summary>
        /// The id of the sprite "intermission 1".
        /// </summary>
        private const int intermission1Sprite = 3;
        #endregion

        #region int intermission2Sprite
        /// <summary>
        /// The id of the sprite "intermission 2".
        /// </summary>
        private const int intermission2Sprite = 4;
        #endregion

        #region int intermission3Sprite
        /// <summary>
        /// The id of the sprite "intermission 3".
        /// </summary>
        private const int intermission3Sprite = 5;
        #endregion

        #region int intermission4Sprite
        /// <summary>
        /// The id of the sprite "intermission 4".
        /// </summary>
        private const int intermission4Sprite = 6;
        #endregion


            this.otherSprites[Ghost.intermission1Sprite] = new Animation(render, new int[] { 77, 78 }, Ghost.maxFps);
            this.otherSprites[Ghost.intermission2Sprite] = new Animation(render, new int[] { 79, 80 }, Ghost.ghostLookFps);
            this.otherSprites[Ghost.intermission3Sprite] = new Animation(render, new int[] { 82, 83 }, Ghost.maxFps);
            this.otherSprites[Ghost.intermission4Sprite] = new Animation(render, new int[] { 84, 85 }, Ghost.maxFps);
*/