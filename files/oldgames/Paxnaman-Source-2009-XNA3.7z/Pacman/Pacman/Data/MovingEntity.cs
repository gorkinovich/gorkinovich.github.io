﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents an entity that can move inside the game.
    /// </summary>
    public abstract class MovingEntity : Entity {
        //******************************************************************************************
        // Types
        //******************************************************************************************

        #region delegate bool CheckSpriteCoordinates(int x, int y)
        /// <summary>
        /// Checks if the entity coordinates are valid or not.
        /// </summary>
        /// <param name="x">The X coordinate of the entity.</param>
        /// <param name="y">The Y coordinate of the entity.</param>
        /// <returns>If the coordinates are valid returns true, otherwise false.</returns>
        public delegate bool CheckSpriteCoordinates(int x, int y);
        #endregion

        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int NoSpeed
        /// <summary>
        /// This is the speed when the entity doesn't move.
        /// </summary>
        public const int NoSpeed = 0;
        #endregion

        #region int MinSpeed
        /// <summary>
        /// This is the minimum speed for any entity.
        /// </summary>
        public const int MinSpeed = 2;
        #endregion

        #region long minInterval
        /// <summary>
        /// A normal amount of time that an interval can have.
        /// </summary>
        private const long minInterval = 15;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region long maxTimeInterval
        /// <summary>
        /// The maximum time interval to move.
        /// </summary>
        protected long maxTimeInterval;
        #endregion

        #region long currentTime
        /// <summary>
        /// The current time passed.
        /// </summary>
        protected long currentTime;
        #endregion

        #region int Speed
        /// <summary>
        /// The speed of the entity.
        /// </summary>
        private int speed;

        /// <summary>
        /// The speed of the entity.
        /// </summary>
        public int Speed {
            get { return speed; }
            set {
                if(value == MovingEntity.NoSpeed || value == MovingEntity.MinSpeed) {
                    speed = value;
                } else {
                    speed = MovingEntity.NoSpeed;
                }
            }
        }
        #endregion

        #region MovingDirection Direction
        /// <summary>
        /// The direction of the speed.
        /// </summary>
        public MovingDirection Direction { get; protected set; }
        #endregion

        #region CheckSpriteCoordinates CheckCoordinates
        /// <summary>
        /// This calls to a method that checks if a new coordinates are valid or not.
        /// </summary>
        public CheckSpriteCoordinates CheckCoordinates;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region MovingEntity()
        /// <summary>
        /// Constructs a new MovingEntity object.
        /// </summary>
        public MovingEntity() {
            this.Direction = MovingDirection.None;
            this.ResetSpeed();
            this.maxTimeInterval = MovingEntity.minInterval;
            this.ResetTime();
            this.CheckCoordinates = this.checkSpriteCoords;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region bool checkSpriteCoords(int x, int y)
        /// <summary>
        /// The generic check function of the entity, must be changed for a proper one.
        /// </summary>
        /// <param name="x">This parameter isn't used.</param>
        /// <param name="y">This parameter isn't used.</param>
        /// <returns>Always returns true.</returns>
        protected bool checkSpriteCoords(int x, int y) {
            return true;
        }
        #endregion

        #region bool testUpdateCoordinates(MovingDirection d)
        /// <summary>
        /// Tests if the coordinates can be updated.
        /// </summary>
        /// <param name="d">The direction of the movement.</param>
        /// <returns>If the update can be done returns true, otherwise false.</returns>
        protected bool testUpdateCoordinates(MovingDirection d) {
            switch(d) {
                case MovingDirection.Up:
                    return this.CheckCoordinates(this.X, this.Y - this.Speed);
                case MovingDirection.Down:
                    return this.CheckCoordinates(this.X, this.Y + this.Speed);
                case MovingDirection.Left:
                    return this.CheckCoordinates(this.X - this.Speed, this.Y);
                case MovingDirection.Right:
                    return this.CheckCoordinates(this.X + this.Speed, this.Y);
                default:
                    return false;
            }
        }
        #endregion

        #region bool updateCoordinates()
        /// <summary>
        /// Tries to update the coordinates of the entity.
        /// </summary>
        /// <returns>If the update is done returns true, otherwise false.</returns>
        protected bool updateCoordinates() {
            // We'll check if the entity can move through the maze.
            if(this.testUpdateCoordinates(this.Direction)) {
                // If the test returns true, we'll move the entity.
                this.Move();
                return true;
            } else {
                // If we're in the maze but we can't pass the test, then it could be that
                // we're going through the wormhole, so we'll check that chance.
                if(this.Direction == MovingDirection.Left && this.X <= GameScreen.WormholeLeftX) {
                    this.X = GameScreen.WormholeRightX;
                    return true;
                } else if(this.Direction == MovingDirection.Right && this.X >= GameScreen.WormholeRightX) {
                    this.X = GameScreen.WormholeLeftX;
                    return true;
                } else {
                    return false;
                }
            }
        }
        #endregion

        #region void ResetTime()
        /// <summary>
        /// Resets the time of the entity.
        /// </summary>
        public void ResetTime() {
            this.currentTime = 0;
        }
        #endregion

        #region void ResetSpeed()
        /// <summary>
        /// Resets the speed of the entity.
        /// </summary>
        public void ResetSpeed() {
            this.Speed = MovingEntity.MinSpeed;
        }
        #endregion

        #region void StopSpeed()
        /// <summary>
        /// Stops the speed of the entity.
        /// </summary>
        public void StopSpeed() {
            this.Speed = MovingEntity.NoSpeed;
        }
        #endregion

        #region void SetSpeedInterval(long interval)
        /// <summary>
        /// Sets the speed interval of the entity.
        /// </summary>
        /// <param name="interval">The new maximum tick interval of time.</param>
        public void SetSpeedInterval(long interval) {
            this.maxTimeInterval = interval;
        }
        #endregion

        #region void SetDirection(MovingDirection dir)
        /// <summary>
        /// Sets the direction of the entity.
        /// </summary>
        /// <param name="dir">The direction of the entity.</param>
        public abstract void SetDirection(MovingDirection dir);
        #endregion

        #region void Move()
        /// <summary>
        /// Moves the entity to the current direction.
        /// </summary>
        public void Move() {
            switch(this.Direction) {
                case MovingDirection.Up: this.Y -= this.Speed; break;
                case MovingDirection.Down: this.Y += this.Speed; break;
                case MovingDirection.Left: this.X -= this.Speed; break;
                case MovingDirection.Right: this.X += this.Speed; break;
            }
        }
        #endregion
    }
}