﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents a ghost entity.
    /// </summary>
    public class Ghost : MovingEntity {
        //******************************************************************************************
        // Types
        //******************************************************************************************

        #region delegate void GhostSpeedController(Ghost ghost)
        /// <summary>
        /// Controls that the speed interval tick of the ghost is right.
        /// </summary>
        /// <param name="ghost">The ghost to be checked.</param>
        public delegate void GhostSpeedController(Ghost ghost);
        #endregion

        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int numberOfGhosts
        /// <summary>
        /// The number of different ghosts.
        /// </summary>
        private const int numberOfGhosts = 4;
        #endregion

        #region int redGhost
        /// <summary>
        /// The id of the red ghost.
        /// </summary>
        private const int redGhost = 0;
        #endregion

        #region int pinkGhost
        /// <summary>
        /// The id of the pink ghost.
        /// </summary>
        private const int pinkGhost = 1;
        #endregion

        #region int blueGhost
        /// <summary>
        /// The id of the blue ghost.
        /// </summary>
        private const int blueGhost = 2;
        #endregion

        #region int brownGhost
        /// <summary>
        /// The id of the brown ghost.
        /// </summary>
        private const int brownGhost = 3;
        #endregion


        #region int maxFps
        /// <summary>
        /// The maximum number of frames per second of the animation.
        /// </summary>
        private const int maxFps = 8;
        #endregion


        #region int numberOfNormalSprites
        /// <summary>
        /// The number of sprites of the entity.
        /// </summary>
        private const int numberOfNormalSprites = 4;
        #endregion

        #region int rightSprite
        /// <summary>
        /// The id of the sprite "right".
        /// </summary>
        private const int rightSprite = 0;
        #endregion

        #region int downSprite
        /// <summary>
        /// The id of the sprite "down".
        /// </summary>
        private const int downSprite = 1;
        #endregion

        #region int leftSprite
        /// <summary>
        /// The id of the sprite "left".
        /// </summary>
        private const int leftSprite = 2;
        #endregion

        #region int upSprite
        /// <summary>
        /// The id of the sprite "up".
        /// </summary>
        private const int upSprite = 3;
        #endregion


        #region int numberOfOtherSprites
        /// <summary>
        /// The number of sprites of the entity.
        /// </summary>
        private const int numberOfOtherSprites = 3;
        #endregion

        #region int blueSprite
        /// <summary>
        /// The id of the sprite "blue".
        /// </summary>
        private const int blueSprite = 0;
        #endregion

        #region int white1Sprite
        /// <summary>
        /// The id of the sprite "white 1".
        /// </summary>
        private const int white1Sprite = 1;
        #endregion

        #region int white2Sprite
        /// <summary>
        /// The id of the sprite "white 2".
        /// </summary>
        private const int white2Sprite = 2;
        #endregion


        #region long deadSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is dead.
        /// </summary>
        protected const long deadSpeedInterval = 13;
        #endregion

        #region long normalSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is normal.
        /// </summary>
        protected const long normalSpeedInterval = 15;
        #endregion

        #region long vulnerableSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is vulnerable.
        /// </summary>
        protected const long vulnerableSpeedInterval = 26;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Animation[,] normalSprites
        /// <summary>
        /// The sprites of the entity.
        /// </summary>
        private Animation[,] normalSprites;
        #endregion

        #region int typeOfGhost
        /// <summary>
        /// The current type of ghost.
        /// </summary>
        private int typeOfGhost;
        #endregion

        #region GhostType TypeOfGhost
        /// <summary>
        /// The current type of ghost.
        /// </summary>
        public GhostType TypeOfGhost { get; private set; }
        #endregion

        #region int currentNormalSprite
        /// <summary>
        /// The current used normal sprite.
        /// </summary>
        private int currentNormalSprite;
        #endregion

        #region Animation[] otherSprites
        /// <summary>
        /// The sprites of the entity.
        /// </summary>
        private Animation[] otherSprites;
        #endregion

        #region int currentOtherSprite
        /// <summary>
        /// The current used other sprite.
        /// </summary>
        private int currentOtherSprite;
        #endregion

        #region MovingDirection NeededDirection
        /// <summary>
        /// This is the needed direction by the demo and it will be checked in the future,
        /// to see if the entity can move in that direction.
        /// </summary>
        public MovingDirection NeededDirection;
        #endregion

        #region bool Alive
        /// <summary>
        /// This tells to the program if a ghost is alive or not.
        /// </summary>
        private bool alive;

        /// <summary>
        /// This tells to the program if a ghost is alive or not.
        /// </summary>
        public bool Alive { get { return alive; } }
        #endregion

        #region GhostState State
        /// <summary>
        /// This is the state of an alive ghost.
        /// </summary>
        private GhostState state;

        /// <summary>
        /// This is the state of an alive ghost.
        /// </summary>
        public GhostState State { get { return state; } }
        #endregion

        #region GhostSpeedController SpeedController
        /// <summary>
        /// The speed controller of the ghost.
        /// </summary>
        public GhostSpeedController SpeedController;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Ghost(GhostType type)
        /// <summary>
        /// Constructs a new Ghost object.
        /// </summary>
        /// <param name="type">The type of the ghost.</param>
        public Ghost(GhostType type) {
            // First, get the render manager.
            GameScreen render = CoreManager.Instance.Screen;
            // Then define the normal state array of animations.
            #region Normal Sprites
            this.normalSprites = new Animation[Ghost.numberOfGhosts, Ghost.numberOfNormalSprites];

            this.normalSprites[Ghost.redGhost, Ghost.rightSprite] = new Animation(render, new int[] { 37, 38 }, Ghost.maxFps);
            this.normalSprites[Ghost.redGhost, Ghost.downSprite] = new Animation(render, new int[] { 39, 40 }, Ghost.maxFps);
            this.normalSprites[Ghost.redGhost, Ghost.leftSprite] = new Animation(render, new int[] { 41, 42 }, Ghost.maxFps);
            this.normalSprites[Ghost.redGhost, Ghost.upSprite] = new Animation(render, new int[] { 43, 44 }, Ghost.maxFps);

            this.normalSprites[Ghost.pinkGhost, Ghost.rightSprite] = new Animation(render, new int[] { 53, 54 }, Ghost.maxFps);
            this.normalSprites[Ghost.pinkGhost, Ghost.downSprite] = new Animation(render, new int[] { 55, 56 }, Ghost.maxFps);
            this.normalSprites[Ghost.pinkGhost, Ghost.leftSprite] = new Animation(render, new int[] { 57, 58 }, Ghost.maxFps);
            this.normalSprites[Ghost.pinkGhost, Ghost.upSprite] = new Animation(render, new int[] { 59, 60 }, Ghost.maxFps);

            this.normalSprites[Ghost.blueGhost, Ghost.rightSprite] = new Animation(render, new int[] { 45, 46 }, Ghost.maxFps);
            this.normalSprites[Ghost.blueGhost, Ghost.downSprite] = new Animation(render, new int[] { 47, 48 }, Ghost.maxFps);
            this.normalSprites[Ghost.blueGhost, Ghost.leftSprite] = new Animation(render, new int[] { 49, 50 }, Ghost.maxFps);
            this.normalSprites[Ghost.blueGhost, Ghost.upSprite] = new Animation(render, new int[] { 51, 52 }, Ghost.maxFps);

            this.normalSprites[Ghost.brownGhost, Ghost.rightSprite] = new Animation(render, new int[] { 61, 62 }, Ghost.maxFps);
            this.normalSprites[Ghost.brownGhost, Ghost.downSprite] = new Animation(render, new int[] { 63, 64 }, Ghost.maxFps);
            this.normalSprites[Ghost.brownGhost, Ghost.leftSprite] = new Animation(render, new int[] { 65, 66 }, Ghost.maxFps);
            this.normalSprites[Ghost.brownGhost, Ghost.upSprite] = new Animation(render, new int[] { 67, 68 }, Ghost.maxFps);
            #endregion
            // Then define the other states array of animations.
            #region Other Sprites
            this.otherSprites = new Animation[Ghost.numberOfOtherSprites];
            this.otherSprites[Ghost.blueSprite] = new Animation(render, new int[] { 69, 70 }, Ghost.maxFps);
            this.otherSprites[Ghost.white1Sprite] = new Animation(render, new int[] { 69, 72 }, Ghost.maxFps);
            this.otherSprites[Ghost.white2Sprite] = new Animation(render, new int[] { 71, 70 }, Ghost.maxFps);
            #endregion
            // Second, set the type of ghost and the current sprites.
            switch(type) {
                case GhostType.Red: this.typeOfGhost = Ghost.redGhost; break;
                case GhostType.Pink: this.typeOfGhost = Ghost.pinkGhost; break;
                case GhostType.Blue: this.typeOfGhost = Ghost.blueGhost; break;
                case GhostType.Brown: this.typeOfGhost = Ghost.brownGhost; break;
            }
            this.TypeOfGhost = type;
            this.currentNormalSprite = Ghost.rightSprite;
            this.currentOtherSprite = Ghost.blueSprite;
            // Third, set the other stuff.
            this.NeededDirection = MovingDirection.None;
            this.alive = true;
            this.state = GhostState.Normal;
            this.SpeedController = this.speedController;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void speedController(Ghost ghost)
        /// <summary>
        /// Controls that the speed interval tick of the ghost is right.
        /// </summary>
        /// <param name="ghost">The ghost to be checked.</param>
        protected void speedController(Ghost ghost) {
            if(ghost.Alive) {
                if(ghost.State == GhostState.Normal) {
                    ghost.SetSpeedInterval(Ghost.normalSpeedInterval);
                } else {
                    ghost.SetSpeedInterval(Ghost.vulnerableSpeedInterval);
                }
            } else {
                ghost.SetSpeedInterval(Ghost.deadSpeedInterval);
            }
        }
        #endregion

        #region void resetSprites()
        /// <summary>
        /// Resets all the sprites.
        /// </summary>
        private void resetSprites() {
            foreach(Animation ani in this.normalSprites) {
                ani.Reset();
            }
            foreach(Animation ani in this.otherSprites) {
                ani.Reset();
            }
        }
        #endregion

        #region void updateSprites(long time)
        /// <summary>
        /// Updates all the sprites.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        protected void updateSprites(long time) {
            foreach(Animation ani in this.normalSprites) {
                ani.Update(time);
            }
            foreach(Animation ani in this.otherSprites) {
                ani.Update(time);
            }
        }
        #endregion

        #region void BackToLife()
        /// <summary>
        /// Respawns the ghost entity.
        /// </summary>
        public void BackToLife() {
            this.alive = true;
            this.state = GhostState.Normal;
        }
        #endregion

        #region void Kill()
        /// <summary>
        /// Kills the ghost entity.
        /// </summary>
        public void Kill() {
            this.alive = false;
        }
        #endregion

        #region void ChangeState(GhostState state)
        /// <summary>
        /// Changes the state of the ghost.
        /// </summary>
        /// <param name="state">The new state.</param>
        public void ChangeState(GhostState state) {
            if(this.Alive) {
                this.state = state;
                if(this.state == GhostState.Normal) {

                } else if(this.state == GhostState.Vulnerable) {
                    this.currentOtherSprite = Ghost.blueSprite;

                } else if(this.state == GhostState.Ending) {
                    if(this.otherSprites[this.currentOtherSprite].CurrentFrame == 0) {
                        this.currentOtherSprite = Ghost.white1Sprite;
                    } else {
                        this.currentOtherSprite = Ghost.white2Sprite;
                    }
                }
            }
        } 
        #endregion

        #region void setCurrentSprite(int index)
        /// <summary>
        /// Sets the current sprite of the entity.
        /// </summary>
        /// <param name="index">The current used sprite.</param>
        private void setCurrentSprite(int index) {
            this.currentNormalSprite = index;
        }
        #endregion

        #region void SetDirection(MovingDirection dir)
        /// <summary>
        /// Sets the direction of the entity.
        /// </summary>
        /// <param name="dir">The direction of the entity.</param>
        public override void SetDirection(MovingDirection dir) {
            this.Direction = dir;
            switch(dir) {
                case MovingDirection.Up:
                    this.setCurrentSprite(Ghost.upSprite);
                    break;
                case MovingDirection.Down:
                    this.setCurrentSprite(Ghost.downSprite);
                    break;
                case MovingDirection.Left:
                    this.setCurrentSprite(Ghost.leftSprite);
                    break;
                case MovingDirection.Right:
                    this.setCurrentSprite(Ghost.rightSprite);
                    break;
            }
        }
        #endregion

        #region void testNeededDirection()
        /// <summary>
        /// Tests if the entity can change the direction.
        /// </summary>
        protected void testNeededDirection() {
            // First, we'll validate the asked direction.
            if(this.testUpdateCoordinates(this.NeededDirection)) {
                // And if the direction is valid, we'll change the old one.
                if(this.Direction != this.NeededDirection) {
                    this.SetDirection(this.NeededDirection);
                }
            }
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the ghost inside the screen.
        /// </summary>
        public override void Draw() {
            if(this.alive) {
                // Here we'll draw the ghost when it's alive.
                switch(this.state) {
                    case GhostState.Vulnerable:
                        this.otherSprites[this.currentOtherSprite].Draw(this.X, this.Y);
                        break;
                    case GhostState.Ending:
                        this.otherSprites[this.currentOtherSprite].Draw(this.X, this.Y);
                        break;
                    case GhostState.Normal:
                        this.normalSprites[this.typeOfGhost, this.currentNormalSprite].Draw(this.X, this.Y);
                        break;
                }
            } else {
                // Here we'll draw the ghost when it isn't alive.
                GameScreen render = CoreManager.Instance.Screen;
                switch(this.Direction) {
                    case MovingDirection.Up:
                        render.DrawSprite(this.X, this.Y, Sprites.DeadGhostUp);
                        break;
                    case MovingDirection.Down:
                        render.DrawSprite(this.X, this.Y, Sprites.DeadGhostDown);
                        break;
                    case MovingDirection.Left:
                        render.DrawSprite(this.X, this.Y, Sprites.DeadGhostLeft);
                        break;
                    case MovingDirection.Right:
                        render.DrawSprite(this.X, this.Y, Sprites.DeadGhostRight);
                        break;
                    case MovingDirection.None:
                        render.DrawSprite(this.X, this.Y, Sprites.DeadGhostRight);
                        break;
                }
            }
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner state of the entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public override void Update(long time) {
            // First, we'll control the speed, the asked direction and we'll update the sprites.
            this.SpeedController(this);
            this.testNeededDirection();
            this.updateSprites(time);

            // Second, we'll control the tick logic of the entity.
            this.currentTime += time;
            while(this.currentTime >= this.maxTimeInterval) {
                this.currentTime -= this.maxTimeInterval;
                // And in every tick, we'll update the coordinates.
                this.updateCoordinates();
            }
        }
        #endregion
    }
}