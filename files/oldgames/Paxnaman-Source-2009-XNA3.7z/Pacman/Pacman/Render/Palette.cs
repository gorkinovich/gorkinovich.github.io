﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This static class is the palette of colors suported in the game.
    /// </summary>
    public static class Palette {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int NumberOfColors
        /// <summary>
        /// The number of colors of the palette.
        /// </summary>
        public const int NumberOfColors = 16;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Color[] Color
        /// <summary>
        /// The colors of the palette.
        /// </summary>
        public static Color[] Color { get; private set; }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Palette()
        /// <summary>
        /// Initializes the colors of the palette.
        /// </summary>
        static Palette() {
            Color = new Color[NumberOfColors];
            Color[0] = new Color(0, 0, 0); // Black
            Color[1] = new Color(255, 0, 0); // Red
            Color[2] = new Color(222, 151, 81); // Dark Brown
            Color[3] = new Color(255, 184, 255); // Pink
            Color[4] = new Color(0, 0, 0); // Black
            Color[5] = new Color(0, 255, 255); // Cyan
            Color[6] = new Color(71, 184, 255); // Blue
            Color[7] = new Color(255, 184, 81); // Brown
            Color[8] = new Color(0, 0, 0); // Black
            Color[9] = new Color(255, 255, 0); // Yellow
            Color[10] = new Color(0, 0, 0); // Black
            Color[11] = new Color(33, 33, 255); // Dark Blue
            Color[12] = new Color(0, 255, 0); // Green
            Color[13] = new Color(71, 184, 174); // Dark Green
            Color[14] = new Color(255, 184, 174); // Dark Pink
            Color[15] = new Color(222, 222, 255); // White
        }
        #endregion
    }
}