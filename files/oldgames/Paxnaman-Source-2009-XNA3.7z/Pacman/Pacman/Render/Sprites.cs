﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This static class is a list of sprite definitions.
    /// </summary>
    public static class Sprites {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int Width
        /// <summary>
        /// The width of a sprite.
        /// </summary>
        public const int Width = 32; //16 * 2;
        #endregion

        #region int Height
        /// <summary>
        /// The height of a sprite.
        /// </summary>
        public const int Height = 32; //16 * 2;
        #endregion

        #region int NumberOfSprites
        /// <summary>
        /// The number of sprites in the game.
        /// </summary>
        public const int NumberOfSprites = 86;
        #endregion

        #region Items
        /// <summary>The id of the life sprite.</summary>
        public const int LifeIcon = 0;
        /// <summary>The id of the cherry sprite.</summary>
        public const int FruitCherry = 1;
        /// <summary>The id of the strawberry sprite.</summary>
        public const int FruitStrawberry = 2;
        /// <summary>The id of the peach sprite.</summary>
        public const int FruitPeach = 3;
        /// <summary>The id of the bell sprite.</summary>
        public const int FruitBell = 4;
        /// <summary>The id of the apple sprite.</summary>
        public const int FruitApple = 5;
        /// <summary>The id of the grape sprite.</summary>
        public const int FruitGrape = 6;
        /// <summary>The id of the flower sprite.</summary>
        public const int FruitFlower = 7;
        /// <summary>The id of the key sprite.</summary>
        public const int FruitKey = 8;
        #endregion

        #region Ghost eated points
        /// <summary>The id of the 200 sprite.</summary>
        public const int N200 = 9;
        /// <summary>The id of the 400 sprite.</summary>
        public const int N400 = 10;
        /// <summary>The id of the 800 sprite.</summary>
        public const int N800 = 11;
        /// <summary>The id of the 1600 sprite.</summary>
        public const int N1600 = 12;
        #endregion

        #region Super-Puckman Sprite
        /// <summary>The id of the Super-Puckman right frame 1 sprite.</summary>
        public const int SuperPuckmanR1 = 13;
        /// <summary>The id of the Super-Puckman right frame 2 sprite.</summary>
        public const int SuperPuckmanR2 = 14;
        /// <summary>The id of the Super-Puckman right frame 3 sprite.</summary>
        public const int SuperPuckmanR3 = 15;
        #endregion

        #region Puckman move
        /// <summary>The id of the Puckman initial frame for all sprite.</summary>
        public const int PuckmanAll = 16;
        /// <summary>The id of the Puckman right frame 1 sprite.</summary>
        public const int PuckmanR1 = 17;
        /// <summary>The id of the Puckman right frame 2 sprite.</summary>
        public const int PuckmanR2 = 18;
        /// <summary>The id of the Puckman down frame 1 sprite.</summary>
        public const int PuckmanD1 = 19;
        /// <summary>The id of the Puckman down frame 2 sprite.</summary>
        public const int PuckmanD2 = 20;
        /// <summary>The id of the Puckman left frame 1 sprite.</summary>
        public const int PuckmanL1 = 21;
        /// <summary>The id of the Puckman left frame 2 sprite.</summary>
        public const int PuckmanL2 = 22;
        /// <summary>The id of the Puckman up frame 1 sprite.</summary>
        public const int PuckmanU1 = 23;
        /// <summary>The id of the Puckman up frame 2 sprite.</summary>
        public const int PuckmanU2 = 24;
        #endregion

        #region Puckman death
        /// <summary>The id of the Puckman death frame 1 sprite.</summary>
        public const int PuckmanDeath01 = 25;
        /// <summary>The id of the Puckman death frame 2 sprite.</summary>
        public const int PuckmanDeath02 = 26;
        /// <summary>The id of the Puckman death frame 3 sprite.</summary>
        public const int PuckmanDeath03 = 27;
        /// <summary>The id of the Puckman death frame 4 sprite.</summary>
        public const int PuckmanDeath04 = 28;
        /// <summary>The id of the Puckman death frame 5 sprite.</summary>
        public const int PuckmanDeath05 = 29;
        /// <summary>The id of the Puckman death frame 6 sprite.</summary>
        public const int PuckmanDeath06 = 30;
        /// <summary>The id of the Puckman death frame 7 sprite.</summary>
        public const int PuckmanDeath07 = 31;
        /// <summary>The id of the Puckman death frame 8 sprite.</summary>
        public const int PuckmanDeath08 = 32;
        /// <summary>The id of the Puckman death frame 9 sprite.</summary>
        public const int PuckmanDeath09 = 33;
        /// <summary>The id of the Puckman death frame 10 sprite.</summary>
        public const int PuckmanDeath10 = 34;
        /// <summary>The id of the Puckman death frame 11 sprite.</summary>
        public const int PuckmanDeath11 = 35;
        /// <summary>The id of the Puckman death frame 12 sprite.</summary>
        public const int PuckmanDeath12 = 36;
        #endregion

        #region Red ghost move
        /// <summary>The id of the red ghost right frame 1 sprite.</summary>
        public const int RedGhostR1 = 37;
        /// <summary>The id of the red ghost right frame 2 sprite.</summary>
        public const int RedGhostR2 = 38;
        /// <summary>The id of the red ghost down frame 1 sprite.</summary>
        public const int RedGhostD1 = 39;
        /// <summary>The id of the red ghost down frame 2 sprite.</summary>
        public const int RedGhostD2 = 40;
        /// <summary>The id of the red ghost left frame 1 sprite.</summary>
        public const int RedGhostL1 = 41;
        /// <summary>The id of the red ghost left frame 2 sprite.</summary>
        public const int RedGhostL2 = 42;
        /// <summary>The id of the red ghost up frame 1 sprite.</summary>
        public const int RedGhostU1 = 43;
        /// <summary>The id of the red ghost up frame 2 sprite.</summary>
        public const int RedGhostU2 = 44;
        #endregion

        #region Blue ghost move
        /// <summary>The id of the blue ghost right frame 1 sprite.</summary>
        public const int BlueGhostR1 = 45;
        /// <summary>The id of the blue ghost right frame 2 sprite.</summary>
        public const int BlueGhostR2 = 46;
        /// <summary>The id of the blue ghost down frame 1 sprite.</summary>
        public const int BlueGhostD1 = 47;
        /// <summary>The id of the blue ghost down frame 2 sprite.</summary>
        public const int BlueGhostD2 = 48;
        /// <summary>The id of the blue ghost left frame 1 sprite.</summary>
        public const int BlueGhostL1 = 49;
        /// <summary>The id of the blue ghost left frame 2 sprite.</summary>
        public const int BlueGhostL2 = 50;
        /// <summary>The id of the blue ghost up frame 1 sprite.</summary>
        public const int BlueGhostU1 = 51;
        /// <summary>The id of the blue ghost up frame 2 sprite.</summary>
        public const int BlueGhostU2 = 52;
        #endregion

        #region Pink ghost move
        /// <summary>The id of the pink ghost right frame 1 sprite.</summary>
        public const int PinkGhostR1 = 53;
        /// <summary>The id of the pink ghost right frame 2 sprite.</summary>
        public const int PinkGhostR2 = 54;
        /// <summary>The id of the pink ghost down frame 1 sprite.</summary>
        public const int PinkGhostD1 = 55;
        /// <summary>The id of the pink ghost down frame 2 sprite.</summary>
        public const int PinkGhostD2 = 56;
        /// <summary>The id of the pink ghost left frame 1 sprite.</summary>
        public const int PinkGhostL1 = 57;
        /// <summary>The id of the pink ghost left frame 2 sprite.</summary>
        public const int PinkGhostL2 = 58;
        /// <summary>The id of the pink ghost up frame 1 sprite.</summary>
        public const int PinkGhostU1 = 59;
        /// <summary>The id of the pink ghost up frame 2 sprite.</summary>
        public const int PinkGhostU2 = 60;
        #endregion

        #region Brown ghost move
        /// <summary>The id of the brown ghost right frame 1 sprite.</summary>
        public const int BrownGhostR1 = 61;
        /// <summary>The id of the brown ghost right frame 2 sprite.</summary>
        public const int BrownGhostR2 = 62;
        /// <summary>The id of the brown ghost down frame 1 sprite.</summary>
        public const int BrownGhostD1 = 63;
        /// <summary>The id of the brown ghost down frame 2 sprite.</summary>
        public const int BrownGhostD2 = 64;
        /// <summary>The id of the brown ghost left frame 1 sprite.</summary>
        public const int BrownGhostL1 = 65;
        /// <summary>The id of the brown ghost left frame 2 sprite.</summary>
        public const int BrownGhostL2 = 66;
        /// <summary>The id of the brown ghost up frame 1 sprite.</summary>
        public const int BrownGhostU1 = 67;
        /// <summary>The id of the brown ghost up frame 2 sprite.</summary>
        public const int BrownGhostU2 = 68;
        #endregion

        #region Death ghost move
        /// <summary>The id of the blue ghost frame 1 sprite.</summary>
        public const int BlueGhost1 = 69;
        /// <summary>The id of the blue ghost frame 2 sprite.</summary>
        public const int BlueGhost2 = 70;
        /// <summary>The id of the white ghost frame 1 sprite.</summary>
        public const int WhiteGhost1 = 71;
        /// <summary>The id of the white ghost frame 2 sprite.</summary>
        public const int WhiteGhost2 = 72;
        /// <summary>The id of the dead ghost right sprite.</summary>
        public const int DeadGhostRight = 73;
        /// <summary>The id of the dead ghost down sprite.</summary>
        public const int DeadGhostDown = 74;
        /// <summary>The id of the dead ghost left sprite.</summary>
        public const int DeadGhostLeft = 75;
        /// <summary>The id of the dead ghost up sprite.</summary>
        public const int DeadGhostUp = 76;
        #endregion

        #region Intermission ghost move
        /// <summary>The id of the intermission 1 frame 1 sprite.</summary>
        public const int Intermission11 = 77;
        /// <summary>The id of the intermission 1 frame 2 sprite.</summary>
        public const int Intermission12 = 78;
        /// <summary>The id of the intermission 2 frame 1 sprite.</summary>
        public const int Intermission21 = 79;
        /// <summary>The id of the intermission 2 frame 2 sprite.</summary>
        public const int Intermission22 = 80;
        /// <summary>The id of the intermission boom sprite.</summary>
        public const int IntermissionBoom = 81;
        /// <summary>The id of the intermission 3 frame 1 sprite.</summary>
        public const int Intermission31 = 82;
        /// <summary>The id of the intermission 3 frame 2 sprite.</summary>
        public const int Intermission32 = 83;
        /// <summary>The id of the intermission 4 frame 1 sprite.</summary>
        public const int Intermission41 = 84;
        /// <summary>The id of the intermission 4 frame 2 sprite.</summary>
        public const int Intermission42 = 85;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Rectangle[] Rectangles
        /// <summary>
        /// The rectangles of the sprites.
        /// </summary>
        public static Rectangle[] Rectangles { get; private set; }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Sprites()
        /// <summary>
        /// Initializes the sprite data.
        /// </summary>
        static Sprites() {
            int w = GameScreen.CellWidth;
            int h = GameScreen.CellHeight;

            Rectangles = new Rectangle[NumberOfSprites];

            #region Items
            Rectangles[0] = new Rectangle(w * 0, h * 3, Width, Height); //Puckman
            Rectangles[1] = new Rectangle(w * 2, h * 3, Width, Height); //Cherry
            Rectangles[2] = new Rectangle(w * 4, h * 3, Width, Height); //Strawberry
            Rectangles[3] = new Rectangle(w * 6, h * 3, Width, Height); //Peach
            Rectangles[4] = new Rectangle(w * 8, h * 3, Width, Height); //Bell
            Rectangles[5] = new Rectangle(w * 10, h * 3, Width, Height); //Apple
            Rectangles[6] = new Rectangle(w * 12, h * 3, Width, Height); //Grape
            Rectangles[7] = new Rectangle(w * 14, h * 3, Width, Height); //WTF???
            Rectangles[8] = new Rectangle(w * 16, h * 3, Width, Height); //Key
            #endregion

            #region Ghost eated points
            Rectangles[9] = new Rectangle(w * 24, h * 7, Width, Height); //200
            Rectangles[10] = new Rectangle(w * 26, h * 7, Width, Height); //400
            Rectangles[11] = new Rectangle(w * 28, h * 7, Width, Height); //800
            Rectangles[12] = new Rectangle(w * 30, h * 7, Width, Height); //1600
            #endregion

            #region Super-Puckman Sprite
            Rectangles[13] = new Rectangle(w * 18, h * 3, Width * 2, Height * 2);
            Rectangles[14] = new Rectangle(w * 22, h * 3, Width * 2, Height * 2);
            Rectangles[15] = new Rectangle(w * 26, h * 3, Width * 2, Height * 2);
            #endregion

            #region Puckman move
            Rectangles[16] = new Rectangle(w * 0, h * 5, Width, Height); //All 0
            Rectangles[17] = new Rectangle(w * 2, h * 5, Width, Height); //Right 1
            Rectangles[18] = new Rectangle(w * 10, h * 5, Width, Height); //Right 2
            Rectangles[19] = new Rectangle(w * 4, h * 5, Width, Height); //Down 1
            Rectangles[20] = new Rectangle(w * 12, h * 5, Width, Height); //Down 2
            Rectangles[21] = new Rectangle(w * 6, h * 5, Width, Height); //Left 1
            Rectangles[22] = new Rectangle(w * 14, h * 5, Width, Height); //Left 2
            Rectangles[23] = new Rectangle(w * 8, h * 5, Width, Height); //Up 1
            Rectangles[24] = new Rectangle(w * 16, h * 5, Width, Height); //Up 2
            #endregion

            #region Puckman death
            Rectangles[25] = new Rectangle(w * 0, h * 7, Width, Height);
            Rectangles[26] = new Rectangle(w * 2, h * 7, Width, Height);
            Rectangles[27] = new Rectangle(w * 4, h * 7, Width, Height);
            Rectangles[28] = new Rectangle(w * 6, h * 7, Width, Height);
            Rectangles[29] = new Rectangle(w * 8, h * 7, Width, Height);
            Rectangles[30] = new Rectangle(w * 10, h * 7, Width, Height);
            Rectangles[31] = new Rectangle(w * 12, h * 7, Width, Height);
            Rectangles[32] = new Rectangle(w * 14, h * 7, Width, Height);
            Rectangles[33] = new Rectangle(w * 16, h * 7, Width, Height);
            Rectangles[34] = new Rectangle(w * 18, h * 7, Width, Height);
            Rectangles[35] = new Rectangle(w * 20, h * 7, Width, Height);
            Rectangles[36] = new Rectangle(w * 22, h * 7, Width, Height);
            #endregion

            #region Red ghost move
            Rectangles[37] = new Rectangle(w * 0, h * 9, Width, Height); //R1
            Rectangles[38] = new Rectangle(w * 2, h * 9, Width, Height); //R2
            Rectangles[39] = new Rectangle(w * 4, h * 9, Width, Height); //D1
            Rectangles[40] = new Rectangle(w * 6, h * 9, Width, Height); //D2
            Rectangles[41] = new Rectangle(w * 8, h * 9, Width, Height); //L1
            Rectangles[42] = new Rectangle(w * 10, h * 9, Width, Height); //L2
            Rectangles[43] = new Rectangle(w * 12, h * 9, Width, Height); //U1
            Rectangles[44] = new Rectangle(w * 14, h * 9, Width, Height); //U2
            #endregion

            #region Blue ghost move
            Rectangles[45] = new Rectangle(w * 16, h * 9, Width, Height); //R1
            Rectangles[46] = new Rectangle(w * 18, h * 9, Width, Height); //R2
            Rectangles[47] = new Rectangle(w * 20, h * 9, Width, Height); //D1
            Rectangles[48] = new Rectangle(w * 22, h * 9, Width, Height); //D2
            Rectangles[49] = new Rectangle(w * 24, h * 9, Width, Height); //L1
            Rectangles[50] = new Rectangle(w * 26, h * 9, Width, Height); //L2
            Rectangles[51] = new Rectangle(w * 28, h * 9, Width, Height); //U1
            Rectangles[52] = new Rectangle(w * 30, h * 9, Width, Height); //U2
            #endregion

            #region Pink ghost move
            Rectangles[53] = new Rectangle(w * 0, h * 11, Width, Height); //R1
            Rectangles[54] = new Rectangle(w * 2, h * 11, Width, Height); //R2
            Rectangles[55] = new Rectangle(w * 4, h * 11, Width, Height); //D1
            Rectangles[56] = new Rectangle(w * 6, h * 11, Width, Height); //D2
            Rectangles[57] = new Rectangle(w * 8, h * 11, Width, Height); //L1
            Rectangles[58] = new Rectangle(w * 10, h * 11, Width, Height); //L2
            Rectangles[59] = new Rectangle(w * 12, h * 11, Width, Height); //U1
            Rectangles[60] = new Rectangle(w * 14, h * 11, Width, Height); //U2
            #endregion

            #region Brown ghost move
            Rectangles[61] = new Rectangle(w * 16, h * 11, Width, Height); //R1
            Rectangles[62] = new Rectangle(w * 18, h * 11, Width, Height); //R2
            Rectangles[63] = new Rectangle(w * 20, h * 11, Width, Height); //D1
            Rectangles[64] = new Rectangle(w * 22, h * 11, Width, Height); //D2
            Rectangles[65] = new Rectangle(w * 24, h * 11, Width, Height); //L1
            Rectangles[66] = new Rectangle(w * 26, h * 11, Width, Height); //L2
            Rectangles[67] = new Rectangle(w * 28, h * 11, Width, Height); //U1
            Rectangles[68] = new Rectangle(w * 30, h * 11, Width, Height); //U2
            #endregion

            #region Death ghost move
            Rectangles[69] = new Rectangle(w * 32, h * 11, Width, Height); //Blue1
            Rectangles[70] = new Rectangle(w * 34, h * 11, Width, Height); //Blue2
            Rectangles[71] = new Rectangle(w * 32, h * 9, Width, Height); //White1
            Rectangles[72] = new Rectangle(w * 34, h * 9, Width, Height); //White1
            Rectangles[73] = new Rectangle(w * 28, h * 13, Width, Height); //R
            Rectangles[74] = new Rectangle(w * 30, h * 13, Width, Height); //D
            Rectangles[75] = new Rectangle(w * 32, h * 13, Width, Height); //L
            Rectangles[76] = new Rectangle(w * 34, h * 13, Width, Height); //U
            #endregion

            #region Intermission ghost move
            Rectangles[77] = new Rectangle(w * 0, h * 13, Width, Height); //I11
            Rectangles[78] = new Rectangle(w * 2, h * 13, Width, Height); //I12
            Rectangles[79] = new Rectangle(w * 4, h * 13, Width, Height); //I21
            Rectangles[80] = new Rectangle(w * 6, h * 13, Width, Height); //I21
            Rectangles[81] = new Rectangle(w * 8, h * 13, Width, Height); //BOOM
            Rectangles[82] = new Rectangle(w * 10, h * 13, Width, Height); //I31
            Rectangles[83] = new Rectangle(w * 12, h * 13, Width, Height); //I32
            Rectangles[84] = new Rectangle(w * 14, h * 13, Width, Height); //I41
            Rectangles[85] = new Rectangle(w * 16, h * 13, Width, Height); //I42
            #endregion
        }
        #endregion
    }
}