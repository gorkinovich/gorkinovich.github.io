﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This static class is a list with the name of the suported colors in the game.
    /// </summary>
    public static class Colors {
        /// <summary>The id of the black color.</summary>
        public const int Black = 0;
        /// <summary>The id of the red color.</summary>
        public const int Red = 1;
        /// <summary>The id of the dark brown color.</summary>
        public const int DarkBrown = 2;
        /// <summary>The id of the pink color.</summary>
        public const int Pink = 3;
        /// <summary>The id of the cyan color.</summary>
        public const int Cyan = 5;
        /// <summary>The id of the blue color.</summary>
        public const int Blue = 6;
        /// <summary>The id of the brown color.</summary>
        public const int Brown = 7;
        /// <summary>The id of the yellow color.</summary>
        public const int Yellow = 9;
        /// <summary>The id of the dark blue color.</summary>
        public const int DarkBlue = 11;
        /// <summary>The id of the green color.</summary>
        public const int Green = 12;
        /// <summary>The id of the dark green color.</summary>
        public const int DarkGreen = 13;
        /// <summary>The id of the dark pink color.</summary>
        public const int DarkPink = 14;
        /// <summary>The id of the white color.</summary>
        public const int White = 15;
    }
}