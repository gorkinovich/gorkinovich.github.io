﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class is used to manage the render system of the game.
    /// </summary>
    public sealed class GameScreen {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int Width
        /// <summary>
        /// The width of the screen.
        /// </summary>
        public const int Width = 448; //224 * 2;
        #endregion

        #region int Height
        /// <summary>
        /// The height of the screen.
        /// </summary>
        public const int Height = 576; //288 * 2;
        #endregion

        #region int CellWidth
        /// <summary>
        /// The width of a cell.
        /// </summary>
        public const int CellWidth = 16; //8 * 2;
        #endregion

        #region int CellHeight
        /// <summary>
        /// The height of a cell.
        /// </summary>
        public const int CellHeight = 16; //8 * 2;
        #endregion

        #region int NumberOfRows
        /// <summary>
        /// The number of rows of the screen.
        /// </summary>
        public const int NumberOfRows = Height / CellHeight; //36
        #endregion

        #region int NumberOfColums
        /// <summary>
        /// The number of columns of the screen.
        /// </summary>
        public const int NumberOfColums = Width / CellWidth; //28
        #endregion


        #region int WormholeLeftX
        /// <summary>
        /// The X coordinate of the left wormhole.
        /// </summary>
        public const int WormholeLeftX = -32;
        #endregion

        #region int WormholeRightX
        /// <summary>
        /// The X coordinate of the right wormhole.
        /// </summary>
        public const int WormholeRightX = 448;
        #endregion

        #region int WormholeY
        /// <summary>
        /// The Y coordinate of both wormholes.
        /// </summary>
        public const int WormholeY = 264;
        #endregion


        #region int ScreenStartX
        /// <summary>
        /// The X coordinate of the start of the screen.
        /// </summary>
        public const int ScreenStartX = 26;
        #endregion

        #region int ScreenStartY
        /// <summary>
        /// The Y coordinate of the start of the screen.
        /// </summary>
        public const int ScreenStartY = 12;
        #endregion


        #region int NumberOfTiles
        /// <summary>
        /// The number of tiles.
        /// </summary>
        public const int NumberOfTiles = 139;
        #endregion

        #region int spaceIndex
        /// <summary>
        /// The index value of the space character.
        /// </summary>
        private const int spaceIndex = 58;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Texture2D Tiles
        /// <summary>
        /// The texture with the tiles of the game.
        /// </summary>
        public Texture2D Tiles { get; private set; }
        #endregion

        #region Rectangle[] Rectangles
        /// <summary>
        /// The rectangles of the tiles.
        /// </summary>
        public Rectangle[] Rectangles { get; private set; }
        #endregion

        #region Texture2D blankCell
        /// <summary>
        /// The blank cell texture.
        /// </summary>
        private Texture2D blankCell;
        #endregion

        #region Texture2D blankSprite
        /// <summary>
        /// The blank sprite texture.
        /// </summary>
        private Texture2D blankSprite;
        #endregion

        #region SpriteBatch spriteBatch
        /// <summary>
        /// The sprite batch manager.
        /// </summary>
        private SpriteBatch spriteBatch;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameScreen()
        /// <summary>
        /// Constructs a new GameScreen object.
        /// </summary>
        public GameScreen() {
            this.Rectangles = new Rectangle[NumberOfTiles];

            #region Hexadecimal numbers
            this.Rectangles[0] = new Rectangle(CellWidth * 0, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[1] = new Rectangle(CellWidth * 1, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[2] = new Rectangle(CellWidth * 2, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[3] = new Rectangle(CellWidth * 3, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[4] = new Rectangle(CellWidth * 4, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[5] = new Rectangle(CellWidth * 5, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[6] = new Rectangle(CellWidth * 6, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[7] = new Rectangle(CellWidth * 7, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[8] = new Rectangle(CellWidth * 8, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[9] = new Rectangle(CellWidth * 9, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[10] = new Rectangle(CellWidth * 10, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[11] = new Rectangle(CellWidth * 11, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[12] = new Rectangle(CellWidth * 12, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[13] = new Rectangle(CellWidth * 13, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[14] = new Rectangle(CellWidth * 14, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[15] = new Rectangle(CellWidth * 15, CellHeight * 0, CellWidth, CellHeight);
            #endregion

            #region Corners
            this.Rectangles[16] = new Rectangle(CellWidth * 23, CellHeight * 0, CellWidth, CellHeight); //Up-right
            this.Rectangles[17] = new Rectangle(CellWidth * 24, CellHeight * 0, CellWidth, CellHeight); //Down-right
            this.Rectangles[18] = new Rectangle(CellWidth * 25, CellHeight * 0, CellWidth, CellHeight); //Up-left
            this.Rectangles[19] = new Rectangle(CellWidth * 26, CellHeight * 0, CellWidth, CellHeight); //Down-left 
            #endregion

            #region Points labels (100, 300, 500, 700, 1000, 2000, 3000, 5000)
            this.Rectangles[20] = new Rectangle(CellWidth * 21, CellHeight * 1, CellWidth, CellHeight); //1xx
            this.Rectangles[21] = new Rectangle(CellWidth * 22, CellHeight * 1, CellWidth, CellHeight); //3xx
            this.Rectangles[22] = new Rectangle(CellWidth * 23, CellHeight * 1, CellWidth, CellHeight); //5xx
            this.Rectangles[23] = new Rectangle(CellWidth * 24, CellHeight * 1, CellWidth, CellHeight); //7xx
            this.Rectangles[24] = new Rectangle(CellWidth * 25, CellHeight * 1, CellWidth, CellHeight); //x00
            this.Rectangles[25] = new Rectangle(CellWidth * 16, CellHeight * 1, CellWidth, CellHeight); //10xx
            this.Rectangles[26] = new Rectangle(CellWidth * 17, CellHeight * 1, CellWidth, CellHeight); //20xxa
            this.Rectangles[27] = new Rectangle(CellWidth * 18, CellHeight * 1, CellWidth, CellHeight); //20xxb
            this.Rectangles[28] = new Rectangle(CellWidth * 19, CellHeight * 1, CellWidth, CellHeight); //30xxa
            this.Rectangles[29] = new Rectangle(CellWidth * 20, CellHeight * 1, CellWidth, CellHeight); //30xxb
            this.Rectangles[30] = new Rectangle(CellWidth * 26, CellHeight * 1, CellWidth, CellHeight); //50xxa
            this.Rectangles[31] = new Rectangle(CellWidth * 27, CellHeight * 1, CellWidth, CellHeight); //50xxb
            this.Rectangles[32] = new Rectangle(CellWidth * 28, CellHeight * 1, CellWidth, CellHeight); //xx00a
            this.Rectangles[33] = new Rectangle(CellWidth * 29, CellHeight * 1, CellWidth, CellHeight); //xx00b
            #endregion

            #region Other ghost stuff
            this.Rectangles[34] = new Rectangle(CellWidth * 18, CellHeight * 13, CellWidth, CellHeight);
            this.Rectangles[35] = new Rectangle(CellWidth * 18, CellHeight * 14, CellWidth, CellHeight);
            this.Rectangles[36] = new Rectangle(CellWidth * 19, CellHeight * 13, CellWidth, CellHeight);
            this.Rectangles[37] = new Rectangle(CellWidth * 19, CellHeight * 14, CellWidth, CellHeight);
            this.Rectangles[38] = new Rectangle(CellWidth * 20, CellHeight * 13, CellWidth, CellHeight);
            this.Rectangles[39] = new Rectangle(CellWidth * 20, CellHeight * 14, CellWidth, CellHeight);
            this.Rectangles[40] = new Rectangle(CellWidth * 21, CellHeight * 13, CellWidth, CellHeight);
            this.Rectangles[41] = new Rectangle(CellWidth * 21, CellHeight * 14, CellWidth, CellHeight);
            this.Rectangles[42] = new Rectangle(CellWidth * 22, CellHeight * 13, CellWidth, CellHeight);
            this.Rectangles[43] = new Rectangle(CellWidth * 22, CellHeight * 14, CellWidth, CellHeight);
            this.Rectangles[44] = new Rectangle(CellWidth * 23, CellHeight * 13, CellWidth, CellHeight);
            this.Rectangles[45] = new Rectangle(CellWidth * 23, CellHeight * 14, CellWidth, CellHeight);
            this.Rectangles[46] = new Rectangle(CellWidth * 24, CellHeight * 13, CellWidth, CellHeight);
            this.Rectangles[47] = new Rectangle(CellWidth * 24, CellHeight * 14, CellWidth, CellHeight);
            #endregion

            #region Main font
            this.Rectangles[48] = new Rectangle(CellWidth * 6, CellHeight * 1, CellWidth, CellHeight); //0 (48)
            this.Rectangles[49] = new Rectangle(CellWidth * 7, CellHeight * 1, CellWidth, CellHeight); //1
            this.Rectangles[50] = new Rectangle(CellWidth * 8, CellHeight * 1, CellWidth, CellHeight); //2
            this.Rectangles[51] = new Rectangle(CellWidth * 9, CellHeight * 1, CellWidth, CellHeight); //3
            this.Rectangles[52] = new Rectangle(CellWidth * 10, CellHeight * 1, CellWidth, CellHeight); //4
            this.Rectangles[53] = new Rectangle(CellWidth * 11, CellHeight * 1, CellWidth, CellHeight); //5
            this.Rectangles[54] = new Rectangle(CellWidth * 12, CellHeight * 1, CellWidth, CellHeight); //6
            this.Rectangles[55] = new Rectangle(CellWidth * 13, CellHeight * 1, CellWidth, CellHeight); //7
            this.Rectangles[56] = new Rectangle(CellWidth * 14, CellHeight * 1, CellWidth, CellHeight); //8
            this.Rectangles[57] = new Rectangle(CellWidth * 15, CellHeight * 1, CellWidth, CellHeight); //9
            this.Rectangles[58] = new Rectangle(CellWidth * 0, CellHeight * 1, CellWidth, CellHeight); //Space
            this.Rectangles[59] = new Rectangle(CellWidth * 5, CellHeight * 1, CellWidth, CellHeight); //!
            this.Rectangles[60] = new Rectangle(CellWidth * 2, CellHeight * 1, CellWidth, CellHeight); //"
            this.Rectangles[61] = new Rectangle(CellWidth * 4, CellHeight * 1, CellWidth, CellHeight); //-
            this.Rectangles[62] = new Rectangle(CellWidth * 1, CellHeight * 1, CellWidth, CellHeight); //.
            this.Rectangles[63] = new Rectangle(CellWidth * 3, CellHeight * 1, CellWidth, CellHeight); // /
            this.Rectangles[64] = new Rectangle(CellWidth * 26, CellHeight * 2, CellWidth, CellHeight); //(c)
            this.Rectangles[65] = new Rectangle(CellWidth * 0, CellHeight * 2, CellWidth, CellHeight); //A (65)
            this.Rectangles[66] = new Rectangle(CellWidth * 1, CellHeight * 2, CellWidth, CellHeight); //B
            this.Rectangles[67] = new Rectangle(CellWidth * 2, CellHeight * 2, CellWidth, CellHeight); //C
            this.Rectangles[68] = new Rectangle(CellWidth * 3, CellHeight * 2, CellWidth, CellHeight); //D
            this.Rectangles[69] = new Rectangle(CellWidth * 4, CellHeight * 2, CellWidth, CellHeight); //E
            this.Rectangles[70] = new Rectangle(CellWidth * 5, CellHeight * 2, CellWidth, CellHeight); //F
            this.Rectangles[71] = new Rectangle(CellWidth * 6, CellHeight * 2, CellWidth, CellHeight); //G
            this.Rectangles[72] = new Rectangle(CellWidth * 7, CellHeight * 2, CellWidth, CellHeight); //H
            this.Rectangles[73] = new Rectangle(CellWidth * 8, CellHeight * 2, CellWidth, CellHeight); //I
            this.Rectangles[74] = new Rectangle(CellWidth * 9, CellHeight * 2, CellWidth, CellHeight); //J
            this.Rectangles[75] = new Rectangle(CellWidth * 10, CellHeight * 2, CellWidth, CellHeight); //K
            this.Rectangles[76] = new Rectangle(CellWidth * 11, CellHeight * 2, CellWidth, CellHeight); //L
            this.Rectangles[77] = new Rectangle(CellWidth * 12, CellHeight * 2, CellWidth, CellHeight); //M
            this.Rectangles[78] = new Rectangle(CellWidth * 13, CellHeight * 2, CellWidth, CellHeight); //N
            this.Rectangles[79] = new Rectangle(CellWidth * 14, CellHeight * 2, CellWidth, CellHeight); //O
            this.Rectangles[80] = new Rectangle(CellWidth * 15, CellHeight * 2, CellWidth, CellHeight); //P
            this.Rectangles[81] = new Rectangle(CellWidth * 16, CellHeight * 2, CellWidth, CellHeight); //Q
            this.Rectangles[82] = new Rectangle(CellWidth * 17, CellHeight * 2, CellWidth, CellHeight); //R
            this.Rectangles[83] = new Rectangle(CellWidth * 18, CellHeight * 2, CellWidth, CellHeight); //S
            this.Rectangles[84] = new Rectangle(CellWidth * 19, CellHeight * 2, CellWidth, CellHeight); //T
            this.Rectangles[85] = new Rectangle(CellWidth * 20, CellHeight * 2, CellWidth, CellHeight); //U
            this.Rectangles[86] = new Rectangle(CellWidth * 21, CellHeight * 2, CellWidth, CellHeight); //V
            this.Rectangles[87] = new Rectangle(CellWidth * 22, CellHeight * 2, CellWidth, CellHeight); //W
            this.Rectangles[88] = new Rectangle(CellWidth * 23, CellHeight * 2, CellWidth, CellHeight); //X
            this.Rectangles[89] = new Rectangle(CellWidth * 24, CellHeight * 2, CellWidth, CellHeight); //Y
            this.Rectangles[90] = new Rectangle(CellWidth * 25, CellHeight * 2, CellWidth, CellHeight); //Z
            this.Rectangles[91] = new Rectangle(CellWidth * 27, CellHeight * 2, CellWidth * 3, CellHeight); //PTS
            this.Rectangles[92] = new Rectangle(CellWidth * 16, CellHeight * 0, CellWidth * 7, CellHeight); //Namco
            #endregion

            #region Dots
            this.Rectangles[93] = new Rectangle(CellWidth * 30, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[94] = new Rectangle(CellWidth * 31, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[95] = new Rectangle(CellWidth * 30, CellHeight * 1, CellWidth, CellHeight);
            this.Rectangles[96] = new Rectangle(CellWidth * 31, CellHeight * 1, CellWidth, CellHeight);
            #endregion

            #region Maze walls
            this.Rectangles[97] = new Rectangle(CellWidth * 32, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[98] = new Rectangle(CellWidth * 33, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[99] = new Rectangle(CellWidth * 34, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[100] = new Rectangle(CellWidth * 35, CellHeight * 0, CellWidth, CellHeight);
            this.Rectangles[101] = new Rectangle(CellWidth * 32, CellHeight * 1, CellWidth, CellHeight);
            this.Rectangles[102] = new Rectangle(CellWidth * 33, CellHeight * 1, CellWidth, CellHeight);
            this.Rectangles[103] = new Rectangle(CellWidth * 34, CellHeight * 1, CellWidth, CellHeight);
            this.Rectangles[104] = new Rectangle(CellWidth * 35, CellHeight * 1, CellWidth, CellHeight);
            this.Rectangles[105] = new Rectangle(CellWidth * 32, CellHeight * 2, CellWidth, CellHeight);
            this.Rectangles[106] = new Rectangle(CellWidth * 33, CellHeight * 2, CellWidth, CellHeight);
            this.Rectangles[107] = new Rectangle(CellWidth * 34, CellHeight * 2, CellWidth, CellHeight);
            this.Rectangles[108] = new Rectangle(CellWidth * 35, CellHeight * 2, CellWidth, CellHeight);
            this.Rectangles[109] = new Rectangle(CellWidth * 30, CellHeight * 2, CellWidth, CellHeight);
            this.Rectangles[110] = new Rectangle(CellWidth * 31, CellHeight * 2, CellWidth, CellHeight);
            this.Rectangles[111] = new Rectangle(CellWidth * 32, CellHeight * 3, CellWidth, CellHeight);
            this.Rectangles[112] = new Rectangle(CellWidth * 33, CellHeight * 3, CellWidth, CellHeight);
            this.Rectangles[113] = new Rectangle(CellWidth * 34, CellHeight * 3, CellWidth, CellHeight);
            this.Rectangles[114] = new Rectangle(CellWidth * 35, CellHeight * 3, CellWidth, CellHeight);
            this.Rectangles[115] = new Rectangle(CellWidth * 30, CellHeight * 3, CellWidth, CellHeight);
            this.Rectangles[116] = new Rectangle(CellWidth * 31, CellHeight * 3, CellWidth, CellHeight);
            this.Rectangles[117] = new Rectangle(CellWidth * 32, CellHeight * 4, CellWidth, CellHeight);
            this.Rectangles[118] = new Rectangle(CellWidth * 33, CellHeight * 4, CellWidth, CellHeight);
            this.Rectangles[119] = new Rectangle(CellWidth * 34, CellHeight * 4, CellWidth, CellHeight);
            this.Rectangles[120] = new Rectangle(CellWidth * 35, CellHeight * 4, CellWidth, CellHeight);
            this.Rectangles[121] = new Rectangle(CellWidth * 30, CellHeight * 4, CellWidth, CellHeight);
            this.Rectangles[122] = new Rectangle(CellWidth * 31, CellHeight * 4, CellWidth, CellHeight);
            this.Rectangles[123] = new Rectangle(CellWidth * 32, CellHeight * 5, CellWidth, CellHeight);
            this.Rectangles[124] = new Rectangle(CellWidth * 33, CellHeight * 5, CellWidth, CellHeight);
            this.Rectangles[125] = new Rectangle(CellWidth * 34, CellHeight * 5, CellWidth, CellHeight);
            this.Rectangles[126] = new Rectangle(CellWidth * 35, CellHeight * 5, CellWidth, CellHeight);
            this.Rectangles[127] = new Rectangle(CellWidth * 32, CellHeight * 6, CellWidth, CellHeight);
            this.Rectangles[128] = new Rectangle(CellWidth * 33, CellHeight * 6, CellWidth, CellHeight);
            this.Rectangles[129] = new Rectangle(CellWidth * 34, CellHeight * 6, CellWidth, CellHeight);
            this.Rectangles[130] = new Rectangle(CellWidth * 35, CellHeight * 6, CellWidth, CellHeight);
            this.Rectangles[131] = new Rectangle(CellWidth * 32, CellHeight * 7, CellWidth, CellHeight);
            this.Rectangles[132] = new Rectangle(CellWidth * 33, CellHeight * 7, CellWidth, CellHeight);
            this.Rectangles[133] = new Rectangle(CellWidth * 34, CellHeight * 7, CellWidth, CellHeight);
            this.Rectangles[134] = new Rectangle(CellWidth * 35, CellHeight * 7, CellWidth, CellHeight);
            this.Rectangles[135] = new Rectangle(CellWidth * 32, CellHeight * 8, CellWidth, CellHeight);
            this.Rectangles[136] = new Rectangle(CellWidth * 33, CellHeight * 8, CellWidth, CellHeight);
            this.Rectangles[137] = new Rectangle(CellWidth * 34, CellHeight * 8, CellWidth, CellHeight);
            this.Rectangles[138] = new Rectangle(CellWidth * 35, CellHeight * 8, CellWidth, CellHeight);
            #endregion
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region Texture2D createBlankTexture(int width, int height, GraphicsDevice graphicsDevice)
        /// <summary>
        /// Creates a new blank texture.
        /// </summary>
        /// <param name="width">The width of the texture.</param>
        /// <param name="height">The height of the texture.</param>
        /// <param name="graphicsDevice">The graphics device manager.</param>
        /// <returns>A new blank texture.</returns>
        private Texture2D createBlankTexture(int width, int height, GraphicsDevice graphicsDevice) {
            // First, we'll create a new 2D texture.
            Texture2D texture = new Texture2D(graphicsDevice, width, height, 0,
                                              TextureUsage.None, SurfaceFormat.Color);
            // Second, we'll create and set the pixel data to black.
            Color[] pixels = new Color[width * height];
            for(int i = 0; i < pixels.Length; i++) {
                pixels[i] = Color.Black;
            }
            // And finally, we'll set the new pixel data and return the texture.
            texture.SetData(pixels);
            return texture;
        }
        #endregion

        #region void LoadContent(Game game, SpriteBatch spriteBatch)
        /// <summary>
        /// Loads the graphic content of the game.
        /// </summary>
        /// <param name="game">The xna game manager.</param>
        /// <param name="spriteBatch">The sprite batch manager.</param>
        public void LoadContent(Game game, SpriteBatch spriteBatch) {
            this.Tiles = game.Content.Load<Texture2D>("Tiles");
            this.blankCell = this.createBlankTexture(CellWidth, CellHeight, game.GraphicsDevice);
            this.blankSprite = this.createBlankTexture(Sprites.Width, Sprites.Height, game.GraphicsDevice);
            this.spriteBatch = spriteBatch;
        }
        #endregion

        //******************************************************************************************
        // Tile methods
        //******************************************************************************************

        #region Vector2 CellCoordsToVector2(int row, int col)
        /// <summary>
        /// Transforms a tile coordinates to a 2D vector.
        /// </summary>
        /// <param name="row">The row of the tile.</param>
        /// <param name="col">The column of the tile.</param>
        /// <returns>A 2D vector with the tile coordinates.</returns>
        public Vector2 CellCoordsToVector2(int row, int col) {
            return new Vector2(ScreenStartX + col * CellWidth,
                               ScreenStartY + row * CellWidth);
        }
        #endregion

        #region void ClearCell(int row, int col)
        /// <summary>
        /// Clear a tile from the screen.
        /// </summary>
        /// <param name="row">The row of the tile.</param>
        /// <param name="col">The column of the tile.</param>
        public void ClearCell(int row, int col) {
            this.spriteBatch.Draw(this.blankCell, CellCoordsToVector2(row, col), Color.White);
        }
        #endregion

        #region void DrawTile(int row, int col, int index, Color color)
        /// <summary>
        /// Draws a tile on the screen.
        /// </summary>
        /// <param name="row">The row of the tile.</param>
        /// <param name="col">The column of the tile.</param>
        /// <param name="index">The tile identification value.</param>
        /// <param name="color">The drawing color to be used.</param>
        public void DrawTile(int row, int col, int index, Color color) {
            this.ClearCell(row, col);
            this.spriteBatch.Draw(this.Tiles, CellCoordsToVector2(row, col),
                                  this.Rectangles[index], color);
        }
        #endregion

        #region void DrawTile(int row, int col, int index)
        /// <summary>
        /// Draws a tile on the screen.
        /// </summary>
        /// <param name="row">The row of the tile.</param>
        /// <param name="col">The column of the tile.</param>
        /// <param name="index">The tile identification value.</param>
        public void DrawTile(int row, int col, int index) {
            this.DrawTile(row, col, index, Color.White);
        }
        #endregion

        //******************************************************************************************
        // Text methods
        //******************************************************************************************

        #region int GetIndexFromChar(char c)
        /// <summary>
        /// Transforms a character value to the index value used to draw text.
        /// </summary>
        /// <param name="c">The character to be drawn.</param>
        /// <returns>The index value of the character.</returns>
        public int GetIndexFromChar(char c) {
            int code = (int)c;
            if((47 < code && code < 58) || (64 < code && code < 91)) {
                return code;
            } else if(code == 33) { // !
                return 59;
            } else if(code == 34) { // "
                return 60;
            } else if(code == 45) { // -
                return 61;
            } else if(code == 46) { // .
                return 62;
            } else if(code == 47) { // /
                return 63;
            } else { // Anything else will be an space.
                return spaceIndex;
            }
        }
        #endregion

        #region void DrawText(int row, int col, string text, int color)
        /// <summary>
        /// Draws a text on the screen.
        /// </summary>
        /// <param name="row">The row of the text.</param>
        /// <param name="col">The column of the text.</param>
        /// <param name="text">The text to draw.</param>
        /// <param name="color">The drawing color to be used.</param>
        public void DrawText(int row, int col, string text, int color) {
            text = text.ToUpper();
            foreach(char c in text) {
                this.DrawTile(row, col, this.GetIndexFromChar(c),
                              Palette.Color[color]);
                ++col;
            }
        }
        #endregion

        #region void DrawText(int row, int col, string text)
        /// <summary>
        /// Draws a text on the screen.
        /// </summary>
        /// <param name="row">The row of the text.</param>
        /// <param name="col">The column of the text.</param>
        /// <param name="text">The text to draw.</param>
        public void DrawText(int row, int col, string text) {
            this.DrawText(row, col, text, Colors.White);
        }
        #endregion

        #region void DrawTextLeft(int row, int col, string text, int color)
        /// <summary>
        /// Draws a text on the screen, aligned to the left.
        /// </summary>
        /// <param name="row">The row of the text.</param>
        /// <param name="col">The column of the text.</param>
        /// <param name="text">The text to draw.</param>
        /// <param name="color">The drawing color to be used.</param>
        public void DrawTextLeft(int row, int col, string text, int color) {
            int offset = text.Length - 1;
            this.DrawText(row, col - offset, text, color);
        }
        #endregion

        #region void DrawTextLeft(int row, int col, string text)
        /// <summary>
        /// Draws a text on the screen, aligned to the left.
        /// </summary>
        /// <param name="row">The row of the text.</param>
        /// <param name="col">The column of the text.</param>
        /// <param name="text">The text to draw.</param>
        public void DrawTextLeft(int row, int col, string text) {
            this.DrawTextLeft(row, col, text, Colors.White);
        }
        #endregion

        #region void DrawSymbol(int row, int col, FontSymbol symbol, int color)
        /// <summary>
        /// Draws a symbol on the screen.
        /// </summary>
        /// <param name="row">The row of the symbol.</param>
        /// <param name="col">The column of the symbol.</param>
        /// <param name="symbol">The symbol identification value.</param>
        /// <param name="color">The drawing color to be used.</param>
        public void DrawSymbol(int row, int col, FontSymbol symbol, int color) {
            switch(symbol) {
                #region Copyright
                case FontSymbol.Copyright:
                    this.DrawTile(row, col, 64, Palette.Color[color]);
                    break;
                #endregion

                #region Pts
                case FontSymbol.Pts:
                    this.ClearCell(row, col + 1);
                    this.DrawTile(row, col, 91, Palette.Color[color]);
                    break;
                #endregion

                #region N100
                case FontSymbol.N100:
                    this.DrawTile(row, col, 20, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 24, Palette.Color[color]);
                    break;
                #endregion

                #region N300
                case FontSymbol.N300:
                    this.DrawTile(row, col, 21, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 24, Palette.Color[color]);
                    break;
                #endregion

                #region N500
                case FontSymbol.N500:
                    this.DrawTile(row, col, 22, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 24, Palette.Color[color]);
                    break;
                #endregion

                #region N700
                case FontSymbol.N700:
                    this.DrawTile(row, col, 23, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 24, Palette.Color[color]);
                    break;
                #endregion

                #region N1000
                case FontSymbol.N1000:
                    this.DrawTile(row, col, 25, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 32, Palette.Color[color]);
                    this.DrawTile(row, col + 2, 33, Palette.Color[color]);
                    break;
                #endregion

                #region N2000
                case FontSymbol.N2000:
                    this.DrawTile(row, col, 26, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 27, Palette.Color[color]);
                    this.DrawTile(row, col + 2, 32, Palette.Color[color]);
                    this.DrawTile(row, col + 3, 33, Palette.Color[color]);
                    break;
                #endregion

                #region N3000
                case FontSymbol.N3000:
                    this.DrawTile(row, col, 28, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 29, Palette.Color[color]);
                    this.DrawTile(row, col + 2, 32, Palette.Color[color]);
                    this.DrawTile(row, col + 3, 33, Palette.Color[color]);
                    break;
                #endregion

                #region N5000
                case FontSymbol.N5000:
                    this.DrawTile(row, col, 30, Palette.Color[color]);
                    this.DrawTile(row, col + 1, 31, Palette.Color[color]);
                    this.DrawTile(row, col + 2, 32, Palette.Color[color]);
                    this.DrawTile(row, col + 3, 33, Palette.Color[color]);
                    break;
                #endregion

                #region Namco
                case FontSymbol.Namco:
                    for(int i = 1; i < 7; i++) {
                        this.ClearCell(row, col + i);
                    }
                    this.DrawTile(row, col, 92, Palette.Color[color]);
                    break;
                #endregion

                #region UpRight
                case FontSymbol.UpRight:
                    this.DrawTile(row, col, 16, Palette.Color[color]);
                    break;
                #endregion

                #region DownRight
                case FontSymbol.DownRight:
                    this.DrawTile(row, col, 17, Palette.Color[color]);
                    break;
                #endregion

                #region UpLeft
                case FontSymbol.UpLeft:
                    this.DrawTile(row, col, 18, Palette.Color[color]);
                    break;
                #endregion

                #region DownLeft
                case FontSymbol.DownLeft:
                    this.DrawTile(row, col, 19, Palette.Color[color]);
                    break;
                #endregion
            }
        }
        #endregion

        #region void DrawSymbol(int row, int col, FontSymbol symbol)
        /// <summary>
        /// Draws a symbol on the screen.
        /// </summary>
        /// <param name="row">The row of the symbol.</param>
        /// <param name="col">The column of the symbol.</param>
        /// <param name="symbol">The symbol identification value.</param>
        public void DrawSymbol(int row, int col, FontSymbol symbol) {
            this.DrawSymbol(row, col, symbol, Colors.White);
        }
        #endregion

        //******************************************************************************************
        // Sprite methods
        //******************************************************************************************

        #region Vector2 SpriteCoordsToVector2(int x, int y)
        /// <summary>
        /// Transforms a sprite coordinates to a 2D vector.
        /// </summary>
        /// <param name="x">The X coordinate of the sprite.</param>
        /// <param name="y">The Y coordinate of the sprite.</param>
        /// <returns>A 2D vector with the sprite coordinates.</returns>
        public Vector2 SpriteCoordsToVector2(int x, int y) {
            return new Vector2(ScreenStartX + x, ScreenStartY + y);
        }
        #endregion

        #region void ClearSprite(int x, int y)
        /// <summary>
        /// Clear a sprite from the screen.
        /// </summary>
        /// <param name="x">The X coordinate of the sprite.</param>
        /// <param name="y">The Y coordinate of the sprite.</param>
        public void ClearSprite(int x, int y) {
            this.spriteBatch.Draw(this.blankSprite, SpriteCoordsToVector2(x, y), Color.White);
        }
        #endregion

        #region void DrawSprite(int x, int y, int index)
        /// <summary>
        /// Draws a sprite on the screen.
        /// </summary>
        /// <param name="x">The X coordinate of the sprite.</param>
        /// <param name="y">The Y coordinate of the sprite.</param>
        /// <param name="index">The sprite identification value.</param>
        public void DrawSprite(int x, int y, int index) {
            this.spriteBatch.Draw(this.Tiles, SpriteCoordsToVector2(x, y),
                                  Sprites.Rectangles[index], Color.White);
        }
        #endregion
    }
}