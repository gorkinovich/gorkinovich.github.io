﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This enumeration is a list of the font symbols in the game.
    /// </summary>
    public enum FontSymbol {
        /// <summary>The id of the (c) symbol.</summary>
        Copyright,
        /// <summary>The id of the points symbol.</summary>
        Pts,
        /// <summary>The id of the 100 symbol.</summary>
        N100,
        /// <summary>The id of the 300 symbol.</summary>
        N300,
        /// <summary>The id of the 500 symbol.</summary>
        N500,
        /// <summary>The id of the 700 symbol.</summary>
        N700,
        /// <summary>The id of the 1000 symbol.</summary>
        N1000,
        /// <summary>The id of the 2000 symbol.</summary>
        N2000,
        /// <summary>The id of the 3000 symbol.</summary>
        N3000,
        /// <summary>The id of the 5000 symbol.</summary>
        N5000,
        /// <summary>The id of the Namco symbol.</summary>
        Namco,
        /// <summary>The id of the up-right corner symbol.</summary>
        UpRight,
        /// <summary>The id of the down-right corner symbol.</summary>
        DownRight,
        /// <summary>The id of the up-left corner symbol.</summary>
        UpLeft,
        /// <summary>The id of the down-left corner symbol.</summary>
        DownLeft
    }
}