﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class is used to make an animation using sprites.
    /// </summary>
    public sealed class Animation {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameScreen render
        /// <summary>
        /// The render subroutines.
        /// </summary>
        private GameScreen render;
        #endregion

        #region long maxTimeInterval
        /// <summary>
        /// The maximum amount of time to change the current frame.
        /// </summary>
        private long maxTimeInterval;
        #endregion

        #region long currentTime
        /// <summary>
        /// The current passed time.
        /// </summary>
        private long currentTime;
        #endregion

        #region int currentFrame
        /// <summary>
        /// The current frame of the animation.
        /// </summary>
        public int CurrentFrame { get; private set; }
        #endregion

        #region int[] Frames
        /// <summary>
        /// The frames of the animation.
        /// </summary>
        public int[] Frames { get; set; }
        #endregion

        #region bool Loop
        /// <summary>
        /// This tells if the animation is a loop one or not.
        /// </summary>
        public bool Loop { get; set; }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Animation(GameScreen render, int[] frames, int fps)
        /// <summary>
        /// Constructs a new Animation object.
        /// </summary>
        /// <param name="render">The render subroutines.</param>
        /// <param name="frames">The frames of the animation.</param>
        /// <param name="fps">The frames per second of the animation.</param>
        public Animation(GameScreen render, int[] frames, int fps) {
            this.render = render;
            this.Frames = frames;
            this.SetFps(fps);
            this.currentTime = 0;
            this.CurrentFrame = 0;
            this.Loop = true;
        }
        #endregion

        #region Animation(GameScreen render, int[] frames, int fps, bool loop)
        /// <summary>
        /// Constructs a new Animation object.
        /// </summary>
        /// <param name="render">The render subroutines.</param>
        /// <param name="frames">The frames of the animation.</param>
        /// <param name="fps">The frames per second of the animation.</param>
        /// <param name="loop">Is this animation a loop one or not?</param>
        public Animation(GameScreen render, int[] frames, int fps, bool loop) {
            this.render = render;
            this.Frames = frames;
            this.SetFps(fps);
            this.currentTime = 0;
            this.CurrentFrame = 0;
            this.Loop = loop;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Draw(int x, int y)
        /// <summary>
        /// Draws the current frame of the animation.
        /// </summary>
        /// <param name="x">The x coordinate.</param>
        /// <param name="y">The y coordinate.</param>
        public void Draw(int x, int y) {
            this.render.DrawSprite(x, y, this.Frames[this.CurrentFrame]);
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the current frame of the animation.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            // First we have to add the passed time.
            this.currentTime += time;
            // Then we check if we have wait enough to change the current frame.
            while(this.currentTime >= this.maxTimeInterval) {
                // Second, we'll check if we have a loop animation or not. If we haven't a
                // loop animation, we'll check if we aren't at the last frame.
                if(this.Loop) {
                    // If this is a loop animation, we'll change the current frame.
                    this.CurrentFrame = (this.CurrentFrame + 1) % this.Frames.Length;
                } else if(this.CurrentFrame + 1 < this.Frames.Length) {
                    // Only if we aren't at the end, we'll change the current frame.
                    this.CurrentFrame = this.CurrentFrame + 1;
                }
                // Finally we'll remove an interval from the passed time.
                this.currentTime -= this.maxTimeInterval;
            }
        }
        #endregion

        #region void Reset()
        /// <summary>
        /// Resets the whole animation.
        /// </summary>
        public void Reset() {
            this.currentTime = 0;
            this.CurrentFrame = 0;
        }
        #endregion

        #region void ResetTime()
        /// <summary>
        /// Resets only the passed time.
        /// </summary>
        public void ResetTime() {
            this.currentTime = 0;
        }
        #endregion

        #region void SetFps(int fps)
        /// <summary>
        /// Sets the frames per second of the animation.
        /// </summary>
        /// <param name="fps">The frames per second.</param>
        public void SetFps(int fps) {
            this.maxTimeInterval = 1000 / fps;
        }
        #endregion

        #region bool IsOnFinalFrame()
        /// <summary>
        /// Checks if the current frame is the final one.
        /// </summary>
        /// <returns>If the animation is in the final one returns true, otherwise false.</returns>
        public bool IsOnFinalFrame() {
            return ((this.Frames.Length - 1) == this.CurrentFrame);
        }
        #endregion
    }
}