﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;

namespace Pacman {
    /// <summary>
    /// This class represents the maze graph.
    /// </summary>
    public sealed class MazeGraph {
        //******************************************************************************************
        // Types
        //******************************************************************************************

        #region struct RowNode
        /// <summary>
        /// This structure represents a row node.
        /// </summary>
        private struct RowNode {
            /// <summary>The row of the node.</summary>
            public int Row;
            /// <summary>The y coordinate of the intersection.</summary>
            public int Y;
            /// <summary>The list of columns of the node.</summary>
            public Node[] Cols;
        }
        #endregion

        #region struct Node
        /// <summary>
        /// This structure represents a node in the graph.
        /// </summary>
        public struct Node {
            /// <summary>The row of the node.</summary>
            public int Row;
            /// <summary>The column of the node.</summary>
            public int Col;
            /// <summary>The x coordinate of the intersection.</summary>
            public int X;
            /// <summary>The y coordinate of the intersection.</summary>
            public int Y;
            /// <summary>The list of directions of the node.</summary>
            public MovingDirection[] Dirs;

            /// <summary>
            /// Constructs a new Node structure.
            /// </summary>
            /// <param name="row">The row of the node.</param>
            /// <param name="col">The column of the node.</param>
            public Node(int row, int col) {
                this.Row = row;
                this.Col = col;
                this.X = col * GameScreen.CellWidth - Maze.SpriteSepX;
                this.Y = row * GameScreen.CellHeight - Maze.SpriteSepY;
                this.Dirs = null;
            }

            /// <summary>
            /// Checks if the node is valid or not.
            /// </summary>
            /// <returns>Returns true when the node is valid, otherwise returns false.</returns>
            public bool IsValid() {
                return (this.Row != 0) && (this.Col != 0);
            }
        }
        #endregion

        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int numberOfRows
        /// <summary>
        /// This is the number of rows of the graph.
        /// </summary>
        private const int numberOfRows = 10;
        #endregion

        #region int[] numberOfCols
        /// <summary>
        /// This is the number of columns in each row of the graph.
        /// </summary>
        private static readonly int[] numberOfCols = new int[] { 6, 8, 8, 4, 4, 2, 8, 10, 10, 4 };
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region RowNode[] rows
        /// <summary>
        /// The list of rows in the graph.
        /// </summary>
        private RowNode[] rows;
        #endregion

        #region bool[,] map
        /// <summary>
        /// The map of the maze.
        /// </summary>
        private bool[,] map;
        #endregion

        #region Random rnd
        /// <summary>
        /// A random number generator.
        /// </summary>
        private static Random rnd = new Random();
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region MazeGraph()
        /// <summary>
        /// Constructs a new MazeGraph object.
        /// </summary>
        public MazeGraph() {
            int[] rowValues = new int[] { 4, 8, 11, 14, 17, 20, 23, 26, 29, 32 };

            int[][] colValues = new int[][] {
                new int[] { 1, 6, 12, 15, 21, 26 },
                new int[] { 1, 6, 9, 12, 15, 18, 21, 26 },
                new int[] { 1, 6, 9, 12, 15, 18, 21, 26 },
                new int[] { 9, 12, 15, 18 },
                new int[] { 6, 9, 18, 21 },
                new int[] { 9, 18 },
                new int[] { 1, 6, 9, 12, 15, 18, 21, 26 },
                new int[] { 1, 3, 6, 9, 12, 15, 18, 21, 24, 26 },
                new int[] { 1, 3, 6, 9, 12, 15, 18, 21, 24, 26 },
                new int[] { 1, 12, 15, 26 }
            };

            MovingDirection[][] dirValues = new MovingDirection[][] {
                // Row 4
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                // Row 8
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Up },
                // Row 11
                new MovingDirection[] { MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Up },
                // Row 14
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                // Row 17
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                // Row 20
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Up },
                // Row 23
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                // Row 26
                new MovingDirection[] { MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Up },
                // Row 29
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Right },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Down, MovingDirection.Left },
                // Row 32
                new MovingDirection[] { MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Right, MovingDirection.Up },
                new MovingDirection[] { MovingDirection.Left, MovingDirection.Up }
            };

            this.rows = new RowNode[MazeGraph.numberOfRows];

            int k = 0;
            for(int i = 0; i < MazeGraph.numberOfRows; i++) {
                this.rows[i].Row = rowValues[i];
                this.rows[i].Y = rowValues[i] * GameScreen.CellHeight - Maze.SpriteSepY;
                this.rows[i].Cols = new Node[MazeGraph.numberOfCols[i]];

                for(int j = 0; j < MazeGraph.numberOfCols[i]; j++) {
                    this.rows[i].Cols[j].Row = this.rows[i].Row;
                    this.rows[i].Cols[j].Col = colValues[i][j];
                    this.rows[i].Cols[j].X = colValues[i][j] * GameScreen.CellWidth - Maze.SpriteSepX;
                    this.rows[i].Cols[j].Y = this.rows[i].Y;
                    this.rows[i].Cols[j].Dirs = dirValues[k];
                    k++;
                }
            }

            this.resetMap();
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void resetMap()
        /// <summary>
        /// Resets the maze map.
        /// </summary>
        private void resetMap() {
            this.map = new bool[,] {
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true},
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true},
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {false, true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true, false},
                {false, true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true, false},
                {false, true, false, true, true, false, true, false, true, true, true, false, true, false, false, true, false, true, true, true, false, true, false, true, true, false, true, false},
                {false, true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true, false},
                {false, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false},
                {false, true, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, true, false},
                {false, true, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, true, false},
                {false, true, true, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, true, true, false},
                {false, false, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, false, false},
                {true, true, true, true, true, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, true, true, true, true, true},
                {true, true, true, true, true, false, true, false, false, true, true, true, true, true, true, true, true, true, true, false, false, true, false, true, true, true, true, true},
                {true, true, true, true, true, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, true, true, true, true, true},
                {false, false, false, false, false, false, true, false, false, true, false, true, true, true, true, true, true, false, true, false, false, true, false, false, false, false, false, false},
                {true, true, true, true, true, true, true, true, true, true, false, true, true, true, true, true, true, false, true, true, true, true, true, true, true, true, true, true},
                {false, false, false, false, false, false, true, false, false, true, false, true, true, true, true, true, true, false, true, false, false, true, false, false, false, false, false, false},
                {true, true, true, true, true, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, true, true, true, true, true},
                {true, true, true, true, true, false, true, false, false, true, true, true, true, true, true, true, true, true, true, false, false, true, false, true, true, true, true, true},
                {true, true, true, true, true, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, true, true, true, true, true},
                {false, false, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, false, false},
                {false, true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true, false},
                {false, true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true, false},
                {false, true, false, false, false, false, true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false, false, false, false, true, false},
                {false, true, true, true, false, false, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, false, true, true, true, false},
                {false, false, false, true, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, true, false, false, false},
                {false, false, false, true, false, false, true, false, false, true, false, false, false, false, false, false, false, false, true, false, false, true, false, false, true, false, false, false},
                {false, true, true, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, false, false, true, true, true, true, true, true, false},
                {false, true, false, false, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, false, false, true, false},
                {false, true, false, false, false, false, false, false, false, false, false, false, true, false, false, true, false, false, false, false, false, false, false, false, false, false, true, false},
                {false, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false},
                {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false},
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true},
                {true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true}
            };
        }
        #endregion

        #region void setMapValue(int row, int col, bool value)
        /// <summary>
        /// Sets a cell of the map with a value.
        /// </summary>
        /// <param name="row">The row of the cell.</param>
        /// <param name="col">The colum of the cell.</param>
        /// <param name="value">The value of the cell.</param>
        private void setMapValue(int row, int col, bool value) {
            if(row < 0) { row += GameScreen.NumberOfRows; }
            if(col < 0) { col += GameScreen.NumberOfColums; }
            this.map[row % GameScreen.NumberOfRows, col % GameScreen.NumberOfColums] = value;
        }
        #endregion

        #region bool getMapValue(int row, int col)
        /// <summary>
        /// Gets the value from a cell of the map.
        /// </summary>
        /// <param name="row">The row of the cell.</param>
        /// <param name="col">The colum of the cell.</param>
        /// <returns>The value of the cell.</returns>
        private bool getMapValue(int row, int col) {
            if(row < 0) { row += GameScreen.NumberOfRows; }
            if(col < 0) { col += GameScreen.NumberOfColums; }
            return this.map[row % GameScreen.NumberOfRows, col % GameScreen.NumberOfColums];
        }
        #endregion

        #region void lockCell(Point cell)
        /// <summary>
        /// Locks a cell in the map.
        /// </summary>
        /// <param name="cell">The cell to lock.</param>
        private void lockCell(Point cell) {
            this.setMapValue(cell.Y, cell.X, false);
        }
        #endregion

        #region void unlockCell(Point cell)
        /// <summary>
        /// Unlocks a cell in the map.
        /// </summary>
        /// <param name="cell">The cell to unlock.</param>
        private void unlockCell(Point cell) {
            this.setMapValue(cell.Y, cell.X, true);
        }
        #endregion

        #region MovingDirection[] GetDirections(int row, int col)
        /// <summary>
        /// Gets all the posible directions from a cell.
        /// </summary>
        /// <param name="row">The row of the cell.</param>
        /// <param name="col">The col of the cell.</param>
        /// <returns>Returns an array with all the directions.</returns>
        public MovingDirection[] GetDirections(int row, int col) {
            List<MovingDirection> list = new List<MovingDirection>();
            if(this.getMapValue(row - 1, col)) { list.Add(MovingDirection.Up); }
            if(this.getMapValue(row + 1, col)) { list.Add(MovingDirection.Down); }
            if(this.getMapValue(row, col - 1)) { list.Add(MovingDirection.Left); }
            if(this.getMapValue(row, col + 1)) { list.Add(MovingDirection.Right); }
            return list.ToArray();
        }
        #endregion

        #region MovingDirection[] GetDirections(Point orig, Point dest)
        /// <summary>
        /// Gets all the posible directions from a cell.
        /// </summary>
        /// <param name="orig">The origin cell.</param>
        /// <param name="dest">The destination cell.</param>
        /// <returns>Returns an array with all the directions.</returns>
        public MovingDirection[] GetDirections(Point orig, Point dest) {
            List<MovingDirection> list = new List<MovingDirection>();
            if(orig.Y < dest.Y) {
                if(orig.X < dest.X) { // NW
                    if((dest.Y - orig.Y) <= (dest.X - orig.X)) {
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                    } else {
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                    }
                } else if(orig.X == dest.X) { // N
                    if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                    if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                    if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                    if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                } else { // NE
                    if((dest.Y - orig.Y) <= (orig.X - dest.X)) {
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                    } else {
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                    }
                }
            } else if(orig.Y == dest.Y) {
                if(orig.X < dest.X) { // W
                    if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                    if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                    if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                    if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                } else if(orig.X > dest.X) { // E
                    if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                    if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                    if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                    if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                }
            } else {
                if(orig.X < dest.X) { // SW
                    if((orig.Y - dest.Y) <= (dest.X - orig.X)) {
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                    } else {
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                    }
                } else if(orig.X == dest.X) { // S
                    if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                    if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                    if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                    if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                } else { // SE
                    if((orig.Y - dest.Y) <= (orig.X - dest.X)) {
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                    } else {
                        if(this.getMapValue(orig.Y, orig.X - 1)) { list.Add(MovingDirection.Left); }
                        if(this.getMapValue(orig.Y - 1, orig.X)) { list.Add(MovingDirection.Up); }
                        if(this.getMapValue(orig.Y + 1, orig.X)) { list.Add(MovingDirection.Down); }
                        if(this.getMapValue(orig.Y, orig.X + 1)) { list.Add(MovingDirection.Right); }
                    }
                }
            }
            return list.ToArray();
        }
        #endregion

        #region Point GetNextPoint(Point orig, MovingDirection dir)
        /// <summary>
        /// Gets the next point when we have a direction.
        /// </summary>
        /// <param name="orig">The origin point.</param>
        /// <param name="dir">The direction.</param>
        /// <returns>The next point to the origin.</returns>
        public Point GetNextPoint(Point orig, MovingDirection dir) {
            Point aux = new Point(orig.X, orig.Y);
            switch(dir) {
                case MovingDirection.Up:
                    aux.Y--;
                    if(aux.Y < 0) {
                        aux.Y += GameScreen.NumberOfRows;
                    }
                    break;
                case MovingDirection.Down:
                    aux.Y++;
                    if(aux.Y >= GameScreen.NumberOfRows) {
                        aux.Y -= GameScreen.NumberOfRows;
                    }
                    break;
                case MovingDirection.Left:
                    aux.X--;
                    if(aux.X < 0) {
                        aux.X += GameScreen.NumberOfColums;
                    }
                    break;
                case MovingDirection.Right:
                    aux.X++;
                    if(aux.X >= GameScreen.NumberOfColums) {
                        aux.X -= GameScreen.NumberOfColums;
                    }
                    break;
            }
            return aux;
        }
        #endregion

        #region int getDistance(Point orig, Point dest)
        /// <summary>
        /// Gets the distance in cells from an origin to a destination.
        /// </summary>
        /// <param name="orig">The origin cell.</param>
        /// <param name="dest">The destination cell.</param>
        /// <returns>The distance between the origin and the destination.</returns>
        private int getDistance(Point orig, Point dest) {
            return Math.Abs(orig.Y - dest.Y) + Math.Abs(orig.X - dest.X);
        }
        #endregion

        #region bool findDirectPath(Point orig, Point dest, MovingDirection lastDir, int max)
        /// <summary>
        /// Checks if there is a direct path.
        /// </summary>
        /// <param name="orig">The origin point.</param>
        /// <param name="dest">The destination point.</param>
        /// <param name="lastDir">The last direction used.</param>
        /// <param name="max">The maximum distance allowed.</param>
        /// <returns>Returns true if there is a direct path, otherwise false.</returns>
        private bool findDirectPath(Point orig, Point dest, MovingDirection lastDir, int max) {
            // The first thing to check is if we are in the destination.
            if(orig != dest) {
                // If we aren't in the destination, we'll get the current distance to it.
                int currentDistance = this.getDistance(orig, dest);
                if(max >= currentDistance) {
                    // If we go in the right direction, we'll lock this cell to test it.
                    bool result = false;
                    this.lockCell(orig);

                    // We'll check if the current cell is an intersection or not.
                    if(this.IsOnIntersection(orig.Y, orig.X)) {
                        // If we're on an intersection, we'll first get the possible directions.
                        MovingDirection[] dirs = this.GetDirections(orig, dest);
                        foreach(MovingDirection dir in dirs) {
                            // Then for each possible direction, we'll check if we have a direct
                            // path with it. When a direction returns true, the algorithm stops.
                            if(!result) {
                                result = this.findDirectPath(this.GetNextPoint(orig, dir),
                                                             dest, dir, currentDistance);
                            }
                        }
                    } else {
                        // If we're not on an intersection, we'll check the next cell.
                        result = this.findDirectPath(this.GetNextPoint(orig, lastDir), dest,
                                                     lastDir, currentDistance);
                    }

                    // Finally, we'll unlock the cell and return the result of the algorithm.
                    this.unlockCell(orig);
                    return result;
                } else {
                    // If we don't go in the right direction, we don't have a direct path.
                    return false;
                }
            } else {
                // If we are in the destination, we find a direct path.
                return true;
            }
        }
        #endregion

        #region MovingDirection GetOppositeDirection(MovingDirection dir)
        /// <summary>
        /// Gets the opposite direction from another one.
        /// </summary>
        /// <param name="dir">The current direction.</param>
        /// <returns>The opposite direction.</returns>
        public MovingDirection GetOppositeDirection(MovingDirection dir) {
            switch(dir) {
                case MovingDirection.Up: return MovingDirection.Down;
                case MovingDirection.Down: return MovingDirection.Up;
                case MovingDirection.Left: return MovingDirection.Right;
                case MovingDirection.Right: return MovingDirection.Left;
                default: return MovingDirection.None;
            }
        }
        #endregion

        #region MovingDirection[] eraseDirection(MovingDirection[] dirs, MovingDirection dir)
        /// <summary>
        /// Erase a direction from an array.
        /// </summary>
        /// <param name="dirs">The array of directions.</param>
        /// <param name="dir">The direction to erase from the array.</param>
        /// <returns>The new array without the direction.</returns>
        private MovingDirection[] eraseDirection(MovingDirection[] dirs, MovingDirection dir) {
            List<MovingDirection> list = new List<MovingDirection>();
            foreach(MovingDirection d in dirs) {
                if(d != dir) {
                    list.Add(d);
                }
            }
            return list.ToArray();
        }
        #endregion

        #region MovingDirection getRandomDirection(MovingEntity entity, MovingDirection[] dirs)
        /// <summary>
        /// Gets a random direction from a list.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="dirs">The list.</param>
        /// <returns>A random direction.</returns>
        private MovingDirection getRandomDirection(MovingEntity entity, MovingDirection[] dirs) {
            if(dirs.Length > 0) {
                // If the list isn't empty, we'll erase the opposite direction from the list.
                MovingDirection opdir = this.GetOppositeDirection(entity.Direction);
                MovingDirection[] options = this.eraseDirection(dirs, opdir);
                // Then, we'll check the new list is empty.
                if(options.Length == 0) {
                    // If the new list is empty, we'll return the unique direction in the old list.
                    return dirs[0];
                } else if(options.Length == 1) {
                    // If the new list isn't empty, but only have one element, we'll return that one.
                    return options[0];
                } else {
                    // If the new list isn't empty and have more than one element, we'll check if
                    // in the new list is the last direction of the entity to follow that one.
                    foreach(MovingDirection d in options) {
                        if(d == entity.Direction) {
                            return d;
                        }
                    }

                    // If not, we'll get a random element from the new list.
                    return options[MazeGraph.rnd.Next(options.Length)];
                }
            } else {
                // If the list is empty, we have none direction to return.
                return MovingDirection.None;
            }
        }
        #endregion

        #region MovingDirection getRandomDirection(MovingDirection[] dirs)
        /// <summary>
        /// Gets a random direction from a list.
        /// </summary>
        /// <param name="dirs">The list.</param>
        /// <returns>A random direction.</returns>
        private MovingDirection getRandomDirection(MovingDirection[] dirs) {
            return dirs[MazeGraph.rnd.Next(dirs.Length)];
        }
        #endregion

        #region MovingDirection checkDirectionInList(MovingDirection[] dirs, MovingDirection dir)
        /// <summary>
        /// Checks if a direction exists inside the array.
        /// </summary>
        /// <param name="dirs">The list of directions.</param>
        /// <param name="dir">The direction to find.</param>
        /// <returns>The direction if exists, otherwise a none direction.</returns>
        private MovingDirection checkDirectionInList(MovingDirection[] dirs, MovingDirection dir) {
            foreach(MovingDirection d in dirs) {
                if(d == dir) { return dir; }
            }
            return MovingDirection.None;
        }
        #endregion

        #region MovingDirection getDirectDirection(Point orig, Point dest, MovingDirection[] dirs)
        /// <summary>
        /// Gets the direct direction if exists in the list.
        /// </summary>
        /// <param name="orig">The origin cell.</param>
        /// <param name="dest">The destination cell.</param>
        /// <param name="dirs">The list of directions.</param>
        /// <returns>The direct direction if exists in the list.</returns>
        private MovingDirection getDirectDirection(Point orig, Point dest, MovingDirection[] dirs) {
            if(orig.Y == dest.Y && orig.X < dest.X) { // W
                return this.checkDirectionInList(dirs, MovingDirection.Right);
            } else if(orig.Y == dest.Y && orig.X > dest.X) { // E
                return this.checkDirectionInList(dirs, MovingDirection.Left);
            } else if(orig.X == dest.X && orig.Y < dest.Y) { // N
                return this.checkDirectionInList(dirs, MovingDirection.Down);
            } else if(orig.X == dest.X && orig.Y > dest.Y) { // S
                return this.checkDirectionInList(dirs, MovingDirection.Up);
            } else {
                return MovingDirection.None;
            }
        }
        #endregion

        #region MovingDirection GetDirection(MovingEntity entity, Point dest)
        /// <summary>
        /// Gets the best direction to go to a destination.
        /// </summary>
        /// <param name="entity">The entity to test.</param>
        /// <param name="dest">The destination cell.</param>
        /// <returns>The best direction to go.</returns>
        public MovingDirection GetDirection(MovingEntity entity, Point dest) {
            // First, we'll get the origin cell of the entity.
            Point orig = Maze.SpriteCoordsToMaze(entity.X, entity.Y);
            // And then we'll check if we're not in the destination.
            if(orig != dest) {
                // If we aren't in the destination, we'll get the possible directions.
                MovingDirection[] dirs = this.GetDirections(orig, dest);
                MovingDirection result = MovingDirection.None;
                // We also need the distance from the entity to the destination cell.
                int maxDistance = this.getDistance(orig, dest);

                // Then, we'll lock the origin cell and try to find the first possible
                // direction with a direct path available. After the test we'll unlock
                // the cell to reset the maze map.
                this.lockCell(orig);
                foreach(MovingDirection dir in dirs) {
                    if(result == MovingDirection.None &&
                       this.findDirectPath(this.GetNextPoint(orig, dir), dest, dir, maxDistance)) {
                        result = dir;
                    }
                }
                this.unlockCell(orig);

                // When there isn't a direct path, we'll try to get the direct direction.
                if(result == MovingDirection.None) {
                    result = this.getDirectDirection(orig, dest, dirs);
                }

                // When there isn't a direct direction, we'll get a random direction,
                // but we wont take the opposite to the current entity's direction.
                if(result == MovingDirection.None) {
                    result = this.getRandomDirection(entity, dirs);
                }

                // If we still haven't a direction, we finally get a random one.
                if(result == MovingDirection.None) {
                    result = this.getRandomDirection(dirs);
                }

                // Finally, we'll return the result.
                return result;
            } else {
                // If we are in the destination, we don't have to move anywhere.
                return MovingDirection.None;
            }
        }
        #endregion

        #region MovingDirection GetEscapeDirection(Ghost ghost, Puckman puckman)
        /// <summary>
        /// Gets a random direction to escape from the puckman.
        /// </summary>
        /// <param name="ghost">The frightened ghost.</param>
        /// <param name="puckman">The powerful puckman.</param>
        /// <returns>A random direction</returns>
        public MovingDirection GetEscapeDirection(Ghost ghost, Puckman puckman) {
            // First, we'll get the cell of the ghost.
            Point orig = Maze.SpriteCoordsToMaze(ghost.X, ghost.Y);
            // Second, we'll get the possible directions.
            MovingDirection[] dirs = this.GetDirections(orig.Y, orig.X);
            if(dirs.Length > 0) {
                MovingDirection opdir;
                // Third, we'll check if puckman is in the same line.
                Point orig2 = Maze.SpriteCoordsToMaze(puckman.X, puckman.Y);
                if(orig.X == orig2.X || orig.Y == orig2.Y) {
                    // When puckman is in the same line, we'll get the opposite direction
                    // of puckman, to erase it from the possible directions. We do this
                    // to avoid the ghost to run to a truly death.
                    opdir = this.GetOppositeDirection(puckman.Direction);
                } else {
                    // When puckman isn't in the same line, we'll get the opposite direction
                    // of the ghost, to erase it from the possible directions. We do this
                    // to avoid the ghost to repeat a loop between two intersections.
                    opdir = this.GetOppositeDirection(ghost.Direction);
                }
                // Here, we'll erase the selected opposite direction from the list.
                MovingDirection[] options = this.eraseDirection(dirs, opdir);
                if(options.Length > 0) {
                    // And finally, we'll return a random direction.
                    return options[MazeGraph.rnd.Next(options.Length)];
                } else {
                    return dirs[0];
                }
            } else {
                return MovingDirection.None;
            }
        }
        #endregion

        #region MovingDirection GetRandomDirection(MovingEntity entity)
        /// <summary>
        /// Gets a random direction for an entity.
        /// </summary>
        /// <param name="entity">The entity to test.</param>
        /// <returns>A random direction.</returns>
        public MovingDirection GetRandomDirection(MovingEntity entity) {
            // First, we'll get the origin cell of the entity.
            Point orig = Maze.SpriteCoordsToMaze(entity.X, entity.Y);
            // Second, we'll the possible directions of the cell.
            MovingDirection[] dirs = this.GetDirections(orig.Y, orig.X);
            // And, finally we'll return a random direction.
            return this.getRandomDirection(dirs); ;
        }
        #endregion

        #region Node GetNode(MovingEntity entity)
        /// <summary>
        /// Gets a node of the graph if the entity is inside the correct cell.
        /// </summary>
        /// <param name="entity">The entity to check.</param>
        /// <returns>Returns a node of the graph.</returns>
        public Node GetNode(MovingEntity entity) {
            Point cell = Maze.SpriteCoordsToMaze(entity.X, entity.Y);
            // First, we'll seek the current row.
            for(int i = 0; i < MazeGraph.numberOfRows; i++) {
                if(this.rows[i].Row == cell.Y) {
                    // Second, we'll seek the current column.
                    for(int j = 0; j < MazeGraph.numberOfCols[i]; j++) {
                        if(this.rows[i].Cols[j].Col == cell.X) {
                            // Finally, if we find a node with the same row and column
                            // we'll return that node to the user.
                            return this.rows[i].Cols[j];
                        }
                    }
                }
            }
            // But when no node have the same coordinates we'll return the invalid node.
            return new Node(0, 0);
        }
        #endregion

        #region Node GetNode(int row, int col)
        /// <summary>
        /// Gets a node of the graph.
        /// </summary>
        /// <param name="row">The row of the cell.</param>
        /// <param name="col">The colum of the cell.</param>
        /// <returns>Returns a node of the graph.</returns>
        public Node GetNode(int row, int col) {
            // First, we'll seek the current row.
            for(int i = 0; i < MazeGraph.numberOfRows; i++) {
                if(this.rows[i].Row == row) {
                    // Second, we'll seek the current column.
                    for(int j = 0; j < MazeGraph.numberOfCols[i]; j++) {
                        if(this.rows[i].Cols[j].Col == col) {
                            // Finally, if we find a node with the same row and column
                            // we'll return that node to the user.
                            return this.rows[i].Cols[j];
                        }
                    }
                }
            }
            // But when no node have the same coordinates we'll return the invalid node.
            return new Node(0, 0);
        }
        #endregion

        #region bool IsOnIntersection(MovingEntity entity)
        /// <summary>
        /// Checks if an entity is on an intersection.
        /// </summary>
        /// <param name="entity">The entity to check.</param>
        /// <returns>Returns true when the entity is on an intersection, otherwise false.</returns>
        public bool IsOnIntersection(MovingEntity entity) {
            return this.GetNode(entity).IsValid();
        }
        #endregion

        #region bool IsOnIntersection(int row, int col)
        /// <summary>
        /// Checks if a coordinates are an intersection.
        /// </summary>
        /// <param name="row">The row of the cell.</param>
        /// <param name="col">The colum of the cell.</param>
        /// <returns>Returns true when the coordinates are an intersection, otherwise false.</returns>
        public bool IsOnIntersection(int row, int col) {
            return this.GetNode(row, col).IsValid();
        }
        #endregion

        #region bool IsNearToIntersection(MovingEntity entity)
        /// <summary>
        /// Checks if an entity is near to an intersection.
        /// </summary>
        /// <param name="entity">The entity to check.</param>
        /// <returns>Returns true when the entity is near, otherwise false.</returns>
        public bool IsNearToIntersection(MovingEntity entity) {
            Point cell = Maze.SpriteCoordsToMaze(entity.X, entity.Y);
            return this.GetNode(cell.Y - 1, cell.X).IsValid() ||
                   this.GetNode(cell.Y + 1, cell.X).IsValid() ||
                   this.GetNode(cell.Y, cell.X - 1).IsValid() ||
                   this.GetNode(cell.Y, cell.X + 1).IsValid();
        }
        #endregion

        #region bool IsNearToIntersection(int row, int col)
        /// <summary>
        /// Checks if a coordinates are near to an intersection.
        /// </summary>
        /// <param name="row">The row of the cell.</param>
        /// <param name="col">The colum of the cell.</param>
        /// <returns>Returns true when the coordinates are near, otherwise false.</returns>
        public bool IsNearToIntersection(int row, int col) {
            return this.GetNode(row - 1, col).IsValid() ||
                   this.GetNode(row + 1, col).IsValid() ||
                   this.GetNode(row, col - 1).IsValid() ||
                   this.GetNode(row, col + 1).IsValid();
        }
        #endregion
    }
}