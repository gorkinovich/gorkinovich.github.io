﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;

namespace Pacman {
    /// <summary>
    /// This class is used to control the ghosts direction in the maze.
    /// </summary>
    public sealed class GhostController {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int numberOfGhosts
        /// <summary>
        /// The number of different ghosts.
        /// </summary>
        private const int numberOfGhosts = 4;
        #endregion

        #region int redGhost
        /// <summary>
        /// The id of the red ghost.
        /// </summary>
        private const int redGhost = 0;
        #endregion

        #region int pinkGhost
        /// <summary>
        /// The id of the pink ghost.
        /// </summary>
        private const int pinkGhost = 1;
        #endregion

        #region int blueGhost
        /// <summary>
        /// The id of the blue ghost.
        /// </summary>
        private const int blueGhost = 2;
        #endregion

        #region int brownGhost
        /// <summary>
        /// The id of the brown ghost.
        /// </summary>
        private const int brownGhost = 3;
        #endregion


        #region long scatterInterval
        /// <summary>
        /// The amount of time the ghosts are in scatter mode.
        /// </summary>
        private const long scatterInterval = 7000;
        #endregion

        #region long chaseInterval
        /// <summary>
        /// The amount of time the ghosts are in chase mode.
        /// </summary>
        private const long chaseInterval = 30000;
        #endregion

        #region long[] houseIntervals
        /// <summary>
        /// The amount of time the ghosts are waiting in the house.
        /// </summary>
        private static readonly long[] houseIntervals = new long[] {
            0,    // Red
            1000, // Pink
            7000, // Blue
            15000 // Brown
        };
        #endregion

        #region int[] minDotsToExit
        /// <summary>
        /// The minimum number of dots to exit from the house.
        /// </summary>
        private static readonly int[] minDotsToExit = new int[] {
            0,   // Red
            7,  // Pink
            17, // Blue
            32  // Brown
        };
        #endregion


        #region int numberOfChanges
        /// <summary>
        /// The number of state changes.
        /// </summary>
        private const int numberOfChanges = 8;
        #endregion

        #region Point[] corners
        /// <summary>
        /// The coordinates of the ghosts corners.
        /// </summary>
        private static readonly Point[] corners = new Point[] {
            new Point(26, 4),  // Red
            new Point(1, 4),   // Pink
            new Point(26, 32), // Blue
            new Point(1, 32)   // Brown
        };
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Ghost[] ghosts
        /// <summary>
        /// This is the ghosts control algorithm.
        /// </summary>
        private GhostControl[] control;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GhostController()
        /// <summary>
        /// Constructs a new GhostController object.
        /// </summary>
        public GhostController() {
            this.control = new GhostControl[GhostController.numberOfGhosts];
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region int getMinDotsToExit(int ghost, Maze maze)
        /// <summary>
        /// Gets the min dots to exit the house for a ghost.
        /// </summary>
        /// <param name="ghost">The current ghost.</param>
        /// <param name="maze">The used maze.</param>
        /// <returns>The min dots value.</returns>
        private int getMinDotsToExit(int ghost, Maze maze) {
            int result = GhostController.minDotsToExit[ghost] + maze.NumberOfEatedDots;
            if(result < Maze.MaximumNumberOfDots) {
                return result;
            } else {
                return 0;
            }
        }
        #endregion

        #region void Initialize(Ghost red, Ghost pink, Ghost blue, Ghost brown, Puckman puckman, Maze maze)
        /// <summary>
        /// Initializes the controller data.
        /// </summary>
        /// <param name="red">The red ghost.</param>
        /// <param name="pink">The pink ghost.</param>
        /// <param name="blue">The blue ghost.</param>
        /// <param name="brown">The brown ghost.</param>
        /// <param name="puckman">The puckman.</param>
        /// <param name="maze">The maze.</param>
        public void Initialize(Ghost red, Ghost pink, Ghost blue, Ghost brown,
                               Puckman puckman, Maze maze) {
            this.control[GhostController.redGhost] = new GhostControl(GhostController.scatterInterval,
                GhostController.chaseInterval, GhostController.houseIntervals[GhostController.redGhost],
                GhostController.minDotsToExit[GhostController.redGhost], GhostController.numberOfChanges,
                GhostController.corners[GhostController.redGhost], red, GhostControlState.Scatter,
                puckman, maze);

            this.control[GhostController.pinkGhost] = new GhostControl(GhostController.scatterInterval,
                GhostController.chaseInterval, GhostController.houseIntervals[GhostController.pinkGhost],
                this.getMinDotsToExit(GhostController.pinkGhost, maze),
                GhostController.numberOfChanges, GhostController.corners[GhostController.pinkGhost],
                pink, GhostControlState.House, puckman, maze);

            this.control[GhostController.blueGhost] = new GhostControl(GhostController.scatterInterval,
                GhostController.chaseInterval, GhostController.houseIntervals[GhostController.blueGhost],
                this.getMinDotsToExit(GhostController.blueGhost, maze),
                GhostController.numberOfChanges, GhostController.corners[GhostController.blueGhost],
                blue, GhostControlState.House, puckman, maze);

            this.control[GhostController.brownGhost] = new GhostControl(GhostController.scatterInterval,
                GhostController.chaseInterval, GhostController.houseIntervals[GhostController.brownGhost],
                this.getMinDotsToExit(GhostController.brownGhost, maze),
                GhostController.numberOfChanges, GhostController.corners[GhostController.brownGhost],
                brown, GhostControlState.House, puckman, maze);
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the direction of all the ghosts.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            for(int i = 0; i < GhostController.numberOfGhosts; i++) {
                this.control[i].Update(time);
            }
        }
        #endregion
    }
}