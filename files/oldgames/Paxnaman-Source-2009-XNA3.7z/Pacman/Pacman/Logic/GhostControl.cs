﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using System;
using Microsoft.Xna.Framework;

namespace Pacman {
    /// <summary>
    /// This class is used to control the ghost direction in the maze.
    /// </summary>
    public sealed class GhostControl {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region long maxScatterInterval
        /// <summary>
        /// The amount of time the ghost is in scatter mode.
        /// </summary>
        private long maxScatterInterval;
        #endregion

        #region long maxChaseInterval
        /// <summary>
        /// The amount of time the ghost is in chase mode.
        /// </summary>
        private long maxChaseInterval;
        #endregion

        #region long maxHouseInterval
        /// <summary>
        /// The amount of time the ghost is waiting in the house.
        /// </summary>
        private long maxHouseInterval;
        #endregion

        #region int minDotsToExit
        /// <summary>
        /// The minimum number of dots to exit from the house.
        /// </summary>
        private int minDotsToExit;
        #endregion

        #region int maxNumberOfChanges
        /// <summary>
        /// The number of state changes.
        /// </summary>
        private int maxNumberOfChanges;
        #endregion

        #region Point corner
        /// <summary>
        /// The coordinates of the ghost corner.
        /// </summary>
        private Point corner;
        #endregion


        #region Ghost ghost
        /// <summary>
        /// This is the ghost reference.
        /// </summary>
        private Ghost ghost;
        #endregion

        #region GhostState state
        /// <summary>
        /// This is the current state of the ghost.
        /// </summary>
        private GhostControlState state;
        #endregion

        #region bool isChasing
        /// <summary>
        /// This is a chasing mark to control the change of state.
        /// </summary>
        private bool isChasing;
        #endregion

        #region bool isInHouse
        /// <summary>
        /// This is an "in house" mark to control the change of state.
        /// </summary>
        private bool isInHouse;
        #endregion

        #region long timeCounter
        /// <summary>
        /// This is the time counter for the ghost.
        /// </summary>
        private long timeCounter;
        #endregion

        #region int changes
        /// <summary>
        /// This is the number of state changes of the ghost.
        /// </summary>
        private int changes;
        #endregion


        #region Puckman puckman
        /// <summary>
        /// This is the puckman reference.
        /// </summary>
        private Puckman puckman;
        #endregion

        #region Maze maze
        /// <summary>
        /// This is the maze reference.
        /// </summary>
        private Maze maze;
        #endregion

        #region bool isDirectionGetted
        /// <summary>
        /// This tells to the program if a direction is getted on an intersection.
        /// </summary>
        private bool isDirectionGetted;
        #endregion

        #region MazeGraph graph
        /// <summary>
        /// This is the maze graph.
        /// </summary>
        private static MazeGraph graph = new MazeGraph();
        #endregion

        #region Point houseEnter
        /// <summary>
        /// This is the maze graph.
        /// </summary>
        private static Point houseEnter = new Point(13, 14);
        #endregion

        #region Ghost red
        /// <summary>
        /// This is the red ghost entity.
        /// </summary>
        private static Ghost red;
        #endregion

        #region Ghost pink
        /// <summary>
        /// This is the pink ghost entity.
        /// </summary>
        private static Ghost pink;
        #endregion

        #region Ghost blue
        /// <summary>
        /// This is the blue ghost entity.
        /// </summary>
        private static Ghost blue;
        #endregion

        #region Ghost brown
        /// <summary>
        /// This is the brown ghost entity.
        /// </summary>
        private static Ghost brown;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GhostControl(long, long, long, int, int, Point, Ghost, GhostControlState, Puckman, Maze)
        /// <summary>
        /// Constructs a new GhostControl object.
        /// </summary>
        /// <param name="maxScatterInterval">The amount of time the ghost is in scatter mode.</param>
        /// <param name="maxChaseInterval">The amount of time the ghost is in chase mode.</param>
        /// <param name="maxHouseInterval">The amount of time the ghost is waiting in the house.</param>
        /// <param name="minDotsToExit">The minimum number of dots to exit from the house.</param>
        /// <param name="maxNumberOfChanges">The number of state changes.</param>
        /// <param name="corner">The coordinates of the ghost corner.</param>
        /// <param name="ghost">This is the ghost reference.</param>
        /// <param name="state">This is the current state of the ghost.</param>
        /// <param name="puckman">This is the puckman reference.</param>
        /// <param name="maze">This is the maze reference.</param>
        public GhostControl(long maxScatterInterval, long maxChaseInterval, long maxHouseInterval,
                            int minDotsToExit, int maxNumberOfChanges, Point corner, Ghost ghost,
                            GhostControlState state, Puckman puckman, Maze maze) {
            this.maxScatterInterval = maxScatterInterval;
            this.maxChaseInterval = maxChaseInterval;
            this.maxHouseInterval = maxHouseInterval;
            this.minDotsToExit = minDotsToExit;
            this.maxNumberOfChanges = maxNumberOfChanges;
            this.corner = corner;
            this.ghost = ghost;
            this.state = state;
            this.isChasing = (state == GhostControlState.Chase);
            this.isInHouse = (state == GhostControlState.House);
            this.timeCounter = 0;
            this.changes = 0;
            this.puckman = puckman;
            this.maze = maze;
            this.setTimeCounter();
            this.isDirectionGetted = false;
            switch(ghost.TypeOfGhost) {
                case GhostType.Red: GhostControl.red = ghost; break;
                case GhostType.Pink: GhostControl.pink = ghost; break;
                case GhostType.Blue: GhostControl.blue = ghost; break;
                case GhostType.Brown: GhostControl.brown = ghost; break;
            }
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void setTimeCounter()
        /// <summary>
        /// Sets the time counter.
        /// </summary>
        private void setTimeCounter() {
            switch(this.state) {
                case GhostControlState.House:
                    this.timeCounter = this.maxHouseInterval;
                    break;
                case GhostControlState.Scatter:
                    this.timeCounter = this.maxScatterInterval;
                    break;
                case GhostControlState.Chase:
                    this.timeCounter = this.maxChaseInterval;
                    break;
            }
        }
        #endregion

        #region void changeState(GhostControlState state)
        /// <summary>
        /// Changes the state.
        /// </summary>
        /// <param name="state">The new state.</param>
        private void changeState(GhostControlState state) {
            if(this.state != state) {
                this.state = state;
            }
        }
        #endregion

        #region bool isGhostOnCorner()
        /// <summary>
        /// Checks if the ghost is on the corner.
        /// </summary>
        /// <returns>Returns true if the ghost is on the corner, otherwise false.</returns>
        private bool isGhostOnCorner() {
            return (this.ghost.X + Maze.SpriteSepX == this.corner.X * GameScreen.CellWidth) &&
                   (this.ghost.Y + Maze.SpriteSepY == this.corner.Y * GameScreen.CellHeight);
        }
        #endregion

        #region void checkState(long time)
        /// <summary>
        /// Checks the state of a ghost.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        private void checkState(long time) {
            // First, we'll check if the ghost is alive.
            if(this.ghost.Alive) {
                // If the ghost is alive, check if the state of the ghost.
                if(this.ghost.State == GhostState.Normal) {
                    // If the ghost is in normal mode, we'll check the control state.
                    switch(this.state) {
                        #region GhostControlState.House
                        case GhostControlState.House:
                            // If the ghost is in house state, we'll check the time counter
                            // first, to remove time from it, only when it have time.
                            if(this.timeCounter > 0 && this.maze.NumberOfEatedDots < this.minDotsToExit) {
                                this.timeCounter -= time;
                            } else {
                                // When the time is over, we have to check if the ghost is outside
                                // the house and in the start coordinates.
                                if(!Maze.IsGhostInsideTheHouse(this.ghost) &&
                                   Maze.IsGhostInTheStartPoint(this.ghost)) {
                                    // Then, we'll change the "is in house" flag and the ghost direction.
                                    this.isInHouse = false;
                                    this.ghost.NeededDirection = MovingDirection.Left;
                                    // After that, we'll have to check if the ghost is chasing the
                                    // puckman or not, to change the state and the time counter.
                                    if(this.isChasing) {
                                        this.state = GhostControlState.Chase;
                                        this.timeCounter = this.maxChaseInterval;
                                    } else {
                                        this.state = GhostControlState.Scatter;
                                        this.timeCounter = this.maxScatterInterval;
                                    }
                                }
                            }
                            break;
                        #endregion

                        #region GhostControlState.Scatter
                        case GhostControlState.Scatter:
                            // If the ghost is in scatter state, we'll check the time counter
                            // first, to remove time from it, only when it have time. We also
                            // have to check if the ghost is in its corner.
                            if(this.timeCounter > 0 && !this.isGhostOnCorner()) {
                                this.timeCounter -= time;
                            } else {
                                // When the time is over, we have to check if we can continue
                                // changing between the chase and the scatter state.
                                if(this.changes < this.maxNumberOfChanges) {
                                    // If we can make a change, we'll change the state to chase.
                                    this.state = GhostControlState.Chase;
                                    this.isChasing = true;
                                    // Then we'll set the time counter and add a change mark.
                                    this.timeCounter = this.maxChaseInterval;
                                    this.changes++;
                                    this.isDirectionGetted = false;
                                }
                            }
                            break;
                        #endregion

                        #region GhostControlState.Chase
                        case GhostControlState.Chase:
                            // If the ghost is in chase state, we'll check the time counter
                            // first, to remove time from it, only when it have time.
                            if(this.timeCounter > 0) {
                                this.timeCounter -= time;
                            } else {
                                // When the time is over, we have to check if we can continue
                                // changing between the chase and the scatter state.
                                if(this.changes < this.maxNumberOfChanges) {
                                    // If we can make a change, we'll change the state to scatter.
                                    this.state = GhostControlState.Scatter;
                                    this.isChasing = false;
                                    // Then we'll set the time counter and add a change mark.
                                    this.timeCounter = this.maxScatterInterval;
                                    this.changes++;
                                    this.isDirectionGetted = false;
                                }
                            }
                            break;
                        #endregion

                        #region GhostControlState.Frightened
                        case GhostControlState.Frightened:
                            // If the ghost is in frightened state, is because it was in
                            // vulnerable mode and now is back to normal. So we'll check
                            // in which state the ghost was before the vulnerable mode.
                            if(this.isInHouse) {
                                // If the ghost is inside the house, we'll have to check
                                // the "is in house" flag, to continue with the countdown.
                                this.state = GhostControlState.House;
                            } else {
                                // If the ghost is out the house, we'll have to check
                                // if the ghost is chasing the puckman or not.
                                if(this.isChasing) {
                                    this.state = GhostControlState.Chase;
                                } else {
                                    this.state = GhostControlState.Scatter;
                                }
                                this.isDirectionGetted = false;
                            }
                            break;
                        #endregion

                        #region GhostControlState.Dead
                        case GhostControlState.Dead:
                            // If the ghost is in dead state, is because it was killed by
                            // puckman and now after get back to life inside the house,
                            // the ghost is still in dead state but it is alive. So we'll
                            // change the current state to the house control state.
                            this.state = GhostControlState.House;
                            this.isInHouse = true;
                            // Because the ghost was out when it was killed, it make no
                            // sense to wait some time to get out the house.
                            this.timeCounter = 0;
                            break;
                        #endregion
                    }
                } else {
                    // If the ghost isn't in normal mode, it will be frightened.
                    this.changeState(GhostControlState.Frightened);
                    // We also need to check if the ghost is still in the house.
                    if(this.isInHouse) {
                        // If the ghost was in house state, we'll check the time counter
                        // first, to remove time from it, only when it have time.
                        if(this.timeCounter > 0) {
                            this.timeCounter -= time;
                        } else {
                            // When the time is over, we have to check if the ghost is outside
                            // the house and in the start coordinates.
                            if(!Maze.IsGhostInsideTheHouse(this.ghost) &&
                               Maze.IsGhostInTheStartPoint(this.ghost)) {
                                // Then, we'll change the "is in house" flag and the ghost direction.
                                this.isInHouse = false;
                                this.ghost.NeededDirection = MovingDirection.Left;
                                // After that, we'll have to check if the ghost is chasing the
                                // puckman or not, to change the state.
                                if(this.isChasing) {
                                    this.timeCounter = this.maxChaseInterval;
                                } else {
                                    this.timeCounter = this.maxScatterInterval;
                                }
                            }
                        }
                    }
                }
            } else {
                // If the ghost isn't alive, we'll be in dead state.
                if(this.state != GhostControlState.Dead) {
                    this.state = GhostControlState.Dead;
                    this.isDirectionGetted = false;
                }
            }
        }
        #endregion

        #region void houseUpdate()
        /// <summary>
        /// Updates the direction when the ghost is in the house state.
        /// </summary>
        private void houseUpdate() {
            // First, we'll check the time counter.
            if(this.timeCounter > 0 && this.maze.NumberOfEatedDots < this.minDotsToExit) {
                // When the time isn't over, we'll check if the ghost have
                // reached the limit inside the house, to move in the Y-axis.
                if(this.ghost.Y <= Maze.GhostHouseStartY) {
                    this.ghost.NeededDirection = MovingDirection.Down;
                } else if(this.ghost.Y >= Maze.GhostHouseEndY) {
                    this.ghost.NeededDirection = MovingDirection.Up;
                }
            } else {
                // When the time is over, we'll have to get the ghost out the house.
                // So if the ghost is in the same line that the start x coordinate,
                // we'll set the ghost direction to up.
                if(this.ghost.X == Maze.GhostStartX) {
                    this.ghost.NeededDirection = MovingDirection.Up;
                } else {
                    // If not, we'll try to put the ghost in the middle of the house,
                    // to move it to the center start x coordinate line.
                    if(this.ghost.Y <= Maze.GhostHouseStartY) {
                        this.ghost.NeededDirection = MovingDirection.Down;
                    } else if(this.ghost.Y >= Maze.GhostHouseEndY) {
                        this.ghost.NeededDirection = MovingDirection.Up;
                    } else if(this.ghost.Y >= Maze.GhostHouseCenterY) {
                        // When the ghost is in the center of the house, we'll move
                        // it from the right or the left to the center.
                        if(this.ghost.X <= Maze.BlueGhostStartX) {
                            this.ghost.NeededDirection = MovingDirection.Right;
                        } else if(this.ghost.X >= Maze.BrownGhostStartX) {
                            this.ghost.NeededDirection = MovingDirection.Left;
                        }
                    }
                }
            }
        }
        #endregion

        #region void scatterUpdate()
        /// <summary>
        /// Updates the direction when the ghost is in the scatter state.
        /// </summary>
        private void scatterUpdate() {
            // First, we'll check if we're on an intersection.
            if(GhostControl.graph.IsOnIntersection(this.ghost)) {
                // If we're on an intersection, we'll check that we didn't select
                // a direction in a previous update.
                if(!this.isDirectionGetted) {
                    // If we can select a direction, we'll find a new one.
                    this.ghost.NeededDirection = GhostControl.graph.GetDirection(this.ghost, this.corner);
                    // And then, we'll set this flag to avoid to make the same
                    // algorithim for the same data.
                    if(this.ghost.NeededDirection != MovingDirection.None) {
                        this.isDirectionGetted = true;
                    }
                }
            } else {
                // If we're not on an intersection, we'll set this flag to make
                // possible in a future update to select a new direction.
                this.isDirectionGetted = false;
            }
        }
        #endregion

        #region void chaseUpdate()
        /// <summary>
        /// Updates the direction when the ghost is in the chase state.
        /// </summary>
        private void chaseUpdate() {
            // First, we'll check if we're on an intersection.
            if(GhostControl.graph.IsOnIntersection(this.ghost)) {
                // If we're on an intersection, we'll check that we didn't select
                // a direction in a previous update.
                if(!this.isDirectionGetted) {
                    // If we can select a direction, we'll find a new one.
                    Point dest = Maze.SpriteCoordsToMaze(this.puckman.X, this.puckman.Y);
                    switch(this.ghost.TypeOfGhost) {
                        #region GhostType.Red
                        case GhostType.Red:
                            // The red ghost will always try to track puckman directly.
                            this.ghost.NeededDirection = GhostControl.graph.GetDirection(this.ghost, dest);
                            // This ghost will be behind puckman and sometimes will enter the same cell
                            // that the puckman is exiting. The path finder will return the none direction
                            // because they both are in the same cell, so we'll asign the same direction
                            // that the player have chosen.
                            if(this.ghost.NeededDirection == MovingDirection.None) {
                                this.ghost.NeededDirection = this.puckman.Direction;
                            }
                            break;
                        #endregion

                        #region GhostType.Pink
                        case GhostType.Pink:
                            // The pink ghost will always try anticipate puckman location.
                            switch(this.puckman.Direction) {
                                case MovingDirection.Up: dest.Y -= 4; break;
                                case MovingDirection.Down: dest.Y += 4; break;
                                case MovingDirection.Left: dest.X -= 4; break;
                                case MovingDirection.Right: dest.X += 4; break;
                            }
                            this.ghost.NeededDirection = GhostControl.graph.GetDirection(this.ghost, dest);
                            // And if the ghost get stopped in the destination cell, will be next to the
                            // puckam and we'll set the direction to finally cut the player's path.
                            if(this.ghost.NeededDirection == MovingDirection.None) {
                                this.ghost.NeededDirection = GhostControl.graph.GetOppositeDirection(this.puckman.Direction);
                            }
                            break;
                        #endregion

                        #region GhostType.Blue
                        case GhostType.Blue:
                            // The blue ghost will always try to be the least predictable.
                            switch(this.puckman.Direction) {
                                case MovingDirection.Up: dest.Y -= 2; dest.X -= 2; break;
                                case MovingDirection.Down: dest.Y += 2; break;
                                case MovingDirection.Left: dest.X -= 2; break;
                                case MovingDirection.Right: dest.X += 2; break;
                            }
                            Point redOrig = Maze.SpriteCoordsToMaze(GhostControl.red.X, GhostControl.red.Y);
                            Point vector = new Point(dest.X - redOrig.X, dest.Y - redOrig.Y);
                            dest.X += vector.X;
                            dest.Y += vector.Y;
                            // After calculate the destination, we'll get the direction.
                            this.ghost.NeededDirection = GhostControl.graph.GetDirection(this.ghost, dest);
                            // And if the ghost get stopped in the destination cell, we'll get a random direction.
                            if(this.ghost.NeededDirection == MovingDirection.None) {
                                this.ghost.NeededDirection = GhostControl.graph.GetRandomDirection(this.ghost);
                            }
                            break;
                        #endregion

                        #region GhostType.Brown
                        case GhostType.Brown:
                            // The brown ghost will always try to pretend ignorance.
                            Point cell = Maze.SpriteCoordsToMaze(this.ghost.X, this.ghost.Y);
                            int sideX2 = Math.Abs(dest.X - cell.X) * Math.Abs(dest.X - cell.X);
                            int sideY2 = Math.Abs(dest.Y - cell.Y) * Math.Abs(dest.Y - cell.Y);
                            int distance = (int)Math.Sqrt(sideX2 + sideY2);
                            // After calculate the distance between the puckman and the ghost,
                            // we'll get the direction to chase puckam or to get back to the corner.
                            if(distance <= 8) {
                                this.ghost.NeededDirection = GhostControl.graph.GetDirection(this.ghost, this.corner);
                            } else {
                                this.ghost.NeededDirection = GhostControl.graph.GetDirection(this.ghost, dest);
                            }
                            // And if the ghost get stopped in the destination cell, we'll get a random direction.
                            if(this.ghost.NeededDirection == MovingDirection.None) {
                                this.ghost.NeededDirection = GhostControl.graph.GetRandomDirection(this.ghost);
                            }
                            break;
                        #endregion
                    }
                    // And then, we'll set this flag to avoid to make the same
                    // algorithim for the same data.
                    if(this.ghost.NeededDirection != MovingDirection.None) {
                        this.isDirectionGetted = true;
                    }
                }
            } else {
                // If we're not on an intersection, we'll set this flag to make
                // possible in a future update to select a new direction.
                this.isDirectionGetted = false;
            }
        }
        #endregion

        #region void frightenedUpdate()
        /// <summary>
        /// Updates the direction when the ghost is in the frightened state.
        /// </summary>
        private void frightenedUpdate() {
            if(this.isInHouse) {
                if(Maze.IsGhostInsideTheHouse(this.ghost)) {
                    // If the ghost is in the same line that the start x coordinate,
                    // we'll set the ghost direction to up.
                    if(this.ghost.X == Maze.GhostStartX) {
                        this.ghost.NeededDirection = MovingDirection.Up;
                    } else {
                        // If not, we'll try to put the ghost in the middle of the house,
                        // to move it to the center start x coordinate line.
                        if(this.ghost.Y <= Maze.GhostHouseStartY) {
                            this.ghost.NeededDirection = MovingDirection.Down;
                        } else if(this.ghost.Y >= Maze.GhostHouseEndY) {
                            this.ghost.NeededDirection = MovingDirection.Up;
                        } else if(this.ghost.Y >= Maze.GhostHouseCenterY) {
                            // When the ghost is in the center of the house, we'll move
                            // it from the right or the left to the center.
                            if(this.ghost.X <= Maze.BlueGhostStartX) {
                                this.ghost.NeededDirection = MovingDirection.Right;
                            } else if(this.ghost.X >= Maze.BrownGhostStartX) {
                                this.ghost.NeededDirection = MovingDirection.Left;
                            }
                        }
                    }
                } else if(Maze.IsGhostInTheStartPoint(this.ghost)) {
                    this.isInHouse = false;
                    this.ghost.NeededDirection = MovingDirection.Left;
                }
            } else {
                // Here we'll check if we're on an intersection.
                if(GhostControl.graph.IsOnIntersection(this.ghost)) {
                    // If we're on an intersection, we'll check that we didn't select
                    // a direction in a previous update.
                    if(!this.isDirectionGetted) {
                        // If we can select a direction, we'll find a new one.
                        this.ghost.NeededDirection = GhostControl.graph.GetEscapeDirection(this.ghost, this.puckman);
                        // And then, we'll set this flag to avoid to make the same
                        // algorithim for the same data.
                        if(this.ghost.NeededDirection != MovingDirection.None) {
                            this.isDirectionGetted = true;
                        }
                    }
                } else {
                    // If we're not on an intersection, we'll set this flag to make
                    // possible in a future update to select a new direction.
                    this.isDirectionGetted = false;
                }
            }
        }
        #endregion

        #region void deadUpdate()
        /// <summary>
        /// Updates the direction when the ghost is in the dead state.
        /// </summary>
        private void deadUpdate() {
            // First, we'll check if the ghost is inside the house or not.
            if(Maze.IsGhostInsideTheHouse(this.ghost)) {
                // If we're inside the house, we'll check this cases:
                if(this.ghost.TypeOfGhost == GhostType.Blue &&
                   this.ghost.Y >= Maze.GhostHouseCenterY) {
                    // If we are the blue ghost and it's in the center of the house,
                    // we'll change the direction to move that ghost to the left.
                    this.ghost.NeededDirection = MovingDirection.Left;

                } else if(this.ghost.TypeOfGhost == GhostType.Brown &&
                          this.ghost.Y >= Maze.GhostHouseCenterY) {
                    // If we are the brown ghost and it's in the center of the house,
                    // we'll change the direction to move that ghost to the right.
                    this.ghost.NeededDirection = MovingDirection.Right;
                }
            } else {
                // If we're not inside the house, we'll check if the ghost is
                // in the house enter or not.
                Point orig = Maze.SpriteCoordsToMaze(this.ghost.X, this.ghost.Y);
                if(orig == GhostControl.houseEnter) {
                    // If we're at the house enter, we'll set the direction
                    // to make enter the ghost inside the house.
                    this.ghost.NeededDirection = MovingDirection.Down;

                } else {
                    // If we're not at the house enter, we'll check if we're on an intersection.
                    if(GhostControl.graph.IsOnIntersection(this.ghost)) {
                        // If we're on an intersection, we'll check that we didn't
                        // select a direction in a previous update.
                        if(!this.isDirectionGetted) {
                            // If we can select a direction, we'll find a new one.
                            this.ghost.NeededDirection = GhostControl.graph.GetDirection(this.ghost,
                                                         GhostControl.houseEnter);
                            // And then, we'll set this flag to avoid to make the same
                            // algorithim for the same data.
                            if(this.ghost.NeededDirection != MovingDirection.None) {
                                this.isDirectionGetted = true;
                            }
                        }
                    } else {
                        // If we're not on an intersection, we'll set this flag to make
                        // possible in a future update to select a new direction.
                        this.isDirectionGetted = false;
                    }
                }
            }
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the direction of the ghost.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            // First, we'll check the state of the ghost controller.
            this.checkState(time);
            // And then, we'll update the direction.
            switch(this.state) {
                case GhostControlState.House: this.houseUpdate(); break;
                case GhostControlState.Scatter: this.scatterUpdate(); break;
                case GhostControlState.Chase: this.chaseUpdate(); break;
                case GhostControlState.Frightened: this.frightenedUpdate(); break;
                case GhostControlState.Dead: this.deadUpdate(); break;
            }
        }
        #endregion
    }
}