﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This static class is a simple timer to add some countdowns to the game.
    /// </summary>
    public static class GameTimer {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region int timeStopped
        /// <summary>
        /// This represents when the timer is stopped.
        /// </summary>
        private const int timeStopped = 0;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region long time
        /// <summary>
        /// The current time of the timer's countdown.
        /// </summary>
        private static long time;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameTimer()
        /// <summary>
        /// Initializes the game timer subsystem.
        /// </summary>
        static GameTimer() {
            time = GameTimer.timeStopped;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Stop()
        /// <summary>
        /// Stops the timer's countdown.
        /// </summary>
        public static void Stop() {
            time = GameTimer.timeStopped;
        }
        #endregion

        #region void Set(long countdown)
        /// <summary>
        /// Sets a new timer's countdown.
        /// </summary>
        /// <param name="countdown">The time of the countdown.</param>
        public static void Set(long countdown) {
            time = countdown;
        }
        #endregion

        #region bool IsStopped()
        /// <summary>
        /// Checks if the timer's countdown is stopped or not.
        /// </summary>
        /// <returns>If the countdown is stopped returns true, otherwise false.</returns>
        public static bool IsStopped() {
            return (time <= GameTimer.timeStopped);
        }
        #endregion

        #region void Update(long t)
        /// <summary>
        /// Updates the current timer's countdown.
        /// </summary>
        /// <param name="t">The passed time after the last call of the update.</param>
        public static void Update(long t) {
            if(time > GameTimer.timeStopped) {
                time -= t;
            }
        }
        #endregion
    }
}