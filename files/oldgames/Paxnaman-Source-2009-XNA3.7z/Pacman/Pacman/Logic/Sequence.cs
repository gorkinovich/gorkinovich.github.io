﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class is used to make a sequence using entities.
    /// </summary>
    public sealed class Sequence {
        //******************************************************************************************
        // Types
        //******************************************************************************************

        #region struct Node
        /// <summary>
        /// This struct is used in the sequence array.
        /// </summary>
        public struct Node {
            #region int Row
            /// <summary>The row.</summary>
            public int Row;
            #endregion

            #region int Column
            /// <summary>The column.</summary>
            public int Column;
            #endregion

            #region MovingDirection Direction
            /// <summary>The direction.</summary>
            public MovingDirection Direction;
            #endregion

            #region bool PixelCoords
            /// <summary>
            /// Tells to the program if the coordinates are in pixel values.
            /// </summary>
            public bool PixelCoords;
            #endregion

            #region Node(int row, int col, MovingDirection dir)
            /// <summary>
            /// Constructs a new Node object.
            /// </summary>
            /// <param name="row">The row.</param>
            /// <param name="col">The column.</param>
            /// <param name="dir">The direction.</param>
            public Node(int row, int col, MovingDirection dir) {
                this.Row = row;
                this.Column = col;
                this.Direction = dir;
                this.PixelCoords = false;
            }
            #endregion

            #region Node(int row, int col, MovingDirection dir, bool pixelCoords)
            /// <summary>
            /// Constructs a new Node object.
            /// </summary>
            /// <param name="row">The row.</param>
            /// <param name="col">The column.</param>
            /// <param name="dir">The direction.</param>
            /// <param name="pixelCoords">Tells if the coordinates are in pixel values.</param>
            public Node(int row, int col, MovingDirection dir, bool pixelCoords) {
                this.Row = row;
                this.Column = col;
                this.Direction = dir;
                this.PixelCoords = pixelCoords;
            }
            #endregion
        }
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Node[] Data
        /// <summary>
        /// The sequence of directions for the entities.
        /// </summary>
        public Node[] Data { get; private set; }
        #endregion

        #region int currentNode
        /// <summary>
        /// The current node in the sequence.
        /// </summary>
        private int currentNode;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Sequence(Node[] data)
        /// <summary>
        /// Constructs a new Sequence object.
        /// </summary>
        /// <param name="data">The sequence of directions.</param>
        public Sequence(Node[] data) {
            this.Data = data;
            this.currentNode = 0;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Reset()
        /// <summary>
        /// Resets the sequence.
        /// </summary>
        public void Reset() {
            this.currentNode = 0;
        }
        #endregion

        #region bool checkCoordinates(MovingEntity entity)
        /// <summary>
        /// Checks if an entity is in the right cell.
        /// </summary>
        /// <param name="entity">The entity to check.</param>
        /// <returns>If the coordinates are the same returns true, otherwise false.</returns>
        private bool checkCoordinates(MovingEntity entity) {
            if(this.Data[this.currentNode].PixelCoords == false) {
                Point cell = Maze.SpriteCoordsToMaze(entity.X, entity.Y);
                return (this.Data[this.currentNode].Row == cell.Y) &&
                       (this.Data[this.currentNode].Column == cell.X);
            } else {
                return (this.Data[this.currentNode].Row == entity.Y) &&
                       (this.Data[this.currentNode].Column == entity.X);
            }
        }
        #endregion

        #region bool IsEnded()
        /// <summary>
        /// Checks the sequence have ended or not.
        /// </summary>
        /// <returns>If the sequence have ended returns true, otherwise false.</returns>
        public bool IsEnded() {
            return (this.currentNode == this.Data.Length);
        }
        #endregion

        #region void nextNode()
        /// <summary>
        /// Sets the current sequence in the next node.
        /// </summary>
        private void nextNode() {
            if(this.currentNode < this.Data.Length) {
                this.currentNode++;
            }
        }
        #endregion

        #region void Check(Ghost entity)
        /// <summary>
        /// Checks and update an entity's direction.
        /// </summary>
        /// <param name="entity">The entity to be updated.</param>
        public void Check(Ghost entity) {
            if(this.IsEnded()) return;
            if(this.checkCoordinates(entity)) {
                entity.NeededDirection = this.Data[this.currentNode].Direction;
                this.nextNode();
            }
        }
        #endregion

        #region void Check(AnimatedPuckman entity)
        /// <summary>
        /// Checks and update an entity's direction.
        /// </summary>
        /// <param name="entity">The entity to be updated.</param>
        public void Check(AnimatedPuckman entity) {
            if(this.IsEnded()) return;
            if(this.checkCoordinates(entity)) {
                entity.NeededDirection = this.Data[this.currentNode].Direction;
                this.nextNode();
            }
        }
        #endregion
    }
}