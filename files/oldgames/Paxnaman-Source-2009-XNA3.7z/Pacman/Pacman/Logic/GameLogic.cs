﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;

namespace Pacman {
    /// <summary>
    /// This class represents the game logic.
    /// </summary>
    public sealed class GameLogic : GenericLogic {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region long beginDelayTime
        /// <summary>
        /// The amount of time when the game begins.
        /// </summary>
        private const long beginDelayTime = 1800;
        #endregion

        #region long killDelayTime
        /// <summary>
        /// The amount of time when the puckman is killed.
        /// </summary>
        private const long killDelayTime = 1000;
        #endregion

        #region long shortEndDelayTime
        /// <summary>
        /// The amount of time when the logic ends.
        /// </summary>
        private const long shortEndDelayTime = 500;
        #endregion

        #region long showFruitPointsDelayTime
        /// <summary>
        /// The amount of time when the points of an eated fruit is shown.
        /// </summary>
        private const long showFruitPointsDelayTime = 1000;
        #endregion

        #region long victoryDelayTime
        /// <summary>
        /// The amount of time when the puckman is victorious.
        /// </summary>
        private const long victoryDelayTime = 1500;
        #endregion

        #region long endVictoryDelayTime
        /// <summary>
        /// The amount of time when the logic ends and puckman is victorious.
        /// </summary>
        private const long endVictoryDelayTime = 1500;
        #endregion


        #region int initialSoundState
        /// <summary>
        /// This is the state id when the logic is paused at the beginning.
        /// </summary>
        private const int initialSoundState = 10;
        #endregion

        #region int initialNoSoundState
        /// <summary>
        /// This is the state id when the logic is paused at the beginning.
        /// </summary>
        private const int initialNoSoundState = 11;
        #endregion

        #region int victoryState
        /// <summary>
        /// This is the state id when puckman is victorious.
        /// </summary>
        private const int victoryState = 12;
        #endregion

        #region int endVictoryState
        /// <summary>
        /// This is the state id when puckman is victorious and ends the game.
        /// </summary>
        private const int endVictoryState = 13;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameData data
        /// <summary>
        /// The data manager of the game.
        /// </summary>
        private GameData data;
        #endregion

        #region GameSound sound
        /// <summary>
        /// The sound manager of the game.
        /// </summary>
        private GameSound sound;
        #endregion

        #region long showFruitPointsTime
        /// <summary>
        /// The time controller when the points of an eated fruit is shown.
        /// </summary>
        private long showFruitPointsTime;
        #endregion

        #region bool showFruitPoints
        /// <summary>
        /// Tells if the points of an eated fruit must be shown or not.
        /// </summary>
        private bool showFruitPoints;
        #endregion

        #region bool Victory
        /// <summary>
        /// Tells to the program if the puckman have been victorious.
        /// </summary>
        public bool Victory { get; private set; }
        #endregion

        #region GhostController controller
        /// <summary>
        /// This is the IA controller for the ghosts.
        /// </summary>
        private GhostController controller;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameLogic()
        /// <summary>
        /// Constructs a new GameLogic object.
        /// </summary>
        public GameLogic() {
            this.data = CoreManager.Instance.Data;
            this.sound = CoreManager.Instance.Sound;

            this.red = new Ghost(GhostType.Red);
            this.pink = new Ghost(GhostType.Pink);
            this.blue = new Ghost(GhostType.Blue);
            this.brown = new Ghost(GhostType.Brown);

            this.controller = new GhostController();
            this.fruit = new Fruit();
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Initialize(FruitType currentFruit, bool firstPlay, bool clearMaze)
        /// <summary>
        /// Initializes the game logic object.
        /// </summary>
        /// <param name="currentFruit">The current fruit used in the maze.</param>
        /// <param name="firstPlay">Tells if this is the first round.</param>
        public void Initialize(FruitType currentFruit, bool firstPlay, bool clearMaze) {
            // First, we'll get the current used maze.
            this.maze = this.data.Maze;

            // Then, we'll set the collision controler of the ghosts.
            this.red.CheckCoordinates = this.maze.CheckGhostCoords;
            this.pink.CheckCoordinates = this.maze.CheckGhostCoords;
            this.blue.CheckCoordinates = this.maze.CheckGhostCoords;
            this.brown.CheckCoordinates = this.maze.CheckGhostCoords;

            // And, we'll initialize the current maze data.
            this.initializeMaze(clearMaze);

            // Second, we'll initialize the ghost data.
            this.initializeGhosts();
            if(this.data.Level > 20) {
                this.hurryMode = true;
            }
            this.controller.Initialize(this.red, this.pink, this.blue, this.brown,
                                       this.data.Puckman, this.maze);

            // Third, we'll initialize the fruit data.
            this.initializeFruit(currentFruit);

            // Fourth, we'll initialize the puckman data.
            this.data.Puckman.Respawn();
            this.initializePuckman(this.data.Puckman);

            // And finally, we'll initialize the logic data.
            this.Victory = false;
            this.ended = false;
            this.showFruitPoints = false;
            this.showFruitPointsTime = 0;
            if(firstPlay) {
                this.state = GameLogic.initialState;
                this.sound.Beginning.Play();
            } else {
                this.state = GameLogic.initialNoSoundState;
            }
            GameTimer.Set(GameLogic.beginDelayTime);
        }
        #endregion

        #region void Release()
        /// <summary>
        /// Releases the game logic object.
        /// </summary>
        public void Release() {
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the content of the game.
        /// </summary>
        public void Draw() {
            switch(this.state) {
                #region GameLogic.initialState
                case GameLogic.initialState:
                    // First, we'll draw the maze.
                    this.drawMaze();
                    // Second, we'll draw the player turn message.
                    if(this.data.PlayerTurn == 1) {
                        this.screen.DrawText(14, 9, "PLAYER ONE", Colors.Cyan);
                    } else {
                        this.screen.DrawText(14, 9, "PLAYER TWO", Colors.Cyan);
                    }
                    // And finally, we'll draw the ready message.
                    this.screen.DrawText(20, 11, "READY!", Colors.Yellow);
                    break;
                #endregion

                #region GameLogic.initialNoSoundState, GameLogic.initialSoundState
                case GameLogic.initialNoSoundState:
                    goto case GameLogic.initialSoundState;

                case GameLogic.initialSoundState:
                    // First, we'll draw the maze.
                    this.drawMaze();
                    // Second, we'll draw the entities.
                    this.brown.Draw();
                    this.blue.Draw();
                    this.pink.Draw();
                    this.red.Draw();
                    this.data.Puckman.Draw();
                    // And finally, we'll draw the ready message.
                    this.screen.DrawText(20, 11, "READY!", Colors.Yellow);
                    break;
                #endregion

                #region GameLogic.normalState, GameLogic.killState
                case GameLogic.normalState:
                    // First, we'll draw the maze and the fruit.
                    this.drawMaze();
                    this.drawFruit();
                    this.drawFruitPoints();

                    // Second, we'll check if the ghost are normal or not, because we have
                    // to draw ghost when they are normal over puckman and when they are
                    // vulnerable or dead under puckman.
                    if(this.ghostsState == GhostState.Normal) {
                        this.drawDeadGhosts();
                        this.data.Puckman.Draw();
                        this.drawAliveGhosts();

                    } else {
                        // If the ghosts are in vulnerable state and puckman eats one, there
                        // will be a pause to show the points of the last killed ghost, that's
                        // the reason why the timer is used in this state. When the timer is
                        // stopped there isn't any pause and everybody is moving.
                        if(GameTimer.IsStopped()) {
                            this.drawVulnerableGhosts();
                            this.data.Puckman.Draw();
                            this.drawNormalGhosts();

                        } else {
                            // But if there is a pause the puckman and one ghost can't be drawn.
                            // So we'll check one by one each ghost to find the eat one, to draw
                            // the point over it.
                            this.drawGhostsWhenPuckmanEats();
                        }
                    }
                    break;

                case GameLogic.killState:
                    goto case GameLogic.normalState;
                #endregion

                #region GameLogic.deathState
                case GameLogic.deathState:
                    this.drawMaze();
                    this.data.Puckman.Draw();
                    break;
                #endregion

                #region GameLogic.endState
                case GameLogic.endState:
                    this.drawMaze();
                    if(this.data.ExtraLives <= 0) {
                        if(this.data.NumberOfPlayers > 1) {
                            if(this.data.PlayerTurn == 1) {
                                this.screen.DrawText(14, 9, "PLAYER ONE", Colors.Cyan);
                            } else {
                                this.screen.DrawText(14, 9, "PLAYER TWO", Colors.Cyan);
                            }
                        }
                        this.screen.DrawText(20, 9, "GAME  OVER", Colors.Red);
                    }
                    break;
                #endregion

                #region GameLogic.victoryState
                case GameLogic.victoryState:
                    this.drawMaze();
                    this.drawFruit();
                    this.drawFruitPoints();

                    if(this.ghostsState == GhostState.Normal) {
                        this.drawDeadGhosts();
                        this.data.Puckman.Draw();
                        this.drawAliveGhosts();
                    } else {
                        this.drawVulnerableGhosts();
                        this.data.Puckman.Draw();
                        this.drawNormalGhosts();
                    }
                    break;
                #endregion

                #region GameLogic.endVictoryState
                case GameLogic.endVictoryState:
                    this.drawMaze();
                    this.data.Puckman.Draw();
                    this.screen.DrawText(20, 10, "VICTORY!", Colors.Yellow);
                    break;
                #endregion
            }
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner logic of the game.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            switch(this.state) {
                #region GameLogic.initialState
                case GameLogic.initialState:
                    // In this state we'll take a pause in the game.
                    if(GameTimer.IsStopped()) {
                        this.state = GameLogic.initialSoundState;
                    }
                    break;
                #endregion

                #region GameLogic.initialSoundState
                case GameLogic.initialSoundState:
                    // In this state we'll take a pause in the game.
                    if(this.sound.Beginning.SoundInstance.State == SoundState.Stopped) {
                        this.state = GameLogic.normalState;
                        this.sound.Siren.PlayLoop();
                    }
                    break;
                #endregion

                #region GameLogic.initialNoSoundState
                case GameLogic.initialNoSoundState:
                    // In this state we'll take a pause in the game.
                    if(GameTimer.IsStopped()) {
                        this.state = GameLogic.normalState;
                        this.sound.Siren.PlayLoop();
                    }
                    break;
                #endregion

                #region GameLogic.normalState
                case GameLogic.normalState:
                    // In this state we'll update the big dots blink controller and we'll
                    // check if any dead ghost is in the house, to bring it back to life.
                    this.bigDotsLogic.Update(time);
                    this.checksDeadGhostInHouse();

                    if(this.maze.NumberOfDots <= 0) {
                        // If all the dots are eated puckman will be victorious.
                        this.Victory = true;
                        this.sound.Siren.Stop();
                        // We'll stop all the entities.
                        this.data.Puckman.StopSpeed();
                        this.red.StopSpeed();
                        this.pink.StopSpeed();
                        this.blue.StopSpeed();
                        this.brown.StopSpeed();
                        // And change the inner state of the logic.
                        this.state = GameLogic.victoryState;
                        GameTimer.Set(GameLogic.victoryDelayTime);

                    } else {
                        // And if the game isn't paused, we'll update the ghost state,
                        // the fruit logic, the collisions and all the entities.
                        if(GameTimer.IsStopped()) {
                            this.updateGhostState(time);
                            this.updateFruit(time);
                            this.updateFruitPoints(time);

                            int aux = this.numberOfGhostsKilled;
                            this.checkCollisions(this.data.Puckman);
                            if(aux != this.numberOfGhostsKilled) {
                                this.sound.GhostEat.Play();
                                switch(this.numberOfGhostsKilled) {
                                    case 1: this.addScore(200); break;
                                    case 2: this.addScore(400); break;
                                    case 3: this.addScore(800); break;
                                    case 4: this.addScore(1600); break;
                                }
                            }

                            this.puckmanUpdate(time);
                            this.controller.Update(time);
                            this.red.Update(time);
                            this.pink.Update(time);
                            this.blue.Update(time);
                            this.brown.Update(time);

                        } else {
                            // If the game is paused, we'll only update the ghosts
                            // that are not alive and are not the last one killed.
                            this.controller.Update(time);
                            this.updateGhostsWhenPuckmanEats(time);
                        }
                    }
                    break;
                #endregion

                #region GameLogic.killState
                case GameLogic.killState:
                    // Here the puckman have been caught and we're waiting some time.
                    if(GameTimer.IsStopped()) {
                        this.state = GameLogic.deathState;
                        this.data.Puckman.Kill();
                        this.sound.Death.Play();
                    } else {
                        this.bigDotsLogic.Update(time);
                        this.red.Update(time);
                        this.pink.Update(time);
                        this.blue.Update(time);
                        this.brown.Update(time);
                    }
                    break;
                #endregion

                #region GameLogic.deathState
                case GameLogic.deathState:
                    // After wait, we'll see the puckman death animation.
                    if(this.data.Puckman.IsDeathSpriteEnded()) {
                        this.state = GameLogic.endState;
                        if(this.data.ExtraLives > 0) {
                            GameTimer.Set(GameLogic.shortEndDelayTime);
                        } else {
                            GameTimer.Set(GameLogic.endDelayTime);
                        }
                    } else {
                        this.bigDotsLogic.Update(time);
                        this.data.Puckman.Update(time);
                    }
                    break;
                #endregion

                #region GameLogic.endState
                case GameLogic.endState:
                    // And finally we'll have a pause and end the game.
                    if(GameTimer.IsStopped()) {
                        this.ended = true;
                    }
                    break;
                #endregion

                #region GameLogic.victoryState
                case GameLogic.victoryState:
                    // Here the puckman have been victorious and we're waiting some time.
                    if(GameTimer.IsStopped()) {
                        this.state = GameLogic.endVictoryState;
                        GameTimer.Set(GameLogic.endVictoryDelayTime);
                    } else {
                        this.bigDotsLogic.Update(time);
                        this.red.Update(time);
                        this.pink.Update(time);
                        this.blue.Update(time);
                        this.brown.Update(time);
                    }
                    break;
                #endregion

                #region GameLogic.endVictoryState
                case GameLogic.endVictoryState:
                    // And finally we'll have a pause and end the game.
                    if(GameTimer.IsStopped()) {
                        this.ended = true;
                    }
                    break;
                #endregion
            }
        }
        #endregion

        #region void addScore(int points)
        /// <summary>
        /// Adds points to the current score.
        /// </summary>
        /// <param name="points">The points to add.</param>
        private void addScore(int points) {
            const int bonusMark = 10000;
            int prev = this.data.Score / bonusMark;
            this.data.Score += points;
            int next = this.data.Score / bonusMark;
            if((next > prev) && (this.data.ExtraLives < 6)) {
                this.sound.ExtraPac.Play();
                this.data.ExtraLives += 1;
            }
            this.data.CheckHighScore();
        }
        #endregion

        #region void killPuckman()
        /// <summary>
        /// Update the state of the logic to kill the puckman.
        /// </summary>
        protected override void killPuckman() {
            this.sound.Siren.Stop();
            this.data.Puckman.StopSpeed();
            this.genericKillPuckman();
            GameTimer.Set(GameLogic.killDelayTime);
        }
        #endregion

        #region void drawFruitPoints()
        /// <summary>
        /// Draws the points of an eated fruit.
        /// </summary>
        private void drawFruitPoints() {
            if(this.showFruitPoints) {
                int col = 13;
                switch(this.fruit.Symbol) {
                    case FontSymbol.N100: col = 13; break;
                    case FontSymbol.N300: col = 13; break;
                    case FontSymbol.N500: col = 13; break;
                    case FontSymbol.N700: col = 13; break;
                    case FontSymbol.N1000: col = 12; break;
                    case FontSymbol.N2000: col = 12; break;
                    case FontSymbol.N3000: col = 12; break;
                    case FontSymbol.N5000: col = 12; break;
                }
                this.screen.DrawSymbol(20, col, this.fruit.Symbol, Colors.Pink);
            }
        }
        #endregion

        #region void updateFruitPoints(long time)
        /// <summary>
        /// Updates the points of an eated fruit.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        private void updateFruitPoints(long time) {
            if(this.showFruitPoints) {
                this.showFruitPointsTime -= time;
                if(this.showFruitPointsTime <= 0) {
                    this.showFruitPoints = false;
                }
            }
        }
        #endregion

        #region void checkFruitCollision(Puckman puckman)
        /// <summary>
        /// Check the collision between the puckman and a fruit in the maze.
        /// </summary>
        /// <param name="puckman">The puckman entity.</param>
        protected override void checkFruitCollision(Puckman puckman) {
            if(this.showFruit) {
                if(this.checkCollision(this.data.Puckman, this.fruit)) {
                    this.showFruit = false;
                    this.showFruitPoints = true;
                    this.sound.FruitEat.Play();
                    this.addScore(this.fruit.Value);
                    this.showFruitPointsTime = GameLogic.showFruitPointsDelayTime;
                    this.fruitTime += GenericLogic.showFruitDelayTime;
                }
            }
        }
        #endregion

        #region void checkNumberOfDots()
        /// <summary>
        /// Checks the number of dots to update the logic of the game.
        /// </summary>
        private void checkNumberOfDots() {
            this.maze.NumberOfDots--;
            switch(this.data.Level) {
                case 1: if(this.maze.NumberOfDots <= 10) this.hurryMode = true; break;
                case 2: if(this.maze.NumberOfDots <= 20) this.hurryMode = true; break;
                case 3: if(this.maze.NumberOfDots <= 30) this.hurryMode = true; break;
                case 4: if(this.maze.NumberOfDots <= 40) this.hurryMode = true; break;
                case 5: if(this.maze.NumberOfDots <= 50) this.hurryMode = true; break;
                case 6: if(this.maze.NumberOfDots <= 60) this.hurryMode = true; break;
                case 7: if(this.maze.NumberOfDots <= 70) this.hurryMode = true; break;
                case 8: if(this.maze.NumberOfDots <= 80) this.hurryMode = true; break;
                case 9: if(this.maze.NumberOfDots <= 90) this.hurryMode = true; break;
                case 10: if(this.maze.NumberOfDots <= 100) this.hurryMode = true; break;
                case 11: if(this.maze.NumberOfDots <= 110) this.hurryMode = true; break;
                case 12: if(this.maze.NumberOfDots <= 120) this.hurryMode = true; break;
                case 13: if(this.maze.NumberOfDots <= 130) this.hurryMode = true; break;
                case 14: if(this.maze.NumberOfDots <= 140) this.hurryMode = true; break;
                case 15: if(this.maze.NumberOfDots <= 150) this.hurryMode = true; break;
                case 16: if(this.maze.NumberOfDots <= 160) this.hurryMode = true; break;
                case 17: if(this.maze.NumberOfDots <= 170) this.hurryMode = true; break;
                case 18: if(this.maze.NumberOfDots <= 180) this.hurryMode = true; break;
                case 19: if(this.maze.NumberOfDots <= 190) this.hurryMode = true; break;
                case 20: if(this.maze.NumberOfDots <= 200) this.hurryMode = true; break;
            }
        }
        #endregion

        #region void puckmanUpdate(long time)
        /// <summary>
        /// Updates the puckman entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        private void puckmanUpdate(long time) {
            // First, we'll get the current cell of the puckman entity.
            Point cell = Maze.SpriteCoordsToMaze(this.data.Puckman.X, this.data.Puckman.Y);
            
            // Second, if the coordinates are inside the maze.
            if(0 <= cell.X && cell.X < GameScreen.NumberOfColums) {
                // We'll get the value of that cell.
                int cellValue = this.maze.Data[cell.Y, cell.X];

                // And then we'll check that value.
                if(cellValue == Maze.Clean) {
                    // If the cell is empty and isn't the last cell cleared, the
                    // puckman will go in fast mode.
                    if(cell != this.lastCellCleared) {
                        this.data.Puckman.SetFast();
                    }

                } else if(cellValue == Maze.Dot) {
                    // If the cell have a dot, we'll clear the cell and set
                    // puckman in slow mode.
                    this.clearCell(this.data.Puckman, cell);
                    this.checkNumberOfDots();
                    this.addScore(10);

                } else if(cellValue == Maze.BigDot) {
                    // If the cell have a big dot, we'll clear the cell, set
                    // puckman in slow mode and set the ghosts in vulnerable mode.
                    this.clearCell(this.data.Puckman, cell);
                    this.setGhostsToVulnerable();
                    this.checkNumberOfDots();
                    this.addScore(50);
                }
            }

            // And finally, we'll update the puckman entity.
            this.data.Puckman.Update(time);
        }
        #endregion
    }
}