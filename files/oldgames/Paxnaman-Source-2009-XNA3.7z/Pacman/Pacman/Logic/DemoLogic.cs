﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;

namespace Pacman {
    /// <summary>
    /// This class represents a demo logic.
    /// </summary>
    public sealed class DemoLogic : GenericLogic {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region long beginDelayTime
        /// <summary>
        /// The amount of time when the demo begins.
        /// </summary>
        private const long beginDelayTime = 1800;
        #endregion

        #region long killDelayTime
        /// <summary>
        /// The amount of time when the puckman is killed.
        /// </summary>
        private const long killDelayTime = 1000;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region SequencedPuckman puckman
        /// <summary>
        /// This is the puckman used in the demo.
        /// </summary>
        private SequencedPuckman puckman;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region DemoLogic()
        /// <summary>
        /// Constructs a new DemoLogic object.
        /// </summary>
        public DemoLogic() {
            this.maze = new Maze();

            #region Puckman sequence definition
            Sequence.Node[] sequence = new Sequence.Node[] {
		        new Sequence.Node(26, 9, MovingDirection.Down),
                new Sequence.Node(29, 9, MovingDirection.Right),
                new Sequence.Node(29, 12, MovingDirection.Down),
                new Sequence.Node(32, 12, MovingDirection.Right),
                new Sequence.Node(32, 26, MovingDirection.Up),
                new Sequence.Node(29, 26, MovingDirection.Left),
                new Sequence.Node(29, 24, MovingDirection.Up),
                new Sequence.Node(26, 24, MovingDirection.Right),
                new Sequence.Node(26, 26, MovingDirection.Up),
                new Sequence.Node(23, 26, MovingDirection.Left), //10
                new Sequence.Node(23, 18, MovingDirection.Up),
                new Sequence.Node(14, 18, MovingDirection.Left),
                new Sequence.Node(14, 9, MovingDirection.Down),
                new Sequence.Node(17, 9, MovingDirection.Left),
                new Sequence.Node(17, 6, MovingDirection.Up),
                new Sequence.Node(4, 6, MovingDirection.Left),
                new Sequence.Node(4, 1, MovingDirection.Down),
                new Sequence.Node(8, 1, MovingDirection.Right),
                new Sequence.Node(8, 12, MovingDirection.Up),
                new Sequence.Node(4, 12, MovingDirection.Left), //20
                new Sequence.Node(4, 6, MovingDirection.Down),
                new Sequence.Node(11, 6, MovingDirection.Left),
                new Sequence.Node(11, 1, MovingDirection.Up),
                new Sequence.Node(8, 1, MovingDirection.Right),
                new Sequence.Node(8, 9, MovingDirection.Down),
                new Sequence.Node(11, 9, MovingDirection.Right),
                new Sequence.Node(11, 12, MovingDirection.Down),
                new Sequence.Node(14, 12, MovingDirection.Left),
                new Sequence.Node(14, 9, MovingDirection.Down),
                new Sequence.Node(17, 9, MovingDirection.Left), //30
                new Sequence.Node(17, 21, MovingDirection.Down),
                new Sequence.Node(29, 21, MovingDirection.Right),
                new Sequence.Node(29, 26, MovingDirection.Down),
                new Sequence.Node(32, 26, MovingDirection.Left),
                new Sequence.Node(32, 1, MovingDirection.Up),
                new Sequence.Node(29, 1, MovingDirection.Right),
                new Sequence.Node(29, 3, MovingDirection.Up),
                new Sequence.Node(26, 3, MovingDirection.Left),
                new Sequence.Node(26, 1, MovingDirection.Up),
                new Sequence.Node(23, 1, MovingDirection.Right), //40
                new Sequence.Node(23, 12, MovingDirection.Down),
                new Sequence.Node(26, 12, MovingDirection.Right),
                new Sequence.Node(26, 15, MovingDirection.Up),
                new Sequence.Node(23, 15, MovingDirection.Right),
                new Sequence.Node(23, 26, MovingDirection.Down),
                new Sequence.Node(26, 26, MovingDirection.Left),
                new Sequence.Node(26, 24, MovingDirection.Down),
                new Sequence.Node(29, 24, MovingDirection.Right),
                new Sequence.Node(29, 26, MovingDirection.Down),
                new Sequence.Node(32, 26, MovingDirection.Left), //50
                new Sequence.Node(32, 1, MovingDirection.Up),
                new Sequence.Node(29, 1, MovingDirection.Right),
                new Sequence.Node(29, 3, MovingDirection.Up),
                new Sequence.Node(26, 3, MovingDirection.Left),
                new Sequence.Node(26, 1, MovingDirection.Up),
                new Sequence.Node(23, 1, MovingDirection.Right)
            };
            #endregion
            this.puckman = new SequencedPuckman(new Sequence(sequence));

            #region Red ghost sequence definition
            sequence = new Sequence.Node[] {
		        new Sequence.Node(14, 9, MovingDirection.Down),
		        new Sequence.Node(17, 9, MovingDirection.Left),
		        new Sequence.Node(17, 6, MovingDirection.Up),
		        new Sequence.Node(8, 6, MovingDirection.Right),
		        new Sequence.Node(8, 21, MovingDirection.Up),
		        new Sequence.Node(4, 21, MovingDirection.Right),
		        new Sequence.Node(4, 23, MovingDirection.Left),
		        new Sequence.Node(4, 21, MovingDirection.Down),
		        new Sequence.Node(11, 21, MovingDirection.Right), //10
		        new Sequence.Node(11, 26, MovingDirection.Up),
		        new Sequence.Node(8, 26, MovingDirection.Left),
		        new Sequence.Node(8, 21, MovingDirection.Down),
		        new Sequence.Node(11, 21, MovingDirection.Right),
		        new Sequence.Node(11, 26, MovingDirection.Up),
		        new Sequence.Node(56, 408, MovingDirection.Down, true),
		        new Sequence.Node(11, 26, MovingDirection.Left),
		        new Sequence.Node(11, 21, MovingDirection.Down),
		        new Sequence.Node(17, 21, MovingDirection.Right),
		        new Sequence.Node(17, 1, MovingDirection.Left), //20
		        new Sequence.Node(17, 18, MovingDirection.Up),
		        new Sequence.Node(14, 18, MovingDirection.Left),
		        new Sequence.Node(14, 9, MovingDirection.Down),
		        new Sequence.Node(20, 9, MovingDirection.Right),
		        new Sequence.Node(20, 18, MovingDirection.Down),
		        new Sequence.Node(23, 18, MovingDirection.Right),
		        new Sequence.Node(23, 21, MovingDirection.Down),
		        new Sequence.Node(29, 21, MovingDirection.Right),
		        new Sequence.Node(29, 24, MovingDirection.Up), //30
		        new Sequence.Node(26, 24, MovingDirection.Right),
		        new Sequence.Node(26, 26, MovingDirection.Up),
		        new Sequence.Node(23, 26, MovingDirection.Left),
		        new Sequence.Node(23, 15, MovingDirection.Down),
		        new Sequence.Node(26, 15, MovingDirection.Left),
		        new Sequence.Node(26, 8, MovingDirection.Right),
		        new Sequence.Node(26, 12, MovingDirection.Up),
		        new Sequence.Node(23, 12, MovingDirection.Left),
		        new Sequence.Node(23, 6, MovingDirection.Up), //40
		        new Sequence.Node(17, 6, MovingDirection.Right),
		        new Sequence.Node(17, 9, MovingDirection.Up),
		        new Sequence.Node(14, 9, MovingDirection.Right),
		        new Sequence.Node(14, 13, MovingDirection.Down),
		        new Sequence.Node(272, 208, MovingDirection.Up, true),
		        new Sequence.Node(14, 13, MovingDirection.Left),
		        new Sequence.Node(14, 9, MovingDirection.Down),
		        new Sequence.Node(20, 9, MovingDirection.Right),
		        new Sequence.Node(20, 18, MovingDirection.Down),
		        new Sequence.Node(23, 18, MovingDirection.Left), //50
		        new Sequence.Node(23, 15, MovingDirection.Down),
		        new Sequence.Node(26, 15, MovingDirection.Left),
		        new Sequence.Node(26, 9, MovingDirection.Down),
		        new Sequence.Node(29, 9, MovingDirection.Right),
		        new Sequence.Node(29, 12, MovingDirection.Down),
		        new Sequence.Node(32, 12, MovingDirection.Left),
		        new Sequence.Node(32, 1, MovingDirection.Up),
		        new Sequence.Node(29, 1, MovingDirection.Right),
		        new Sequence.Node(29, 3, MovingDirection.Up)
            };
            #endregion
            this.red = new SequencedGhost(GhostType.Red, new Sequence(sequence));

            #region Pink ghost sequence definition
            sequence = new Sequence.Node[] {
		        new Sequence.Node(17, 13, MovingDirection.Up),
		        new Sequence.Node(14, 13, MovingDirection.Left),
		        new Sequence.Node(14, 9, MovingDirection.Down),
		        new Sequence.Node(17, 9, MovingDirection.Left),
		        new Sequence.Node(17, 6, MovingDirection.Up),
		        new Sequence.Node(4, 6, MovingDirection.Left),
		        new Sequence.Node(4, 1, MovingDirection.Down),
		        new Sequence.Node(8, 1, MovingDirection.Right),
		        new Sequence.Node(8, 3, MovingDirection.Left),
		        new Sequence.Node(8, 1, MovingDirection.Up), //10
		        new Sequence.Node(4, 1, MovingDirection.Right),
		        new Sequence.Node(4, 6, MovingDirection.Down),
		        new Sequence.Node(8, 6, MovingDirection.Left),
		        new Sequence.Node(8, 1, MovingDirection.Up),
		        new Sequence.Node(4, 1, MovingDirection.Right),
		        new Sequence.Node(4, 12, MovingDirection.Down), //15a
		        new Sequence.Node(7, 12, MovingDirection.Up),
		        new Sequence.Node(4, 12, MovingDirection.Left),
		        new Sequence.Node(4, 6, MovingDirection.Down),
		        new Sequence.Node(11, 6, MovingDirection.Left),
		        new Sequence.Node(11, 1, MovingDirection.Up),
		        new Sequence.Node(8, 1, MovingDirection.Right),
		        new Sequence.Node(8, 9, MovingDirection.Down), //20
		        new Sequence.Node(11, 9, MovingDirection.Right),
		        new Sequence.Node(11, 12, MovingDirection.Down),
		        new Sequence.Node(14, 12, MovingDirection.Right),
		        new Sequence.Node(14, 13, MovingDirection.Down),
		        new Sequence.Node(272, 208, MovingDirection.Up, true),
		        new Sequence.Node(14, 13, MovingDirection.Left),
		        new Sequence.Node(14, 12, MovingDirection.Right),
		        new Sequence.Node(14, 18, MovingDirection.Down),
		        new Sequence.Node(20, 18, MovingDirection.Left),
		        new Sequence.Node(20, 9, MovingDirection.Up), //30
		        new Sequence.Node(14, 9, MovingDirection.Right),
		        new Sequence.Node(14, 18, MovingDirection.Down),
		        new Sequence.Node(23, 18, MovingDirection.Right),
		        new Sequence.Node(23, 21, MovingDirection.Down),
		        new Sequence.Node(29, 21, MovingDirection.Right),
		        new Sequence.Node(29, 24, MovingDirection.Up),
		        new Sequence.Node(26, 24, MovingDirection.Right),
		        new Sequence.Node(26, 26, MovingDirection.Up),
		        new Sequence.Node(23, 26, MovingDirection.Left),
		        new Sequence.Node(23, 15, MovingDirection.Down), //40
		        new Sequence.Node(26, 15, MovingDirection.Left),
		        new Sequence.Node(26, 13, MovingDirection.Right),
		        new Sequence.Node(26, 15, MovingDirection.Up),
		        new Sequence.Node(23, 15, MovingDirection.Right),
		        new Sequence.Node(23, 18, MovingDirection.Up),
		        new Sequence.Node(20, 18, MovingDirection.Left),
		        new Sequence.Node(20, 9, MovingDirection.Up),
		        new Sequence.Node(17, 9, MovingDirection.Left),
		        new Sequence.Node(17, 6, MovingDirection.Down),
		        new Sequence.Node(23, 6, MovingDirection.Right), //50
		        new Sequence.Node(23, 12, MovingDirection.Down),
		        new Sequence.Node(26, 12, MovingDirection.Left),
		        new Sequence.Node(26, 9, MovingDirection.Down),
		        new Sequence.Node(29, 9, MovingDirection.Right),
		        new Sequence.Node(29, 12, MovingDirection.Down),
		        new Sequence.Node(32, 12, MovingDirection.Left),
		        new Sequence.Node(32, 1, MovingDirection.Up),
		        new Sequence.Node(29, 1, MovingDirection.Right),
		        new Sequence.Node(29, 6, MovingDirection.Up)
            };
            #endregion
            this.pink = new SequencedGhost(GhostType.Pink, new Sequence(sequence));

            #region Blue ghost sequence definition
            sequence = new Sequence.Node[] {
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(272, 176, MovingDirection.Up, true),
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(272, 176, MovingDirection.Up, true),
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(272, 176, MovingDirection.Up, true),
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(272, 176, MovingDirection.Up, true),
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(272, 176, MovingDirection.Up, true),
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(272, 176, MovingDirection.Up, true),
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(272, 176, MovingDirection.Up, true),
		        new Sequence.Node(256, 176, MovingDirection.Down, true),
		        new Sequence.Node(264, 176, MovingDirection.Right, true),
		        new Sequence.Node(264, 208, MovingDirection.Up, true),
		        new Sequence.Node(14, 13, MovingDirection.Left),

		        new Sequence.Node(14, 12, MovingDirection.Right),
		        new Sequence.Node(14, 15, MovingDirection.Up),
		        new Sequence.Node(11, 15, MovingDirection.Right),
		        new Sequence.Node(11, 18, MovingDirection.Up),
		        new Sequence.Node(8, 18, MovingDirection.Left),
		        new Sequence.Node(8, 1, MovingDirection.Down),
		        new Sequence.Node(11, 1, MovingDirection.Right),
		        new Sequence.Node(11, 5, MovingDirection.Left),
		        new Sequence.Node(11, 1, MovingDirection.Up),
		        new Sequence.Node(8, 1, MovingDirection.Right), //10
		        new Sequence.Node(8, 6, MovingDirection.Up),
		        new Sequence.Node(4, 6, MovingDirection.Right),
		        new Sequence.Node(4, 12, MovingDirection.Down),
		        new Sequence.Node(8, 12, MovingDirection.Right),
		        new Sequence.Node(8, 18, MovingDirection.Down),
		        new Sequence.Node(11, 18, MovingDirection.Left),
		        new Sequence.Node(11, 15, MovingDirection.Down),
		        new Sequence.Node(14, 15, MovingDirection.Left),
		        new Sequence.Node(14, 13, MovingDirection.Down),
		        new Sequence.Node(272, 208, MovingDirection.Left, true), //20
		        new Sequence.Node(272, 176, MovingDirection.Right, true),
		        new Sequence.Node(272, 208, MovingDirection.Up, true),
		        new Sequence.Node(14, 13, MovingDirection.Left),
		        new Sequence.Node(14, 12, MovingDirection.Right),
		        new Sequence.Node(14, 18, MovingDirection.Down),
		        new Sequence.Node(20, 18, MovingDirection.Left),
		        new Sequence.Node(20, 9, MovingDirection.Up),
		        new Sequence.Node(17, 9, MovingDirection.Left),
		        new Sequence.Node(17, 6, MovingDirection.Down),
		        new Sequence.Node(23, 6, MovingDirection.Right), //30
		        new Sequence.Node(23, 12, MovingDirection.Down),
		        new Sequence.Node(26, 12, MovingDirection.Right),
		        new Sequence.Node(26, 21, MovingDirection.Down),
		        new Sequence.Node(29, 21, MovingDirection.Right),
		        new Sequence.Node(29, 26, MovingDirection.Down),
		        new Sequence.Node(32, 26, MovingDirection.Left),
		        new Sequence.Node(32, 2, MovingDirection.Right),
		        new Sequence.Node(32, 12, MovingDirection.Up),
		        new Sequence.Node(29, 12, MovingDirection.Left),
		        new Sequence.Node(29, 9, MovingDirection.Up), //40
		        new Sequence.Node(26, 9, MovingDirection.Right),
		        new Sequence.Node(26, 12, MovingDirection.Up),
		        new Sequence.Node(23, 12, MovingDirection.Left),
		        new Sequence.Node(23, 9, MovingDirection.Up),
		        new Sequence.Node(20, 9, MovingDirection.Right),
		        new Sequence.Node(20, 18, MovingDirection.Down),
		        new Sequence.Node(23, 18, MovingDirection.Left),
		        new Sequence.Node(23, 15, MovingDirection.Down),
		        new Sequence.Node(26, 15, MovingDirection.Left),
		        new Sequence.Node(26, 6, MovingDirection.Up), //50
		        new Sequence.Node(23, 6, MovingDirection.Left),
		        new Sequence.Node(23, 1, MovingDirection.Down),
		        new Sequence.Node(26, 1, MovingDirection.Right),
		        new Sequence.Node(26, 3, MovingDirection.Down)
            };
            #endregion
            this.blue = new SequencedGhost(GhostType.Blue, new Sequence(sequence));

            #region Brown ghost sequence definition
            sequence = new Sequence.Node[] {
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
		        new Sequence.Node(256, 240, MovingDirection.Down, true),
		        new Sequence.Node(272, 240, MovingDirection.Up, true),
                new Sequence.Node(264, 240, MovingDirection.Left, true),
                new Sequence.Node(264, 208, MovingDirection.Up, true),
                new Sequence.Node(14, 13, MovingDirection.Left),

		        new Sequence.Node(14, 12, MovingDirection.Right),
		        new Sequence.Node(14, 18, MovingDirection.Down),
		        new Sequence.Node(17, 18, MovingDirection.Right),
		        new Sequence.Node(17, 22, MovingDirection.Left),
		        new Sequence.Node(17, 18, MovingDirection.Up),
		        new Sequence.Node(14, 18, MovingDirection.Left),
		        new Sequence.Node(14, 9, MovingDirection.Down),
		        new Sequence.Node(23, 9, MovingDirection.Left),
		        new Sequence.Node(23, 1, MovingDirection.Down),
		        new Sequence.Node(26, 1, MovingDirection.Right), //10
		        new Sequence.Node(26, 3, MovingDirection.Down),
		        new Sequence.Node(29, 3, MovingDirection.Right),
		        new Sequence.Node(29, 6, MovingDirection.Up),
		        new Sequence.Node(26, 6, MovingDirection.Right),
		        new Sequence.Node(26, 18, MovingDirection.Down),
		        new Sequence.Node(29, 18, MovingDirection.Left),
		        new Sequence.Node(29, 15, MovingDirection.Down),
		        new Sequence.Node(32, 15, MovingDirection.Left),
		        new Sequence.Node(32, 1, MovingDirection.Up),
		        new Sequence.Node(29, 1, MovingDirection.Right), //20
		        new Sequence.Node(29, 6, MovingDirection.Up),
		        new Sequence.Node(28, 6, MovingDirection.Down),
		        new Sequence.Node(29, 6, MovingDirection.Left),
		        new Sequence.Node(29, 1, MovingDirection.Down),
		        new Sequence.Node(32, 1, MovingDirection.Right),
		        new Sequence.Node(32, 12, MovingDirection.Up),
		        new Sequence.Node(29, 12, MovingDirection.Left),
		        new Sequence.Node(29, 9, MovingDirection.Up),
		        new Sequence.Node(26, 9, MovingDirection.Right),
		        new Sequence.Node(26, 18, MovingDirection.Down), //30
		        new Sequence.Node(29, 18, MovingDirection.Left),
		        new Sequence.Node(29, 15, MovingDirection.Down),
		        new Sequence.Node(32, 15, MovingDirection.Left),
		        new Sequence.Node(32, 1, MovingDirection.Up),
		        new Sequence.Node(29, 1, MovingDirection.Right),
		        new Sequence.Node(29, 3, MovingDirection.Up),
		        new Sequence.Node(26, 3, MovingDirection.Left),
		        new Sequence.Node(26, 1, MovingDirection.Up)
            };
            #endregion
            this.brown = new SequencedGhost(GhostType.Brown, new Sequence(sequence));

            this.fruit = new Fruit(FruitType.Cherry);

            this.puckman.CheckCoordinates = this.maze.CheckSpriteCoords;
            this.red.CheckCoordinates = this.maze.CheckGhostCoords;
            this.pink.CheckCoordinates = this.maze.CheckGhostCoords;
            this.blue.CheckCoordinates = this.maze.CheckGhostCoords;
            this.brown.CheckCoordinates = this.maze.CheckGhostCoords;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************
        
        #region void Initialize()
        /// <summary>
        /// Initializes the demo logic object.
        /// </summary>
        public void Initialize() {
            // First, we'll initialize the maze data.
            this.initializeMaze(true);

            // Second, we'll initialize the ghost data.
            this.initializeGhosts();

            // Third, we'll initialize the fruit data.
            this.initializeFruit(FruitType.Cherry);

            // Fourth, we'll initialize the puckman data.
            this.initializePuckman(this.puckman);
            this.puckman.NeededDirection = MovingDirection.Left;

            // Fifth, we'll initialize the sequences data.
            this.puckman.Sequence.Reset();
            ((SequencedGhost)this.red).Sequence.Reset();
            ((SequencedGhost)this.pink).Sequence.Reset();
            ((SequencedGhost)this.blue).Sequence.Reset();
            ((SequencedGhost)this.brown).Sequence.Reset();

            // And finally, we'll initialize the logic data.
            this.ended = false;
            this.state = DemoLogic.initialState;
            GameTimer.Set(DemoLogic.beginDelayTime);
        }
        #endregion

        #region void Release()
        /// <summary>
        /// Releases the demo logic object.
        /// </summary>
        public void Release() {
        }
        #endregion

        #region void drawDemoMaze()
        /// <summary>
        /// Draws the maze of the demo.
        /// </summary>
        private void drawDemoMaze() {
            // Here, we'll draw the maze and the big dots blink controller will hide
            // or not the registered dots. The we'll draw a text for the demo.
            this.drawMaze();
            this.screen.DrawText(20, 9, "GAME  OVER", Colors.Red);
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the content of the demo.
        /// </summary>
        public void Draw() {
            switch(this.state) {
                #region DemoLogic.initialState, DemoLogic.normalState, DemoLogic.killState
                case DemoLogic.initialState:
                    goto case DemoLogic.normalState;

                case DemoLogic.normalState:
                    // First, we'll draw the maze and the fruit.
                    this.drawDemoMaze();
                    this.drawFruit();

                    // Second, we'll check if the ghost are normal or not, because we have
                    // to draw ghost when they are normal over puckman and when they are
                    // vulnerable or dead under puckman.
                    if(this.ghostsState == GhostState.Normal) {
                        this.drawDeadGhosts();
                        this.puckman.Draw();
                        this.drawAliveGhosts();

                    } else {
                        // If the ghosts are in vulnerable state and puckman eats one, there
                        // will be a pause to show the points of the last killed ghost, that's
                        // the reason why the timer is used in this state. When the timer is
                        // stopped there isn't any pause and everybody is moving.
                        if(GameTimer.IsStopped()) {
                            this.drawVulnerableGhosts();
                            this.puckman.Draw();
                            this.drawNormalGhosts();

                        } else {
                            // But if there is a pause the puckman and one ghost can't be drawn.
                            // So we'll check one by one each ghost to find the eat one, to draw
                            // the point over it.
                            this.drawGhostsWhenPuckmanEats();
                        }
                    }
                    break;

                case DemoLogic.killState:
                    goto case DemoLogic.normalState;
                #endregion

                #region DemoLogic.deathState
                case DemoLogic.deathState:
                    this.drawDemoMaze();
                    this.puckman.Draw();
                    break;
                #endregion

                #region DemoLogic.endState
                case DemoLogic.endState:
                    this.drawDemoMaze();
                    break;
                #endregion
            }
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner logic of the demo.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            switch(this.state) {
                #region DemoLogic.initialState
                case DemoLogic.initialState:
                    // In this state we'll take a pause in the game.
                    if(GameTimer.IsStopped()) {
                        this.state = DemoLogic.normalState;
                    }
                    break;
                #endregion

                #region DemoLogic.normalState
                case DemoLogic.normalState:
                    // In this state we'll update the big dots blink controller and we'll
                    // check if any dead ghost is in the house, to bring it back to life.
                    this.bigDotsLogic.Update(time);
                    this.checksDeadGhostInHouse();

                    // And if the game isn't paused, we'll update the ghost state, the
                    // fruit logic, the collisions and all the entities.
                    if(GameTimer.IsStopped()) {
                        this.updateGhostState(time);
                        this.updateFruit(time);
                        this.checkCollisions(this.puckman);

                        this.puckmanUpdate(time);
                        this.red.Update(time);
                        this.pink.Update(time);
                        this.blue.Update(time);
                        this.brown.Update(time);

                    } else {
                        // If the game is paused, we'll only update the ghosts that are
                        // not alive and are not the last one killed.
                        this.updateGhostsWhenPuckmanEats(time);
                    }
                    break;
                #endregion

                #region DemoLogic.killState
                case DemoLogic.killState:
                    // Here the puckman have been caught and we're waiting some time.
                    if(GameTimer.IsStopped()) {
                        this.state = DemoLogic.deathState;
                        this.puckman.Kill();
                    } else {
                        this.bigDotsLogic.Update(time);
                        this.red.Update(time);
                        this.pink.Update(time);
                        this.blue.Update(time);
                        this.brown.Update(time);
                    }
                    break;
                #endregion

                #region DemoLogic.deathState
                case DemoLogic.deathState:
                    // After wait, we'll see the puckman death animation.
                    if(this.puckman.IsDeathSpriteEnded()) {
                        this.state = DemoLogic.endState;
                        GameTimer.Set(DemoLogic.endDelayTime);
                    } else {
                        this.bigDotsLogic.Update(time);
                        this.puckman.Update(time);
                    }
                    break;
                #endregion

                #region DemoLogic.endState
                case DemoLogic.endState:
                    // And finally we'll have a pause and end the demo.
                    if(GameTimer.IsStopped()) {
                        this.ended = true;
                        this.puckman.Respawn();
                    }
                    break;
                #endregion
            }
        }
        #endregion

        #region void killPuckman()
        /// <summary>
        /// Update the state of the logic to kill the puckman.
        /// </summary>
        protected override void killPuckman() {
            this.puckman.StopSpeed();
            this.genericKillPuckman();
            GameTimer.Set(DemoLogic.killDelayTime);
        }
        #endregion

        #region void puckmanUpdate(long time)
        /// <summary>
        /// Updates the puckman entity.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        private void puckmanUpdate(long time) {
            // First, we'll get the current cell of the puckman entity.
            Point cell = Maze.SpriteCoordsToMaze(this.puckman.X, this.puckman.Y);

            // Second, if the coordinates are inside the maze.
            if(0 <= cell.X && cell.X < GameScreen.NumberOfColums) {
                // We'll get the value of that cell.
                int cellValue = this.maze.Data[cell.Y, cell.X];

                // And then we'll check that value.
                if(cellValue == Maze.Clean) {
                    // If the cell is empty and isn't the last cell cleared, the
                    // puckman will go in fast mode.
                    if(cell != this.lastCellCleared) {
                        this.puckman.SetFast();
                    }

                } else if(cellValue == Maze.Dot) {
                    // If the cell have a dot, we'll clear the cell and set
                    // puckman in slow mode.
                    this.clearCell(this.puckman, cell);

                } else if(cellValue == Maze.BigDot) {
                    // If the cell have a big dot, we'll clear the cell, set
                    // puckman in slow mode and set the ghosts in vulnerable mode.
                    this.clearCell(this.puckman, cell);
                    this.setGhostsToVulnerable();
                }
            }

            // And finally, we'll update the puckman entity.
            this.puckman.Update(time);
        }
        #endregion

        #region void checkFruitCollision(Puckman puckman)
        /// <summary>
        /// Check the collision between the puckman and a fruit in the maze.
        /// </summary>
        /// <param name="puckman">The puckman entity.</param>
        protected override void checkFruitCollision(Puckman puckman) {
        }
        #endregion
    }
}