﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class represents the controller behind the big dots blinking.
    /// </summary>
    public sealed class BigDotsLogic {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region long maxTimeInterval
        /// <summary>
        /// The maximum time interval to blink.
        /// </summary>
        private const long maxTimeInterval = 200;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region LinkedList<Point> coords
        /// <summary>
        /// The coordinates of the big dots on the screen.
        /// </summary>
        private LinkedList<Point> coords;
        #endregion

        #region long currentTime
        /// <summary>
        /// The current time passed.
        /// </summary>
        private long currentTime;
        #endregion

        #region bool hideDots
        /// <summary>
        /// Tells the game if the big dots must be hidden or not.
        /// </summary>
        private bool hideDots;
        #endregion

        #region GameScreen screen
        /// <summary>
        /// The screen manager of the game.
        /// </summary>
        private GameScreen screen;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region BigDotsLogic()
        /// <summary>
        /// Constructs a new BigDotsLogic object.
        /// </summary>
        public BigDotsLogic() {
            this.coords = new LinkedList<Point>();
            this.currentTime = 0;
            this.hideDots = false;
            this.screen = CoreManager.Instance.Screen;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Reset()
        /// <summary>
        /// Resets the data inside the controller.
        /// </summary>
        public void Reset() {
            this.coords.Clear();
            this.currentTime = 0;
            this.hideDots = false;
        }
        #endregion

        #region void ResetTime()
        /// <summary>
        /// Resets the time inside the controller.
        /// </summary>
        public void ResetTime() {
            this.currentTime = 0;
            this.hideDots = false;
        }
        #endregion

        #region void Register(int row, int col)
        /// <summary>
        /// Register a big dot inside the controller.
        /// </summary>
        /// <param name="row">The row where the dot is.</param>
        /// <param name="col">The column where the dot is.</param>
        public void Register(int row, int col) {
            this.coords.AddLast(new Point(col, row));
        }
        #endregion
        
        #region void Draw()
        /// <summary>
        /// Allow the big dots to appear or not in the screen.
        /// </summary>
        public void Draw() {
            if(this.hideDots) {
                foreach(Point p in this.coords) {
                    this.screen.ClearCell(p.Y, p.X);
                }
            }
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner state of the controller.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            this.currentTime += time;
            while(this.currentTime >= BigDotsLogic.maxTimeInterval) {
                this.hideDots = !this.hideDots;
                this.currentTime -= BigDotsLogic.maxTimeInterval;
            }
        }
        #endregion
    }
}