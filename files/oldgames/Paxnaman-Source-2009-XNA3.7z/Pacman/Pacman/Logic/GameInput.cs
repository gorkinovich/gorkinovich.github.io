﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Pacman {
    /// <summary>
    /// This static class is the input controller.
    /// </summary>
    public static class GameInput {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region bool Escape
        /// <summary>
        /// Tells if the escape key was pressed or not.
        /// </summary>
        private static bool escape;

        /// <summary>
        /// Tells if the escape key is pressed or not.
        /// </summary>
        public static bool Escape {
            get {
                if(!escape) { // No escape pressed before.
                    escape = Keyboard.GetState().IsKeyDown(Keys.Escape);
                    return escape;
                } else { // Escape pressed before.
                    escape = Keyboard.GetState().IsKeyDown(Keys.Escape);
                    return false;
                }
            }
        }
        #endregion

        #region bool Coin
        /// <summary>
        /// Tells if the coin key was pressed or not.
        /// </summary>
        private static bool coin;

        /// <summary>
        /// Tells if the coin key is pressed or not.
        /// </summary>
        public static bool Coin {
            get {
                if(!coin) { // No coin pressed before.
                    coin = Keyboard.GetState().IsKeyDown(Keys.C);
                    return coin;
                } else { // Coin pressed before.
                    coin = Keyboard.GetState().IsKeyDown(Keys.C);
                    return false;
                }
            }
        }
        #endregion

        #region bool Up
        /// <summary>
        /// Tells if the up key is pressed or not.
        /// </summary>
        public static bool Up {
            get {
                return Keyboard.GetState().IsKeyDown(Keys.Up);
            }
        }
        #endregion

        #region bool Down
        /// <summary>
        /// Tells if the down key is pressed or not.
        /// </summary>
        public static bool Down {
            get {
                return Keyboard.GetState().IsKeyDown(Keys.Down);
            }
        }
        #endregion

        #region bool Right
        /// <summary>
        /// Tells if the right key is pressed or not.
        /// </summary>
        public static bool Right {
            get {
                return Keyboard.GetState().IsKeyDown(Keys.Right);
            }
        }
        #endregion

        #region bool Left
        /// <summary>
        /// Tells if the left key is pressed or not.
        /// </summary>
        public static bool Left {
            get {
                return Keyboard.GetState().IsKeyDown(Keys.Left);
            }
        }
        #endregion

        #region bool OnePlayer
        /// <summary>
        /// Tells if the one player key is pressed or not.
        /// </summary>
        public static bool OnePlayer {
            get {
                return Keyboard.GetState().IsKeyDown(Keys.D1);
            }
        }
        #endregion

        #region bool TwoPlayers
        /// <summary>
        /// Tells if the two players key is pressed or not.
        /// </summary>
        public static bool TwoPlayers {
            get {
                return Keyboard.GetState().IsKeyDown(Keys.D2);
            }
        }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameInput()
        /// <summary>
        /// Initializes the input controller.
        /// </summary>
        static GameInput() {
            escape = false;
            coin = false;
        }
        #endregion
    }
}