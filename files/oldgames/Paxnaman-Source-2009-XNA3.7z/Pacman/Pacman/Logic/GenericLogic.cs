﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class represents a generic game logic.
    /// </summary>
    public abstract class GenericLogic {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region long killPauseInterval
        /// <summary>
        /// The amount of time that the kill pause interval must have.
        /// </summary>
        protected const long killPauseInterval = 1000;
        #endregion

        #region long vulnerableInterval
        /// <summary>
        /// The vulnerable amount of time that the interval must have.
        /// </summary>
        protected const long vulnerableInterval = 3600;
        #endregion

        #region long vulnerableEndingInterval
        /// <summary>
        /// The vulnerable ending amount of time that the interval must have.
        /// </summary>
        protected const long vulnerableEndingInterval = 1800;
        #endregion

        #region long endDelayTime
        /// <summary>
        /// The amount of time when the logic ends.
        /// </summary>
        protected const long endDelayTime = 2000;
        #endregion

        #region long showFruitDelayTime
        /// <summary>
        /// The amount of time to show the fruit.
        /// </summary>
        protected const long showFruitDelayTime = 18000;
        #endregion

        #region long fruitDelayTime
        /// <summary>
        /// The amount of time where the fruit is shown.
        /// </summary>
        protected const long fruitDelayTime = 10000;
        #endregion


        #region int initialState
        /// <summary>
        /// This is the state id when the logic is paused at the beginning.
        /// </summary>
        protected const int initialState = 0;
        #endregion

        #region int normalState
        /// <summary>
        /// This is the state id when the logic starts to work.
        /// </summary>
        protected const int normalState = 1;
        #endregion

        #region int killState
        /// <summary>
        /// This is the state id when the puckman is going to die.
        /// </summary>
        protected const int killState = 2;
        #endregion

        #region int deathState
        /// <summary>
        /// This is the state id when the puckman dies.
        /// </summary>
        protected const int deathState = 3;
        #endregion

        #region int endState
        /// <summary>
        /// This is the state id when the game ends.
        /// </summary>
        protected const int endState = 4;
        #endregion


        #region int noneLastKilled
        /// <summary>
        /// This is the identification when the last ghost killed is the no one.
        /// </summary>
        protected const int noneLastKilled = 0;
        #endregion

        #region int redLastKilled
        /// <summary>
        /// This is the identification when the last ghost killed is the red one.
        /// </summary>
        protected const int redLastKilled = 1;
        #endregion

        #region int pinkLastKilled
        /// <summary>
        /// This is the identification when the last ghost killed is the pink one.
        /// </summary>
        protected const int pinkLastKilled = 2;
        #endregion

        #region int blueLastKilled
        /// <summary>
        /// This is the identification when the last ghost killed is the blue one.
        /// </summary>
        protected const int blueLastKilled = 3;
        #endregion

        #region int brownLastKilled
        /// <summary>
        /// This is the identification when the last ghost killed is the brown one.
        /// </summary>
        protected const int brownLastKilled = 4;
        #endregion


        #region long deadSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is dead.
        /// </summary>
        protected const long deadSpeedInterval = 12;
        #endregion

        #region long hurrySpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is in hurry mode.
        /// </summary>
        protected const long hurrySpeedInterval = 14;
        #endregion

        #region long normalSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is normal.
        /// </summary>
        protected const long normalSpeedInterval = 15;
        #endregion

        #region long wormholeSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is in the wormhole.
        /// </summary>
        protected const long wormholeSpeedInterval = 18;
        #endregion

        #region long vulnerableSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is vulnerable.
        /// </summary>
        protected const long vulnerableSpeedInterval = 26;
        #endregion

        #region long houseSpeedInterval
        /// <summary>
        /// The speed interval tick when the ghost is in the house.
        /// </summary>
        protected const long houseSpeedInterval = 30;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameScreen screen
        /// <summary>
        /// The screen manager of the game.
        /// </summary>
        protected GameScreen screen;
        #endregion

        #region bool Ended
        /// <summary>
        /// Tells to the program if the logic have ended.
        /// </summary>
        protected bool ended;

        /// <summary>
        /// Tells to the program if the logic have ended.
        /// </summary>
        public bool Ended { get { return ended; } }
        #endregion

        #region int state
        /// <summary>
        /// The inner state of the logic.
        /// </summary>
        protected int state;
        #endregion


        #region GhostState ghostsState
        /// <summary>
        /// This is the state of all alive ghosts.
        /// </summary>
        protected GhostState ghostsState;
        #endregion

        #region long ghostTime
        /// <summary>
        /// The current time passed in the vulnerable ghost state.
        /// </summary>
        protected long ghostTime;
        #endregion

        #region Ghost red
        /// <summary>
        /// This is the red ghost entity.
        /// </summary>
        protected Ghost red;
        #endregion

        #region Ghost pink
        /// <summary>
        /// This is the pink ghost entity.
        /// </summary>
        protected Ghost pink;
        #endregion

        #region Ghost blue
        /// <summary>
        /// This is the blue ghost entity.
        /// </summary>
        protected Ghost blue;
        #endregion

        #region Ghost brown
        /// <summary>
        /// This is the brown ghost entity.
        /// </summary>
        protected Ghost brown;
        #endregion

        #region bool hurryMode
        /// <summary>
        /// Tells to the program if the ghosts are in hurry mode.
        /// </summary>
        protected bool hurryMode;
        #endregion

        #region int lastGhostKilled
        /// <summary>
        /// The last ghost killed by the puckman.
        /// </summary>
        protected int lastGhostKilled;
        #endregion

        #region int numberOfGhostsKilled
        /// <summary>
        /// The number of ghosts killed by the puckman.
        /// </summary>
        protected int numberOfGhostsKilled;
        #endregion


        #region Fruit fruit
        /// <summary>
        /// This is the fruit shown in the maze.
        /// </summary>
        protected Fruit fruit;
        #endregion

        #region long fruitTime
        /// <summary>
        /// This is the fruit time counter.
        /// </summary>
        protected long fruitTime;
        #endregion

        #region bool showFruit
        /// <summary>
        /// Tells to the program if the fruit must be shown or not.
        /// </summary>
        protected bool showFruit;
        #endregion


        #region Maze maze
        /// <summary>
        /// This is the maze reference.
        /// </summary>
        protected Maze maze;
        #endregion

        #region BigDotsLogic bigDotsLogic
        /// <summary>
        /// This is the controller of the big dots blinking.
        /// </summary>
        protected BigDotsLogic bigDotsLogic;
        #endregion

        #region Point lastCellCleared
        /// <summary>
        /// The last cell cleared by the puckman.
        /// </summary>
        protected Point lastCellCleared;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GenericLogic()
        /// <summary>
        /// Constructs a new GenericLogic object.
        /// </summary>
        public GenericLogic() {
            this.screen = CoreManager.Instance.Screen;
            this.ended = false;

            this.bigDotsLogic = new BigDotsLogic();
            this.bigDotsLogic.Register(6, 1);
            this.bigDotsLogic.Register(6, 26);
            this.bigDotsLogic.Register(26, 1);
            this.bigDotsLogic.Register(26, 26);
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void initializeMaze()
        /// <summary>
        /// Initializes the maze.
        /// </summary>
        /// <param name="clearMaze">Clears the maze.</param>
        protected void initializeMaze(bool clearMaze) {
            this.lastCellCleared = new Point(0, 0);
            this.bigDotsLogic.ResetTime();
            if(clearMaze) {
                this.maze.Initialize();
            }
            this.maze.DoorOpen = true;
        }
        #endregion

        #region void initializePuckman(Puckman puckman)
        /// <summary>
        /// Initializes the puckman.
        /// </summary>
        /// <param name="puckman">The puckman entity.</param>
        protected void initializePuckman(Puckman puckman) {
            puckman.SetCoordinates(Maze.PuckmanStartX, Maze.PuckmanStartY);
            puckman.SetDirection(MovingDirection.Left);
            puckman.ResetSpeed();
            puckman.SetFast();
            puckman.ResetTime();
        }
        #endregion

        #region void ghostSpeedController(Ghost ghost)
        /// <summary>
        /// Controls that the speed interval tick of the ghost is right.
        /// </summary>
        /// <param name="ghost">The ghost to be checked.</param>
        protected void ghostSpeedController(Ghost ghost) {
            // First, we'll check if the ghost is alive.
            if(ghost.Alive) {
                // Second, we'll check if the ghost is in normal mode.
                if(ghost.State == GhostState.Normal) {
                    Point cell = Maze.SpriteCoordsToMaze(ghost.X, ghost.Y);
                    const int wormholeRow = 17;
                    const int wormholeLeftCol = 4;
                    const int wormholeRightCol = 23;

                    // Third, we'll check if the ghost is inside the wormhole or the house.
                    if((cell.Y == wormholeRow) &&
                       (cell.X <= wormholeLeftCol || cell.X >= wormholeRightCol)) {
                        ghost.SetSpeedInterval(GenericLogic.wormholeSpeedInterval);

                    } else if(Maze.GhostHouseStartX <= ghost.X && ghost.X <= Maze.GhostHouseEndX &&
                              Maze.GhostHouseStartY <= ghost.Y && ghost.Y <= Maze.GhostHouseEndY) {
                        ghost.SetSpeedInterval(GenericLogic.houseSpeedInterval);

                    } else {
                        // And finally, we'll check if the ghosts are in hurry mode.
                        if(this.hurryMode) {
                            ghost.SetSpeedInterval(GenericLogic.hurrySpeedInterval);
                        } else {
                            ghost.SetSpeedInterval(GenericLogic.normalSpeedInterval);
                        }
                    }
                } else {
                    ghost.SetSpeedInterval(GenericLogic.vulnerableSpeedInterval);
                }
            } else {
                if(Maze.GhostHouseStartX <= ghost.X && ghost.X <= Maze.GhostHouseEndX &&
                   Maze.GhostHouseStartY <= ghost.Y && ghost.Y <= Maze.GhostHouseEndY) {
                    ghost.SetSpeedInterval(GenericLogic.houseSpeedInterval);

                } else {
                    ghost.SetSpeedInterval(GenericLogic.deadSpeedInterval);
                }
            }
        }
        #endregion

        #region void initializeGhost(Ghost ghost, int x, int y, MovingDirection dir)
        /// <summary>
        /// Initializes one ghost.
        /// </summary>
        /// <param name="ghost">The ghost to initialize.</param>
        /// <param name="x">The x coordinate of the ghost.</param>
        /// <param name="y">The y coordinate of the ghost.</param>
        /// <param name="dir">The direction of the ghost.</param>
        private void initializeGhost(Ghost ghost, int x, int y, MovingDirection dir) {
            ghost.SetCoordinates(x, y);
            ghost.SetDirection(dir);
            ghost.NeededDirection = dir;
            ghost.BackToLife();
            ghost.ResetTime();
            ghost.ResetSpeed();
            ghost.SpeedController = this.ghostSpeedController;
        }
        #endregion

        #region void initializeGhosts()
        /// <summary>
        /// Initializes all the ghosts.
        /// </summary>
        protected void initializeGhosts() {
            this.initializeGhost(this.red, Maze.RedGhostStartX, Maze.RedGhostStartY, MovingDirection.Left);
            this.initializeGhost(this.pink, Maze.PinkGhostStartX, Maze.PinkGhostStartY, MovingDirection.Down);
            this.initializeGhost(this.blue, Maze.BlueGhostStartX, Maze.BlueGhostStartY, MovingDirection.Up);
            this.initializeGhost(this.brown, Maze.BrownGhostStartX, Maze.BrownGhostStartY, MovingDirection.Up);

            this.setGhostsToNormal();
            this.lastGhostKilled = GenericLogic.noneLastKilled;
            this.numberOfGhostsKilled = 0;
            this.hurryMode = false;
        }
        #endregion

        #region void updateGhostsState()
        /// <summary>
        /// Updates the state of all the ghosts to the current one.
        /// </summary>
        private void updateGhostsState() {
            this.ghostTime = 0;
            this.red.ChangeState(this.ghostsState);
            this.pink.ChangeState(this.ghostsState);
            this.blue.ChangeState(this.ghostsState);
            this.brown.ChangeState(this.ghostsState);
        }
        #endregion

        #region void setGhostsToNormal()
        /// <summary>
        /// Sets all the ghosts to normal state.
        /// </summary>
        protected void setGhostsToNormal() {
            this.ghostsState = GhostState.Normal;
            this.updateGhostsState();
        }
        #endregion

        #region void setGhostsToVulnerable()
        /// <summary>
        /// Sets all the ghosts to vulnerable state.
        /// </summary>
        protected void setGhostsToVulnerable() {
            // Here we'll set the data used when puckman eats a ghost.
            this.lastGhostKilled = GenericLogic.noneLastKilled;
            this.numberOfGhostsKilled = 0;
            // And here we'll change the state of the ghosts.
            this.ghostsState = GhostState.Vulnerable;
            this.updateGhostsState();
        }
        #endregion

        #region void setGhostsToEnding()
        /// <summary>
        /// Sets all the ghosts to ending vulnerable state.
        /// </summary>
        protected void setGhostsToEnding() {
            this.ghostsState = GhostState.Ending;
            this.ghostTime = 0;

            if(this.red.State == GhostState.Vulnerable)
                this.red.ChangeState(this.ghostsState);

            if(this.pink.State == GhostState.Vulnerable)
                this.pink.ChangeState(this.ghostsState);

            if(this.blue.State == GhostState.Vulnerable)
                this.blue.ChangeState(this.ghostsState);

            if(this.brown.State == GhostState.Vulnerable)
                this.brown.ChangeState(this.ghostsState);
        }
        #endregion

        #region void resetLastKilledGhost(int ghost)
        /// <summary>
        /// Resets the last killed ghost identification.
        /// </summary>
        /// <param name="ghost">The last killed ghost identification to check.</param>
        private void resetLastKilledGhost(int ghost) {
            if(this.lastGhostKilled == ghost) {
                this.lastGhostKilled = GenericLogic.noneLastKilled;
            }
        }
        #endregion

        #region void checksDeadGhostInHouse(Ghost ghost)
        /// <summary>
        /// Checks if a dead ghost is inside the house.
        /// </summary>
        /// <param name="ghost">The ghost to check.</param>
        private void checksDeadGhostInHouse(Ghost ghost) {
            if(!ghost.Alive && Maze.IsGhostInsideTheHouse(ghost)) {
                switch(ghost.TypeOfGhost) {
                    case GhostType.Red:
                        if(ghost.Y >= Maze.GhostHouseCenterY) {
                            ghost.BackToLife();
                            this.resetLastKilledGhost(GenericLogic.redLastKilled);
                        }
                        break;

                    case GhostType.Pink:
                        if(ghost.Y >= Maze.GhostHouseCenterY) {
                            ghost.BackToLife();
                            this.resetLastKilledGhost(GenericLogic.pinkLastKilled);
                        }
                        break;

                    case GhostType.Blue:
                        if(ghost.Y >= Maze.GhostHouseCenterY &&
                           ghost.X <= Maze.BlueGhostStartX) {
                            ghost.BackToLife();
                            this.resetLastKilledGhost(GenericLogic.blueLastKilled);
                        }
                        break;

                    case GhostType.Brown:
                        if(ghost.Y >= Maze.GhostHouseCenterY &&
                           ghost.X >= Maze.BrownGhostStartX) {
                            ghost.BackToLife();
                            this.resetLastKilledGhost(GenericLogic.brownLastKilled);
                        }
                        break;
                }
            }
        }
        #endregion

        #region void checksDeadGhostInHouse()
        /// <summary>
        /// Checks if any dead ghost is inside the house.
        /// </summary>
        protected void checksDeadGhostInHouse() {
            this.checksDeadGhostInHouse(this.red);
            this.checksDeadGhostInHouse(this.pink);
            this.checksDeadGhostInHouse(this.blue);
            this.checksDeadGhostInHouse(this.brown);
        }
        #endregion

        #region void drawDeadGhosts()
        /// <summary>
        /// Draws the dead ghosts.
        /// </summary>
        protected void drawDeadGhosts() {
            if(!this.brown.Alive) { this.brown.Draw(); }
            if(!this.blue.Alive) { this.blue.Draw(); }
            if(!this.pink.Alive) { this.pink.Draw(); }
            if(!this.red.Alive) { this.red.Draw(); }
        }
        #endregion

        #region void drawAliveGhosts()
        /// <summary>
        /// Draws the ghosts.
        /// </summary>
        protected void drawAliveGhosts() {
            if(this.brown.Alive) { this.brown.Draw(); }
            if(this.blue.Alive) { this.blue.Draw(); }
            if(this.pink.Alive) { this.pink.Draw(); }
            if(this.red.Alive) { this.red.Draw(); }
        }
        #endregion

        #region void drawVulnerableGhosts()
        /// <summary>
        /// Draws the vulnerable ghosts.
        /// </summary>
        protected void drawVulnerableGhosts() {
            if(this.brown.State != GhostState.Normal) { this.brown.Draw(); }
            if(this.blue.State != GhostState.Normal) { this.blue.Draw(); }
            if(this.pink.State != GhostState.Normal) { this.pink.Draw(); }
            if(this.red.State != GhostState.Normal) { this.red.Draw(); }
        }
        #endregion

        #region void drawNormalGhosts()
        /// <summary>
        /// Draws the normal ghosts.
        /// </summary>
        protected void drawNormalGhosts() {
            if(this.brown.State == GhostState.Normal) { this.brown.Draw(); }
            if(this.blue.State == GhostState.Normal) { this.blue.Draw(); }
            if(this.pink.State == GhostState.Normal) { this.pink.Draw(); }
            if(this.red.State == GhostState.Normal) { this.red.Draw(); }
        }
        #endregion

        #region void drawGhostWhenPuckmanEats(Ghost ghost, int lastKilledId)
        /// <summary>
        /// Draws a ghost when the puckman have eated one.
        /// </summary>
        /// <param name="ghost">The ghost entity</param>
        /// <param name="lastKilledId">The last killed identification.</param>
        private void drawGhostWhenPuckmanEats(Ghost ghost, int lastKilledId) {
            if(this.lastGhostKilled != lastKilledId) {
                ghost.Draw();
            } else {
                this.drawPoints(ghost.X, ghost.Y);
            }
        }
        #endregion

        #region void drawGhostsWhenPuckmanEats()
        /// <summary>
        /// Draws the ghosts when the puckman have eated one.
        /// </summary>
        protected void drawGhostsWhenPuckmanEats() {
            this.drawGhostWhenPuckmanEats(this.brown, GenericLogic.brownLastKilled);
            this.drawGhostWhenPuckmanEats(this.blue, GenericLogic.blueLastKilled);
            this.drawGhostWhenPuckmanEats(this.pink, GenericLogic.pinkLastKilled);
            this.drawGhostWhenPuckmanEats(this.red, GenericLogic.redLastKilled);
        }
        #endregion

        #region void updateGhostWhenPuckmanEats(long time, Ghost ghost, int lastKilledId)
        /// <summary>
        /// Updates a ghost when the puckman have eated one.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        /// <param name="ghost">The ghost entity</param>
        /// <param name="lastKilledId">The last killed identification.</param>
        private void updateGhostWhenPuckmanEats(long time, Ghost ghost, int lastKilledId) {
            if(!ghost.Alive) {
                if((this.lastGhostKilled != lastKilledId)) {
                    ghost.Update(time);
                }
            }
        }
        #endregion

        #region void updateGhostsWhenPuckmanEats(long time)
        /// <summary>
        /// Updates the ghosts when the puckman have eated one.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        protected void updateGhostsWhenPuckmanEats(long time) {
            this.updateGhostWhenPuckmanEats(time, this.red, GenericLogic.redLastKilled);
            this.updateGhostWhenPuckmanEats(time, this.pink, GenericLogic.pinkLastKilled);
            this.updateGhostWhenPuckmanEats(time, this.blue, GenericLogic.blueLastKilled);
            this.updateGhostWhenPuckmanEats(time, this.brown, GenericLogic.brownLastKilled);
        }
        #endregion

        #region void drawMaze()
        /// <summary>
        /// Draws the maze of the game.
        /// </summary>
        protected void drawMaze() {
            // First, we'll draw the maze.
            this.maze.Draw(this.screen);
            // And then the big dots blink controller will hide them or not.
            this.bigDotsLogic.Draw();
        }
        #endregion

        #region void initializeFruit(FruitType type)
        /// <summary>
        /// Initializes the fruit of the maze.
        /// </summary>
        /// <param name="type">The type of the fruit.</param>
        protected void initializeFruit(FruitType type) {
            this.fruit.Type = type;
            this.fruit.SetCoordinates(Maze.FruitStartX, Maze.FruitStartY);
            this.fruitTime = GenericLogic.fruitDelayTime;
            this.showFruit = false;
        }
        #endregion

        #region void drawFruit()
        /// <summary>
        /// Draws the fruit of the game.
        /// </summary>
        protected void drawFruit() {
            // If the fruit is active we'll draw it into the screen.
            if(this.showFruit) {
                this.fruit.Draw();
            }
        }
        #endregion

        #region void updateFruit(long time)
        /// <summary>
        /// Updates the fruit state.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        protected void updateFruit(long time) {
            this.fruitTime -= time;

            if(this.fruitTime <= 0) {
                if(this.showFruit) {
                    this.fruitTime += GenericLogic.showFruitDelayTime;
                } else {
                    this.fruitTime += GenericLogic.fruitDelayTime;
                }
                this.showFruit = !this.showFruit;
            }
        }
        #endregion

        #region void updateGhostState(long time)
        /// <summary>
        /// Updates the ghosts state.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        protected void updateGhostState(long time) {
            // Here we'll check when the vulnerable state of the ghost ends.
            if(this.ghostsState == GhostState.Vulnerable) {
                // If the ghost is in vulnerable state we'll check if that have ended or not.
                this.ghostTime += time;
                if(this.ghostTime >= GenericLogic.vulnerableInterval) {
                    this.setGhostsToEnding();
                }
            } else if(this.ghostsState == GhostState.Ending) {
                // If the ghost is in ending state we'll check if that have ended or not.
                this.ghostTime += time;
                if(this.ghostTime >= GenericLogic.vulnerableEndingInterval) {
                    this.setGhostsToNormal();
                }
            }
        }
        #endregion

        #region void clearCell(Puckman puckman, Point cell)
        /// <summary>
        /// Clears a cell in the maze and set the puckman's speed.
        /// </summary>
        /// <param name="puckman">The puckman entity.</param>
        /// <param name="cell">The cell coordinates.</param>
        protected void clearCell(Puckman puckman, Point cell) {
            puckman.SetSlow();
            this.maze.Data[cell.Y, cell.X] = Maze.Clean;
            this.lastCellCleared = cell;
        }
        #endregion

        #region bool checkCollision(Entity a, Entity b)
        /// <summary>
        /// Checks if there is a collision between two entities.
        /// </summary>
        /// <param name="a">The first entity.</param>
        /// <param name="b">The second entity.</param>
        /// <returns>If there is a collision returns true, otherwise false.</returns>
        protected bool checkCollision(Entity a, Entity b) {
            const int collisionSeparation = 16; // 8 * 2
            return ((a.X == b.X) && (Math.Abs(a.Y - b.Y) <= collisionSeparation)) ||
                   ((a.Y == b.Y) && (Math.Abs(a.X - b.X) <= collisionSeparation));
        }
        #endregion

        #region void killPuckman()
        /// <summary>
        /// Update the state of the logic to kill the puckman.
        /// </summary>
        protected abstract void killPuckman();
        #endregion

        #region void genericKillPuckman()
        /// <summary>
        /// Update the state of the logic to kill the puckman.
        /// </summary>
        protected void genericKillPuckman() {
            // First, we'll stop all the ghosts.
            this.red.StopSpeed();
            this.pink.StopSpeed();
            this.blue.StopSpeed();
            this.brown.StopSpeed();
            // And then, we'll set the new state of the logic.
            this.state = GenericLogic.killState;
        }
        #endregion

        #region void checkGhostCollision(Puckman puckman, Ghost ghost, int lastKilledId)
        /// <summary>
        /// Check the collision between the puckman and a ghost in the maze.
        /// </summary>
        /// <param name="puckman">The puckman entity.</param>
        /// <param name="ghost">The ghost entity</param>
        /// <param name="lastKilledId">The last killed identification.</param>
        private void checkGhostCollision(Puckman puckman, Ghost ghost, int lastKilledId) {
            // If the ghost is alive and collides with puckman, we'll check the ghost state.
            if(ghost.Alive && this.checkCollision(puckman, ghost)) {
                // When the ghost is in normal state the puckman is killed.
                if(ghost.State == GhostState.Normal) {
                    this.killPuckman();
                } else {
                    // But in any other case the ghost is eated by puckman.
                    ghost.Kill();
                    // After kill the ghost, the counter of killed ghost must be increased.
                    this.numberOfGhostsKilled++;
                    // And the last ghost killed identification must be set.
                    this.lastGhostKilled = lastKilledId;
                    // Finally, we'll set a pause in the game to show the points.
                    GameTimer.Set(GenericLogic.killPauseInterval);
                }
            }
        }
        #endregion

        #region void checkFruitCollision(Puckman puckman)
        /// <summary>
        /// Check the collision between the puckman and a fruit in the maze.
        /// </summary>
        /// <param name="puckman">The puckman entity.</param>
        protected abstract void checkFruitCollision(Puckman puckman);
        #endregion

        #region void checkCollisions(Puckman puckman)
        /// <summary>
        /// Checks all the collisions between the entities in the maze.
        /// </summary>
        /// <param name="puckman">The puckman entity.</param>
        protected void checkCollisions(Puckman puckman) {
            this.checkGhostCollision(puckman, this.red, GenericLogic.redLastKilled);
            this.checkGhostCollision(puckman, this.pink, GenericLogic.pinkLastKilled);
            this.checkGhostCollision(puckman, this.blue, GenericLogic.blueLastKilled);
            this.checkGhostCollision(puckman, this.brown, GenericLogic.brownLastKilled);
            this.checkFruitCollision(puckman);
        }
        #endregion

        #region void drawPoints(int x, int y)
        /// <summary>
        /// Draws the points of a killed ghost.
        /// </summary>
        /// <param name="x">The X coordinate of the ghost killed.</param>
        /// <param name="y">The Y coordinate of the ghost killed.</param>
        protected void drawPoints(int x, int y) {
            switch(this.numberOfGhostsKilled) {
                case 1: this.screen.DrawSprite(x, y, Sprites.N200); break;
                case 2: this.screen.DrawSprite(x, y, Sprites.N400); break;
                case 3: this.screen.DrawSprite(x, y, Sprites.N800); break;
                case 4: this.screen.DrawSprite(x, y, Sprites.N1600); break;
            }
        }
        #endregion
    }
}