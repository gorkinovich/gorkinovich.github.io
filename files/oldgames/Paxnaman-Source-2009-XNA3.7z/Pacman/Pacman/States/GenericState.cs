﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents a generic state.
    /// </summary>
    public abstract class GenericState {
        //******************************************************************************************
        // Static data
        //******************************************************************************************

        #region bool showScorePlayer2
        /// <summary>
        /// Tells to the object if the player 2 score must be drawn or not.
        /// </summary>
        protected static bool showScorePlayer2 = false;
        #endregion

        #region Fruit auxFruit
        /// <summary>
        /// An auxiliar fruit used to paint the list of fruits in the hud.
        /// </summary>
        private Fruit auxFruit = new Fruit();
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameScreen screen
        /// <summary>
        /// The screen manager of the game.
        /// </summary>
        protected GameScreen screen;
        #endregion

        #region GameSound sound
        /// <summary>
        /// The sound manager of the game.
        /// </summary>
        protected GameSound sound;
        #endregion

        #region GameData data
        /// <summary>
        /// The data manager of the game.
        /// </summary>
        protected GameData data;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GenericState()
        /// <summary>
        /// Constructs a new GenericState object.
        /// </summary>
        public GenericState() {
            this.screen = CoreManager.Instance.Screen;
            this.sound = CoreManager.Instance.Sound;
            this.data = CoreManager.Instance.Data;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void drawFruitsHud()
        /// <summary>
        /// Draws the fruits HUD.
        /// </summary>
        protected void drawFruitsHud() {
            if(this.data.LastFruits != null) {
                const int fruitsHudStartX = 384;
                const int fruitsHudStartY = 544;

                for(int i = 0; i < this.data.LastFruits.Length; i++) {
                    auxFruit.Type = this.data.LastFruits[i];
                    auxFruit.SetCoordinates(fruitsHudStartX - Sprites.Width * i,
                                            fruitsHudStartY);
                    auxFruit.Draw();
                }
            }
        }
        #endregion

        #region void drawLivesHud()
        /// <summary>
        /// Draws the lives HUD.
        /// </summary>
        protected void drawLivesHud() {
            const int livesHudStartX = 32;
            const int livesHudStartY = 544;

            for(int i = 0; i < this.data.ExtraLives; i++) {
                this.screen.DrawSprite(livesHudStartX + Sprites.Width * i,
                                       livesHudStartY, Sprites.LifeIcon);
            }
        }
        #endregion

        #region void drawMenuHud()
        /// <summary>
        /// Draws the menu HUD.
        /// </summary>
        protected void drawMenuHud() {
            this.screen.DrawText(0, 3, "1UP");
            this.screen.DrawTextLeft(1, 6, this.data.Player1.Score.ToString("00"));

            this.screen.DrawText(0, 9, "HIGH SCORE");
            if(this.data.HighScore > 0) {
                this.screen.DrawTextLeft(1, 16, this.data.HighScore.ToString("00"));
            }

            this.screen.DrawText(0, 22, "2UP");
            if(GenericState.showScorePlayer2) {
                this.screen.DrawTextLeft(1, 25, this.data.Player2.Score.ToString("00"));
            }

            this.screen.DrawText(35, 2, "CREDIT");
            this.screen.DrawTextLeft(35, 10, this.data.Coins.ToString());

            this.drawFruitsHud();
        }
        #endregion
    }
}