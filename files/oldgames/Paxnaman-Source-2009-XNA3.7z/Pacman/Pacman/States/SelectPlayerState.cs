﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class represents select number of players state.
    /// </summary>
    public sealed class SelectPlayerState : GenericState, IState {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameManager manager
        /// <summary>
        /// The xna manager of the game.
        /// </summary>
        private GameManager manager;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region SelectPlayerState()
        /// <summary>
        /// Constructs a new SelectPlayerState object.
        /// </summary>
        public SelectPlayerState() {
            this.manager = CoreManager.Instance.Manager;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Initialize()
        /// <summary>
        /// Initializes the state.
        /// </summary>
        public void Initialize() {
        }
        #endregion

        #region void Release()
        /// <summary>
        /// Releases the state.
        /// </summary>
        public void Release() {
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the content of the state.
        /// </summary>
        public void Draw() {
            this.manager.GraphicsDevice.Clear(Color.Black);
            this.drawMenuHud();

            this.screen.DrawText(16, 6, "PUSH START BUTTON", Colors.Brown);

            if(this.data.Coins > 1) {
                this.screen.DrawText(20, 8, "1 OR 2 PLAYERS", Colors.Cyan);
            } else {
                this.screen.DrawText(20, 8, "1 PLAYER ONLY", Colors.Cyan);
            }

            this.screen.DrawText(24, 1, "BONUS PUCKMAN FOR 10000", Colors.DarkPink);
            this.screen.DrawSymbol(24, 25, FontSymbol.Pts, Colors.DarkPink);

            this.screen.DrawSymbol(28, 8, FontSymbol.Copyright, Colors.Pink);
            this.screen.DrawSymbol(28, 10, FontSymbol.Namco, Colors.Pink);
            this.screen.DrawText(28, 18, "1980", Colors.Pink);
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner logic of the state.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            // Here we check if the user wants to exit the game.
            if(GameInput.Escape) {
                this.manager.Exit();
            }

            // Here we check if the user wants to insert a coin.
            if(GameInput.Coin) {
                this.data.AddCoin();
                this.sound.FruitEat.Play();
                return;
            }

            // Here we check if the user wants to start a one player game.
            if(GameInput.OnePlayer && this.data.Coins > 0) {
                CoreManager.Instance.GameState.StartOnePlayerGame();
                CoreManager.Instance.ChangeState(CoreManager.Instance.GameState);
                return;
            }

            // Here we check if the user wants to start a two players game.
            if(GameInput.TwoPlayers && this.data.Coins > 1) {
                CoreManager.Instance.GameState.StartTwoPlayersGame();
                CoreManager.Instance.ChangeState(CoreManager.Instance.GameState);
                return;
            }
        }
        #endregion
    }
}