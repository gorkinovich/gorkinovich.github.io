﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents the game state.
    /// </summary>
    public sealed class GameState : GenericState, IState {
        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region long scoreBlinkDelayTime
        /// <summary>
        /// The amount of time in the score blinking interval.
        /// </summary>
        private const long scoreBlinkDelayTime = 250;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameLogic logic
        /// <summary>
        /// The logic manager of the game.
        /// </summary>
        private GameLogic logic;
        #endregion

        #region long scoreBlinkInterval
        /// <summary>
        /// The current time passed in the score blinking animation.
        /// </summary>
        private long scoreBlinkInterval;
        #endregion

        #region bool showScore
        /// <summary>
        /// Tells to the program if the score must be shown or not.
        /// </summary>
        private bool showScore;
        #endregion

        #region FruitType[] auxLastFruits
        /// <summary>
        /// An auxiliary list of fruits.
        /// </summary>
        private FruitType[] auxLastFruits;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameState()
        /// <summary>
        /// Constructs a new GameState object.
        /// </summary>
        public GameState() {
            this.logic = new GameLogic();
            this.auxLastFruits = null;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region FruitType getCurrentFruit()
        /// <summary>
        /// Gets the current fruit for the level.
        /// </summary>
        /// <returns>The current used fruit in the maze.</returns>
        private FruitType getCurrentFruit() {
            if(this.data.Level <= 1) {
                return FruitType.Cherry;
            } else if(this.data.Level <= 2) {
                return FruitType.Strawberry;
            } else if(this.data.Level <= 4) {
                return FruitType.Peach;
            } else if(this.data.Level <= 6) {
                return FruitType.Apple;
            } else if(this.data.Level <= 8) {
                return FruitType.Grape;
            } else if(this.data.Level <= 10) {
                return FruitType.Flower;
            } else if(this.data.Level <= 12) {
                return FruitType.Bell;
            } else {
                return FruitType.Key;
            }
        }
        #endregion

        #region void startGenericGame()
        /// <summary>
        /// Starts a new generic game.
        /// </summary>
        private void startGenericGame() {
            this.scoreBlinkInterval = 0;
            this.showScore = true;
            this.data.PlayerTurn = 1;
            FruitType currentFruit = this.getCurrentFruit();
            this.data.LastFruits = null;
            this.auxLastFruits = new FruitType[] { currentFruit };
            this.data.AddFruit(currentFruit);
            this.data.Player.ExtraLives--;
            this.logic.Initialize(currentFruit, true, false);
        }
        #endregion

        #region void StartOnePlayerGame()
        /// <summary>
        /// Starts a new one player game.
        /// </summary>
        public void StartOnePlayerGame() {
            this.data.Coins -= 1;
            GenericState.showScorePlayer2 = false;
            this.data.NumberOfPlayers = 1;
            this.data.Player1.NewGame();
            this.startGenericGame();
        }
        #endregion

        #region void StartTwoPlayersGame()
        /// <summary>
        /// Starts a new two players game.
        /// </summary>
        public void StartTwoPlayersGame() {
            this.data.Coins -= 2;
            GenericState.showScorePlayer2 = true;
            this.data.NumberOfPlayers = 2;
            this.data.Player1.NewGame();
            this.data.Player2.NewGame();
            this.startGenericGame();
        }
        #endregion

        #region void Initialize()
        /// <summary>
        /// Initializes the state.
        /// </summary>
        public void Initialize() {
        }
        #endregion

        #region void Release()
        /// <summary>
        /// Releases the state.
        /// </summary>
        public void Release() {
        }
        #endregion

        #region void drawGameHud()
        /// <summary>
        /// Draws the game HUD.
        /// </summary>
        private void drawGameHud() {
            if(this.showScore || this.data.PlayerTurn == 2) {
                this.screen.DrawText(0, 3, "1UP");
            }
            this.screen.DrawTextLeft(1, 6, this.data.Player1.Score.ToString("00"));

            this.screen.DrawText(0, 9, "HIGH SCORE");
            if(this.data.HighScore > 0) {
                this.screen.DrawTextLeft(1, 16, this.data.HighScore.ToString("00"));
            }

            if(GenericState.showScorePlayer2) {
                if(this.showScore || this.data.PlayerTurn == 1) {
                    this.screen.DrawText(0, 22, "2UP");
                }
                this.screen.DrawTextLeft(1, 25, this.data.Player2.Score.ToString("00"));
            }

            this.drawLivesHud();
            this.drawFruitsHud();
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the content of the state.
        /// </summary>
        public void Draw() {
            this.logic.Draw();

            this.screen.ClearSprite(GameScreen.WormholeLeftX, GameScreen.WormholeY);
            this.screen.ClearSprite(GameScreen.WormholeRightX, GameScreen.WormholeY);

            this.drawGameHud();
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner logic of the state.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            // Ends the current game.
            if(GameInput.Escape) {
                this.getBackToTheMenu();
                return;
            }

            // Updates the game logic of this round.
            GameTimer.Update(time);
            this.logic.Update(time);

            // Updates the score blinking.
            this.scoreBlinkInterval += time;
            while(this.scoreBlinkInterval >= GameState.scoreBlinkDelayTime) {
                this.scoreBlinkInterval -= GameState.scoreBlinkDelayTime;
                this.showScore = !this.showScore;
            }

            // Checks if the round have end and if puckman is victorious or not.
            if(this.logic.Ended) {
                if(this.logic.Victory) {
                    this.nextLevel();
                } else {
                    if(this.data.NumberOfPlayers == 1) {
                        this.nextLife();
                    } else {
                        this.nextTurn();
                    }
                }
            }
        }
        #endregion

        #region void nextLevel()
        /// <summary>
        /// Goes to the next life of the one player game.
        /// </summary>
        private void nextLevel() {
            this.data.Player.NextLevel();
            FruitType currentFruit = this.getCurrentFruit();
            this.data.AddFruit(currentFruit);
            this.logic.Initialize(currentFruit, false, true);
        }
        #endregion

        #region void nextLife()
        /// <summary>
        /// Goes to the next life of the one player game.
        /// </summary>
        private void nextLife() {
            // First, we'll check if puckman can play one more round.
            if(this.data.ExtraLives > 0) {
                // Second, we'll quit one extra life.
                this.data.ExtraLives--;
                // And we'll initialize the current round logic.
                this.logic.Initialize(this.getCurrentFruit(), false, false);
            } else {
                // But if the player can't play we'll get back to the menu.
                this.getBackToTheMenu();
            }
        }
        #endregion

        #region void nextTurn()
        /// <summary>
        /// Goes to the next life of the two players game.
        /// </summary>
        private void nextTurn() {
            // First, we'll change the current player turn.
            this.data.ChangeTurn();
            // Then, we'll check if the next player can play or not another round.
            if(this.data.ExtraLives > 0) {
                // If the player can play, we'll get the user last fruits array.
                this.swapLastFruits();
                // After that we'll get an extra life.
                this.data.ExtraLives--;
                // And we'll initialize the current round logic.
                this.logic.Initialize(this.getCurrentFruit(), false, false);
            } else {
                // If the next player can't play, we'll get back to the previous player.
                this.data.ChangeTurn();
                // And we'll check if the previous player can play or not another round.
                if(this.data.ExtraLives > 0) {
                    // If the player can play, we'll get an extra life.
                    this.data.ExtraLives--;
                    // And we'll initialize the current round logic.
                    this.logic.Initialize(this.getCurrentFruit(), false, false);
                } else {
                    // If nobody can't play, we'll get back to the menu.
                    this.getBackToTheMenu();
                }
            }
        }
        #endregion

        #region void swapLastFruits()
        /// <summary>
        /// Swaps the last fruits array.
        /// </summary>
        private void swapLastFruits() {
            FruitType[] aux = this.data.LastFruits;
            this.data.LastFruits = this.auxLastFruits;
            this.auxLastFruits = aux;
        }
        #endregion

        #region void getBackToTheMenu()
        /// <summary>
        /// Gets back to the menu of the game.
        /// </summary>
        private void getBackToTheMenu() {
            // Stop all the loop sounds first.
            this.sound.StopAll();
            // And then change the inner state of the program.
            if(this.data.Coins > GameData.MinCoins) {
                CoreManager.Instance.ChangeState(CoreManager.Instance.SelectPlayerState);
            } else {
                CoreManager.Instance.ChangeState(CoreManager.Instance.InsertCoinState);
            }
        }
        #endregion
    }
}