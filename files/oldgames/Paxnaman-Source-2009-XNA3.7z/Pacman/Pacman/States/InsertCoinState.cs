﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class represents the insert coin state.
    /// </summary>
    public sealed class InsertCoinState : GenericState, IState {
        //******************************************************************************************
        // Types
        //******************************************************************************************

        #region enum Substates
        /// <summary>
        /// This enumeration represents the inner states of this class.
        /// </summary>
        private enum Substates {
            initialState,
            showRedGhostState, showRedNameState, showRedNickState,
            showPinkGhostState, showPinkNameState, showPinkNickState,
            showBlueGhostState, showBlueNameState, showBlueNickState,
            showBrownGhostState, showBrownNameState, showBrownNickState,
            showDotsState, showFinalTextState,
            animationState, demoState
        }
        #endregion

        #region enum AnimationStates
        /// <summary>
        /// This enumeration represents the states of the animation.
        /// </summary>
        private enum AnimationStates {
            Normal, RedDie, PinkDie, BlueDie, BrownDie
        }
        #endregion

        //******************************************************************************************
        // Constants
        //******************************************************************************************

        #region long delayTime
        /// <summary>
        /// The amount of time between one substate and another, until this state
        /// gets to the animation substate.
        /// </summary>
        private const long delayTime = 600;
        #endregion

        #region long pointsDelayTime
        /// <summary>
        /// The amount of time when puckman eats a ghost in the animation.
        /// </summary>
        private const long pointsDelayTime = 600;
        #endregion

        #region long puckmanFastInterval
        /// <summary>
        /// A fast amount of time that the puckman interval can have.
        /// </summary>
        private const long puckmanFastInterval = 14;
        #endregion

        #region long puckmanSlowInterval
        /// <summary>
        /// A slow amount of time that the puckman interval can have.
        /// </summary>
        private const long puckmanSlowInterval = 16;
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameManager manager
        /// <summary>
        /// The xna manager of the game.
        /// </summary>
        private GameManager manager;
        #endregion

        #region Substates innerState
        /// <summary>
        /// The inner substate of the class.
        /// </summary>
        private Substates innerState;
        #endregion

        #region BigDotsLogic bigDotsLogic
        /// <summary>
        /// This is the controller of the big dots blinking.
        /// </summary>
        private BigDotsLogic bigDotsLogic;
        #endregion

        #region bool bigDotEated
        /// <summary>
        /// Tells to the state if the big dot of the animation is eated or not.
        /// </summary>
        private bool bigDotEated;
        #endregion

        #region AnimatedPuckman puckman
        /// <summary>
        /// This is the puckman used in the animation.
        /// </summary>
        private AnimatedPuckman puckman;
        #endregion

        #region Ghost red
        /// <summary>
        /// This is the red ghost used in the animation.
        /// </summary>
        private Ghost red;
        #endregion

        #region Ghost pink
        /// <summary>
        /// This is the pink ghost used in the animation.
        /// </summary>
        private Ghost pink;
        #endregion

        #region Ghost blue
        /// <summary>
        /// This is the blue ghost used in the animation.
        /// </summary>
        private Ghost blue;
        #endregion

        #region Ghost brown
        /// <summary>
        /// This is the brown ghost used in the animation.
        /// </summary>
        private Ghost brown;
        #endregion

        #region AnimationStates aniState
        /// <summary>
        /// The inner substate of the animation.
        /// </summary>
        private AnimationStates aniState;
        #endregion

        #region DemoLogic demo
        /// <summary>
        /// The logic manager of the demo.
        /// </summary>
        private DemoLogic demo;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region InsertCoinState()
        /// <summary>
        /// Constructs a new InsertCoinState object.
        /// </summary>
        public InsertCoinState() {
            this.manager = CoreManager.Instance.Manager;
            this.innerState = Substates.initialState;

            this.bigDotsLogic = new BigDotsLogic();
            this.bigDotsLogic.Register(26, 10);
            this.bigDotsLogic.Register(20, 4);

            this.puckman = new AnimatedPuckman();
            this.red = new Ghost(GhostType.Red);
            this.pink = new Ghost(GhostType.Pink);
            this.blue = new Ghost(GhostType.Blue);
            this.brown = new Ghost(GhostType.Brown);

            this.demo = new DemoLogic();
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void changeInnerState(Substates newState)
        /// <summary>
        /// Changes the inner substate of the class.
        /// </summary>
        /// <param name="newState">The new substate.</param>
        private void changeInnerState(Substates newState) {
            // We set the new state.
            this.innerState = newState;
            // And set a delay if we need it.
            if(newState != Substates.animationState &&
               newState != Substates.demoState) {
                GameTimer.Set(InsertCoinState.delayTime);
            }
        }
        #endregion

        #region void Initialize()
        /// <summary>
        /// Initializes the state.
        /// </summary>
        public void Initialize() {
            // General data.
            this.changeInnerState(Substates.initialState);

            // Animation data.
            this.bigDotEated = false;
            this.bigDotsLogic.ResetTime();

            this.puckman.SetCoordinates(448, 312);
            this.puckman.SetSpeedInterval(InsertCoinState.puckmanSlowInterval);

            this.red.SetCoordinates(506, 312);
            this.pink.SetCoordinates(506 + 32, 312);
            this.blue.SetCoordinates(506 + 64, 312);
            this.brown.SetCoordinates(506 + 96, 312);

            this.puckman.NeededDirection = MovingDirection.Left;
            this.red.NeededDirection = MovingDirection.Left;
            this.pink.NeededDirection = MovingDirection.Left;
            this.blue.NeededDirection = MovingDirection.Left;
            this.brown.NeededDirection = MovingDirection.Left;

            this.red.BackToLife();
            this.pink.BackToLife();
            this.blue.BackToLife();
            this.brown.BackToLife();

            this.red.ChangeState(GhostState.Normal);
            this.pink.ChangeState(GhostState.Normal);
            this.blue.ChangeState(GhostState.Normal);
            this.brown.ChangeState(GhostState.Normal);

            this.aniState = AnimationStates.Normal;
        }
        #endregion

        #region void Release()
        /// <summary>
        /// Releases the state.
        /// </summary>
        public void Release() {
        }
        #endregion

        #region void drawText()
        /// <summary>
        /// Draws the text of the state.
        /// </summary>
        private void drawText() {
            switch(this.innerState) {
                case Substates.animationState:
                    goto case Substates.showFinalTextState;

                case Substates.showFinalTextState:
                    if(this.bigDotEated == false) {
                        this.screen.DrawTile(20, 4, Maze.BigDot);
                    }
                    this.screen.DrawText(29, 5, "PAXNAMAN BY GORKIN", Colors.Pink);
                    this.screen.DrawText(32, 3, "PRESS C TO INSERT COIN", Colors.Blue);
                    goto case Substates.showDotsState;

                case Substates.showDotsState:
                    this.screen.DrawTile(24, 10, Maze.Dot);
                    this.screen.DrawText(24, 12, "10");
                    this.screen.DrawSymbol(24, 15, FontSymbol.Pts);

                    this.screen.DrawTile(26, 10, Maze.BigDot);
                    this.screen.DrawText(26, 12, "50");
                    this.screen.DrawSymbol(26, 15, FontSymbol.Pts);

                    goto case Substates.showBrownNickState;

                case Substates.showBrownNickState:
                    this.screen.DrawText(16, 18, "\"GUZUTA\"", Colors.Brown);
                    goto case Substates.showBrownNameState;

                case Substates.showBrownNameState:
                    this.screen.DrawText(16, 8, "OTOBOKE---", Colors.Brown);
                    goto case Substates.showBrownGhostState;

                case Substates.showBrownGhostState:
                    this.screen.DrawSprite(64, 248, Sprites.BrownGhostR1); // r15.5 c4 Brown ghost
                    goto case Substates.showBlueNickState;

                case Substates.showBlueNickState:
                    this.screen.DrawText(13, 18, "\"AOSUKE\"", Colors.Cyan);
                    goto case Substates.showBlueNameState;

                case Substates.showBlueNameState:
                    this.screen.DrawText(13, 8, "KIMAGURE--", Colors.Cyan);
                    goto case Substates.showBlueGhostState;

                case Substates.showBlueGhostState:
                    this.screen.DrawSprite(64, 200, Sprites.BlueGhostR1); // r12.5 c4 Blue ghost
                    goto case Substates.showPinkNickState;

                case Substates.showPinkNickState:
                    this.screen.DrawText(10, 19, "\"PINKY\"", Colors.Pink);
                    goto case Substates.showPinkNameState;

                case Substates.showPinkNameState:
                    this.screen.DrawText(10, 8, "MACHIBUSE--", Colors.Pink);
                    goto case Substates.showPinkGhostState;

                case Substates.showPinkGhostState:
                    this.screen.DrawSprite(64, 152, Sprites.PinkGhostR1); // r9.5 c4 Pink ghost
                    goto case Substates.showRedNickState;

                case Substates.showRedNickState:
                    this.screen.DrawText(7, 18, "\"AKABEI\"", Colors.Red);
                    goto case Substates.showRedNameState;

                case Substates.showRedNameState:
                    this.screen.DrawText(7, 8, "OIKAKE----", Colors.Red);
                    goto case Substates.showRedGhostState;

                case Substates.showRedGhostState:
                    this.screen.DrawSprite(64, 104, Sprites.RedGhostR1); // r6.5 c4 Red ghost
                    goto case Substates.initialState;

                case Substates.initialState:
                    this.drawMenuHud();
                    this.screen.DrawText(5, 7, "CHARACTER / NICKNAME");
                    break;
            }
        }
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the content of the state.
        /// </summary>
        public void Draw() {
            // First, we'll clear the screen with the black color.
            this.manager.GraphicsDevice.Clear(Color.Black);

            // Then we have to check in which state we are.
            if(this.innerState == Substates.demoState) {
                // In the demo substate we'll call the draw demo method.
                this.demo.Draw();

                // We'll clear the wormhole areas.
                this.screen.ClearSprite(GameScreen.WormholeLeftX, GameScreen.WormholeY);
                this.screen.ClearSprite(GameScreen.WormholeRightX, GameScreen.WormholeY);

                // And after that we'll draw the menu HUD.
                this.drawMenuHud();

            } else if(this.innerState == Substates.animationState) {
                // In the animation substate the first thing to do is to hide or not the
                // big dots of the screen, to make them blink.
                this.drawText();
                this.bigDotsLogic.Draw();

                // Second, we'll draw the ghosts if they are alive. When the ghost are in
                // normal mode, they are drawn over the puckman sprite, but when they are
                // in vulnerable mode, they are drawn under the puckman sprite. In this
                // case the ghosts never touch puckman when they are in normal mode, so
                // we'll always paint then in first place, under the puckman sprite.
                if(this.red.Alive) { this.red.Draw(); }
                if(this.pink.Alive) { this.pink.Draw(); }
                if(this.blue.Alive) { this.blue.Draw(); }
                if(this.brown.Alive) { this.brown.Draw(); }

                // Third, we'll draw puckman if the animation isn't paused.
                if(GameTimer.IsStopped()) {
                    this.puckman.Draw();
                } else {
                    // If the animation is paused, we'll check the state of the animation.
                    // That will allow us to know, which points sprite we'll have to draw.
                    switch(this.aniState) {
                        case AnimationStates.Normal:
                            this.puckman.Draw();
                            break;
                        case AnimationStates.RedDie:
                            this.screen.DrawSprite(this.red.X, this.red.Y, Sprites.N200);
                            break;
                        case AnimationStates.PinkDie:
                            this.screen.DrawSprite(this.pink.X, this.pink.Y, Sprites.N400);
                            break;
                        case AnimationStates.BlueDie:
                            this.screen.DrawSprite(this.blue.X, this.blue.Y, Sprites.N800);
                            break;
                        case AnimationStates.BrownDie:
                            this.screen.DrawSprite(this.brown.X, this.brown.Y, Sprites.N1600);
                            break;
                    }
                }
            } else {
                // Here we'll draw the text of the screen.
                this.drawText();
            }
        }
        #endregion

        #region void changeToNextState(Substates nextState)
        /// <summary>
        /// Try to change to the next substate of this class.
        /// </summary>
        /// <param name="nextState">The next substate to change.</param>
        private void changeToNextState(Substates nextState) {
            if(GameTimer.IsStopped()) {
                this.changeInnerState(nextState);
            }
        }
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner logic of the state.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        public void Update(long time) {
            // Here we check if the user wants to exit the game.
            if(GameInput.Escape) {
                this.manager.Exit();
            }

            // Here we check if the user wants to insert a coin, if so we'll
            // change to the next state in the game, the select player state.
            if(GameInput.Coin) {
                this.data.AddCoin();
                this.sound.FruitEat.Play();
                GameTimer.Stop();
                CoreManager.Instance.ChangeState(CoreManager.Instance.SelectPlayerState);
                return;
            }

            // Because we're doing some animations and effects, we'll need to use the
            // game timer and here we're going to update it.
            GameTimer.Update(time);

            // And here we'll control the logic of the substates. I'm sorry of this
            // spaghetti code, but make a cool animation system is very hard ;)
            switch(this.innerState) {
                #region Substates.animationState
                case Substates.animationState:
                    // In this substate we're going to make an animation, where puckman is going
                    // to eat some ghosts. But first we'll update the big dots blinking.
                    this.bigDotsLogic.Update(time);

                    // After that, we have to check if the game timer is stopped, because we're
                    // going to use it to stop the animation when puckman eats a ghost.
                    if(GameTimer.IsStopped()) {
                        // If the brown ghost, the last one, dies and the timer have stopped,
                        // we'll change to the next substate, where we'll see a demo of this game.
                        if(this.aniState == AnimationStates.BrownDie) {
                            this.demo.Initialize();
                            this.changeInnerState(Substates.demoState);

                        } else {
                            // Here the animation isn't ended, so we'll update the entities of
                            // the animation. This will make them move.
                            this.puckman.Update(time);
                            this.red.Update(time);
                            this.pink.Update(time);
                            this.blue.Update(time);
                            this.brown.Update(time);

                            // The first part of the animation is puckman escaping from the ghosts,
                            // but when puckman gets the big dot everything changes, because the
                            // ghosts are vulnerable now and puckman can eat them. Here is where
                            // we check if puckman have eated the big dot.
                            if(this.puckman.X <= 64) {
                                // If the big dot is eated, we have to update this flag, to
                                // avoid that the big dot eated is painted again.
                                this.bigDotEated = true;

                                // And we set puckman to fast mode.
                                this.puckman.SetSpeedInterval(InsertCoinState.puckmanFastInterval);

                                // Then we'll change the direction of all the entities.
                                this.puckman.NeededDirection = MovingDirection.Right;
                                this.red.NeededDirection = MovingDirection.Right;
                                this.pink.NeededDirection = MovingDirection.Right;
                                this.blue.NeededDirection = MovingDirection.Right;
                                this.brown.NeededDirection = MovingDirection.Right;

                                // And we'll set all the ghosts to vulnerable mode.
                                this.red.ChangeState(GhostState.Vulnerable);
                                this.pink.ChangeState(GhostState.Vulnerable);
                                this.blue.ChangeState(GhostState.Vulnerable);
                                this.brown.ChangeState(GhostState.Vulnerable);
                            }

                            // If the big dot is eated, we'll check if puckman have caught any ghost.
                            if(this.bigDotEated) {
                                // If puckman is over the red ghost, we'll kill it, set the animation
                                // to the next state and pause it some time, to show the points gained
                                // by eating that ghost.
                                if(this.red.Alive && (this.puckman.X + (Sprites.Width / 2) >= this.red.X)) {
                                    this.red.Kill();
                                    this.aniState = AnimationStates.RedDie;
                                    GameTimer.Set(InsertCoinState.pointsDelayTime);
                                }

                                // If puckman is over the pink ghost, we'll kill it, set the animation
                                // to the next state and pause it some time, to show the points gained
                                // by eating that ghost.
                                if(this.pink.Alive && (this.puckman.X + (Sprites.Width / 2) >= this.pink.X)) {
                                    this.pink.Kill();
                                    this.aniState = AnimationStates.PinkDie;
                                    GameTimer.Set(InsertCoinState.pointsDelayTime);
                                }

                                // If puckman is over the blue ghost, we'll kill it, set the animation
                                // to the next state and pause it some time, to show the points gained
                                // by eating that ghost.
                                if(this.blue.Alive && (this.puckman.X + (Sprites.Width / 2) >= this.blue.X)) {
                                    this.blue.Kill();
                                    this.aniState = AnimationStates.BlueDie;
                                    GameTimer.Set(InsertCoinState.pointsDelayTime);
                                }

                                // If puckman is over the brown ghost, we'll kill it, set the animation
                                // to the next state and pause it some time, to show the points gained
                                // by eating that ghost.
                                if(this.brown.Alive && (this.puckman.X + (Sprites.Width / 2) >= this.brown.X)) {
                                    this.brown.Kill();
                                    this.aniState = AnimationStates.BrownDie;
                                    GameTimer.Set(InsertCoinState.pointsDelayTime);
                                }
                            }
                        }
                    }
                    break;
                #endregion

                #region Substates.demoState
                case Substates.demoState:
                    // In this substate we're going to show a demo of the game, that's
                    // why all the big stuff is going to be made inside the demo object.
                    this.demo.Update(time);
                    // And when the demo is ended, we'll reset the state to start the
                    // puckman and text animation one more time.
                    if(this.demo.Ended) {
                        this.Initialize();
                    }
                    break;
                #endregion

                #region Substates.initialState
                case Substates.initialState:
                    this.changeToNextState(Substates.showRedGhostState);
                    break;
                #endregion

                #region Substates.showRedGhostState
                case Substates.showRedGhostState:
                    this.changeToNextState(Substates.showRedNameState);
                    break;
                #endregion

                #region Substates.showRedNameState
                case Substates.showRedNameState:
                    this.changeToNextState(Substates.showRedNickState);
                    break;
                #endregion

                #region Substates.showRedNickState
                case Substates.showRedNickState:
                    this.changeToNextState(Substates.showPinkGhostState);
                    break;
                #endregion

                #region Substates.showPinkGhostState
                case Substates.showPinkGhostState:
                    this.changeToNextState(Substates.showPinkNameState);
                    break;
                #endregion

                #region Substates.showPinkNameState
                case Substates.showPinkNameState:
                    this.changeToNextState(Substates.showPinkNickState);
                    break;
                #endregion

                #region Substates.showPinkNickState
                case Substates.showPinkNickState:
                    this.changeToNextState(Substates.showBlueGhostState);
                    break;
                #endregion

                #region Substates.showBlueGhostState
                case Substates.showBlueGhostState:
                    this.changeToNextState(Substates.showBlueNameState);
                    break;
                #endregion

                #region Substates.showBlueNameState
                case Substates.showBlueNameState:
                    this.changeToNextState(Substates.showBlueNickState);
                    break;
                #endregion

                #region Substates.showBlueNickState
                case Substates.showBlueNickState:
                    this.changeToNextState(Substates.showBrownGhostState);
                    break;
                #endregion

                #region Substates.showBrownGhostState
                case Substates.showBrownGhostState:
                    this.changeToNextState(Substates.showBrownNameState);
                    break;
                #endregion

                #region Substates.showBrownNameState
                case Substates.showBrownNameState:
                    this.changeToNextState(Substates.showBrownNickState);
                    break;
                #endregion

                #region Substates.showBrownNickState
                case Substates.showBrownNickState:
                    this.changeToNextState(Substates.showDotsState);
                    break;
                #endregion

                #region Substates.showDotsState
                case Substates.showDotsState:
                    this.changeToNextState(Substates.showFinalTextState);
                    break;
                #endregion

                #region Substates.showFinalTextState
                case Substates.showFinalTextState:
                    this.changeToNextState(Substates.animationState);
                    break;
                #endregion
            }
        }
        #endregion
    }
}