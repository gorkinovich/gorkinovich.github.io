﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This interface represents a generic state of the game.
    /// </summary>
    public interface IState {

        #region void Initialize()
        /// <summary>
        /// Initializes the state.
        /// </summary>
        void Initialize();
        #endregion

        #region void Release()
        /// <summary>
        /// Releases the state.
        /// </summary>
        void Release();
        #endregion

        #region void Draw()
        /// <summary>
        /// Draws the content of the state.
        /// </summary>
        void Draw();
        #endregion

        #region void Update(long time)
        /// <summary>
        /// Updates the inner logic of the state.
        /// </summary>
        /// <param name="time">The passed time after the last call of the update.</param>
        void Update(long time);
        #endregion
    }
}