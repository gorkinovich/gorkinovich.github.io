// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Su�rez Garc�a
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Pacman {
    /// <summary>
    /// This class represents the xna game manager.
    /// </summary>
    public sealed class GameManager : Microsoft.Xna.Framework.Game {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GraphicsDeviceManager graphics
        /// <summary>
        /// The graphics device manager of the game.
        /// </summary>
        private GraphicsDeviceManager graphics;
        #endregion

        #region SpriteBatch spriteBatch
        /// <summary>
        /// The sprite batch manager of the game.
        /// </summary>
        private SpriteBatch spriteBatch;
        #endregion

        #region CoreManager core
        /// <summary>
        /// The core manager of the game.
        /// </summary>
        private CoreManager core;
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameManager()
        /// <summary>
        /// Constructs a new GameManager object.
        /// </summary>
        public GameManager() {
            // Setting the window.
            this.graphics = new GraphicsDeviceManager(this);
            this.graphics.PreferredBackBufferWidth = 500;
            this.graphics.PreferredBackBufferHeight = 600;
            this.graphics.PreferredBackBufferFormat = SurfaceFormat.Color;
            this.Window.Title = "Paxnaman";
            this.Content.RootDirectory = "Content";
            // Setting the game.
            this.core = CoreManager.Instance;
            this.core.Initialize(this);
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void LoadContent()
        /// <summary>
        /// LoadContent will be called once per game and is the place
        /// to load all of your content.
        /// </summary>
        protected override void LoadContent() {
            // First, get the sprite batch class.
            this.spriteBatch = new SpriteBatch(this.GraphicsDevice);
            // Second, load the content of the game.
            this.core.Screen.LoadContent(this, this.spriteBatch);
            this.core.Sound.LoadContent(this);
            // Third, set the initial state of the game.
            this.core.ChangeState(this.core.InsertCoinState);
        }
        #endregion

        #region void Update(GameTime gameTime)
        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime) {
            // First, get the time interval between this call and the last one.
            long time = (long)gameTime.ElapsedGameTime.TotalMilliseconds;
            // Second, update the game state.
            this.core.State.Update(time);
        }
        #endregion

        #region void Draw(GameTime gameTime)
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime) {
            this.spriteBatch.Begin();
            this.core.State.Draw();
            this.spriteBatch.End();
        }
        #endregion
    }
}