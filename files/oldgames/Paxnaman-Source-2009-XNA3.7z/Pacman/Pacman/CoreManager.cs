﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

namespace Pacman {
    /// <summary>
    /// This class represents the core of the game.
    /// </summary>
    public sealed class CoreManager {
        //******************************************************************************************
        // Static data
        //******************************************************************************************

        #region CoreManager Instance
        /// <summary>
        /// The instance of the class.
        /// </summary>
        private static CoreManager instance = new CoreManager();

        /// <summary>
        /// The instance of the class.
        /// </summary>
        public static CoreManager Instance {
            get { return instance; }
        }
        #endregion

        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region GameScreen Screen
        /// <summary>
        /// The screen manager of the game.
        /// </summary>
        public GameScreen Screen { get; private set; }
        #endregion

        #region GameSound Sound
        /// <summary>
        /// The sound manager of the game.
        /// </summary>
        public GameSound Sound { get; private set; }
        #endregion

        #region GameData Data
        /// <summary>
        /// The data manager of the game.
        /// </summary>
        public GameData Data { get; private set; }
        #endregion

        #region IState State
        /// <summary>
        /// The state of the game.
        /// </summary>
        public IState State { get; private set; }
        #endregion

        #region GameManager Manager
        /// <summary>
        /// The xna manager of the game.
        /// </summary>
        public GameManager Manager { get; private set; }
        #endregion

        #region InsertCoinState InsertCoinState
        /// <summary>
        /// The insert coin state instance.
        /// </summary>
        public InsertCoinState InsertCoinState { get; private set; }
        #endregion

        #region SelectPlayerState SelectPlayerState
        /// <summary>
        /// The select player state instance.
        /// </summary>
        public SelectPlayerState SelectPlayerState { get; private set; }
        #endregion

        #region GameState GameState
        /// <summary>
        /// The game state instance.
        /// </summary>
        public GameState GameState { get; private set; }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region CoreManager()
        /// <summary>
        /// Constructs a new CoreManager object.
        /// </summary>
        private CoreManager() {
            this.Screen = null;
            this.Sound = null;
            this.Data = null;
            this.State = null;
            this.Manager = null;
            this.InsertCoinState = null;
            this.SelectPlayerState = null;
            this.GameState = null;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void Initialize(GameManager manager)
        /// <summary>
        /// Initialize the core of the game.
        /// </summary>
        /// <param name="manager">The xna manager of the game.</param>
        public void Initialize(GameManager manager) {
            this.Screen = new GameScreen();
            this.Sound = new GameSound();
            this.Data = new GameData();
            this.State = null;
            this.Manager = manager;
            this.InsertCoinState = new InsertCoinState();
            this.SelectPlayerState = new SelectPlayerState();
            this.GameState = new GameState();
        }
        #endregion

        #region void ChangeState(IState state)
        /// <summary>
        /// Changes the state of the game.
        /// </summary>
        /// <param name="state">The new state for the game.</param>
        public void ChangeState(IState state) {
            // First, release the last state.
            if(this.State != null) {
                this.State.Release();
            }
            // Second, get the new state.
            this.State = state;
            // And last, initialize the new state.
            this.State.Initialize();
        }
        #endregion
    }
}