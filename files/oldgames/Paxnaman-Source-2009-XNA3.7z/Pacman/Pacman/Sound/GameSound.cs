﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;

namespace Pacman {
    /// <summary>
    /// This class is used to manage the sound system of the game.
    /// </summary>
    public sealed class GameSound {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region Sound Beginning
        /// <summary>
        /// The sound when you begin a new game.
        /// </summary>
        public Sound Beginning { get; private set; }
        #endregion

        #region Sound Chomp
        /// <summary>
        /// The chomp sound.
        /// </summary>
        public Sound Chomp { get; private set; }
        #endregion

        #region Sound Siren
        /// <summary>
        /// The siren sound.
        /// </summary>
        public Sound Siren { get; private set; }
        #endregion

        #region Sound GhostEat
        /// <summary>
        /// The sound when you eat a ghost.
        /// </summary>
        public Sound GhostEat { get; private set; }
        #endregion

        #region Sound FruitEat
        /// <summary>
        /// The sound when you eat a fruit.
        /// </summary>
        public Sound FruitEat { get; private set; }
        #endregion

        #region Sound Death
        /// <summary>
        /// The sound when you die.
        /// </summary>
        public Sound Death { get; private set; }
        #endregion

        #region Sound ExtraPac
        /// <summary>
        /// The sound when you get an extra life.
        /// </summary>
        public Sound ExtraPac { get; private set; }
        #endregion

        #region Sound Intermission
        /// <summary>
        /// The intermission sound.
        /// </summary>
        public Sound Intermission { get; private set; }
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region GameSound()
        /// <summary>
        /// Constructs a new GameSound object.
        /// </summary>
        public GameSound() {
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region void LoadContent(Game game)
        /// <summary>
        /// Loads the sound content of the game.
        /// </summary>
        /// <param name="game">The xna game manager.</param>
        public void LoadContent(Game game) {
            this.Beginning = new Sound(game.Content.Load<SoundEffect>("beginning"));
            this.Chomp = new Sound(game.Content.Load<SoundEffect>("chomp"));
            this.Siren = new Sound(game.Content.Load<SoundEffect>("siren"));
            this.GhostEat = new Sound(game.Content.Load<SoundEffect>("ghosteat"));
            this.FruitEat = new Sound(game.Content.Load<SoundEffect>("fruiteat"));
            this.Death = new Sound(game.Content.Load<SoundEffect>("death"));
            this.ExtraPac = new Sound(game.Content.Load<SoundEffect>("extrapac"));
            this.Intermission = new Sound(game.Content.Load<SoundEffect>("intermission"));
        }
        #endregion

        #region void StopAll()
        /// <summary>
        /// Stops all the sounds of the game.
        /// </summary>
        public void StopAll() {
            this.Beginning.Stop();
            this.Chomp.Stop();
            this.Siren.Stop();
            this.GhostEat.Stop();
            this.FruitEat.Stop();
            this.Death.Stop();
            this.ExtraPac.Stop();
            this.Intermission.Stop();
        }
        #endregion
    }
}