﻿// Paxnaman, a new clone of the old classic game Puckman.
// Copyright (C) 2009  Gorka Suárez García
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;

namespace Pacman {
    /// <summary>
    /// This class is used to handle a sound.
    /// </summary>
    public sealed class Sound {
        //******************************************************************************************
        // Data
        //******************************************************************************************

        #region SoundEffect sound
        /// <summary>
        /// The stored sound buffer.
        /// </summary>
        private SoundEffect sound;
        #endregion

        #region SoundEffectInstance SoundInstance
        /// <summary>
        /// The current instance of the sound being played.
        /// </summary>
        public SoundEffectInstance SoundInstance { get; private set; }
        #endregion

        #region float Volume
        /// <summary>
        /// The volume level of the sound.
        /// </summary>
        public float Volume { get; set; } 
        #endregion

        #region float Pitch
        /// <summary>
        /// The pitch level of the sound.
        /// </summary>
        public float Pitch { get; set; } 
        #endregion

        #region float Pan
        /// <summary>
        /// The pan level of the sound.
        /// </summary>
        public float Pan { get; set; } 
        #endregion

        //******************************************************************************************
        // Constructors
        //******************************************************************************************

        #region Sound(SoundEffect sound)
        /// <summary>
        /// Constructs a new Sound object.
        /// </summary>
        public Sound(SoundEffect sound) {
            this.Volume = 0.5f;
            this.Pitch = 0.0f;
            this.Pan = 0.0f;
            this.sound = sound;
            this.SoundInstance = null;
        }
        #endregion

        //******************************************************************************************
        // Methods
        //******************************************************************************************

        #region SoundEffectInstance Play()
        /// <summary>
        /// Plays the sound.
        /// </summary>
        /// <returns>The current instance of the sound.</returns>
        public SoundEffectInstance Play() {
            if((this.SoundInstance == null) ||
               (this.SoundInstance.State != SoundState.Playing)) {
                this.SoundInstance = this.sound.Play(this.Volume, this.Pitch, this.Pan, false);
            }
            return this.SoundInstance;
        }
        #endregion

        #region SoundEffectInstance PlayLoop()
        /// <summary>
        /// Plays the sound in loop mode.
        /// </summary>
        /// <returns>The current instance of the sound.</returns>
        public SoundEffectInstance PlayLoop() {
            if((this.SoundInstance == null) ||
               (this.SoundInstance.State != SoundState.Playing)) {
                this.SoundInstance = this.sound.Play(this.Volume, this.Pitch, this.Pan, true);
            }
            return this.SoundInstance;
        }
        #endregion

        #region void Stop()
        /// <summary>
        /// Stops the sound.
        /// </summary>
        public void Stop() {
            if(this.SoundInstance != null) {
                this.SoundInstance.Stop();
            }
        }
        #endregion
    }
}