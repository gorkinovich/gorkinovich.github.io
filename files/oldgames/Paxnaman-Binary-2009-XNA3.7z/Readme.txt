If you want to play this game these are the keys:

   ESC     Exit game
   C       Insert coin
   1       Start 1 player game
   2       Start 2 players game

   Up      Move up
   Down    Move down
   Left    Move to the left
   Right   Move to the right

Enjoy the game if you can, heh.
http://gorkasg.wordpress.com/