//******************************************************************************************
// Alien Party is a space 2D shooter videogame.
// Copyright (C) 2005  Gorka Su�rez Garc�a
//
// teclas.h is part of Alien Party.
// 
// Alien Party is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// Alien Party is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Alien Party; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//******************************************************************************************
#ifndef _TECLAS_H_
#define _TECLAS_H_
//******************************************************************************************
#define NUM_TECLAS                  321
//******************************************************************************************
#define TECLA_ESC                   27	//SDLK_ESCAPE
#define TECLA_F1                    282	//SDLK_F1
#define TECLA_F2                    283	//SDLK_F2
#define TECLA_F3                    284	//SDLK_F3
#define TECLA_F4                    285	//SDLK_F4
#define TECLA_F5                    286	//SDLK_F5
#define TECLA_F6                    287	//SDLK_F6
#define TECLA_F7                    288	//SDLK_F7
#define TECLA_F8                    289	//SDLK_F8
#define TECLA_F9                    290	//SDLK_F9
#define TECLA_F10                   291	//SDLK_F10
#define TECLA_F11                   292	//SDLK_F11
#define TECLA_F12                   293	//SDLK_F12
#define TECLA_F13                   294	//SDLK_F13
#define TECLA_F14                   295	//SDLK_F14
#define TECLA_F15                   296	//SDLK_F15
#define TECLA_IMPRPANT              316	//SDLK_PRINT
#define TECLA_BLOQDESPL             302	//SDLK_SCROLLOCK
#define TECLA_PAUSA                 19	//SDLK_PAUSE
#define TECLA_BARRAINV              96	//SDLK_BACKQUOTE
#define TECLA_1                     49	//SDLK_1
#define TECLA_2                     50	//SDLK_2
#define TECLA_3                     51	//SDLK_3
#define TECLA_4                     52	//SDLK_4
#define TECLA_5                     53	//SDLK_5
#define TECLA_6                     54	//SDLK_6
#define TECLA_7                     55	//SDLK_7
#define TECLA_8                     56	//SDLK_8
#define TECLA_9                     57	//SDLK_9
#define TECLA_0                     48	//SDLK_0
#define TECLA_APOSTROFE             45	//SDLK_MINUS
#define TECLA_EXCLAMACION           61	//SDLK_EQUALS
#define TECLA_RETROCESO             8	//SDLK_BACKSPACE
#define TECLA_TABULADOR             9	//SDLK_TAB
#define TECLA_Q                     113	//SDLK_q
#define TECLA_W                     119	//SDLK_w
#define TECLA_E                     101	//SDLK_e
#define TECLA_R                     114	//SDLK_r
#define TECLA_T                     116	//SDLK_t
#define TECLA_Y                     121	//SDLK_y
#define TECLA_U                     117	//SDLK_u
#define TECLA_I                     105	//SDLK_i
#define TECLA_O                     111	//SDLK_o
#define TECLA_P                     112	//SDLK_p
#define TECLA_ABRE_CORCHETE         91	//SDLK_LEFTBRACKET
#define TECLA_CIERRA_CORCHETE       93	//SDLK_RIGHTBRACKET
#define TECLA_BLOQMAYUS             301	//SDLK_CAPSLOCK
#define TECLA_A                     97	//SDLK_a
#define TECLA_S                     115	//SDLK_s
#define TECLA_D                     100	//SDLK_d
#define TECLA_F                     102	//SDLK_f
#define TECLA_G                     103	//SDLK_g
#define TECLA_H                     104	//SDLK_h
#define TECLA_J                     106	//SDLK_j
#define TECLA_K                     107	//SDLK_k
#define TECLA_L                     108	//SDLK_l
#define TECLA_NY                    59	//SDLK_SEMICOLON
#define TECLA_ABRE_LLAVE            39	//SDLK_QUOTE
#define TECLA_CIERRA_LLAVE          92	//SDLK_BACKSLASH
#define TECLA_ENTER                 13	//SDLK_RETURN
#define TECLA_SHIFT_IZUIERDO        304	//SDLK_LSHIFT
#define TECLA_MENOR                 92	//SDLK_BACKSLASH
#define TECLA_Z                     122	//SDLK_z
#define TECLA_X                     120	//SDLK_x
#define TECLA_C                     99	//SDLK_c
#define TECLA_V                     118	//SDLK_v
#define TECLA_B                     98	//SDLK_b
#define TECLA_N                     110	//SDLK_n
#define TECLA_M                     109	//SDLK_m
#define TECLA_COMA                  44	//SDLK_COMMA
#define TECLA_PUNTO                 46	//SDLK_PERIOD
#define TECLA_MENOS                 47	//SDLK_SLASH
#define TECLA_SHIFT_DERECHO         303	//SDLK_RSHIFT
#define TECLA_CONTROL_IZQUIERDO     306	//SDLK_LCTRL
#define TECLA_ALT_IZQUIERDO         308	//SDLK_LALT
#define TECLA_ESPACIO               32	//SDLK_SPACE
#define TECLA_ALT_DERECHO           307	//SDLK_RALT
#define TECLA_CONTROL_DERECHO       305	//SDLK_RCTRL
#define TECLA_INSERTAR              277	//SDLK_INSERT
#define TECLA_INICIO                278	//SDLK_HOME
#define TECLA_REPAG                 280	//SDLK_PAGEUP
#define TECLA_SUPRIMIR              127	//SDLK_DELETE
#define TECLA_FIN                   279	//SDLK_END
#define TECLA_AVPAG                 281	//SDLK_PAGEDOWN
#define TECLA_ARRIBA                273	//SDLK_UP
#define TECLA_IZQUIERDA             276	//SDLK_LEFT
#define TECLA_ABAJO                 274	//SDLK_DOWN
#define TECLA_DERECHA               275	//SDLK_RIGHT
#define TECLA_BLOQNUM               300	//SDLK_NUMLOCK
#define TECLA_NUM_BARRA             267	//SDLK_KP_DIVIDE
#define TECLA_NUM_ASTERISCO         268	//SDLK_KP_MULTIPLY
#define TECLA_NUM_MENOS             269	//SDLK_KP_MINUS
#define TECLA_NUM_7                 263	//SDLK_KP7
#define TECLA_NUM_8                 264	//SDLK_KP8
#define TECLA_NUM_9                 265	//SDLK_KP9
#define TECLA_NUM_4                 260	//SDLK_KP4
#define TECLA_NUM_5                 261	//SDLK_KP5
#define TECLA_NUM_6                 262	//SDLK_KP6
#define TECLA_NUM_MAS               270	//SDLK_KP_PLUS
#define TECLA_NUM_1                 257	//SDLK_KP1
#define TECLA_NUM_2                 258	//SDLK_KP2
#define TECLA_NUM_3                 259	//SDLK_KP3
#define TECLA_NUM_0                 256	//SDLK_KP0
#define TECLA_NUM_PUNTO             266	//SDLK_KP_PERIOD
#define TECLA_NUM_ENTER             271	//SDLK_KP_ENTER
#define TECLA_NUM_IGUAL             272	//SDLK_KP_EQUALS
//******************************************************************************************
#define TECLA_UNKNOWN               0	//SDLK_UNKNOWN
#define TECLA_CLEAR                 12	//SDLK_CLEAR
#define TECLA_EXCLAIM               33	//SDLK_EXCLAIM
#define TECLA_QUOTEDBL              34	//SDLK_QUOTEDBL
#define TECLA_HASH                  35	//SDLK_HASH
#define TECLA_DOLLAR                36	//SDLK_DOLLAR
#define TECLA_AMPERSAND             38	//SDLK_AMPERSAND
#define TECLA_LEFTPAREN             40	//SDLK_LEFTPAREN
#define TECLA_RIGHTPAREN            41	//SDLK_RIGHTPAREN
#define TECLA_ASTERISK              42	//SDLK_ASTERISK
#define TECLA_PLUS                  43	//SDLK_PLUS
#define TECLA_COLON                 58	//SDLK_COLON
#define TECLA_LESS                  60	//SDLK_LESS	
#define TECLA_GREATER               62	//SDLK_GREATER
#define TECLA_QUESTION              63	//SDLK_QUESTION
#define TECLA_AT                    64	//SDLK_AT
#define TECLA_CARET                 94	//SDLK_CARET
#define TECLA_UNDERSCORE            95	//SDLK_UNDERSCORE	
#define TECLA_RMETA                 309	//SDLK_RMETA
#define TECLA_LMETA                 310	//SDLK_LMETA
#define TECLA_LSUPER                311	//SDLK_LSUPER  -> Left "Windows" key
#define TECLA_RSUPER                312	//SDLK_RSUPER  -> Right "Windows" key
#define TECLA_MODE                  313	//SDLK_MODE    -> "Alt Gr" key
#define TECLA_COMPOSE               314	//SDLK_COMPOSE -> Multi-key compose key
#define TECLA_HELP                  315	//SDLK_HELP	
#define TECLA_SYSREQ                317	//SDLK_SYSREQ
#define TECLA_BREAK                 318	//SDLK_BREAK
#define TECLA_MENU                  319	//SDLK_MENU
#define TECLA_EURO                  321	//SDLK_EURO
//******************************************************************************************
#endif
//******************************************************************************************
// Fin Teclas.h
//******************************************************************************************
