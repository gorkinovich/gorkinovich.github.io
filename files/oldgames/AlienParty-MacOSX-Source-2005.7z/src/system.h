//******************************************************************************************
// Alien Party is a space 2D shooter videogame.
// Copyright (C) 2005  Gorka Su�rez Garc�a
//
// system.h is part of Alien Party.
// 
// Alien Party is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// Alien Party is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Alien Party; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//******************************************************************************************
#ifndef _SYSTEM_H_
#define _SYSTEM_H_
//******************************************************************************************
void Salir (const char * mensaje, int error);
void InitJuego (tNucleo * Nucleo, int winmode, int width, int height, int bpp);
void FinJuego (tNucleo * Nucleo);

//==========================================================================================
// Entrada bajo SDL.
//==========================================================================================
void ActualizarEntrada (tNucleo * Nucleo);
int EstadoTecla (tNucleo * Nucleo, int key);
int EstadoTeclado (tNucleo * Nucleo);
int EstadoRaton (tNucleo * Nucleo, int but);
int EstaRatonEn (tNucleo * Nucleo, SDL_Rect * area);

//==========================================================================================
// Rutinas para el manejo de los buffers en SDL.
//==========================================================================================
int ActualizarPantalla (tNucleo * Nucleo);
int PonerImagen (tNucleo * Nucleo, SDL_Surface * imgsrc, SDL_Rect * destino, SDL_Rect * origen);
int PonerColorClave (SDL_Surface * img, Uint32 color);

//==========================================================================================
// Funciones del control del tiempo
//==========================================================================================
void Delay (Uint32 ms);
Uint32 DarTicks (void);

//==========================================================================================
// Funciones para pintar cadenas
//==========================================================================================
void PintarCadena (tNucleo * Nucleo, int fuente, int x, int y, const char * cadena);

//******************************************************************************************
#endif
//******************************************************************************************
// Fin system.h
//******************************************************************************************
