//******************************************************************************************
// Alien Party is a space 2D shooter videogame.
// Copyright (C) 2005  Gorka Su�rez Garc�a
//
// system.c is part of Alien Party.
// 
// Alien Party is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// Alien Party is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Alien Party; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//******************************************************************************************
#include "invaders.h"
#include "system.h"
#include "teclas.h"
//******************************************************************************************
// Rutinas relacionadas con la SDL.
//******************************************************************************************
void Salir (const char * mensaje, int error)
{
	//--------------------------------------------------------------------------------------
	// Mandamos el mensaje de error por pantalla.
	//--------------------------------------------------------------------------------------
	printf("%s", mensaje);
	printf("%s\n", SDL_GetError());
	
	//--------------------------------------------------------------------------------------
	// Hacemos que el rat�n est� mostrado y desactivamos la SDL.
	//--------------------------------------------------------------------------------------
	SDL_ShowCursor(SDL_ENABLE);
	SDL_Quit();
	
	//--------------------------------------------------------------------------------------
	// Salimos devolviendo el c�digo de error.
	//--------------------------------------------------------------------------------------
	exit(error);
}
//==========================================================================================
SDL_Surface * CrearBufferPantalla (int winmode, char * title, int width, int height, int bpp)
{
	SDL_Surface * BufferPantalla;
	Uint32 flags;

	//--------------------------------------------------------------------------------------
	// Inicializamos la libreria SDL.
	//--------------------------------------------------------------------------------------
	if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_TIMER) == FAIL)
		Salir("No se puede iniciar la librer�a SDL.\n", -1);

	//--------------------------------------------------------------------------------------
	// Elegimos los flags para pantalla completa o modo ventana.
	//--------------------------------------------------------------------------------------
	if(winmode)
		flags = (SDL_HWSURFACE|SDL_DOUBLEBUF);
	else
		flags = (SDL_HWSURFACE|SDL_DOUBLEBUF|SDL_FULLSCREEN);

	//--------------------------------------------------------------------------------------
	// Comprobamos si est� soportada la resoluci�n que queremos.
	//--------------------------------------------------------------------------------------
	if(!SDL_VideoModeOK(width, height, bpp, flags))
		Salir("Modo de video no soportado.\n", -2);

	//--------------------------------------------------------------------------------------
	// Cambiamos la resoluci�n de la pantalla.
	//--------------------------------------------------------------------------------------
	BufferPantalla = SDL_SetVideoMode(width, height, bpp, flags);

	if(BufferPantalla == NULL)
		Salir("No se pudo activar el modo de video.\n", -3);

	//--------------------------------------------------------------------------------------
	// Cambiamos el t�tulo de la ventana.
	//--------------------------------------------------------------------------------------
	if(winmode)
		SDL_WM_SetCaption(title, NULL);

	//--------------------------------------------------------------------------------------
	// Devolvemos el buffer de pantalla creado.
	//--------------------------------------------------------------------------------------
	return BufferPantalla;
}
//==========================================================================================
void ActivarEntrada (tNucleo * Nucleo)
{
	//--------------------------------------------------------------------------------------
	// Activamos el sistema de entrada del SDL.
	//--------------------------------------------------------------------------------------
	SDL_PumpEvents();
	Nucleo->Teclado = SDL_GetKeyState(NULL);

	//--------------------------------------------------------------------------------------
	// Inicializamos la estructura del rat�n.
	//--------------------------------------------------------------------------------------
	Nucleo->Raton.x  = 0;
	Nucleo->Raton.y  = 0;
	Nucleo->Raton.rx = 0;
	Nucleo->Raton.ry = 0;
	Nucleo->Raton.lb = FALSE;
	Nucleo->Raton.cb = FALSE;
	Nucleo->Raton.rb = FALSE;
	Nucleo->Raton.wu = FALSE;
	Nucleo->Raton.wd = FALSE;
}
//==========================================================================================
void CargarTexturas (tNucleo * Nucleo)
{
	//--------------------------------------------------------------------------------------
	// Cargamos las texturas.
	//--------------------------------------------------------------------------------------
	Nucleo->Texturas.imgMenu = SDL_LoadBMP("gfx/menu.bmp");
	if(Nucleo->Texturas.imgMenu == NULL)
		Salir("No se pudo cargar la imagen menu.bmp.\n", -4);

	Nucleo->Texturas.imgPuntuaciones = SDL_LoadBMP("gfx/puntuaciones.bmp");
	if(Nucleo->Texturas.imgPuntuaciones == NULL)
		Salir("No se pudo cargar la imagen puntuaciones.bmp.\n", -4);

	Nucleo->Texturas.imgFondo = SDL_LoadBMP("gfx/fondo.bmp");
	if(Nucleo->Texturas.imgFondo == NULL)
		Salir("No se pudo cargar la imagen fondo.bmp.\n", -4);

	Nucleo->Texturas.imgOpcion01 = SDL_LoadBMP("gfx/opcion01.bmp");
	if(Nucleo->Texturas.imgOpcion01 == NULL)
		Salir("No se pudo cargar la imagen opcion01.bmp.\n", -4);

	Nucleo->Texturas.imgOpcion02 = SDL_LoadBMP("gfx/opcion02.bmp");
	if(Nucleo->Texturas.imgOpcion02 == NULL)
		Salir("No se pudo cargar la imagen opcion02.bmp.\n", -4);

	Nucleo->Texturas.imgOpcion03 = SDL_LoadBMP("gfx/opcion03.bmp");
	if(Nucleo->Texturas.imgOpcion03 == NULL)
		Salir("No se pudo cargar la imagen opcion03.bmp.\n", -4);

	Nucleo->Texturas.imgOpcion04 = SDL_LoadBMP("gfx/opcion04.bmp");
	if(Nucleo->Texturas.imgOpcion04 == NULL)
		Salir("No se pudo cargar la imagen opcion04.bmp.\n", -4);

	Nucleo->Texturas.imgOpcion05 = SDL_LoadBMP("gfx/opcion05.bmp");
	if(Nucleo->Texturas.imgOpcion05 == NULL)
		Salir("No se pudo cargar la imagen opcion05.bmp.\n", -4);

	Nucleo->Texturas.imgOpcion06 = SDL_LoadBMP("gfx/opcion06.bmp");
	if(Nucleo->Texturas.imgOpcion06 == NULL)
		Salir("No se pudo cargar la imagen opcion06.bmp.\n", -4);

	Nucleo->Texturas.imgSpike = SDL_LoadBMP("gfx/spike.bmp");
	if(Nucleo->Texturas.imgSpike == NULL)
		Salir("No se pudo cargar la imagen spike.bmp.\n", -4);

	Nucleo->Texturas.imgMalosos = SDL_LoadBMP("gfx/malosos.bmp");
	if(Nucleo->Texturas.imgMalosos == NULL)
		Salir("No se pudo cargar la imagen malosos.bmp.\n", -4);

	Nucleo->Texturas.imgDisparos = SDL_LoadBMP("gfx/disparos.bmp");
	if(Nucleo->Texturas.imgDisparos == NULL)
		Salir("No se pudo cargar la imagen disparos.bmp.\n", -4);

	//--------------------------------------------------------------------------------------
	// Ponemos el color clave a las texturas que necesitemos.
	//--------------------------------------------------------------------------------------
	if(SDL_SetColorKey(Nucleo->Texturas.imgSpike, SDL_SRCCOLORKEY, CCROSA) == FAIL)
		Salir("No se pudo poner el color clave para spike.bmp.\n", -4);
	
	if(SDL_SetColorKey(Nucleo->Texturas.imgMalosos, SDL_SRCCOLORKEY, CCROSA) == FAIL)
		Salir("No se pudo poner el color clave para malosos.bmp.\n", -4);
	
	if(SDL_SetColorKey(Nucleo->Texturas.imgDisparos, SDL_SRCCOLORKEY, CCROSA) == FAIL)
		Salir("No se pudo poner el color clave para disparos.bmp.\n", -4);

	//--------------------------------------------------------------------------------------
	// Inicializamos las regiones que hay dentro de las texturas.
	//--------------------------------------------------------------------------------------

	//Malo verde
	Nucleo->Texturas.Malosos[0].x =  0;
	Nucleo->Texturas.Malosos[0].y =  0;
	Nucleo->Texturas.Malosos[0].h = 64;
	Nucleo->Texturas.Malosos[0].w = 64;
	
	//Malo azul
	Nucleo->Texturas.Malosos[1].x = 64;
	Nucleo->Texturas.Malosos[1].y =  0;
	Nucleo->Texturas.Malosos[1].h = 64;
	Nucleo->Texturas.Malosos[1].w = 64;

	//--------------------------------------------------------------------------------------
	//Disparo verde izquierdo
	Nucleo->Texturas.Disparos[0].x =  0;
	Nucleo->Texturas.Disparos[0].y =  0;
	Nucleo->Texturas.Disparos[0].h = 32;
	Nucleo->Texturas.Disparos[0].w =  8;
	
	//Disparo verde derecho
	Nucleo->Texturas.Disparos[1].x =  8;
	Nucleo->Texturas.Disparos[1].y =  0;
	Nucleo->Texturas.Disparos[1].h = 32;
	Nucleo->Texturas.Disparos[1].w =  8;
	
	//Disparo rojo izquierdo
	Nucleo->Texturas.Disparos[2].x = 16;
	Nucleo->Texturas.Disparos[2].y =  0;
	Nucleo->Texturas.Disparos[2].h = 32;
	Nucleo->Texturas.Disparos[2].w =  8;
	
	//Disparo rojo derecho
	Nucleo->Texturas.Disparos[3].x = 24;
	Nucleo->Texturas.Disparos[3].y =  0;
	Nucleo->Texturas.Disparos[3].h = 32;
	Nucleo->Texturas.Disparos[3].w =  8;
	
	//Bomba para abajo
	Nucleo->Texturas.Disparos[4].x = 32;
	Nucleo->Texturas.Disparos[4].y =  0;
	Nucleo->Texturas.Disparos[4].h = 20;
	Nucleo->Texturas.Disparos[4].w =  8;
	
	//Bomba para arriba
	Nucleo->Texturas.Disparos[5].x = 40;
	Nucleo->Texturas.Disparos[5].y = 12;
	Nucleo->Texturas.Disparos[5].h = 20;
	Nucleo->Texturas.Disparos[5].w =  8;
	
	//Rayo de energia
	Nucleo->Texturas.Disparos[6].x = 48;
	Nucleo->Texturas.Disparos[6].y =  0;
	Nucleo->Texturas.Disparos[6].h = 32;
	Nucleo->Texturas.Disparos[6].w =  8;
	
	//Rayo de energia
	Nucleo->Texturas.Disparos[7].x = 56;
	Nucleo->Texturas.Disparos[7].y =  0;
	Nucleo->Texturas.Disparos[7].h = 32;
	Nucleo->Texturas.Disparos[7].w =  8;

	//--------------------------------------------------------------------------------------
	// Opcion Nueva Partida / Continuar Partida (255, 118)
	Nucleo->Texturas.Opciones[0].x = 255;
	Nucleo->Texturas.Opciones[0].y = 118;
	Nucleo->Texturas.Opciones[0].h =  59;
	Nucleo->Texturas.Opciones[0].w = 299;

	// Opcion Opciones (255, 215)
	Nucleo->Texturas.Opciones[1].x = 255;
	Nucleo->Texturas.Opciones[1].y = 215;
	Nucleo->Texturas.Opciones[1].h =  59;
	Nucleo->Texturas.Opciones[1].w = 299;

	// Opcion Puntuaciones (255, 293)
	Nucleo->Texturas.Opciones[2].x = 255;
	Nucleo->Texturas.Opciones[2].y = 293;
	Nucleo->Texturas.Opciones[2].h =  59;
	Nucleo->Texturas.Opciones[2].w = 299;

	// Opcion Salir (255, 410)
	Nucleo->Texturas.Opciones[3].x = 255;
	Nucleo->Texturas.Opciones[3].y = 410;
	Nucleo->Texturas.Opciones[3].h =  59;
	Nucleo->Texturas.Opciones[3].w = 299;
}
//==========================================================================================
void CargarFuentes (tNucleo * Nucleo)
{
	int posiciones[MAXFNT] = {9, 9, 9, 8, 10, 9, 9, 9, 9, 9, 10, 8, 10, 10, 9, 8, 11, 11, 8,
							  9, 9, 7, 13, 10, 11, 7, 13, 8, 10, 11, 10, 8, 15, 10, 9, 11, 10};
	int i;

	//--------------------------------------------------------------------------------------
	// Cargamos las imagenes que contienen las fuentes.
	//--------------------------------------------------------------------------------------
	Nucleo->Fuentes.imgFuente01 = SDL_LoadBMP("gfx/fuente01.bmp");
	if(Nucleo->Fuentes.imgFuente01 == NULL)
		Salir("No se pudo cargar la imagen fuente01.bmp.\n", -5);

	Nucleo->Fuentes.imgFuente02 = SDL_LoadBMP("gfx/fuente02.bmp");
	if(Nucleo->Fuentes.imgFuente02 == NULL)
		Salir("No se pudo cargar la imagen fuente02.bmp.\n", -5);
	
	//--------------------------------------------------------------------------------------
	// Le activamos el color clave a cada una.
	//--------------------------------------------------------------------------------------
	if(SDL_SetColorKey(Nucleo->Fuentes.imgFuente01, SDL_SRCCOLORKEY, CCROSA) == FAIL)
		Salir("No se pudo poner el color clave para fuente01.bmp.\n", -5);
	
	if(SDL_SetColorKey(Nucleo->Fuentes.imgFuente02, SDL_SRCCOLORKEY, CCROSA) == FAIL)
		Salir("No se pudo poner el color clave para fuente02.bmp.\n", -5);
	
	//--------------------------------------------------------------------------------------
	// E inicializamos el vector de las posiciones de las letras en la textura.
	//--------------------------------------------------------------------------------------
	Nucleo->Fuentes.Fuente[0].x = 0;
	Nucleo->Fuentes.Fuente[0].y = 0;
	Nucleo->Fuentes.Fuente[0].w = posiciones[0];
	Nucleo->Fuentes.Fuente[0].h = 16;

	for(i = 1; i < MAXFNT; i++)
	{
		Nucleo->Fuentes.Fuente[i].x = Nucleo->Fuentes.Fuente[i-1].x + Nucleo->Fuentes.Fuente[i-1].w;
		Nucleo->Fuentes.Fuente[i].y = 0;
		Nucleo->Fuentes.Fuente[i].w = posiciones[i];
		Nucleo->Fuentes.Fuente[i].h = 16;
	}
}
//==========================================================================================
void CargarPuntuaciones (tNucleo * Nucleo)
{
	FILE * fichero;
	int i;

	//--------------------------------------------------------------------------------------
	// Abrimos el fichero.
	//--------------------------------------------------------------------------------------
	fichero = fopen("puntos.dat", "rb");

	//--------------------------------------------------------------------------------------
	// Si no existe creamos unas puntuaciones por defecto.
	//--------------------------------------------------------------------------------------
	if(fichero == NULL)
	{
		for(i = 0; i < MAXPUN; i++)
		{
			strcpy(Nucleo->Puntuaciones[i].nombre, "NADIE");
			Nucleo->Puntuaciones[i].puntos = 0;
		}
	}
	//--------------------------------------------------------------------------------------
	// Si existe lo cargamos de golpe y lo cerramos.
	//--------------------------------------------------------------------------------------
	else
	{
		fread(Nucleo->Puntuaciones, sizeof(tPuntuacion), MAXPUN, fichero);
		fclose(fichero);
	}
}
//==========================================================================================
void SalvarPuntuaciones (tNucleo * Nucleo)
{
	FILE * fichero;

	//--------------------------------------------------------------------------------------
	// Abrimos el fichero.
	//--------------------------------------------------------------------------------------
	fichero = fopen("puntos.dat", "wb");

	//--------------------------------------------------------------------------------------
	// Si no da fallo guardamos las puntuaciones de golpe y lo cerramos.
	//--------------------------------------------------------------------------------------
	if(fichero != NULL)
	{
		fwrite(Nucleo->Puntuaciones, sizeof(tPuntuacion), MAXPUN, fichero);
		fclose(fichero);
	}
}
//==========================================================================================
void InitJuego (tNucleo * Nucleo, int winmode, int width, int height, int bpp)
{
	//--------------------------------------------------------------------------------------
	// Creamos el buffer primario de la pantalla.
	//--------------------------------------------------------------------------------------
	Nucleo->BufferPantalla = CrearBufferPantalla(winmode, "Alien Party", width, height, bpp);

	//--------------------------------------------------------------------------------------
	// Activamos la entrada.
	//--------------------------------------------------------------------------------------
	ActivarEntrada(Nucleo);

	//--------------------------------------------------------------------------------------
	// Cargamos las texturas.
	//--------------------------------------------------------------------------------------
	CargarTexturas(Nucleo);

	//--------------------------------------------------------------------------------------
	// Cargamos las fuentes.
	//--------------------------------------------------------------------------------------
	CargarFuentes(Nucleo);

	//--------------------------------------------------------------------------------------
	// Cargamos las puntuaciones
	//--------------------------------------------------------------------------------------
	CargarPuntuaciones(Nucleo);

	//--------------------------------------------------------------------------------------
	// E inicalizamos algunos datos importantes para el programa.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.EstadoDelJuego = ESTMNU; // El juego est� en el estado de MEN�.
	Nucleo->Partida.EstadoJugador  = MUERTO; // No hay ninguna partida iniciada.
}
//==========================================================================================
void FinJuego (tNucleo * Nucleo)
{
	//--------------------------------------------------------------------------------------
	// Salvamos las puntuaciones.
	//--------------------------------------------------------------------------------------
	SalvarPuntuaciones(Nucleo);

	//--------------------------------------------------------------------------------------
	// Liberamos el espacio ocupado por las texturas.
	//--------------------------------------------------------------------------------------
	SDL_FreeSurface(Nucleo->Texturas.imgMenu);
	SDL_FreeSurface(Nucleo->Texturas.imgPuntuaciones);
	SDL_FreeSurface(Nucleo->Texturas.imgFondo);
	SDL_FreeSurface(Nucleo->Texturas.imgOpcion01);
	SDL_FreeSurface(Nucleo->Texturas.imgOpcion02);
	SDL_FreeSurface(Nucleo->Texturas.imgOpcion03);
	SDL_FreeSurface(Nucleo->Texturas.imgOpcion04);
	SDL_FreeSurface(Nucleo->Texturas.imgOpcion05);
	SDL_FreeSurface(Nucleo->Texturas.imgOpcion06);
	SDL_FreeSurface(Nucleo->Texturas.imgSpike);
	SDL_FreeSurface(Nucleo->Texturas.imgMalosos);
	SDL_FreeSurface(Nucleo->Texturas.imgDisparos);

	SDL_FreeSurface(Nucleo->Fuentes.imgFuente01);
	SDL_FreeSurface(Nucleo->Fuentes.imgFuente02);

	//--------------------------------------------------------------------------------------
	// Mostramos el cursor del rat�n y desactivamos la SDL.
	//--------------------------------------------------------------------------------------
	SDL_ShowCursor(SDL_ENABLE);
	SDL_Quit();
}
//==========================================================================================
// Entrada bajo SDL.
//==========================================================================================
void ActualizarEntrada (tNucleo * Nucleo)
{
	Uint8 Botones;

	//--------------------------------------------------------------------------------------
	// Actualiza la entrada bajo SDL.
	//--------------------------------------------------------------------------------------
	SDL_PumpEvents();

	//--------------------------------------------------------------------------------------
	// Actualiza el estado del rat�n.
	//--------------------------------------------------------------------------------------
	Botones = SDL_GetMouseState(&(Nucleo->Raton.x), &(Nucleo->Raton.y));
	SDL_GetRelativeMouseState(&(Nucleo->Raton.rx), &(Nucleo->Raton.ry));
	//SDL_BUTTON(X) -> (SDL_PRESSED<<(X-1))
	Nucleo->Raton.lb = ((Botones & SDL_BUTTON(1)) == 1); //SDL_BUTTON_LEFT      1
	Nucleo->Raton.cb = ((Botones & SDL_BUTTON(2)) == 1); //SDL_BUTTON_MIDDLE    2
	Nucleo->Raton.rb = ((Botones & SDL_BUTTON(3)) == 1); //SDL_BUTTON_RIGHT     3
	Nucleo->Raton.wu = ((Botones & SDL_BUTTON(4)) == 1); //SDL_BUTTON_WHEELUP   4
	Nucleo->Raton.wd = ((Botones & SDL_BUTTON(5)) == 1); //SDL_BUTTON_WHEELDOWN 5
}
//==========================================================================================
int EstadoTecla (tNucleo * Nucleo, int key)
{
	//--------------------------------------------------------------------------------------
	// Devuelve si una tecla est� pulsada o no.
	//--------------------------------------------------------------------------------------
	return (Nucleo->Teclado[key] == TRUE);
}
//==========================================================================================
int EstadoTeclado (tNucleo * Nucleo)
{
	register i;

	//--------------------------------------------------------------------------------------
	// Devuelve si se ha pulsado alguna tecla o no. Descartando algunas como el BloqDespl,
	// el BlogMayus, y el BlooqNum. Si encuentra alguna que est� pulsada devuelve
	// directamente cierto.
	//--------------------------------------------------------------------------------------
	for(i = 0; i < NUM_TECLAS; i++)
		if((i != TECLA_BLOQDESPL) && (i != TECLA_BLOQMAYUS) && (i != TECLA_BLOQNUM))
			if(Nucleo->Teclado[i] == TRUE)
				return TRUE;

	//--------------------------------------------------------------------------------------
	// Si ninguna estaba pulsada se devuelve falso.
	//--------------------------------------------------------------------------------------
	return FALSE;
}
//==========================================================================================
int EstadoRaton (tNucleo * Nucleo, int but)
{
	//--------------------------------------------------------------------------------------
	// Devuelve si est� pulsado el bot�n indicado en but, del rat�n.
	//--------------------------------------------------------------------------------------
	switch(but)
	{
	case BOTON_IZQUIERDO:
		return Nucleo->Raton.lb;

	case BOTON_CENTRAL:
		return Nucleo->Raton.cb;

	case BOTON_DERECHO:
		return Nucleo->Raton.rb;

	case RUEDA_ARRIBA:
		return Nucleo->Raton.wu;

	case RUEDA_ABAJO:
		return Nucleo->Raton.wd;

	default:
		return FALSE;
	}

}
//==========================================================================================
int EstaRatonEn (tNucleo * Nucleo, SDL_Rect * area)
{
	//--------------------------------------------------------------------------------------
	// Calcula si el rat�n se encuentra dentro de un area indicada.
	//--------------------------------------------------------------------------------------
	int maxx = area->x + area->w - 1;
	int maxy = area->y + area->h - 1;

	return ((Nucleo->Raton.y >= area->y) && (Nucleo->Raton.x >= area->x) &&
			(Nucleo->Raton.y <= maxy) && (Nucleo->Raton.x <= maxx));
}
//==========================================================================================
// Rutinas para el manejo de los buffers en SDL.
//==========================================================================================
int ActualizarPantalla (tNucleo * Nucleo)
{
	//--------------------------------------------------------------------------------------
	// Actualiza el buffer de la pantalla.
	//--------------------------------------------------------------------------------------
	return SDL_Flip(Nucleo->BufferPantalla);
}
//==========================================================================================
int PonerImagen (tNucleo * Nucleo, SDL_Surface * imgsrc, SDL_Rect * destino, SDL_Rect * origen)
{
	//--------------------------------------------------------------------------------------
	// Pega en el area destino del buffer de pantalla, el area origen del buffer imgsrc.
	//--------------------------------------------------------------------------------------
	return SDL_BlitSurface(imgsrc, origen, Nucleo->BufferPantalla, destino);
}
//==========================================================================================
int PonerColorClave (SDL_Surface * img, Uint32 color)
{
	//--------------------------------------------------------------------------------------
	// Activa el color clave para el buffer que le indiquemos.
	//--------------------------------------------------------------------------------------
	return SDL_SetColorKey(img, SDL_SRCCOLORKEY, color);
}
//==========================================================================================
// Funciones del control del tiempo
//==========================================================================================
void Delay (Uint32 ms)
{
	//--------------------------------------------------------------------------------------
	// Suspende la ejecuci�n del programa durante los milisegundos indicados.
	//--------------------------------------------------------------------------------------
	SDL_Delay(ms);
}
//------------------------------------------------------------------------------------------
Uint32 DarTicks (void)
{
	//--------------------------------------------------------------------------------------
	// Devuelve el n�mero de milisegundos transcurridos desde el inicio de la ejecuci�n de
	// la aplicaci�n actual.
	//--------------------------------------------------------------------------------------
	return SDL_GetTicks();
}
//==========================================================================================
// Funciones para pintar cadenas
//==========================================================================================
void PintarCadena (tNucleo * Nucleo, int fuente, int x, int y, const char * cadena)
{
	int i, car, len;
	SDL_Surface * imgFuente;
	SDL_Rect destino;

	//--------------------------------------------------------------------------------------
	// Tomamos el tama�o actual de la cadena.
	//--------------------------------------------------------------------------------------
	len = strlen(cadena);

	//--------------------------------------------------------------------------------------
	// Elegimos la fuente.
	//--------------------------------------------------------------------------------------
	if(fuente == 1)
	{
		imgFuente = Nucleo->Fuentes.imgFuente01;
	}
	else if(fuente == 2)
	{
		imgFuente = Nucleo->Fuentes.imgFuente02;
	}

	//--------------------------------------------------------------------------------------
	// Y vamos caracter por caracter mirando que tenemos que pintar.
	//--------------------------------------------------------------------------------------
	for(i = 0; i < len; i++)
	{
		//----------------------------------------------------------------------------------
		// Miramos a ver que tipo de caracter, y en base a ello, calculamos su posici�n
		// en el vector de regiones.
		//----------------------------------------------------------------------------------
		if((cadena[i] >= '0') && (cadena[i] <= '9')) //Es digito
		{
			car = cadena[i] - '0';
		}
		else if((cadena[i] == '�') || (cadena[i] <= '�')) //Es una e�e
		{
			car = MAXFNT - 1;
		}
		else if((cadena[i] >= 'a') && (cadena[i] <= 'z'))
		{
			car = cadena[i] - 'a' + 10;
		}
		else if((cadena[i] >= 'A') && (cadena[i] <= 'Z'))
		{
			car = cadena[i] - 'A' + 10;
		}
		else
		{
			car = FAIL;
		}

		//----------------------------------------------------------------------------------
		// Si no es un espacio en blanco o un simbolo raro, pintamos en la pantalla el
		// caracter que ha sido seleccionado.
		//----------------------------------------------------------------------------------
		if((cadena[i] != ' ') && (car != FAIL))
		{
			destino.x = x;
			destino.y = y;
			destino.w = Nucleo->Fuentes.Fuente[car].w;
			destino.h = Nucleo->Fuentes.Fuente[car].h;
			x += Nucleo->Fuentes.Fuente[car].w;

			SDL_BlitSurface(imgFuente, &(Nucleo->Fuentes.Fuente[car]),
							Nucleo->BufferPantalla, &destino);
		}
		else
		{
			x += 9;
		}
	}
}
//******************************************************************************************
// Fin system.c
//******************************************************************************************
