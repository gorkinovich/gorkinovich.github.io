//******************************************************************************************
// Alien Party is a space 2D shooter videogame.
// Copyright (C) 2005  Gorka Su�rez Garc�a
//
// logica.c is part of Alien Party.
// 
// Alien Party is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// Alien Party is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Alien Party; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//******************************************************************************************
#include "invaders.h"
#include "logica.h"
#include "system.h"
#include "teclas.h"
//******************************************************************************************
// Gesti�n de los disparos.
//******************************************************************************************
void CrearDisparo (tNucleo * Nucleo, int x, int y, int vel, int tex, int danyo, int bando)
{
	tDisparo * nuevo;

	//--------------------------------------------------------------------------------------
	// Creamos un nuevo nodo en la memoria, para almacenar el nuevo disparo.
	//--------------------------------------------------------------------------------------
	nuevo = (tDisparo *) malloc(sizeof(tDisparo));

	//--------------------------------------------------------------------------------------
	// Si no falla, lo a�adimos a la lista de disparos.
	//--------------------------------------------------------------------------------------
	if(nuevo != NULL)
	{
		//----------------------------------------------------------------------------------
		// Metemos los valores del nodo.
		//----------------------------------------------------------------------------------
		nuevo->x     = x;
		nuevo->y     = y;
		nuevo->vel   = vel;
		nuevo->tex   = tex;
		nuevo->danyo = danyo;
		nuevo->bando = bando;

		//----------------------------------------------------------------------------------
		// No olvidando inicializar los punteros, con el anterior a nulo, y el siguiente
		// apuntando al primer nodo de la lista. Ya que el actual pasar� a ser el primero.
		//----------------------------------------------------------------------------------
		nuevo->ant = NULL;
		nuevo->sig = Nucleo->Partida.Disparos;

		//----------------------------------------------------------------------------------
		// En caso de que el primer nodo no sea nulo, hacemos que su anterior, apunte al
		// nuevo nodo creado.
		//----------------------------------------------------------------------------------
		if(Nucleo->Partida.Disparos != NULL)
			Nucleo->Partida.Disparos->ant = nuevo;

		//----------------------------------------------------------------------------------
		// Y finalmente cambiamos el valor del puntero raiz de la lista.
		//----------------------------------------------------------------------------------
		Nucleo->Partida.Disparos = nuevo;
	}
}
//------------------------------------------------------------------------------------------
void DestruirDisparo (tNucleo * Nucleo, tDisparo * disparo)
{
	//--------------------------------------------------------------------------------------
	// Si el puntero raiz no es nulo, y el parametro disparo tampoco, continuamos.
	//--------------------------------------------------------------------------------------
	if((Nucleo->Partida.Disparos != NULL) && (disparo != NULL))
	{
		//----------------------------------------------------------------------------------
		// Si ambos apuntan al mismo lugar, es porque vamos a matar al nodo apuntado por el
		// nodo ra�z. Por lo que el nodo raiz tendr� que ser apuntado a su siguiente, y en
		// caso de no ser nulo, su actual anterior apuntar� a nulo.
		//----------------------------------------------------------------------------------
		if(Nucleo->Partida.Disparos == disparo)
		{
			Nucleo->Partida.Disparos = Nucleo->Partida.Disparos->sig;

			if(Nucleo->Partida.Disparos != NULL)
				Nucleo->Partida.Disparos->ant = NULL;
		}
		//----------------------------------------------------------------------------------
		// Como no es el nodo raiz no tenemos que preocuparnos por el, tan solo de que el
		// nodo anterior del siguiente nodo, apunte al anterior del actual. Y que el nodo
		// siguiente del anterior nodo, apunte al siguiente del actual.
		//----------------------------------------------------------------------------------
		else
		{
			if(disparo->sig != NULL)
				disparo->sig->ant = disparo->ant;
				
			if(disparo->ant != NULL)
				disparo->ant->sig = disparo->sig;
		}

		//----------------------------------------------------------------------------------
		// Liberamos el espacio ocupado por el nodo v�ctima.
		//----------------------------------------------------------------------------------
		free(disparo);
	}
}
//------------------------------------------------------------------------------------------
int Colisiona (tNucleo * Nucleo, int nave, tDisparo * disparo)
{
	//--------------------------------------------------------------------------------------
	// Si es un disparo del jugador, nos saltamos la condici�n, en caso de que la nave sea
	// la del propio jugador. Porque sino nos dar�a colisi�n seg�n fueramos lanzando los
	// disparos.
	//--------------------------------------------------------------------------------------
	if(disparo->bando == DSPJUG)
	{
		if(nave == 0)
			return FALSE;
		else
		{
			//------------------------------------------------------------------------------
			// Si la coordenada x esta entre la m�nima y m�xima coordenada x de la nave, y
			// la coordenada y est� entre la m�nima y la (m�xima / 2) coordenada y,
			// existir� entonces una colisi�n.
			//------------------------------------------------------------------------------
			if((Nucleo->Partida.Naves[nave].x <= disparo->x) &&
				(disparo->x <= Nucleo->Partida.Naves[nave].x + NAVESANCHO) &&
				(Nucleo->Partida.Naves[nave].y <= disparo->y) &&
				(disparo->y <= Nucleo->Partida.Naves[nave].y + NAVESALTOE))
				return TRUE;
			else
				return FALSE;
		}
	}
	//--------------------------------------------------------------------------------------
	// Sino, es un disparo enemigo, y para evitar que se mueran ellos mismos, o se maten
	// entre ellos, si la nave no es la del jugador, no surtir� efecto.
	//--------------------------------------------------------------------------------------
	else
	{
		if(nave != 0)
			return FALSE;
		else
		{
			//------------------------------------------------------------------------------
			// Si la coordenada x esta entre la m�nima y m�xima coordenada x de la nave, y
			// la coordenada y est� entre la m�nima coordenada y, hay colisi�n.
			//------------------------------------------------------------------------------
			if((Nucleo->Partida.Naves[nave].x <= disparo->x) &&
				(disparo->x <= Nucleo->Partida.Naves[nave].x + NAVESANCHO) &&
				(Nucleo->Partida.Naves[nave].y <= disparo->y) &&
				(disparo->y <= Nucleo->Partida.Naves[nave].y + NAVESALTO))
				return TRUE;
			else
				return FALSE;
		}
	}
}
//------------------------------------------------------------------------------------------
void EliminarDisparos (tNucleo * Nucleo)
{
	tDisparo * aux;

	//--------------------------------------------------------------------------------------
	// Mientras queden disparos en la lista, seleccionamos el actual, para hacer que el
	// nodo raiz pase a apuntar al siguiente, y as� liberamos el actual sin peligro.
	//--------------------------------------------------------------------------------------
	while(Nucleo->Partida.Disparos != NULL)
	{
		aux = Nucleo->Partida.Disparos;
		Nucleo->Partida.Disparos = Nucleo->Partida.Disparos->sig;
		free(aux);
	}

	//--------------------------------------------------------------------------------------
	// Finalmente el nodo raiz apuntar� a nulo.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.Disparos = NULL;
}
//******************************************************************************************
// Rutinas del inicio de fase.
//******************************************************************************************
void InitPartida (tNucleo * Nucleo)
{
	int i, j, k = 1;

	//--------------------------------------------------------------------------------------
	// Inicializamos los datos del estado del juego.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.EstadoDelJuego = ESTJUG;
	Nucleo->Partida.EstadoJugador  = VIVO;

	//--------------------------------------------------------------------------------------
	// Inicializamos el nombre y la puntuaci�n del jugador.
	//--------------------------------------------------------------------------------------
	strcpy(Nucleo->Partida.Nombre, "");
	Nucleo->Partida.Puntos = 0;

	//--------------------------------------------------------------------------------------
	// Inicializamos la rapidez del juego.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.TiempoAcumulado = 0;
	Nucleo->Partida.CuentaMax = CNTMAXINI;
	Nucleo->Partida.CuentaAct = 0;

	//--------------------------------------------------------------------------------------
	// Inicializamos la direcci�n de avance de los enemigos y la lista de disparos.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.Direccion = DIRIZQ;

	Nucleo->Partida.Disparos = NULL;

	//--------------------------------------------------------------------------------------
	// Inicializamos la nave del jugador.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.Naves[0].x    = JUGXINI;
	Nucleo->Partida.Naves[0].y    = JUGYINI;
	Nucleo->Partida.Naves[0].vida = JUGVIDINI;
	Nucleo->Partida.Naves[0].tex  = JUGTEXINI;
	Nucleo->Partida.Naves[0].frec = JUGFRCINI;
	Nucleo->Partida.Naves[0].arma = LASER1;

	//--------------------------------------------------------------------------------------
	// Inicalizamos las naves enemigas.
	//--------------------------------------------------------------------------------------
	for(i = 0; i < 4; i++)
	{
		for(j = 0; j < 8; j++)
		{
			Nucleo->Partida.Naves[k].x = ENEXBASE + (ENEXSEP * j);
			Nucleo->Partida.Naves[k].y = ENEYBASE + (ENEYSEP * i);

			Nucleo->Partida.Naves[k].vida = ENEVIDINI;

			if(i < 2) // Enemigos dif�ciles
			{
				Nucleo->Partida.Naves[k].tex  = ENDTEXINI;
				Nucleo->Partida.Naves[k].frec = ENDFRCINI;
				Nucleo->Partida.Naves[k].arma = LASER2;
			}
			else // Enemigos f�ciles
			{
				Nucleo->Partida.Naves[k].tex  = ENFTEXINI;
				Nucleo->Partida.Naves[k].frec = ENFFRCINI;
				Nucleo->Partida.Naves[k].arma = LASER2;
			}

			k++;
		}
	}

	//--------------------------------------------------------------------------------------
	// Generamos una semilla "aleatoria" para n�meros de dudosa aleatoriedad.
	//--------------------------------------------------------------------------------------
	srand((unsigned) time(NULL));
}
//------------------------------------------------------------------------------------------
void SiguienteNivel (tNucleo * Nucleo)
{
	int i, j, k = 1;

	//--------------------------------------------------------------------------------------
	// Actualizamos el nivel de rapidez del juego.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.TiempoAcumulado = 0;

	if(Nucleo->Partida.CuentaMax > 1)
		Nucleo->Partida.CuentaMax--;

	Nucleo->Partida.CuentaAct = 0;

	//--------------------------------------------------------------------------------------
	// Inicializamos la direcci�n de avance de los enemigos y borramos la lista de disparos.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.Direccion = DIRIZQ;

	EliminarDisparos(Nucleo);

	//--------------------------------------------------------------------------------------
	// Inicalizamos las naves enemigas.
	//--------------------------------------------------------------------------------------
	for(i = 0; i < 4; i++)
	{
		for(j = 0; j < 8; j++)
		{
			Nucleo->Partida.Naves[k].x = ENEXBASE + (ENEXSEP * j);
			Nucleo->Partida.Naves[k].y = ENEYBASE + (ENEYSEP * i);

			Nucleo->Partida.Naves[k].vida = ENEVIDINI;

			if(i < 2) // Bichos dif�ciles
			{
				Nucleo->Partida.Naves[k].tex  = ENDTEXINI;
				Nucleo->Partida.Naves[k].frec = ENDFRCINI;
				Nucleo->Partida.Naves[k].arma = LASER2;
			}
			else // Bichos f�ciles
			{
				Nucleo->Partida.Naves[k].tex  = ENFTEXINI;
				Nucleo->Partida.Naves[k].frec = ENFFRCINI;
				Nucleo->Partida.Naves[k].arma = LASER2;
			}

			k++;
		}
	}

	//--------------------------------------------------------------------------------------
	// Generamos una semilla "aleatoria" para n�meros de dudosa aleatoriedad.
	//--------------------------------------------------------------------------------------
	srand((unsigned) time(NULL));
}
//******************************************************************************************
// Gesti�n de la puntuaci�n.
//******************************************************************************************
void MeterPuntuacion (tNucleo * Nucleo)
{
	int i;
	int pos = 0;

	//--------------------------------------------------------------------------------------
	// Buscamos en que posici�n la puntuaci�n de la partida deja de ser menor, que la de la
	// posici�n actual dentro de la tabla de puntuaciones.
	//--------------------------------------------------------------------------------------
	while((pos < MAXPUN) && (Nucleo->Puntuaciones[pos].puntos > Nucleo->Partida.Puntos))
	{
		pos++;
	}

	//--------------------------------------------------------------------------------------
	// Siempre que no nos hayamos salido de la tabla, desplazamos las puntuaciones
	// inferiores, a una casilla inferior, e introducimos la puntuaci�n de la partida.
	//--------------------------------------------------------------------------------------
	if(pos < MAXPUN)
	{
		for(i = MAXPUN - 1; i > pos; i--)
		{
			Nucleo->Puntuaciones[i] = Nucleo->Puntuaciones[i-1];
		}

		strcpy(Nucleo->Puntuaciones[pos].nombre, Nucleo->Partida.Nombre);
		Nucleo->Puntuaciones[pos].puntos = Nucleo->Partida.Puntos;
	}
}
//******************************************************************************************
// Gesti�n de la entrada por teclado.
//******************************************************************************************
void CapturarNombre (tNucleo * Nucleo)
{
	//--------------------------------------------------------------------------------------
	// Si no est� lleno el buffer para almacenar la cadena, vamos comprobando que teclas
	// han sido pulsadas, y concatenandolas al buffer del nombre.
	//--------------------------------------------------------------------------------------
	if(strlen(Nucleo->Partida.Nombre) < (MAXNAM - 1))
	{
		//----------------------------------------------------------------------------------
		// Comprobamos si la tecla es un d�gito.
		//----------------------------------------------------------------------------------
		if(EstadoTecla(Nucleo, TECLA_0))
			strcat(Nucleo->Partida.Nombre, "0");
		else if(EstadoTecla(Nucleo, TECLA_1))
			strcat(Nucleo->Partida.Nombre, "1");
		else if(EstadoTecla(Nucleo, TECLA_2))
			strcat(Nucleo->Partida.Nombre, "2");
		else if(EstadoTecla(Nucleo, TECLA_3))
			strcat(Nucleo->Partida.Nombre, "3");
		else if(EstadoTecla(Nucleo, TECLA_4))
			strcat(Nucleo->Partida.Nombre, "4");
		else if(EstadoTecla(Nucleo, TECLA_5))
			strcat(Nucleo->Partida.Nombre, "5");
		else if(EstadoTecla(Nucleo, TECLA_6))
			strcat(Nucleo->Partida.Nombre, "6");
		else if(EstadoTecla(Nucleo, TECLA_7))
			strcat(Nucleo->Partida.Nombre, "7");
		else if(EstadoTecla(Nucleo, TECLA_8))
			strcat(Nucleo->Partida.Nombre, "8");
		else if(EstadoTecla(Nucleo, TECLA_9))
			strcat(Nucleo->Partida.Nombre, "9");
		//----------------------------------------------------------------------------------
		// Comprobamos si la tecla es una letra.
		//----------------------------------------------------------------------------------
		else if(EstadoTecla(Nucleo, TECLA_A))
			strcat(Nucleo->Partida.Nombre, "A");
		else if(EstadoTecla(Nucleo, TECLA_B))
			strcat(Nucleo->Partida.Nombre, "B");
		else if(EstadoTecla(Nucleo, TECLA_C))
			strcat(Nucleo->Partida.Nombre, "C");
		else if(EstadoTecla(Nucleo, TECLA_D))
			strcat(Nucleo->Partida.Nombre, "D");
		else if(EstadoTecla(Nucleo, TECLA_E))
			strcat(Nucleo->Partida.Nombre, "E");
		else if(EstadoTecla(Nucleo, TECLA_F))
			strcat(Nucleo->Partida.Nombre, "F");
		else if(EstadoTecla(Nucleo, TECLA_G))
			strcat(Nucleo->Partida.Nombre, "G");
		else if(EstadoTecla(Nucleo, TECLA_H))
			strcat(Nucleo->Partida.Nombre, "H");
		else if(EstadoTecla(Nucleo, TECLA_I))
			strcat(Nucleo->Partida.Nombre, "I");
		else if(EstadoTecla(Nucleo, TECLA_J))
			strcat(Nucleo->Partida.Nombre, "J");
		else if(EstadoTecla(Nucleo, TECLA_K))
			strcat(Nucleo->Partida.Nombre, "K");
		else if(EstadoTecla(Nucleo, TECLA_L))
			strcat(Nucleo->Partida.Nombre, "L");
		else if(EstadoTecla(Nucleo, TECLA_M))
			strcat(Nucleo->Partida.Nombre, "M");
		else if(EstadoTecla(Nucleo, TECLA_N))
			strcat(Nucleo->Partida.Nombre, "N");
		else if(EstadoTecla(Nucleo, TECLA_NY))
			strcat(Nucleo->Partida.Nombre, "�");
		else if(EstadoTecla(Nucleo, TECLA_O))
			strcat(Nucleo->Partida.Nombre, "O");
		else if(EstadoTecla(Nucleo, TECLA_P))
			strcat(Nucleo->Partida.Nombre, "P");
		else if(EstadoTecla(Nucleo, TECLA_Q))
			strcat(Nucleo->Partida.Nombre, "Q");
		else if(EstadoTecla(Nucleo, TECLA_R))
			strcat(Nucleo->Partida.Nombre, "R");
		else if(EstadoTecla(Nucleo, TECLA_S))
			strcat(Nucleo->Partida.Nombre, "S");
		else if(EstadoTecla(Nucleo, TECLA_T))
			strcat(Nucleo->Partida.Nombre, "T");
		else if(EstadoTecla(Nucleo, TECLA_U))
			strcat(Nucleo->Partida.Nombre, "U");
		else if(EstadoTecla(Nucleo, TECLA_V))
			strcat(Nucleo->Partida.Nombre, "V");
		else if(EstadoTecla(Nucleo, TECLA_W))
			strcat(Nucleo->Partida.Nombre, "W");
		else if(EstadoTecla(Nucleo, TECLA_X))
			strcat(Nucleo->Partida.Nombre, "X");
		else if(EstadoTecla(Nucleo, TECLA_Y))
			strcat(Nucleo->Partida.Nombre, "Y");
		else if(EstadoTecla(Nucleo, TECLA_Z))
			strcat(Nucleo->Partida.Nombre, "Z");
		//----------------------------------------------------------------------------------
		// Comprobamos si la tecla la tecla de retroceso, con lo que borramos una letra.
		//----------------------------------------------------------------------------------
		else if(EstadoTecla(Nucleo, TECLA_RETROCESO))
			Nucleo->Partida.Nombre[strlen(Nucleo->Partida.Nombre) - 1] = '\0';

		//----------------------------------------------------------------------------------
		// Suspendemos un momento la ejecuci�n del programa, para que de una sola pulsaci�n
		// no se escriban tropecientas letras.
		//----------------------------------------------------------------------------------
		Delay(TMPMAX);
	}
}
//******************************************************************************************
// Gesti�n de la l�gica.
//******************************************************************************************
void InterpretarEntrada (tNucleo * Nucleo)
{
	//--------------------------------------------------------------------------------------
	// Evento: El usuario tiene pulsada la tecla derecha. As� que movemos la nave hacia la
	// derecha, a menos que est� en la posici�n m�xima que puede alcanzar su coordenada x.
	//--------------------------------------------------------------------------------------
	if(EstadoTecla(Nucleo, TECLA_DERECHA))
	{
		if(Nucleo->Partida.Naves[0].x < PAREDDE)
			Nucleo->Partida.Naves[0].x += DESNAV;
	}
	
	//--------------------------------------------------------------------------------------
	// Evento: El usuario tiene pulsada la tecla izquierda. As� que movemos la nave hacia la
	// izquierda, a menos que est� en la posici�n m�nima que puede alcanzar su coordenada x.
	//--------------------------------------------------------------------------------------
	if(EstadoTecla(Nucleo, TECLA_IZQUIERDA))
	{
		if(Nucleo->Partida.Naves[0].x > PAREDIZ)
			Nucleo->Partida.Naves[0].x -= DESNAV;
	}
	
	//--------------------------------------------------------------------------------------
	// Evento: El usuario tiene pulsada la tecla derecha. As� que generamos un disparo.
	//--------------------------------------------------------------------------------------
	if(EstadoTecla(Nucleo, TECLA_ESPACIO))
	{
		//----------------------------------------------------------------------------------
		// Generaci�n del disparo para armas laser solamente. Quiz�s en futuras versiones,
		// se podr�a tratar de implementar otros tipos de disparos.
		//----------------------------------------------------------------------------------
		if(Nucleo->Partida.Naves[0].arma < BOMBA1)
		{
			// Disparo izquierdo.
			CrearDisparo(Nucleo, Nucleo->Partida.Naves[0].x + DISLAXBASI,
				Nucleo->Partida.Naves[0].y + DISLAYBASJ, DESDIS,
				Nucleo->Partida.Naves[0].arma, DISLADANYO, DSPJUG);
			
			// Disparo derecho.
			CrearDisparo(Nucleo, Nucleo->Partida.Naves[0].x + DISLAXBASD,
				Nucleo->Partida.Naves[0].y + DISLAYBASJ, DESDIS,
				Nucleo->Partida.Naves[0].arma + 1, DISLADANYO, DSPJUG);
		}
	}
}
//------------------------------------------------------------------------------------------
void FinPartida (tNucleo * Nucleo)
{
	//--------------------------------------------------------------------------------------
	// Suspendemos un poquito la ejecuci�n del juego.
	//--------------------------------------------------------------------------------------
	Delay(500);

	//--------------------------------------------------------------------------------------
	// Modificamos el estado general del juego.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.EstadoDelJuego = ESTNOM;
	Nucleo->Partida.EstadoJugador = MUERTO;
	
	//--------------------------------------------------------------------------------------
	// Pasamos a cero el tiempo acumulado, para que no se ejecute ning�n tick de l�gica m�s.
	//--------------------------------------------------------------------------------------
	Nucleo->Partida.TiempoAcumulado = 0;

	//--------------------------------------------------------------------------------------
	// Borramos la lista de disparos.
	//--------------------------------------------------------------------------------------
	EliminarDisparos(Nucleo);
}
//------------------------------------------------------------------------------------------
void EjecutarIA (tNucleo * Nucleo)
{
	tDisparo * aux = Nucleo->Partida.Disparos;
	tDisparo * auxdel;
	int i, j;

	//--------------------------------------------------------------------------------------
	// Procesamiento de los disparos.
	//--------------------------------------------------------------------------------------
	while(aux != NULL)
	{
		//----------------------------------------------------------------------------------
		// Inicializamos auxdel a null. Esta variable nos indicar� si se ha de borrar el
		// disparo actual.
		//----------------------------------------------------------------------------------
		auxdel = NULL;

		//----------------------------------------------------------------------------------
		// Comprobamos si ha colisionado el disparo con alguna nave.
		//----------------------------------------------------------------------------------
		for(i = 0; i < MAXNAV; i++)
		{
			//------------------------------------------------------------------------------
			// Con una nave que est� viva preferiblemente.
			//------------------------------------------------------------------------------
			if(Nucleo->Partida.Naves[i].vida > 0)
			{
				//--------------------------------------------------------------------------
				// Si colisiona con una nave, le quitamos el da�o que haga dicha arma. Si
				// la nave muere y no es la del jugador, a�adimos puntos a la puntuaci�n.
				// cambiamos el valor de auxdel, para que se borre el disparo actual, y
				// dejamos de buscar si ha colisionado con alguna nave m�s el disparo.
				//--------------------------------------------------------------------------
				if(Colisiona(Nucleo, i, aux))
				{
					Nucleo->Partida.Naves[i].vida -= aux->danyo;
					if((i > 0) && (Nucleo->Partida.Naves[i].vida <= 0))
					{
						if(Nucleo->Partida.Naves[i].tex == ENFTEXINI)
							Nucleo->Partida.Puntos += 10;
						else if(Nucleo->Partida.Naves[i].tex == ENDTEXINI)
							Nucleo->Partida.Puntos += 20;
					}
					auxdel = aux;
					break;
				}
			}
		}

		//----------------------------------------------------------------------------------
		// Se borra si as� ha ocurrido alguna colisi�n, no sin antes pasar al siguiente
		// disparo de la lista.
		//----------------------------------------------------------------------------------
		if(auxdel != NULL)
		{
			aux = aux->sig;
			DestruirDisparo(Nucleo, auxdel);
		}
		//----------------------------------------------------------------------------------
		// Sino se avanza, y si sale de los bordes se elimina el disparo de la lista.
		//----------------------------------------------------------------------------------
		else
		{
			//------------------------------------------------------------------------------
			// Avance del disparo dependiendo del bando.
			//------------------------------------------------------------------------------
			if(aux->bando == DSPENE)
				aux->y += aux->vel;
			else
				aux->y -= aux->vel;

			//------------------------------------------------------------------------------
			// Si se ha salido de los bordes, se elimina el disparo.
			//------------------------------------------------------------------------------
			if((aux->y < PAREDAR) || (PAREDAB < aux->y))
			{
				auxdel = aux;
				aux = aux->sig;
				DestruirDisparo(Nucleo, auxdel);
			}
			else
			{
				aux = aux->sig;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	// Comprobaci�n de si el jugador est� muerto. En ese caso finalizamos la partida actual.
	//--------------------------------------------------------------------------------------
	if(Nucleo->Partida.Naves[0].vida <= 0)
	{
		FinPartida(Nucleo);
		return;
	}

	//--------------------------------------------------------------------------------------
	// Comprobaci�n de si queda alg�n enemigo con vida. Si est�n todos muertos pasamos al
	// siguiente nivel de la partida.
	//--------------------------------------------------------------------------------------
	for(i = 1; i < MAXNAV; i++)
		if(Nucleo->Partida.Naves[i].vida > 0)
			break;

	if(i >= MAXNAV)
	{
		SiguienteNivel(Nucleo);
		return;
	}

	//--------------------------------------------------------------------------------------
	// Procesamiento de las naves. Solo se ejecutar� si el n�mero de ciclos actual, vale
	// mayor o igual que el n�mero de ciclos m�ximos para la partida.
	//--------------------------------------------------------------------------------------
	if(Nucleo->Partida.CuentaAct >= Nucleo->Partida.CuentaMax)
	{
		//----------------------------------------------------------------------------------
		// Hacemos avanzar a todas las naves en la direcci�n actual, y determinamos si
		// deben disparar o no. Todo esto se har� solo si la nave est� viva todav�a.
		//----------------------------------------------------------------------------------
		for(i = 1; i < MAXNAV; i++)
		{
			//------------------------------------------------------------------------------
			// Preguntamos si est� viva la nave.
			//------------------------------------------------------------------------------
			if(Nucleo->Partida.Naves[i].vida > 0)
			{
				//--------------------------------------------------------------------------
				// Movemos a la nave en el eje x.
				//--------------------------------------------------------------------------
				if(Nucleo->Partida.Direccion == DIRIZQ)
				{
					Nucleo->Partida.Naves[i].x -= DESNAV;
				}
				else
				{
					Nucleo->Partida.Naves[i].x += DESNAV;
				}

				//--------------------------------------------------------------------------
				// Si el arma es un laser, con un random decidimos si dispara o no.
				//--------------------------------------------------------------------------
				if(Nucleo->Partida.Naves[i].arma < BOMBA1)
				{
					//----------------------------------------------------------------------
					// La nave dispar�, si el porcentaje que ha salido es menor o igual,
					// que el porcentaje almacenado en la variable frecuencia de la nave.
					//----------------------------------------------------------------------
					if((rand() % 100) <= Nucleo->Partida.Naves[i].frec)
					{
						// Disparo izquierdo.
						CrearDisparo(Nucleo, Nucleo->Partida.Naves[i].x + DISLAXBASI,
							Nucleo->Partida.Naves[i].y + DISLAYBASE, DESDIS,
							Nucleo->Partida.Naves[i].arma, DISLADANYO, DSPENE);
						
						// Disparo derecho.
						CrearDisparo(Nucleo, Nucleo->Partida.Naves[i].x + DISLAXBASD,
							Nucleo->Partida.Naves[i].y + DISLAYBASE, DESDIS,
							Nucleo->Partida.Naves[i].arma + 1, DISLADANYO, DSPENE);
					}
				}
			}
		}

		//----------------------------------------------------------------------------------
		// Comprobamos si ha llegado alguna nave a los bordes de la pantalla. Pero solo a
		// las naves que est�n vivas.
		//----------------------------------------------------------------------------------
		for(i = 1; i < MAXNAV; i++)
		{
			//------------------------------------------------------------------------------
			// Preguntamos si est� viva la nave.
			//------------------------------------------------------------------------------
			if(Nucleo->Partida.Naves[i].vida > 0)
			{
				//--------------------------------------------------------------------------
				// Si nos hemos salido de la izquierda, yendo hacia la izquierda, o si nos
				// hemos salido de la derecha, yendo hacia la derecha, se avanzar� hacia
				// abajo. Y tambi�n se cambiar� la direcci�n de avance.
				//--------------------------------------------------------------------------
				if(((Nucleo->Partida.Naves[i].x <= PAREDI2) &&
					(Nucleo->Partida.Direccion == DIRIZQ)) ||
				   ((Nucleo->Partida.Naves[i].x >= PAREDD2) &&
					(Nucleo->Partida.Direccion == DIRDER)))
				{
					//----------------------------------------------------------------------
					// Cambio de la direcci�n de avance.
					//----------------------------------------------------------------------
					if(Nucleo->Partida.Direccion == DIRIZQ)
						Nucleo->Partida.Direccion = DIRDER;
					else
						Nucleo->Partida.Direccion = DIRIZQ;

					//----------------------------------------------------------------------
					// Recorremos todo el vector de naves, y las movemos para abajo. Pero
					// solo las naves que est�n vivas, para ahorrar tiempo.
					//----------------------------------------------------------------------
					for(j = 1; j < MAXNAV; j++)
					{
						if(Nucleo->Partida.Naves[i].vida > 0)
						{
							//--------------------------------------------------------------
							// Movemos para abajo la nave.
							//--------------------------------------------------------------
							Nucleo->Partida.Naves[j].y += DESNAV;
							
							//--------------------------------------------------------------
							// Y corregimos la trayectoria, para que no parezca que baja en
							// diagonal las naves.
							//--------------------------------------------------------------
							if(Nucleo->Partida.Direccion == DIRIZQ)
							{
								Nucleo->Partida.Naves[j].x -= DESNAV;
							}
							else
							{
								Nucleo->Partida.Naves[j].x += DESNAV;
							}

							//--------------------------------------------------------------
							// Si alguna nave llega hasta el fondo de la pantalla, donde
							// est� el jugador, se acaba la partida.
							//--------------------------------------------------------------
							if((Nucleo->Partida.Naves[j].y >= Nucleo->Partida.Naves[0].y - NAVESALTO) &&
								(Nucleo->Partida.Naves[j].vida > 0))
							{
								FinPartida(Nucleo);
								return;
							}
						}
					}

					//----------------------------------------------------------------------
					// Dejamos de buscar naves que hayan colisionado con el borde.
					//----------------------------------------------------------------------
					break;
				}
			}
		}

		//----------------------------------------------------------------------------------
		// Tras procesar todas las naves, ponemos a cero el n�mero de ciclos actual.
		//----------------------------------------------------------------------------------
		Nucleo->Partida.CuentaAct = 0;
	}
	//--------------------------------------------------------------------------------------
	// Si no se ha llegado al n�mero m�ximo de ciclos, incrementamos el n�mero actual.
	//--------------------------------------------------------------------------------------
	else
	{
		Nucleo->Partida.CuentaAct++;
	}
}
//------------------------------------------------------------------------------------------
void EjecutarLogica (tNucleo * Nucleo, Uint32 Intervalo)
{
	//--------------------------------------------------------------------------------------
	// Actualizamos la entrada del juego.
	//--------------------------------------------------------------------------------------
	ActualizarEntrada(Nucleo);
	
	//--------------------------------------------------------------------------------------
	// Dependiendo del estado actual del juego se atender�n las cosas de un modo u otro.
	//--------------------------------------------------------------------------------------
	switch(Nucleo->Partida.EstadoDelJuego)
	{
	//--------------------------------------------------------------------------------------
	// Tratamiento del men� principal, tanto cuando est� para una nueva partida, como para
	// continuar la actual.
	//--------------------------------------------------------------------------------------
	case ESTMNU:
	case ESTCON:
		//----------------------------------------------------------------------------------
		// Si hacemos click con el bot�n izquierdo del rat�n comprobamos sobre que bot�n
		// estamos situados.
		//----------------------------------------------------------------------------------
		if(EstadoRaton(Nucleo, BOTON_IZQUIERDO))
		{
			//------------------------------------------------------------------------------
			// El rat�n ha hecho click sobre el primer bot�n.
			//------------------------------------------------------------------------------
			if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[0])))
			{
				//--------------------------------------------------------------------------
				// El bot�n es Nueva Partida.
				//--------------------------------------------------------------------------
				if(Nucleo->Partida.EstadoDelJuego == ESTMNU)
					InitPartida(Nucleo);
				//--------------------------------------------------------------------------
				// El bot�n es Continuar partida.
				//--------------------------------------------------------------------------
				else
					Nucleo->Partida.EstadoDelJuego = ESTJUG;
			}

			//------------------------------------------------------------------------------
			// El rat�n ha hecho click sobre el bot�n Opciones.
			//------------------------------------------------------------------------------
			if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[1])))
			{
				Nucleo->Partida.EstadoDelJuego = ESTOPC;
			}

			//------------------------------------------------------------------------------
			// El rat�n ha hecho click sobre el bot�n Puntuaciones.
			//------------------------------------------------------------------------------
			if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[2])))
			{
				Nucleo->Partida.EstadoDelJuego = ESTPUN;
			}

			//------------------------------------------------------------------------------
			// El rat�n ha hecho click sobre el bot�n Salida.
			//------------------------------------------------------------------------------
			if(EstaRatonEn(Nucleo, &(Nucleo->Texturas.Opciones[3])))
			{
				Nucleo->Partida.EstadoDelJuego = ESTSAL;
			}
		}

		break;
	
	//--------------------------------------------------------------------------------------
	// Tratamiento de la partida actual en curso.
	//--------------------------------------------------------------------------------------
	case ESTJUG:
		//----------------------------------------------------------------------------------
		// Si el jugador pulsa la tecla escape, se carga el men� de Continuar Partida.
		//----------------------------------------------------------------------------------
		if(EstadoTecla(Nucleo, TECLA_ESC))
		{
			Nucleo->Partida.EstadoDelJuego = ESTCON;
		}
		//----------------------------------------------------------------------------------
		// Sino se ejecuta el juego con normalidad.
		//----------------------------------------------------------------------------------
		else
		{
			//------------------------------------------------------------------------------
			// A�adimos el intervalo transcurrido durante el tiempo que se ha empleado para
			// renderizar una imagen en pantalla del juego.
			//------------------------------------------------------------------------------
			Nucleo->Partida.TiempoAcumulado += Intervalo;

			//------------------------------------------------------------------------------
			// Y para que se ejecute la l�gica un n�mero m�ximo de veces en un segundo, el
			// tiempo acumulado debe ser mayor o igual, que el Tiempo M�nimo determinado.
			//------------------------------------------------------------------------------
			if(Nucleo->Partida.TiempoAcumulado >= TMPMIN)
			{
				//---------------------------------------------------------------------------
				// Pero si en la etapa de renderizado, se ha empleado el correspondiente a
				// varios ciclos de l�gica del juego, tendremos que ejecutar tantas veces la
				// l�gica del juego, como ciclos se haya chupado el tiempo de renderizado.
				//---------------------------------------------------------------------------
				while(Nucleo->Partida.TiempoAcumulado >= TMPMIN)
				{
					//-----------------------------------------------------------------------
					// Interpretamos la entrada, y ejecutamos la IA del juego.
					//-----------------------------------------------------------------------
					InterpretarEntrada(Nucleo);
					EjecutarIA(Nucleo);
					
					//-----------------------------------------------------------------------
					// Restamos el tiempo m�nimo, que tendr�a que durar un ciclo de juego, al
					// tiempo acumulado. Y as� se ejecutaran los X ciclos que se comi� el
					// renderizado gr�fico del juego.
					//-----------------------------------------------------------------------
					Nucleo->Partida.TiempoAcumulado -= TMPMIN;
				}

				//---------------------------------------------------------------------------
				// Ponemos el tiempo acumulado a cero, para empezar el proceso.
				//---------------------------------------------------------------------------
				Nucleo->Partida.TiempoAcumulado = 0;
			}
		}

		break;
	
	//--------------------------------------------------------------------------------------
	// Tratamiento de la pantalla de opciones y puntuaciones.
	//--------------------------------------------------------------------------------------
	case ESTOPC:
	case ESTPUN:
		//----------------------------------------------------------------------------------
		// Si se pulsa la tecla escape volveremos a la pantalla del men� principal. Y
		// dependiendo de si estamos jugando una partida o no, volveremos a uno u otro.
		//----------------------------------------------------------------------------------
		if(EstadoTecla(Nucleo, TECLA_ESC))
		{
			//------------------------------------------------------------------------------
			// Se est� jugando una partida, volvemos al men� de Continuar Partida.
			//------------------------------------------------------------------------------
			if(Nucleo->Partida.EstadoJugador == VIVO)
				Nucleo->Partida.EstadoDelJuego = ESTCON;
			//------------------------------------------------------------------------------
			// No se est� jugando una partida, volvemos al men� de Nueva Partida.
			//------------------------------------------------------------------------------
			else if(Nucleo->Partida.EstadoJugador == MUERTO)
				Nucleo->Partida.EstadoDelJuego = ESTMNU;
		}

		break;

	//--------------------------------------------------------------------------------------
	// Tratamiento de la pantalla para introducir el nombre del jugador.
	//--------------------------------------------------------------------------------------
	case ESTNOM:
		//----------------------------------------------------------------------------------
		// Si pulsa enter el usuario, se comprueba que haya introducido un nombre no vac�o,
		// y luego se introduce la puntuaci�n en la tabla. Luego se carga la pantalla de
		// puntuaciones.
		//----------------------------------------------------------------------------------
		if(EstadoTecla(Nucleo, TECLA_ENTER))
		{
			if(strcmp(Nucleo->Partida.Nombre, "") != STREQU)
			{
				MeterPuntuacion(Nucleo);
				Nucleo->Partida.EstadoDelJuego = ESTPUN;
			}
		}
		//----------------------------------------------------------------------------------
		// Si el usuario pulsa escape, se salta la anotaci�n de la puntuaci�n.
		//----------------------------------------------------------------------------------
		else if(EstadoTecla(Nucleo, TECLA_ESC))
		{
			Nucleo->Partida.EstadoDelJuego = ESTMNU;
		}
		//----------------------------------------------------------------------------------
		// Para el resto de teclas, capturamos el caracter que supuestamente represente.
		//----------------------------------------------------------------------------------
		else
		{
			CapturarNombre(Nucleo);
		}

		break;
	}
}
//******************************************************************************************
// Fin logica.c
//******************************************************************************************
