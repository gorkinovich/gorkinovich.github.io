﻿//***************************************************************************
// LineCounter 1.0 - A C/C++/C# source line counter.
// Copyright (C) 2007  Gorka Suárez García
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//***************************************************************************

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace LineCounter
{
    public partial class MainWnd : Form
    {
        /********************************************************************************
         * Class attributes.
         ********************************************************************************/

        /// <summary> The data of the current project. </summary>
        private Data.Project project;

        /// <summary> The help window. </summary>
        HelpWnd helpWnd;


        /********************************************************************************
         * Class methods.
         ********************************************************************************/

        /********************************************************************************/
        /// <summary>
        /// Main constructor of the MainWnd class.
        /// </summary>
        /********************************************************************************/
        public MainWnd()
        {
            InitializeComponent();
        }
        
        /********************************************************************************/
        /// <summary>
        /// This method list the files inside a directory.
        /// </summary>
        /// <param name="path">The directory we want list.</param>
        /********************************************************************************/
        private string[] GetFilesWithExtension(string path)
        {
            //--------------------------------------------------------------------------
            // The first step is to check if we want to list all the files.
            //--------------------------------------------------------------------------
            if (this.menuToolsAllFiles.Checked)
            {
                return Directory.GetFiles(path);
            }
            //--------------------------------------------------------------------------
            // If we don't want to list all the files, maybe we want to list C/C++
            // files, so we check the four extensions of this language.
            //--------------------------------------------------------------------------
            else if (this.menuToolsCppLang.Checked)
            {
                List<string> items = new List<string>();

                string[] files = Directory.GetFiles(path, "*.h");
                foreach (string file in files) items.Add(file);

                files = Directory.GetFiles(path, "*.c");
                foreach (string file in files) items.Add(file);

                files = Directory.GetFiles(path, "*.hpp");
                foreach (string file in files) items.Add(file);

                files = Directory.GetFiles(path, "*.cpp");
                foreach (string file in files) items.Add(file);

                return items.ToArray();
            }
            //--------------------------------------------------------------------------
            // Or maybe we will be interested in list C# files.
            //--------------------------------------------------------------------------
            else if (this.menuToolsCsLang.Checked)
            {
                return Directory.GetFiles(path, "*.cs");
            }
            //--------------------------------------------------------------------------
            // Any other option we will list all the files.
            //--------------------------------------------------------------------------
            else
            {
                return Directory.GetFiles(path);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method changes the current directory listed in the application.
        /// </summary>
        /// <param name="path">The current directory we want to go.</param>
        /********************************************************************************/
        public void ChangeCurrentDirectory(string path)
        {
            try
            {
                //----------------------------------------------------------------------
                // First we get into the directory we want to go, once inside we will
                // get the directories and the files inside that directory.
                //----------------------------------------------------------------------
                Directory.SetCurrentDirectory(path);
                string[] dirs  = Directory.GetDirectories(path);
                string[] files = this.GetFilesWithExtension(path);

                //----------------------------------------------------------------------
                // After get the files into strings, we are going to put them all
                // inside the currentFiles object, so we need to clear it all.
                //----------------------------------------------------------------------
                this.currentFiles.Items.Clear();

                //----------------------------------------------------------------------
                // Then in order to erase the whole common path, we need to check it
                // out the last character of the path, to see if it is an \ of anything
                // else. If it isn't an slash, we will erase one pluss character.
                //----------------------------------------------------------------------
                string aux;
                int len;

                if (path[path.Length - 1] == '\\')
                    len = path.Length;
                else
                    len = path.Length + 1;

                //----------------------------------------------------------------------
                // So for each string inside dirs, we will add a directory.
                //----------------------------------------------------------------------
                foreach (string dir in dirs)
                {
                    aux = dir.Substring(len);
                    this.currentFiles.Items.Add(aux + "\\");
                }

                //----------------------------------------------------------------------
                // And for each string inside files, we will add a file.
                //----------------------------------------------------------------------
                foreach (string file in files)
                {
                    aux = file.Substring(len);
                    this.currentFiles.Items.Add(aux);
                }

                //----------------------------------------------------------------------
                // Once we have added to the currentFiles object any directory of file
                // inside the current directory, we will add the ".." to link with the
                // father directory.
                //----------------------------------------------------------------------
                this.currentFiles.Items.Add("..");
            }
            catch (DirectoryNotFoundException)
            {
                MessageBox.Show(this, "That directory does not exists.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception)
            {
                MessageBox.Show(this, "The application can not change the current directory.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        /********************************************************************************
         * Class events.
         ********************************************************************************/

        #region Main Windows Events

        /********************************************************************************/
        /// <summary>
        /// Sets up the application when it's loaded the first time.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void MainWnd_Load(object sender, EventArgs e)
        {
            try
            {
                this.project = new Data.Project();

                this.currentPath.Text = Directory.GetCurrentDirectory();

                this.menuToolsAllFiles.Checked = true;
                this.menuToolsCppLang.Checked = false;
                this.menuToolsCsLang.Checked = false;

                this.helpWnd = new HelpWnd();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Menu File Events

        /********************************************************************************/
        /// <summary>
        /// This method creates a new project empty.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuFileNew_Click(object sender, EventArgs e)
        {
            try
            {
                this.listFiles.Items.Clear();
                this.dgvResult.RowCount = 0;
                this.project = new Data.Project();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method opens a saved project.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuFileOpen_Click(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // First we set up the open dialog.
                //----------------------------------------------------------------------
                this.openDialog.Title = "Open the project";
                this.openDialog.DefaultExt = "*.lcp";
                this.openDialog.Filter = "Project file (*.lcp)|*.lcp|All files (*.*)|*.*";
                this.openDialog.FilterIndex = 1;
                this.openDialog.RestoreDirectory = false;

                //----------------------------------------------------------------------
                // Then we call it and load the project in a file, and update the
                // whole interface to see the files of the project.
                //----------------------------------------------------------------------
                if (this.openDialog.ShowDialog() == DialogResult.OK)
                {
                    this.currentPath.Text = Directory.GetCurrentDirectory();
                    this.project.Load(this.openDialog.FileName);

                    this.ShowFileData(this.project.Files);
                    this.listFiles.Items.Clear();
                    foreach (string file in this.project.Paths)
                    {
                        this.listFiles.Items.Add(file);
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method saves the current project.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuFileSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.project.Name.Length > 0)
                {
                    this.UpdateProject();
                    this.project.Save();
                }
                else
                {
                    this.menuFileSaveAs_Click(sender, e);
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method saves the current project.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuFileSaveAs_Click(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // First we set up the save dialog.
                //----------------------------------------------------------------------
                this.saveDialog.Title = "Save the project";
                this.saveDialog.DefaultExt = "*.lcp";
                this.saveDialog.Filter = "Project file (*.lcp)|*.lcp|All files (*.*)|*.*";
                this.saveDialog.FilterIndex = 1;
                this.saveDialog.RestoreDirectory = true;

                //----------------------------------------------------------------------
                // Then we call it and save the project in a file.
                //----------------------------------------------------------------------
                if (this.saveDialog.ShowDialog() == DialogResult.OK)
                {
                    this.UpdateProject();
                    this.project.Save(this.saveDialog.FileName);
                }
            }
            catch (Exception)
            {
            }
        }

        /********************************************************************************/
        /// <summary>
        /// Close the application.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuFileExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #endregion

        #region Menu Tools Events

        /********************************************************************************/
        /// <summary>
        /// Change the current active tab to the Files tab.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuToolsFiles_Click(object sender, EventArgs e)
        {
            try
            {
                this.mainTabs.SelectedIndex = 0;
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// Change the current active tab to the Result tab.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuToolsResult_Click(object sender, EventArgs e)
        {
            try
            {
                this.mainTabs.SelectedIndex = 1;
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// Change the current search extension to any kind of file.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuToolsAllFiles_Click(object sender, EventArgs e)
        {
            try
            {
                this.menuToolsAllFiles.Checked = true;
                this.menuToolsCppLang.Checked = false;
                this.menuToolsCsLang.Checked = false;
                this.ChangeCurrentDirectory(this.currentPath.Text);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// Change the current search extension to C/C++ files.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuToolsCppLang_Click(object sender, EventArgs e)
        {
            try
            {
                this.menuToolsAllFiles.Checked = false;
                this.menuToolsCppLang.Checked = true;
                this.menuToolsCsLang.Checked = false;
                this.ChangeCurrentDirectory(this.currentPath.Text);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// Change the current search extension to C# files.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuToolsCsLang_Click(object sender, EventArgs e)
        {
            try
            {
                this.menuToolsAllFiles.Checked = false;
                this.menuToolsCppLang.Checked = false;
                this.menuToolsCsLang.Checked = true;
                this.ChangeCurrentDirectory(this.currentPath.Text);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Menu Help Events

        /********************************************************************************/
        /// <summary>
        /// Calls the help of the application.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuHelpHelp_Click(object sender, EventArgs e)
        {
            try
            {
                this.helpWnd.Show();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// Calls the about dialog.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void menuHelpAbout_Click(object sender, EventArgs e)
        {
            try
            {
                using (AboutWnd dialog = new AboutWnd())
                {
                    dialog.ShowDialog(this);
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Files Tab Controls Events

        /********************************************************************************/
        /// <summary>
        /// Calls the folder browser dialog, to change the current directory.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void cmdChangeDirectory_Click(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // We will call the folder browser dialog, and if we select any
                // directory, we will change the text of the currentPath object.
                //----------------------------------------------------------------------
                if (this.folderDialog.ShowDialog(this) == DialogResult.OK)
                {
                    this.currentPath.Text = this.folderDialog.SelectedPath;
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method is to add files to the project.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void cmdAddFiles_Click(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // First we take the selected indices in currentFiles object.
                //----------------------------------------------------------------------
                IEnumerator i = this.currentFiles.SelectedIndices.GetEnumerator();

                //----------------------------------------------------------------------
                // Then we prepare the cdir to make the complete path for any file.
                //----------------------------------------------------------------------
                string aux;
                string cdir = Directory.GetCurrentDirectory() + "\\";

                //----------------------------------------------------------------------
                // And for each string selected, we will add them to the listFiles
                // object, passing it the files with the whole path.
                //----------------------------------------------------------------------
                while (i.MoveNext())
                {
                    aux = this.currentFiles.Items[(int)i.Current].ToString();
                    if ((aux != "..") && (!this.listFiles.Items.Contains(cdir + aux)))
                    {
                        this.listFiles.Items.Add(cdir + aux);
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method is to remove files from the project.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void cmdRemove_Click(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // First we take the selected indices in listFiles object.
                //----------------------------------------------------------------------
                IEnumerator i = this.listFiles.SelectedItems.GetEnumerator();

                //----------------------------------------------------------------------
                // Then we take each object selected.
                //----------------------------------------------------------------------
                ArrayList items = new ArrayList();
                
                while (i.MoveNext())
                {
                    items.Add(i.Current);
                }

                //----------------------------------------------------------------------
                // And then we will remove them all from listFiles object.
                //----------------------------------------------------------------------
                i = items.GetEnumerator();

                while (i.MoveNext())
                {
                    this.listFiles.Items.Remove(i.Current);
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method will change the current path of the application.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void currentPath_TextChanged(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // Here we will first change the current directory, and if it's
                // possible, we will call the ChangeCurrentDirectory to update the
                // currentFiles object.
                //----------------------------------------------------------------------
                Directory.SetCurrentDirectory(this.currentPath.Text);
                this.ChangeCurrentDirectory(this.currentPath.Text);
            }
            catch (Exception)
            {
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method will change the current path of the application.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void currentFiles_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // First we get the selected item in the currentFiles object.
                //----------------------------------------------------------------------
                string item = this.currentFiles.SelectedItem.ToString();

                //----------------------------------------------------------------------
                // And then we check if it's a directory to change the current one.
                //----------------------------------------------------------------------
                if ((item == "..") || (item[item.Length - 1] == '\\'))
                {
                    Directory.SetCurrentDirectory(item);
                    this.currentPath.Text = Directory.GetCurrentDirectory();
                }
                //----------------------------------------------------------------------
                // Otherwise we have selected a file, so we add it to the list.
                //----------------------------------------------------------------------
                else
                {
                    string cdir = Directory.GetCurrentDirectory() + "\\";
                    if (!this.listFiles.Items.Contains(cdir + item))
                    {
                        this.listFiles.Items.Add(cdir + item);
                    }
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Result Tab Controls Events

        /********************************************************************************/
        /// <summary>
        /// This method will calculate the lines of the files added to the project.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void cmdCountLines_Click(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // Firs we have to add all the paths and check the project.
                //----------------------------------------------------------------------
                this.UpdateProject();

                //----------------------------------------------------------------------
                // And then we update the grid with the result.
                //----------------------------------------------------------------------
                this.ShowFileData(this.project.Files);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method updates the internal state of the project.
        /// </summary>
        /********************************************************************************/
        private void UpdateProject()
        {
            //--------------------------------------------------------------------------
            // Fist we have to get all the strings inside listFiles.
            //--------------------------------------------------------------------------
            IEnumerator selPaths = this.listFiles.Items.GetEnumerator();
            List<string> paths = new List<string>();

            while (selPaths.MoveNext())
            {
                paths.Add(selPaths.Current.ToString());
            }

            //--------------------------------------------------------------------------
            // And after that we'll pass all the paths to the project and check them.
            //--------------------------------------------------------------------------
            this.project.Check(paths.ToArray());
        }

        /********************************************************************************/
        /// <summary>
        /// This method updates the dgvResult object which contains the result.
        /// </summary>
        /// <param name="files">The files we want to show in the data grid.</param>
        /********************************************************************************/
        private void ShowFileData(Data.File[] files)
        {
            //--------------------------------------------------------------------------
            // First we set the number of current rows in the grid.
            //--------------------------------------------------------------------------
            this.dgvResult.RowCount = files.Length;

            //--------------------------------------------------------------------------
            // Second we create one counter for each category.
            //--------------------------------------------------------------------------
            int totalTotalCode = 0;
            int totalCode = 0;
            int totalCodeWithComments = 0;
            int totalComments = 0;
            int totalLines = 0;
            int i;

            //--------------------------------------------------------------------------
            // Then we set the cells of the grid with the files values.
            //--------------------------------------------------------------------------
            for (i = 0; i < this.dgvResult.RowCount; ++i)
            {
                this.dgvResult.Rows[i].Cells[0].Value = files[i].Name;
                this.dgvResult.Rows[i].Cells[1].Value = files[i].LinesOfTotalCode;
                this.dgvResult.Rows[i].Cells[2].Value = files[i].LinesOfCode;
                this.dgvResult.Rows[i].Cells[3].Value = files[i].LinesOfCodeWithComments;
                this.dgvResult.Rows[i].Cells[4].Value = files[i].LinesOfComments;
                this.dgvResult.Rows[i].Cells[5].Value = files[i].TotalLines;

                totalTotalCode += files[i].LinesOfTotalCode;
                totalCode += files[i].LinesOfCode;
                totalCodeWithComments += files[i].LinesOfCodeWithComments;
                totalComments += files[i].LinesOfComments;
                totalLines += files[i].TotalLines;
            }

            //--------------------------------------------------------------------------
            // And finally we set the cells of the total values.
            //--------------------------------------------------------------------------
            this.dgvResult.RowCount += 2;
            i = this.dgvResult.RowCount - 1;

            this.dgvResult.Rows[i].Cells[0].Value = "Total";
            this.dgvResult.Rows[i].Cells[1].Value = totalTotalCode;
            this.dgvResult.Rows[i].Cells[2].Value = totalCode;
            this.dgvResult.Rows[i].Cells[3].Value = totalCodeWithComments;
            this.dgvResult.Rows[i].Cells[4].Value = totalComments;
            this.dgvResult.Rows[i].Cells[5].Value = totalLines;
        }

        /********************************************************************************/
        /// <summary>
        /// This method will save the result as a text file.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void cmdSaveResult_Click(object sender, EventArgs e)
        {
            try
            {
                //----------------------------------------------------------------------
                // First we set up the save dialog.
                //----------------------------------------------------------------------
                this.saveDialog.Title = "Save the project result";
                this.saveDialog.DefaultExt = "*.txt";
                this.saveDialog.Filter = "Text file (*.txt)|*.txt|Xml file (*.xml)|*.xml|All files (*.*)|*.*";
                this.saveDialog.FilterIndex = 1;
                this.saveDialog.RestoreDirectory = true;

                //----------------------------------------------------------------------
                // Then we call it and save the result in a file.
                //----------------------------------------------------------------------
                if (this.saveDialog.ShowDialog() == DialogResult.OK)
                {
                    this.UpdateProject();
                    this.project.SaveResult(this.saveDialog.FileName);
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }

        #endregion
    }
}