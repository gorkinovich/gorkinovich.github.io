//***************************************************************************
// LineCounter 1.0 - A C/C++/C# source line counter.
// Copyright (C) 2007  Gorka Su�rez Garc�a
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//***************************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LineCounter
{
    public partial class AboutWnd : Form
    {
        /********************************************************************************/
        /// <summary>
        /// Main constructor of the AboutWnd class.
        /// </summary>
        /********************************************************************************/
        public AboutWnd()
        {
            InitializeComponent();

            this.linkMyWebsite.Links.Add(new LinkLabel.Link());
            this.linkMyWebsite.Links[0].Name = "Alexander Lessman Website";
            this.linkMyWebsite.Links[0].Description = "My personal website.";
            this.linkMyWebsite.Links[0].LinkData = "http://lex.blogsite.org/";
        }

        /********************************************************************************/
        /// <summary>
        /// This method close the about dialog.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void cmdAccept_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        /********************************************************************************/
        /// <summary>
        /// This method calls an URL.
        /// </summary>
        /// <param name="sender">The object who calls the event.</param>
        /// <param name="e">The arguments of the event.</param>
        /********************************************************************************/
        private void linkMyWebsite_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string target = this.linkMyWebsite.Links[0].LinkData.ToString();
            System.Diagnostics.Process.Start(target);
        }
    }
}