//***************************************************************************
// LineCounter 1.0 - A C/C++/C# source line counter.
// Copyright (C) 2007  Gorka Su�rez Garc�a
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//***************************************************************************

namespace LineCounter
{
    partial class AboutWnd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblText01 = new System.Windows.Forms.Label();
            this.linkMyWebsite = new System.Windows.Forms.LinkLabel();
            this.cmdAccept = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblText01
            // 
            this.lblText01.AutoSize = true;
            this.lblText01.Location = new System.Drawing.Point(62, 9);
            this.lblText01.Name = "lblText01";
            this.lblText01.Size = new System.Drawing.Size(191, 91);
            this.lblText01.TabIndex = 0;
            this.lblText01.Text = "Line Counter 1.0     Copyright (C) 2007\r\n\r\n   A C/C++/C# source line counter.\r\n  " +
                "Programed by Gorka Su�rez Garc�a.\r\n\r\nThis software is under the GPL license.\r\n  " +
                "      (Last Update: 2007-07-18)";
            // 
            // linkMyWebsite
            // 
            this.linkMyWebsite.AutoSize = true;
            this.linkMyWebsite.Location = new System.Drawing.Point(96, 111);
            this.linkMyWebsite.Name = "linkMyWebsite";
            this.linkMyWebsite.Size = new System.Drawing.Size(113, 13);
            this.linkMyWebsite.TabIndex = 1;
            this.linkMyWebsite.TabStop = true;
            this.linkMyWebsite.Text = "http://lex.blogsite.org/";
            this.linkMyWebsite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkMyWebsite_LinkClicked);
            // 
            // cmdAccept
            // 
            this.cmdAccept.Location = new System.Drawing.Point(117, 138);
            this.cmdAccept.Name = "cmdAccept";
            this.cmdAccept.Size = new System.Drawing.Size(75, 23);
            this.cmdAccept.TabIndex = 2;
            this.cmdAccept.Text = "&Accept";
            this.cmdAccept.UseVisualStyleBackColor = true;
            this.cmdAccept.Click += new System.EventHandler(this.cmdAccept_Click);
            // 
            // AboutWnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 173);
            this.Controls.Add(this.cmdAccept);
            this.Controls.Add(this.linkMyWebsite);
            this.Controls.Add(this.lblText01);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AboutWnd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About Line Counter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblText01;
        private System.Windows.Forms.LinkLabel linkMyWebsite;
        private System.Windows.Forms.Button cmdAccept;
    }
}