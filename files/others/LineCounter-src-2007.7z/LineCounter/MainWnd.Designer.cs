﻿//***************************************************************************
// LineCounter 1.0 - A C/C++/C# source line counter.
// Copyright (C) 2007  Gorka Suárez García
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//***************************************************************************

namespace LineCounter
{
    partial class MainWnd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.menuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileNew = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFileSep01 = new System.Windows.Forms.ToolStripSeparator();
            this.menuFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTools = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolsFiles = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolsResult = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolsSep01 = new System.Windows.Forms.ToolStripSeparator();
            this.menuToolsAllFiles = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolsCppLang = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolsCsLang = new System.Windows.Forms.ToolStripMenuItem();
            this.menuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.menuHelpHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.menuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.mainTabs = new System.Windows.Forms.TabControl();
            this.tabFiles = new System.Windows.Forms.TabPage();
            this.panelFilesAdded = new System.Windows.Forms.Panel();
            this.cmdRemove = new System.Windows.Forms.Button();
            this.listFiles = new System.Windows.Forms.ListBox();
            this.panelFilesToAdd = new System.Windows.Forms.Panel();
            this.cmdAddFiles = new System.Windows.Forms.Button();
            this.cmdChangeDirectory = new System.Windows.Forms.Button();
            this.currentFiles = new System.Windows.Forms.ListBox();
            this.lblCurrentFiles = new System.Windows.Forms.Label();
            this.currentPath = new System.Windows.Forms.TextBox();
            this.lblCurrentDirectory = new System.Windows.Forms.Label();
            this.tabResult = new System.Windows.Forms.TabPage();
            this.cmdSaveResult = new System.Windows.Forms.Button();
            this.cmdCountLines = new System.Windows.Forms.Button();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.colFileName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLinesCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOnlyCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colWithBoth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colComments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotalLines = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveDialog = new System.Windows.Forms.SaveFileDialog();
            this.folderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.mainMenu.SuspendLayout();
            this.mainTabs.SuspendLayout();
            this.tabFiles.SuspendLayout();
            this.panelFilesAdded.SuspendLayout();
            this.panelFilesToAdd.SuspendLayout();
            this.tabResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.SuspendLayout();
            // 
            // mainMenu
            // 
            this.mainMenu.AccessibleName = "";
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFile,
            this.menuTools,
            this.menuHelp});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(696, 24);
            this.mainMenu.TabIndex = 0;
            // 
            // menuFile
            // 
            this.menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFileNew,
            this.menuFileOpen,
            this.menuFileSave,
            this.menuFileSaveAs,
            this.menuFileSep01,
            this.menuFileExit});
            this.menuFile.Name = "menuFile";
            this.menuFile.Size = new System.Drawing.Size(35, 20);
            this.menuFile.Text = "&File";
            // 
            // menuFileNew
            // 
            this.menuFileNew.Name = "menuFileNew";
            this.menuFileNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.menuFileNew.Size = new System.Drawing.Size(140, 22);
            this.menuFileNew.Text = "&New";
            this.menuFileNew.Click += new System.EventHandler(this.menuFileNew_Click);
            // 
            // menuFileOpen
            // 
            this.menuFileOpen.Name = "menuFileOpen";
            this.menuFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.menuFileOpen.Size = new System.Drawing.Size(140, 22);
            this.menuFileOpen.Text = "&Open";
            this.menuFileOpen.Click += new System.EventHandler(this.menuFileOpen_Click);
            // 
            // menuFileSave
            // 
            this.menuFileSave.Name = "menuFileSave";
            this.menuFileSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.menuFileSave.Size = new System.Drawing.Size(140, 22);
            this.menuFileSave.Text = "&Save";
            this.menuFileSave.Click += new System.EventHandler(this.menuFileSave_Click);
            // 
            // menuFileSaveAs
            // 
            this.menuFileSaveAs.Name = "menuFileSaveAs";
            this.menuFileSaveAs.Size = new System.Drawing.Size(140, 22);
            this.menuFileSaveAs.Text = "Save &as...";
            this.menuFileSaveAs.Click += new System.EventHandler(this.menuFileSaveAs_Click);
            // 
            // menuFileSep01
            // 
            this.menuFileSep01.Name = "menuFileSep01";
            this.menuFileSep01.Size = new System.Drawing.Size(137, 6);
            // 
            // menuFileExit
            // 
            this.menuFileExit.Name = "menuFileExit";
            this.menuFileExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.menuFileExit.Size = new System.Drawing.Size(140, 22);
            this.menuFileExit.Text = "&Exit";
            this.menuFileExit.Click += new System.EventHandler(this.menuFileExit_Click);
            // 
            // menuTools
            // 
            this.menuTools.Checked = true;
            this.menuTools.CheckState = System.Windows.Forms.CheckState.Checked;
            this.menuTools.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolsFiles,
            this.menuToolsResult,
            this.menuToolsSep01,
            this.menuToolsAllFiles,
            this.menuToolsCppLang,
            this.menuToolsCsLang});
            this.menuTools.Name = "menuTools";
            this.menuTools.Size = new System.Drawing.Size(44, 20);
            this.menuTools.Text = "&Tools";
            // 
            // menuToolsFiles
            // 
            this.menuToolsFiles.Name = "menuToolsFiles";
            this.menuToolsFiles.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.menuToolsFiles.Size = new System.Drawing.Size(171, 22);
            this.menuToolsFiles.Text = "Show &Files";
            this.menuToolsFiles.Click += new System.EventHandler(this.menuToolsFiles_Click);
            // 
            // menuToolsResult
            // 
            this.menuToolsResult.Name = "menuToolsResult";
            this.menuToolsResult.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D2)));
            this.menuToolsResult.Size = new System.Drawing.Size(171, 22);
            this.menuToolsResult.Text = "Show &Result";
            this.menuToolsResult.Click += new System.EventHandler(this.menuToolsResult_Click);
            // 
            // menuToolsSep01
            // 
            this.menuToolsSep01.Name = "menuToolsSep01";
            this.menuToolsSep01.Size = new System.Drawing.Size(168, 6);
            // 
            // menuToolsAllFiles
            // 
            this.menuToolsAllFiles.Checked = true;
            this.menuToolsAllFiles.CheckState = System.Windows.Forms.CheckState.Checked;
            this.menuToolsAllFiles.Name = "menuToolsAllFiles";
            this.menuToolsAllFiles.Size = new System.Drawing.Size(171, 22);
            this.menuToolsAllFiles.Text = "All files";
            this.menuToolsAllFiles.Click += new System.EventHandler(this.menuToolsAllFiles_Click);
            // 
            // menuToolsCppLang
            // 
            this.menuToolsCppLang.Name = "menuToolsCppLang";
            this.menuToolsCppLang.Size = new System.Drawing.Size(171, 22);
            this.menuToolsCppLang.Text = "C/C++";
            this.menuToolsCppLang.Click += new System.EventHandler(this.menuToolsCppLang_Click);
            // 
            // menuToolsCsLang
            // 
            this.menuToolsCsLang.Name = "menuToolsCsLang";
            this.menuToolsCsLang.Size = new System.Drawing.Size(171, 22);
            this.menuToolsCsLang.Text = "C#";
            this.menuToolsCsLang.Click += new System.EventHandler(this.menuToolsCsLang_Click);
            // 
            // menuHelp
            // 
            this.menuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuHelpHelp,
            this.menuHelpAbout});
            this.menuHelp.Name = "menuHelp";
            this.menuHelp.Size = new System.Drawing.Size(40, 20);
            this.menuHelp.Text = "&Help";
            // 
            // menuHelpHelp
            // 
            this.menuHelpHelp.Name = "menuHelpHelp";
            this.menuHelpHelp.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.menuHelpHelp.Size = new System.Drawing.Size(114, 22);
            this.menuHelpHelp.Text = "&Help";
            this.menuHelpHelp.Click += new System.EventHandler(this.menuHelpHelp_Click);
            // 
            // menuHelpAbout
            // 
            this.menuHelpAbout.Name = "menuHelpAbout";
            this.menuHelpAbout.Size = new System.Drawing.Size(114, 22);
            this.menuHelpAbout.Text = "&About";
            this.menuHelpAbout.Click += new System.EventHandler(this.menuHelpAbout_Click);
            // 
            // mainTabs
            // 
            this.mainTabs.Controls.Add(this.tabFiles);
            this.mainTabs.Controls.Add(this.tabResult);
            this.mainTabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainTabs.Location = new System.Drawing.Point(0, 24);
            this.mainTabs.Name = "mainTabs";
            this.mainTabs.SelectedIndex = 0;
            this.mainTabs.Size = new System.Drawing.Size(696, 483);
            this.mainTabs.TabIndex = 1;
            // 
            // tabFiles
            // 
            this.tabFiles.Controls.Add(this.panelFilesAdded);
            this.tabFiles.Controls.Add(this.panelFilesToAdd);
            this.tabFiles.Location = new System.Drawing.Point(4, 22);
            this.tabFiles.Name = "tabFiles";
            this.tabFiles.Padding = new System.Windows.Forms.Padding(3);
            this.tabFiles.Size = new System.Drawing.Size(688, 457);
            this.tabFiles.TabIndex = 0;
            this.tabFiles.Text = "Files";
            this.tabFiles.UseVisualStyleBackColor = true;
            // 
            // panelFilesAdded
            // 
            this.panelFilesAdded.Controls.Add(this.cmdRemove);
            this.panelFilesAdded.Controls.Add(this.listFiles);
            this.panelFilesAdded.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFilesAdded.Location = new System.Drawing.Point(343, 3);
            this.panelFilesAdded.Name = "panelFilesAdded";
            this.panelFilesAdded.Padding = new System.Windows.Forms.Padding(5);
            this.panelFilesAdded.Size = new System.Drawing.Size(342, 451);
            this.panelFilesAdded.TabIndex = 2;
            // 
            // cmdRemove
            // 
            this.cmdRemove.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cmdRemove.Location = new System.Drawing.Point(5, 414);
            this.cmdRemove.Name = "cmdRemove";
            this.cmdRemove.Size = new System.Drawing.Size(332, 32);
            this.cmdRemove.TabIndex = 1;
            this.cmdRemove.Text = "&Remove files";
            this.cmdRemove.UseVisualStyleBackColor = true;
            this.cmdRemove.Click += new System.EventHandler(this.cmdRemove_Click);
            // 
            // listFiles
            // 
            this.listFiles.Dock = System.Windows.Forms.DockStyle.Top;
            this.listFiles.FormattingEnabled = true;
            this.listFiles.Location = new System.Drawing.Point(5, 5);
            this.listFiles.Name = "listFiles";
            this.listFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listFiles.Size = new System.Drawing.Size(332, 407);
            this.listFiles.TabIndex = 0;
            // 
            // panelFilesToAdd
            // 
            this.panelFilesToAdd.Controls.Add(this.cmdAddFiles);
            this.panelFilesToAdd.Controls.Add(this.cmdChangeDirectory);
            this.panelFilesToAdd.Controls.Add(this.currentFiles);
            this.panelFilesToAdd.Controls.Add(this.lblCurrentFiles);
            this.panelFilesToAdd.Controls.Add(this.currentPath);
            this.panelFilesToAdd.Controls.Add(this.lblCurrentDirectory);
            this.panelFilesToAdd.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelFilesToAdd.Location = new System.Drawing.Point(3, 3);
            this.panelFilesToAdd.Name = "panelFilesToAdd";
            this.panelFilesToAdd.Padding = new System.Windows.Forms.Padding(5);
            this.panelFilesToAdd.Size = new System.Drawing.Size(340, 451);
            this.panelFilesToAdd.TabIndex = 1;
            // 
            // cmdAddFiles
            // 
            this.cmdAddFiles.Location = new System.Drawing.Point(170, 414);
            this.cmdAddFiles.MaximumSize = new System.Drawing.Size(165, 36);
            this.cmdAddFiles.Name = "cmdAddFiles";
            this.cmdAddFiles.Size = new System.Drawing.Size(165, 32);
            this.cmdAddFiles.TabIndex = 5;
            this.cmdAddFiles.Text = "&Add files";
            this.cmdAddFiles.UseVisualStyleBackColor = true;
            this.cmdAddFiles.Click += new System.EventHandler(this.cmdAddFiles_Click);
            // 
            // cmdChangeDirectory
            // 
            this.cmdChangeDirectory.Location = new System.Drawing.Point(5, 414);
            this.cmdChangeDirectory.MaximumSize = new System.Drawing.Size(165, 36);
            this.cmdChangeDirectory.Name = "cmdChangeDirectory";
            this.cmdChangeDirectory.Size = new System.Drawing.Size(165, 32);
            this.cmdChangeDirectory.TabIndex = 4;
            this.cmdChangeDirectory.Text = "&Change directory";
            this.cmdChangeDirectory.UseVisualStyleBackColor = true;
            this.cmdChangeDirectory.Click += new System.EventHandler(this.cmdChangeDirectory_Click);
            // 
            // currentFiles
            // 
            this.currentFiles.Dock = System.Windows.Forms.DockStyle.Top;
            this.currentFiles.FormattingEnabled = true;
            this.currentFiles.Location = new System.Drawing.Point(5, 66);
            this.currentFiles.Name = "currentFiles";
            this.currentFiles.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.currentFiles.Size = new System.Drawing.Size(330, 342);
            this.currentFiles.TabIndex = 3;
            this.currentFiles.DoubleClick += new System.EventHandler(this.currentFiles_DoubleClick);
            // 
            // lblCurrentFiles
            // 
            this.lblCurrentFiles.AutoSize = true;
            this.lblCurrentFiles.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCurrentFiles.Location = new System.Drawing.Point(5, 43);
            this.lblCurrentFiles.Name = "lblCurrentFiles";
            this.lblCurrentFiles.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.lblCurrentFiles.Size = new System.Drawing.Size(68, 23);
            this.lblCurrentFiles.TabIndex = 2;
            this.lblCurrentFiles.Text = "Current Files:";
            // 
            // currentPath
            // 
            this.currentPath.Dock = System.Windows.Forms.DockStyle.Top;
            this.currentPath.Location = new System.Drawing.Point(5, 23);
            this.currentPath.Name = "currentPath";
            this.currentPath.Size = new System.Drawing.Size(330, 20);
            this.currentPath.TabIndex = 1;
            this.currentPath.TextChanged += new System.EventHandler(this.currentPath_TextChanged);
            // 
            // lblCurrentDirectory
            // 
            this.lblCurrentDirectory.AutoSize = true;
            this.lblCurrentDirectory.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCurrentDirectory.Location = new System.Drawing.Point(5, 5);
            this.lblCurrentDirectory.Name = "lblCurrentDirectory";
            this.lblCurrentDirectory.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblCurrentDirectory.Size = new System.Drawing.Size(89, 18);
            this.lblCurrentDirectory.TabIndex = 0;
            this.lblCurrentDirectory.Text = "Current Directory:";
            // 
            // tabResult
            // 
            this.tabResult.Controls.Add(this.cmdSaveResult);
            this.tabResult.Controls.Add(this.cmdCountLines);
            this.tabResult.Controls.Add(this.dgvResult);
            this.tabResult.Location = new System.Drawing.Point(4, 22);
            this.tabResult.Name = "tabResult";
            this.tabResult.Padding = new System.Windows.Forms.Padding(3);
            this.tabResult.Size = new System.Drawing.Size(688, 457);
            this.tabResult.TabIndex = 1;
            this.tabResult.Text = "Result";
            this.tabResult.UseVisualStyleBackColor = true;
            // 
            // cmdSaveResult
            // 
            this.cmdSaveResult.Location = new System.Drawing.Point(429, 414);
            this.cmdSaveResult.Name = "cmdSaveResult";
            this.cmdSaveResult.Size = new System.Drawing.Size(256, 40);
            this.cmdSaveResult.TabIndex = 2;
            this.cmdSaveResult.Text = "&Save result";
            this.cmdSaveResult.UseVisualStyleBackColor = true;
            this.cmdSaveResult.Click += new System.EventHandler(this.cmdSaveResult_Click);
            // 
            // cmdCountLines
            // 
            this.cmdCountLines.Location = new System.Drawing.Point(3, 414);
            this.cmdCountLines.Name = "cmdCountLines";
            this.cmdCountLines.Size = new System.Drawing.Size(256, 40);
            this.cmdCountLines.TabIndex = 1;
            this.cmdCountLines.Text = "&Count lines";
            this.cmdCountLines.UseVisualStyleBackColor = true;
            this.cmdCountLines.Click += new System.EventHandler(this.cmdCountLines_Click);
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AllowUserToResizeColumns = false;
            this.dgvResult.AllowUserToResizeRows = false;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colFileName,
            this.colLinesCode,
            this.colOnlyCode,
            this.colWithBoth,
            this.colComments,
            this.colTotalLines});
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvResult.Location = new System.Drawing.Point(3, 3);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.RowHeadersWidth = 24;
            this.dgvResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvResult.Size = new System.Drawing.Size(682, 405);
            this.dgvResult.TabIndex = 0;
            // 
            // colFileName
            // 
            this.colFileName.HeaderText = "File name";
            this.colFileName.Name = "colFileName";
            this.colFileName.ReadOnly = true;
            this.colFileName.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colFileName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colFileName.Width = 130;
            // 
            // colLinesCode
            // 
            this.colLinesCode.HeaderText = "Lines of code";
            this.colLinesCode.Name = "colLinesCode";
            this.colLinesCode.ReadOnly = true;
            this.colLinesCode.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colLinesCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colOnlyCode
            // 
            this.colOnlyCode.HeaderText = "Only code";
            this.colOnlyCode.Name = "colOnlyCode";
            this.colOnlyCode.ReadOnly = true;
            this.colOnlyCode.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colOnlyCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colWithBoth
            // 
            this.colWithBoth.HeaderText = "With both";
            this.colWithBoth.Name = "colWithBoth";
            this.colWithBoth.ReadOnly = true;
            this.colWithBoth.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colWithBoth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colComments
            // 
            this.colComments.HeaderText = "Comments";
            this.colComments.Name = "colComments";
            this.colComments.ReadOnly = true;
            this.colComments.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colComments.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // colTotalLines
            // 
            this.colTotalLines.HeaderText = "Total lines";
            this.colTotalLines.Name = "colTotalLines";
            this.colTotalLines.ReadOnly = true;
            this.colTotalLines.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colTotalLines.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // openDialog
            // 
            this.openDialog.FileName = "openFileDialog1";
            // 
            // folderDialog
            // 
            this.folderDialog.Description = "Select a directory:";
            this.folderDialog.RootFolder = System.Environment.SpecialFolder.MyComputer;
            this.folderDialog.ShowNewFolderButton = false;
            // 
            // MainWnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 507);
            this.Controls.Add(this.mainTabs);
            this.Controls.Add(this.mainMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.mainMenu;
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(702, 532);
            this.Name = "MainWnd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Line Counter";
            this.Load += new System.EventHandler(this.MainWnd_Load);
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.mainTabs.ResumeLayout(false);
            this.tabFiles.ResumeLayout(false);
            this.panelFilesAdded.ResumeLayout(false);
            this.panelFilesToAdd.ResumeLayout(false);
            this.panelFilesToAdd.PerformLayout();
            this.tabResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem menuFile;
        private System.Windows.Forms.ToolStripMenuItem menuFileExit;
        private System.Windows.Forms.TabControl mainTabs;
        private System.Windows.Forms.TabPage tabFiles;
        private System.Windows.Forms.TabPage tabResult;
        private System.Windows.Forms.ToolStripMenuItem menuFileOpen;
        private System.Windows.Forms.ToolStripMenuItem menuFileSave;
        private System.Windows.Forms.ToolStripMenuItem menuFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator menuFileSep01;
        private System.Windows.Forms.ToolStripMenuItem menuFileNew;
        private System.Windows.Forms.OpenFileDialog openDialog;
        private System.Windows.Forms.SaveFileDialog saveDialog;
        private System.Windows.Forms.FolderBrowserDialog folderDialog;
        private System.Windows.Forms.ToolStripMenuItem menuTools;
        private System.Windows.Forms.ToolStripMenuItem menuHelp;
        private System.Windows.Forms.ToolStripMenuItem menuHelpHelp;
        private System.Windows.Forms.ToolStripMenuItem menuHelpAbout;
        private System.Windows.Forms.ToolStripMenuItem menuToolsFiles;
        private System.Windows.Forms.ToolStripMenuItem menuToolsResult;
        private System.Windows.Forms.ToolStripSeparator menuToolsSep01;
        private System.Windows.Forms.ToolStripMenuItem menuToolsCppLang;
        private System.Windows.Forms.Panel panelFilesToAdd;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.Panel panelFilesAdded;
        private System.Windows.Forms.Button cmdRemove;
        private System.Windows.Forms.ListBox listFiles;
        private System.Windows.Forms.TextBox currentPath;
        private System.Windows.Forms.Label lblCurrentDirectory;
        private System.Windows.Forms.ListBox currentFiles;
        private System.Windows.Forms.Label lblCurrentFiles;
        private System.Windows.Forms.Button cmdChangeDirectory;
        private System.Windows.Forms.Button cmdAddFiles;
        private System.Windows.Forms.Button cmdSaveResult;
        private System.Windows.Forms.Button cmdCountLines;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFileName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLinesCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOnlyCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWithBoth;
        private System.Windows.Forms.DataGridViewTextBoxColumn colComments;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotalLines;
        private System.Windows.Forms.ToolStripMenuItem menuToolsCsLang;
        private System.Windows.Forms.ToolStripMenuItem menuToolsAllFiles;


    }
}

