//***************************************************************************
// LineCounter 1.0 - A C/C++/C# source line counter.
// Copyright (C) 2007  Gorka Su�rez Garc�a
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//***************************************************************************

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace LineCounter.Data
{
    [Serializable]
    public class File
    {
        /********************************************************************************
         * Class attributes.
         ********************************************************************************/

        #region Attributes (path, linesInBlank, linesOfCode, linesOfComments, linesOfCodeWithComments)

        /// <summary> The path of the file. </summary>
        private string path;

        /// <summary> The number of lines with nothing. </summary>
        private int linesInBlank;

        /// <summary> The number of lines with only code. </summary>
        private int linesOfCode;

        /// <summary> The number of lines with only comments. </summary>
        private int linesOfComments;

        /// <summary> The number of lines with code and comments. </summary>
        private int linesOfCodeWithComments;

        /// <summary> If we are in a multiline comment this will be true. </summary>
        private bool multilineComment;

        /// <summary> If we are in a multiline string this will be true. </summary>
        private bool multilineString;

        /// <summary> If we are in a multiline character this will be true. </summary>
        private bool multilineCharacter;

        #endregion


        /********************************************************************************
         * Class properties.
         ********************************************************************************/

        #region Properties (Name, Extension, Path, LinesInBlank, LinesOfCode, LinesOfComments, ...)

        /********************************************************************************/
        /// <summary> The name of the file. </summary>
        /********************************************************************************/
        public string Name
        {
            get
            {
                //----------------------------------------------------------------------
                // First we check to find the slash, and if we find it, we will return
                // a substring with the name of the file.
                //----------------------------------------------------------------------
                for (int i = (this.path.Length - 1); i >= 0; --i)
                {
                    if (path[i] == '\\')
                    {
                        return path.Substring(i + 1);
                    }
                }

                //----------------------------------------------------------------------
                // If we don't find any slash we return the whole path.
                //----------------------------------------------------------------------
                return path;
            }
        }

        /********************************************************************************/
        /// <summary> The extension of the file. </summary>
        /********************************************************************************/
        public string Extension
        {
            get
            {
                //----------------------------------------------------------------------
                // First we check to find the point, and if we find it, we will return
                // a substring with the extension of the file.
                //----------------------------------------------------------------------
                for (int i = (this.path.Length - 1); i >= 0; --i)
                {
                    if (path[i] == '.')
                    {
                        return path.Substring(i);
                    }
                }

                //----------------------------------------------------------------------
                // If we don't find any point we return nothing.
                //----------------------------------------------------------------------
                return "";
            }
        }

        /********************************************************************************/
        /// <summary> The path of the file. </summary>
        /********************************************************************************/
        public string Path
        {
            get { return path; }
            set { path = value; }
        }

        /********************************************************************************/
        /// <summary> The number of lines with only code. </summary>
        /********************************************************************************/
        public int LinesInBlank
        {
            get { return linesInBlank; }
            set { linesInBlank = value; }
        }

        /********************************************************************************/
        /// <summary> The number of lines with only code. </summary>
        /********************************************************************************/
        public int LinesOfCode
        {
            get { return linesOfCode; }
            set { linesOfCode = value; }
        }

        /********************************************************************************/
        /// <summary> The number of lines with only comments. </summary>
        /********************************************************************************/
        public int LinesOfComments
        {
            get { return linesOfComments; }
            set { linesOfComments = value; }
        }

        /********************************************************************************/
        /// <summary> The number of lines with code and comments. </summary>
        /********************************************************************************/
        public int LinesOfCodeWithComments
        {
            get { return linesOfCodeWithComments; }
            set { linesOfCodeWithComments = value; }
        }

        /********************************************************************************/
        /// <summary> The number of lines code with or without comments. </summary>
        /********************************************************************************/
        public int LinesOfTotalCode
        {
            get { return linesOfCode + linesOfCodeWithComments; }
        }

        /********************************************************************************/
        /// <summary> The number of total lines of the file. </summary>
        /********************************************************************************/
        public int TotalLines
        {
            get { return linesOfCode + linesOfCodeWithComments + linesOfComments + linesInBlank; }
        }

        #endregion


        /********************************************************************************
         * Class methods.
         ********************************************************************************/

        /********************************************************************************/
        /// <summary>
        /// Main constructor of the File class.
        /// </summary>
        /********************************************************************************/
        public File()
        {
            this.path = "";

            this.linesInBlank = 0;
            this.linesOfCode = 0;
            this.linesOfComments = 0;
            this.linesOfCodeWithComments = 0;
        }
        
        /********************************************************************************/
        /// <summary>
        /// This method will read a file and check the number lines of it.
        /// </summary>
        /// <param name="path">File we want to check.</param>
        /********************************************************************************/
        public void Check(string path)
        {
            this.path = path;
            this.Check();
        }

        /********************************************************************************/
        /// <summary>
        /// This method will read a file and check the number lines of it.
        /// </summary>
        /********************************************************************************/
        public void Check()
        {
            try
            {
                //----------------------------------------------------------------------
                // First we reset the internal values of the object.
                //----------------------------------------------------------------------
                this.linesInBlank = 0;
                this.linesOfCode = 0;
                this.linesOfComments = 0;
                this.linesOfCodeWithComments = 0;

                this.multilineComment = false;
                this.multilineString = false;
                this.multilineCharacter = false;

                //----------------------------------------------------------------------
                // Second we open a file and read a line.
                //----------------------------------------------------------------------
                TextReader streamReader = new StreamReader(this.path);
                String line = streamReader.ReadLine();

                //----------------------------------------------------------------------
                // If the have be able to read one, we'll check it and read the next.
                //----------------------------------------------------------------------
                while(line != null)
                {
                    this.CheckLine(line.ToString());
                    line = streamReader.ReadLine();
                }

                //----------------------------------------------------------------------
                // After read the whole file, we'll close it.
                //----------------------------------------------------------------------
                streamReader.Close();
            }
            catch (Exception e)
            {
                this.linesInBlank = 0;
                this.linesOfCode = 0;
                this.linesOfComments = 0;
                this.linesOfCodeWithComments = 0;

                throw e;
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method checks a line we have taken from the file.
        /// </summary>
        /// <param name="line">Line of code we want to check.</param>
        /********************************************************************************/
        private void CheckLine(string line)
        {
            if (line.Length == 0)
            {
                //----------------------------------------------------------------------
                // We are in an empty line, so we will check if we are in a multiline
                // comment, or a multiline string.
                //----------------------------------------------------------------------
                if (this.multilineComment)
                    this.linesOfComments++;
                else if (this.multilineString)
                    this.linesOfCode++;
                else if (this.multilineCharacter)
                    this.linesOfCode++;
                else
                    this.linesInBlank++;
            }
            else
            {
                //----------------------------------------------------------------------
                // If the line isn't empty, we'll check if it's a blank line.
                //----------------------------------------------------------------------
                int index = this.CheckIsLineBlank(line, 0);

                //----------------------------------------------------------------------
                // If it's a blank line, we will check if we are in a multiline
                // comment, or a multiline string.
                //----------------------------------------------------------------------
                if (index < 0)
                {
                    if (this.multilineComment)
                        this.linesOfComments++;
                    else if (this.multilineString)
                        this.linesOfCode++;
                    else if (this.multilineCharacter)
                        this.linesOfCode++;
                    else
                        this.linesInBlank++;
                }
                //----------------------------------------------------------------------
                // Otherwise we well check the type of line.
                //----------------------------------------------------------------------
                else
                {
                    switch (this.CheckCodeLine(line, index))
                    {
                        case LineType.CodeLine:
                            this.linesOfCode++;
                            break;

                        case LineType.CommentLine:
                            this.linesOfComments++;
                            break;

                        case LineType.CodeAndCommentLine:
                            this.linesOfCodeWithComments++;
                            break;

                        default:
                            this.linesInBlank++;
                            break;
                    }
                }
            }
        }

        /********************************************************************************/
        /// <summary> Enumeration for the type of the lines. </summary>
        /********************************************************************************/
        private enum LineType
        {
            CodeLine = 0,
            CommentLine = 1,
            CodeAndCommentLine = 2,
            BlankLine = 3
        }

        /********************************************************************************/
        /// <summary>
        /// This method will return the type of line according to a couple of booleans.
        /// </summary>
        /// <param name="hasCode">This will be true if the line have code.</param>
        /// <param name="hasCooment">This will be true if the line have a comment.</param>
        /// <returns>The type of line.</returns>
        /********************************************************************************/
        private LineType GetLineType(bool hasCode, bool hasComment)
        {
            if (hasCode && hasComment)
            {
                return LineType.CodeAndCommentLine;
            }
            else if (hasCode)
            {
                return LineType.CodeLine;
            }
            else if (hasComment)
            {
                return LineType.CommentLine;
            }
            else
            {
                return LineType.BlankLine;
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method checks if the number of previous slashes are a parity number.
        /// </summary>
        /// <param name="line">The line we want to check.</param>
        /// <param name="index">The start position of the line.</param>
        /// <returns>The parity or not of slashes in the line.</returns>
        /********************************************************************************/
        private bool CheckSlashParity(string line, int index)
        {
            int numSlashes = 0;
            int i = index - 1;

            while (i > 0)
            {
                if (line[i] == '\\')
                {
                    numSlashes++;
                    i--;
                }
                else
                    break;
            }

            return ((numSlashes % 2) == 0);
        }

        /********************************************************************************/
        /// <summary>
        /// This method will check the type of line of the current line.
        /// </summary>
        /// <param name="line">The line we want to check.</param>
        /// <param name="index">The start position of the line.</param>
        /// <returns>The type of line we have checked.</returns>
        /********************************************************************************/
        private LineType CheckCodeLine(string line, int index)
        {
            //--------------------------------------------------------------------------
            // First we have to check if a multiline comment have been previously
            // opened, in that case we will have at least a comment line.
            //--------------------------------------------------------------------------
            bool hasCode = false, hasComment = this.multilineComment;

            //--------------------------------------------------------------------------
            // Then we have to check every character inside the line, to find code and
            // comments inside looking for the special combinations of characters.
            //--------------------------------------------------------------------------
            for (int i = index; i < line.Length; ++i)
            {
                //----------------------------------------------------------------------
                // If we aren't inside a multiline comment, we will check two things,
                // if there is any open comment mark, or an open string mark.
                //----------------------------------------------------------------------
                if (!this.multilineComment)
                {
                    switch (line[i])
                    {
                        //--------------------------------------------------------------
                        // Since we aren't in a multiline comment, we will search for
                        // any open comment mark, so we will check any slash we will
                        // find, if we aren't inside a multiline string or a string.
                        //--------------------------------------------------------------
                        case '/':
                            if ((!this.multilineString && !this.multilineCharacter) &&
                                (i < (line.Length - 1)))
                            {
                                //------------------------------------------------------
                                // If the next character is an * that means that we
                                // have find an open comment mark.
                                //------------------------------------------------------
                                if (line[i + 1] == '*')
                                {
                                    hasComment = true;
                                    this.multilineComment = true;
                                }
                                //------------------------------------------------------
                                // But if the next character is another slash, we have
                                // find an one line comment, represented by the //.
                                //------------------------------------------------------
                                else if (line[i + 1] == '/')
                                {
                                    hasComment = true;
                                    return this.GetLineType(hasCode, hasComment);
                                }
                            }
                            else
                            {
                                hasCode = true;
                            }
                            break;

                        //--------------------------------------------------------------
                        // If we find the " symbol that means that we have maybe open
                        // or close a code string. So first we have to check if we are
                        // inside a string, in that case we'll have to see if the
                        // previous character was a slash, if not we'll have closed the
                        // string. If we aren't in a string we'll have opened one.
                        //--------------------------------------------------------------
                        case '\"':
                            hasCode = true;

                            if (!this.multilineCharacter)
                            {
                                if (this.multilineString)
                                {
                                    if (this.CheckSlashParity(line, i))
                                    {
                                        this.multilineString = false;
                                    }
                                }
                                else
                                {
                                    this.multilineString = true;
                                }
                            }
                            break;

                        //--------------------------------------------------------------
                        // If we find the ' symbol that means that we have maybe open
                        // or close a code string. So first we have to check if we are
                        // inside a string, in that case we'll have to see if the
                        // previous character was a slash, if not we'll have closed the
                        // string. If we aren't in a string we'll have opened one.
                        //--------------------------------------------------------------
                        case '\'':
                            hasCode = true;

                            if (!this.multilineString)
                            {
                                if (this.multilineCharacter)
                                {
                                    if (this.CheckSlashParity(line, i))
                                    {
                                        this.multilineCharacter = false;
                                    }
                                }
                                else
                                {
                                    this.multilineCharacter = true;
                                }
                            }
                            break;

                        //--------------------------------------------------------------
                        // Any other symbol will be only code.
                        //--------------------------------------------------------------
                        default:
                            if ((line[i] != '\t') && (line[i] != ' '))
                            {
                                hasCode = true;
                            }
                            break;
                    }
                }
                //----------------------------------------------------------------------
                // If we are inside a multiline comment, we will only need to find the
                // end comment mark, which is like this: "*/".
                //----------------------------------------------------------------------
                else
                {
                    if ((line[i] == '/') && (i > 0) && (line[i - 1] == '*'))
                    {
                        this.multilineComment = false;
                    }
                }
            }

            //--------------------------------------------------------------------------
            // If we get to the end of the line, we will return the type of line,
            // checking the result of hasCode and hasComment.
            //--------------------------------------------------------------------------
            return this.GetLineType(hasCode, hasComment);
        }

        /********************************************************************************/
        /// <summary>
        /// This method will check if a line is a blank one, this is that the line will
        /// only have spaces or tabulations as characters.
        /// </summary>
        /// <param name="line">The line we want to check.</param>
        /// <param name="index">The start position of the line.</param>
        /// <returns>-1 if the line is a blank one, otherwise will return the position
        /// of the first non blank character.</returns>
        /********************************************************************************/
        private int CheckIsLineBlank(string line, int index)
        {
            //--------------------------------------------------------------------------
            // We will check inside the string, that there is only spaces and
            // tabulations. If we find a non-blank character, we will return the
            // position of this non-blank character.
            //--------------------------------------------------------------------------
            for (int i = index; i < line.Length; ++i)
            {
                if ((line[i] != '\t') && (line[i] != ' '))
                    return i;
            }

            //--------------------------------------------------------------------------
            // If we haven't find any non-blank character, we will return -1.
            //--------------------------------------------------------------------------
            return -1;
        }
    }
}
