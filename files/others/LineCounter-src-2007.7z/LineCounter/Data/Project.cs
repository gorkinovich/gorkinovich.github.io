//***************************************************************************
// LineCounter 1.0 - A C/C++/C# source line counter.
// Copyright (C) 2007  Gorka Su�rez Garc�a
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
//***************************************************************************

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace LineCounter.Data
{
    [Serializable]
    public class Project
    {
        /********************************************************************************
         * Class attributes.
         ********************************************************************************/

        #region Attributes (name, paths, files)

        /// <summary> Name of the project file. </summary>
        private string name;

        /// <summary> List of files and directories for the project. </summary>
        private List<string> paths;

        /// <summary> List with the data for each file. </summary>
        private List<File> files;

        #endregion
        

        /********************************************************************************
         * Class properties.
         ********************************************************************************/

        #region Properties (Name, Paths, Files)

        /********************************************************************************/
        /// <summary> Name of the project file. </summary>
        /********************************************************************************/
        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        /********************************************************************************/
        /// <summary> Array with the files and directories for the project. </summary>
        /********************************************************************************/
        public string[] Paths
        {
            get { return this.paths.ToArray(); }

            set
            {
                this.paths = new List<string>();
                foreach (string path in value) this.paths.Add(path);
            }
        }

        /********************************************************************************/
        /// <summary> Array with the data for each file. </summary>
        /********************************************************************************/
        public File[] Files
        {
            get { return this.files.ToArray(); }

            set
            {
                this.files = new List<File>();
                foreach (File file in value) this.files.Add(file);
            }
        }
        
        #endregion


        /********************************************************************************
         * Class methods.
         ********************************************************************************/

        /********************************************************************************/
        /// <summary>
        /// Main constructor of the Project class.
        /// </summary>
        /********************************************************************************/
        public Project()
        {
            this.name = "";
            this.paths = null;
            this.files = null;
        }

        /********************************************************************************/
        /// <summary>
        /// This method reads and check all the files in the project.
        /// </summary>
        /// <param name="paths">List of paths we want to check.</param>
        /********************************************************************************/
        public void Check(string[] paths)
        {
            this.Paths = paths;
            this.Check();
        }

        /********************************************************************************/
        /// <summary>
        /// This method reads and check all the files in the project.
        /// </summary>
        /********************************************************************************/
        public void Check()
        {
            try
            {
                //----------------------------------------------------------------------
                // First we will create a new list of files.
                //----------------------------------------------------------------------
                this.files = new List<File>();

                //----------------------------------------------------------------------
                // Second we will add any path inside the paths array object.
                //----------------------------------------------------------------------
                List<string>.Enumerator itPaths = this.paths.GetEnumerator();
                while (itPaths.MoveNext())
                {
                    this.AddNewFile(itPaths.Current);
                }

                //----------------------------------------------------------------------
                // And then we will check every file added to the list of files.
                //----------------------------------------------------------------------
                List<File>.Enumerator itFiles = this.files.GetEnumerator();
                while (itFiles.MoveNext())
                {
                    itFiles.Current.Check();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method will add a new file from a path given.
        /// </summary>
        /// <param name="path">The path we want to add.</param>
        /********************************************************************************/
        private void AddNewFile(string path)
        {
            //--------------------------------------------------------------------------
            // But the path can be a directory, in that case we will add the files of
            // the C/C++, C# or Java language inside that directory.
            //--------------------------------------------------------------------------
            if (path[path.Length - 1] == '\\')
            {
                //----------------------------------------------------------------------
                // First we add the child directories.
                //----------------------------------------------------------------------
                string[] dirs = Directory.GetDirectories(path);
                foreach (string dir in dirs)
                {
                    this.AddNewFile(dir + "\\");
                }

                //----------------------------------------------------------------------
                // And then the source files.
                //----------------------------------------------------------------------
                string[] files = Directory.GetFiles(path, "*.cs");
                this.AddNewFiles(files);

                files = Directory.GetFiles(path, "*.java");
                this.AddNewFiles(files);

                files = Directory.GetFiles(path, "*.h");
                this.AddNewFiles(files);
                files = Directory.GetFiles(path, "*.c");
                this.AddNewFiles(files);
                files = Directory.GetFiles(path, "*.hpp");
                this.AddNewFiles(files);
                files = Directory.GetFiles(path, "*.cpp");
                this.AddNewFiles(files);
            }
            //--------------------------------------------------------------------------
            // And if the path is a file, we add only one new object File.
            //--------------------------------------------------------------------------
            else
            {
                File fileData = new File();
                fileData.Path = path;
                this.files.Add(fileData);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method will add an array of file paths.
        /// </summary>
        /// <param name="paths">The paths we want to add.</param>
        /********************************************************************************/
        private void AddNewFiles(string[] paths)
        {
            //--------------------------------------------------------------------------
            // First we declare the object where we'll store the file data.
            //--------------------------------------------------------------------------
            File fileData = null;

            //--------------------------------------------------------------------------
            // And for each path in the array, we'll add a new file object.
            //--------------------------------------------------------------------------
            foreach (string path in paths)
            {
                fileData = new File();
                fileData.Path = path;
                this.files.Add(fileData);
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method saves the project in an extern file.
        /// </summary>
        /// <param name="path">Name of the file where we want to save.</param>
        /********************************************************************************/
        public void Save(string path)
        {
            this.name = path;
            this.Save();
        }

        /********************************************************************************/
        /// <summary>
        /// This method saves the project in an extern file.
        /// </summary>
        /********************************************************************************/
        public void Save()
        {
            try
            {
                //----------------------------------------------------------------------
                // First we open the file where we want to save.
                //----------------------------------------------------------------------
                XmlSerializer serializer = new XmlSerializer(typeof(Project));
                XmlTextWriter stream = new XmlTextWriter(this.name, Encoding.UTF8);

                //----------------------------------------------------------------------
                // Second we set the format for the xml.
                //----------------------------------------------------------------------
                stream.Formatting = Formatting.Indented;
                stream.Indentation = 1;
                stream.IndentChar = '\t';

                //----------------------------------------------------------------------
                // And then we write the content inside the file.
                //----------------------------------------------------------------------
                serializer.Serialize(stream, this);
                stream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method loads the project from an extern file.
        /// </summary>
        /// <param name="path">Name of the file from where we want to load.</param>
        /********************************************************************************/
        public void Load(string path)
        {
            this.name = path;
            this.Load();
        }

        /********************************************************************************/
        /// <summary>
        /// This method loads the project from an extern file.
        /// </summary>
        /********************************************************************************/
        public void Load()
        {
            try
            {
                //----------------------------------------------------------------------
                // First we open the file from where we want to load.
                //----------------------------------------------------------------------
                XmlSerializer serializer = new XmlSerializer(typeof(Project));
                XmlTextReader stream = new XmlTextReader(this.name);

                //----------------------------------------------------------------------
                // And then we read the content inside the file.
                //----------------------------------------------------------------------
                Project aux = (Project) serializer.Deserialize(stream);

                this.name = aux.name;
                this.paths = aux.paths;
                this.files = aux.files;

                stream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method saves the result in an extern file.
        /// </summary>
        /// <param name="path">Name of the file where we want to save.</param>
        /********************************************************************************/
        public void SaveResult(string path)
        {
            try
            {
                //----------------------------------------------------------------------
                // First create a file object to check the extension.
                //----------------------------------------------------------------------
                File aux = new File();
                aux.Path = path;

                //----------------------------------------------------------------------
                // And if the extension is xml we'll use the method to save it as an
                // xml file, otherwise we'll save it as a text file.
                //----------------------------------------------------------------------
                if(aux.Extension.ToLower() == ".xml")
                    this.SaveResultAsXML(path);
                else
                    this.SaveResultAsTXT(path);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /********************************************************************************/
        /// <summary>
        /// This method saves the result in an extern txt file.
        /// </summary>
        /// <param name="path">Name of the file where we want to save.</param>
        /********************************************************************************/
        private void SaveResultAsTXT(string path)
        {
            //--------------------------------------------------------------------------
            // First we open the file where we want to save.
            //--------------------------------------------------------------------------
            StreamWriter stream = new StreamWriter(path, false, Encoding.UTF8);

            //--------------------------------------------------------------------------
            // Second we create one counter for each category.
            //--------------------------------------------------------------------------
            int totalTotalCode = 0;
            int totalCode = 0;
            int totalCodeWithComments = 0;
            int totalComments = 0;
            int totalLines = 0;

            //--------------------------------------------------------------------------
            // Then we write the content inside the file.
            //--------------------------------------------------------------------------
            stream.Write("Name: {0}\r\n\r\n", this.name);

            File[] fileData = this.files.ToArray();
            stream.Write("File name                      Lines of code        Only Code            With both            Comments             Total lines\r\n");
            stream.Write("============================== ==================== ==================== ==================== ==================== ====================\r\n");
            for (int i = 0; i < this.files.Count; i++)
            {
                stream.Write(Text.RightAlignedString(fileData[i].Name, 30) + " ");
                stream.Write(Text.LeftAlignedString(fileData[i].LinesOfTotalCode.ToString(), 20) + " ");
                stream.Write(Text.LeftAlignedString(fileData[i].LinesOfCode.ToString(), 20) + " ");
                stream.Write(Text.LeftAlignedString(fileData[i].LinesOfCodeWithComments.ToString(), 20) + " ");
                stream.Write(Text.LeftAlignedString(fileData[i].LinesOfComments.ToString(), 20) + " ");
                stream.Write(Text.LeftAlignedString(fileData[i].TotalLines.ToString(), 20) + "\r\n");

                totalTotalCode += files[i].LinesOfTotalCode;
                totalCode += files[i].LinesOfCode;
                totalCodeWithComments += files[i].LinesOfCodeWithComments;
                totalComments += files[i].LinesOfComments;
                totalLines += files[i].TotalLines;
            }

            //--------------------------------------------------------------------------
            // And finally we set the cells of the total values.
            //--------------------------------------------------------------------------
            stream.Write("\r\n");
            stream.Write(Text.RightAlignedString("Total", 30) + " ");
            stream.Write(Text.LeftAlignedString(totalTotalCode.ToString(), 20) + " ");
            stream.Write(Text.LeftAlignedString(totalCode.ToString(), 20) + " ");
            stream.Write(Text.LeftAlignedString(totalCodeWithComments.ToString(), 20) + " ");
            stream.Write(Text.LeftAlignedString(totalComments.ToString(), 20) + " ");
            stream.Write(Text.LeftAlignedString(totalLines.ToString(), 20));

            stream.Close();
        }

        /********************************************************************************/
        /// <summary>
        /// This method saves the result in an extern xml file.
        /// </summary>
        /// <param name="path">Name of the file where we want to save.</param>
        /********************************************************************************/
        private void SaveResultAsXML(string path)
        {
            //--------------------------------------------------------------------------
            // First we open the file where we want to save.
            //--------------------------------------------------------------------------
            XmlSerializer serializer = new XmlSerializer(typeof(List<File>));
            XmlTextWriter stream = new XmlTextWriter(path, Encoding.UTF8);

            //--------------------------------------------------------------------------
            // Second we set the format for the xml.
            //--------------------------------------------------------------------------
            stream.Formatting = Formatting.Indented;
            stream.Indentation = 1;
            stream.IndentChar = '\t';

            //--------------------------------------------------------------------------
            // And then we write the content inside the file.
            //--------------------------------------------------------------------------
            serializer.Serialize(stream, this.files);
            stream.Close();
        }
    }
}
