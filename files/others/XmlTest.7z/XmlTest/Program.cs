﻿using System;
using System.Text;
using System.Xml;
using System.Xml.Serialization;


namespace XmlTest
{
    [XmlRootAttribute("person", Namespace = "", IsNullable = false)]
    public class Persona
    {
        //******************************************************************************
        #region Campos (nombre, apellidos)

        private string nombre;

        private string apellidos;

        private int auxiliar;

        private int[] telefonos;

        private DatosBiometricos datos;

        #endregion

        //******************************************************************************
        #region Propiedades (Nombre, Apellidos)

        [XmlElementAttribute("name")]
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        [XmlElementAttribute("lastname")]
        public string Apellidos
        {
            get { return apellidos; }
            set { apellidos = value; }
        }

        [XmlIgnoreAttribute()]
        public int Auxiliar
        {
            get { return auxiliar; }
            set { auxiliar = value; }
        }

        [XmlArray("phones"), XmlArrayItem("number", typeof(int))]
        public int[] Telefonos
        {
            get { return telefonos; }
            set { telefonos = value; }
        }

        [XmlElementAttribute("biometrics")]
        public DatosBiometricos Datos
        {
            get { return datos; }
            set { datos = value; }
        }

        #endregion

        //******************************************************************************
        #region Constructores

        public Persona()
        {
            this.nombre = "";
            this.apellidos = "";
            this.auxiliar = 0;
            this.telefonos = null;
            this.datos = new DatosBiometricos();
        }

        public Persona(string nombre, string apellidos)
        {
            this.nombre = nombre;
            this.apellidos = apellidos;
            this.auxiliar = 0;
            this.telefonos = null;
            this.datos = new DatosBiometricos();
        }

        #endregion
    }

    public class DatosBiometricos
    {
        private int peso;

        [XmlElementAttribute("weight")]
        public int Peso
        {
            get { return peso; }
            set { peso = value; }
        }

        public DatosBiometricos()
        {
            this.peso = 0;
        }
    }

    public class Program
    {
        //******************************************************************************
        public static void Main(string[] args)
        {
            Persona p1 = new Persona("Alexander", "Lessman");
            p1.Telefonos = new int[] { 1, 2, 3 };
            p1.Datos.Peso = 80;
            Persona p2 = null;

            Console.WriteLine("Contenido de la primera persona:");
            Console.WriteLine(" + Nombre:    " + p1.Nombre);
            Console.WriteLine(" + Apellidos: " + p1.Apellidos + "\n");

            Console.WriteLine("Salvamos en un XML el contenido de la primera persona...\n");
            Program.Salvar("persona.xml", p1);

            Console.WriteLine("Cargamos el contenido del XML en la segunda persona...\n");
            p2 = Program.Cargar("persona.xml");

            Console.WriteLine("Contenido de la primera persona:");
            Console.WriteLine(" + Nombre:    " + p2.Nombre);
            Console.WriteLine(" + Apellidos: " + p2.Apellidos + "\n");

            Console.WriteLine("Pulse una tecla para finalizar...");
            Console.ReadKey();
        }

        //******************************************************************************
        #region Metodos (Cargar, Salvar)

        public static Persona Cargar(string ruta)
        {
            try
            {
                //----------------------------------------------------------------------
                // Primero creamos el serializador que va a interpretar el XML, para
                // poder crear una clase a partir de este fichero. Después creamos el
                // stream de entrada a nuestro programa, que leerá el fichero.
                //----------------------------------------------------------------------
                XmlSerializer serializer = new XmlSerializer(typeof(Persona));
                XmlTextReader stream = new XmlTextReader(ruta);

                //----------------------------------------------------------------------
                // Creado el serializador y el stream, mandamos transformar el
                // contenido que vamos leyendo del stream, a un objeto del programa.
                //----------------------------------------------------------------------
                Persona aux = (Persona)serializer.Deserialize(stream);

                //----------------------------------------------------------------------
                // Cerramos el stream y devolvemos el objeto que hemos obtenido.
                //----------------------------------------------------------------------
                stream.Close();
                return aux;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static void Salvar(string ruta, Persona objeto)
        {
            try
            {
                //----------------------------------------------------------------------
                // Primero creamos el serializador que va a generar el XML a partir de
                // la clase que le hemos pasado. Después creamos el stream de salida
                // de nuestro programa, que escribirá el fichero.
                //----------------------------------------------------------------------
                XmlSerializer serializer = new XmlSerializer(typeof(Persona));
                XmlTextWriter stream = new XmlTextWriter(ruta, Encoding.UTF8);

                //----------------------------------------------------------------------
                // A fin de permitir una mejor claridad si lo abrimos desde el bloc de
                // notas, le indicaremos al stream, que emplee un estilo de formato
                // identado con tabulaciones.
                //----------------------------------------------------------------------
                stream.Formatting = Formatting.Indented;
                stream.Indentation = 1;
                stream.IndentChar = '\t';

                //----------------------------------------------------------------------
                // Finalmente mandamos que cree el XML y se cierre el stream.
                //----------------------------------------------------------------------
                serializer.Serialize(stream, objeto);
                stream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion
    }
}
