//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Core.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _CORE_H_
#define _CORE_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Surface.h"
#include "Sprite.h"
#include "Font.h"
#include "Graphics.h"
#include "Input.h"
#include "Sound.h"
#include "Audio.h"
#include "Script.h"
//******************************************************************************************
#ifndef _DOC_IN_ENGLISH_
/// Namespace principal de la librer�a Yukino.
/**
 *  El namespace Yukino es el principal y �nico contenedor de clases de la librer�a. Estas
 *  se dividen en dos tipos diferentes, clases que manejan alg�n sistema determinado, y
 *  clases que sirven para almacenar imagenes o sonidos.<br>
 *
 *  + Clases para manejar alg�n sistema: Core, Script, Audio, Input, Graphics.<br>
 *
 *  + Clases para almacenar datos: Surface, Sprite, Sound, Font.<br><br>
 */
#else
/// Main namespace of the Yukino library.
/**
 *  The namespace Yukino is the main and only container of classes of the library. These
 *  are divided in two different types, classes that handle some determined system, and
 *  classes that serve to store images or sounds.<br>
 *
 *  + Classes to handle some system: Core, Script, Audio, Input, Graphics.<br>
 *
 *  + Classes to store data: Surface, Sprite, Sound, Font.<br><br>
 */
#endif
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Core Errors
	//--------------------------------------------------------------------------------------
	const UINT CORE_ERROR_SDLINIT = 1; /**< Error al inicializar la librer�a SDL. */

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase que gestiona el sistema base.
	/**
	 *  El principal motivo para la existencia de la clase Core es inicializar el sistema
	 *  base de la librer�a, sobre el que se montan el resto de funcionalidades de la
	 *  librer�a. Para hacer m�s comodo el uso de los otros apartados, Core contiene
	 *  punteros a las clases Graphics, Input, Audio y Script.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class that manages the base system.
	/**
	 *  The main reason for the existence of the class Core is to initialize the base
	 *  system of the library, on which the rest of functionalities of the library mounts.
	 *  In order to make the use more comfortable of the other sections, Core contains
	 *  pointers to the classes Graphics, Input, Audio and Script.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Core
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			static Core * Instance;

			string AppName;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			Core ();
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Objeto para manejar el apartado gr�fico.
			/**
			 *  Esta variable es un puntero al objeto que maneja el apartado gr�fico de la
			 *  librer�a. Desde �l podremos hacer llamadas para pintar cualquier Surface
			 *  que tengamos en la pantalla de la aplicaci�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Object to handle the graphical section.
			/**
			 *  This variable is a pointer to the object that handles the graphical section
			 *  of the library. From him we will be able to make calls to paint any Surface
			 *  that we have in the screen of the application. 
			 */
			//------------------------------------------------------------------------------
#endif
			Graphics * AppGraphics;

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Objeto para manejar la entrada del programa.
			/**
			 *  Esta variable es un puntero al objeto que maneja el apartado de la entrada
			 *  de la librer�a. Desde �l podremos manejar el teclado y el rat�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Object to handle the input of the program.
			/**
			 *  This variable is a pointer to the object that handles the section of the
			 *  input of the library. From him we will be able to handle the keyboard and
			 *  the mouse.
			 */
			//------------------------------------------------------------------------------
#endif
			Input * AppInput;

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Objeto para manejar el apartado del audio.
			/**
			 *  Esta variable es un puntero al objeto que maneja el apartado del audio de
			 *  la librer�a. Desde �l podremos manejar el audio y reproducir sonidos.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Object to handle the section of the audio one.
			/**
			 *  This variable is a pointer to the object that handles the section of the
			 *  audio one of the library. From him we will be able to handle the audio one
			 *  and to reproduce sounds.
			 */
			//------------------------------------------------------------------------------
#endif
			Audio * AppAudio;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Objeto para manejar el apartado del scripting con Lua.
			/**
			 *  Esta variable es un puntero al objeto que maneja el apartado del scripting
			 *  con Lua de la librer�a. Desde �l podremos configurar el interprete, y
			 *  manejar m�nimamente la pila de Lua, al crearnos nuestras funciones.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Object to handle the section of scripting with Lua.
			/**
			 *  This variable is a pointer to the object that handles the section of
			 *  scripting with Lua of the library. From him we will be able to configure
			 *  interpreter, and to handle the stack of Lua, when we create our functions.
			 */
			//------------------------------------------------------------------------------
#endif
			Script * AppScript;

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para inicializar el objeto Core.
			/**
			 *  Esta funci�n sirve para inicializar tan solo el objeto Core, pas�ndole el
			 *  nombre de la aplicaci�n, que va a usar la librer�a.
			 *  @param name Nombre de la aplicaci�n.
			 *  @see InitAll(), Release(), ReleaseAll().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          CORE_ERROR_SDLINIT.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to initialize the object Core.
			/**
			 *  This function serves to initialize only the object Core, passing to him the
			 *  name of the application, that is going to use the library.
			 *  @param name Name of the application.
			 *  @see InitAll(), Release(), ReleaseAll().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          CORE_ERROR_SDLINIT.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Init (const char * name);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para inicializar la librer�a entera.
			/**
			 *  Esta funci�n sirve para inicializar la librer�a entera, pas�ndole los
			 *  parametros necesarios para iniciar Core, Graphics, Input, Audio y Script.
			 *  @param name      Nombre de la aplicaci�n.
			 *  @param w         Ancho de la aplicaci�n.
			 *  @param h         Alto de la aplicaci�n.
			 *  @param bpp       Profundidad de color de la aplicaci�n.
			 *  @param winmode   Modo ventana activado.
			 *  @param frequency Frecuencia del audio.
			 *  @param format    Formato del audio.
			 *  @param channels  N�mero de canales del audio.
			 *  @param chunksize Tama�o del buffer del audio.
			 *  @see Init(), Release(), ReleaseAll().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          CORE_ERROR_SDLINIT, GRAPHICS_ERROR_VIDEOMODEOK,
			 *          GRAPHICS_ERROR_SETVIDEOMODE, GRAPHICS_ERROR_TTFINIT,
			 *          INPUT_ERROR_GETKEYSTATE, AUDIO_ERROR_OPEN, AUDIO_ERROR_QUERYSPEC,
			 *          AUDIO_ERROR_NOTEQU, SCRIPT_ERROR_LUAOPEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to initialize the whole library.
			/**
			 *  This function serves to initialize the whole library, passing to him the
			 *  parameters necessary to initiate Core, Graphics, Input, Audio and Script.
			 *  @param name      Name of the application.
			 *  @param w         Width of the application.
			 *  @param h         Height of the application.
			 *  @param bpp       Depth of color of the application.
			 *  @param winmode   Window mode activated.
			 *  @param frequency Audio's frequency.
			 *  @param format    Audio's format.
			 *  @param channels  Audio's channels's number.
			 *  @param chunksize Audio's buffer's size.
			 *  @see Init(), Release(), ReleaseAll().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          CORE_ERROR_SDLINIT, GRAPHICS_ERROR_VIDEOMODEOK,
			 *          GRAPHICS_ERROR_SETVIDEOMODE, GRAPHICS_ERROR_TTFINIT,
			 *          INPUT_ERROR_GETKEYSTATE, AUDIO_ERROR_OPEN, AUDIO_ERROR_QUERYSPEC,
			 *          AUDIO_ERROR_NOTEQU, SCRIPT_ERROR_LUAOPEN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT InitAll (const char * name, int w, int h, int bpp = 32, bool winmode = false,
						  int frequency = DEFAULT_FREQUENCY22, word format = DEFAULT_FORMAT,
						  int channels = DEFAULT_NUM_CHANNELS, int chunksize = DEFAULT_CHUNKSIZE);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para finalizar el objeto Core.
			/**
			 *  Esta funci�n sirve para finalizar tan solo el objeto Core.
			 *  @see Init(), InitAll(), ReleaseAll().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to finalize the object Core.
			/**
			 *  This function serves to finalize only the object Core.
			 *  @see Init(), InitAll(), ReleaseAll().
			 */
			//------------------------------------------------------------------------------
#endif
			void Release (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para finalizar la librer�a entera.
			/**
			 *  Esta funci�n sirve para finalizar la librer�a entera.
			 *  @see Init(), InitAll(), Release().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to finalize the whole library.
			/**
			 *  This function serves to finalize the whole library.
			 *  @see Init(), InitAll(), Release().
			 */
			//------------------------------------------------------------------------------
#endif
			void ReleaseAll (void);

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para enviar un mensaje de error por pantalla.
			/**
			 *  Esta funci�n sirve para que la aplicaci�n muestre un mensaje de error al
			 *  usuario, en caso de que tras encontrar un error, querramos mostrar una
			 *  explicaci�n de qu� es lo que ha pasado.
			 *  @param msg Mensaje de error que queremos mostrar al usuario.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to send a message of error by screen.
			/**
			 *  This function serves to show the user a message of error of the application,
			 *  in case that after finding an error, we may want to show an explanation of
			 *  what it is what it has happened.
			 *  @param msg Message of error that we want to show the user.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ErrMsg (const char * msg)
			{
			#ifdef WIN32
				MessageBox(NULL, msg, AppName.c_str(), MB_OK | MB_ICONWARNING);
			#else
				cout << AppName.c_str() << ": " << msg << endl;
			#endif
			}

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para provocar un paro en la ejecuci�n.
			/**
			 *  Esta funci�n sirve para parar la ejecuci�n del programa durante un n�mero
			 *  determinado de milisegundos.
			 *  @param ms N�mero de milisegundos que paramos la ejecuci�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to stop the execution of the program.
			/**
			 *  This function serves to stop the execution of the program during a
			 *  determined number of milliseconds. 
			 *  @param ms Number of milliseconds that we stopped the execution.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void Delay (UINT ms)
			{
				SDL_Delay(ms);
			}

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el tiempo transcurrido.
			/**
			 *  Esta funci�n sirve para obtener el tiempo transcurrido desde el inicio de
			 *  la aplicaci�n. Normalmente se emplea para cronometrar partes del c�digo.
			 *  @return Devuelve el n�mero de milisegundos que ha pasado desde que se
			 *          inici� la ejecuci�n del programa.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the passed time.
			/**
			 *  This function serves to obtain the time passed from the beginning of the
			 *  application. Normally this one is used to chronometrate parts of the code.
			 */
			//------------------------------------------------------------------------------
#endif
			inline dword GetTime (void)
			{
				return SDL_GetTicks();
			}

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la instancia de Core.
			/**
			 *  Esta funci�n crea una instancia de Core, en caso de no estar creada, y
			 *  devuelve un puntero a esta si tiene exito pidiendo memoria.
			 *  @return Devuelve un puntero al objeto Core si todo ha ido bien, en caso de
			 *          no haber memoria para el objeto devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the instance of Core.
			/**
			 *  This function creates an instance of Core, in case of not being created,
			 *  and gives back a pointer of this if memory is successful requesting.
			 *  @return It gives back to a pointer to the object Core if everything has
			 *          gone well, if there is no memory for the object, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			static Core * GetInstance (void);
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Core.h
//******************************************************************************************