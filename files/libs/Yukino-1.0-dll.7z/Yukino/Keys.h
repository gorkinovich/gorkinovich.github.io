//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Keys is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _KEYS_H_
#define _KEYS_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
#ifndef _DOC_IN_ENGLISH_
	//**************************************************************************************
	/// Listado de teclas del teclado.
	/**
	 *  El namespace Keys es un listado de los valores de las teclas del teclado Ingl�s.
	 *  Estos valores pueden ser bastante �tiles para la funci�n GetKey de la clase Input.
	 */
	//**************************************************************************************
#else
	//**************************************************************************************
	/// Listing of keys of the keyboard.
	/**
	 *  The namespace Keys is a listing of the values of the keys of the English keyboard.
	 *  These values can be enough equipment for the GetKey function of the Input class.
	 */
	//**************************************************************************************
#endif
	namespace Keys
	{
		//----------------------------------------------------------------------------------
		// Keyboard values
		//----------------------------------------------------------------------------------
		const short int MAX_KEYS = 321;

		//----------------------------------------------------------------------------------
		// Keys values
		//----------------------------------------------------------------------------------
		const short int KEY_ESC          =  27; //SDLK_ESCAPE
		const short int KEY_F1           = 282; //SDLK_F1
		const short int KEY_F2           = 283; //SDLK_F2
		const short int KEY_F3           = 284; //SDLK_F3
		const short int KEY_F4           = 285; //SDLK_F4
		const short int KEY_F5           = 286; //SDLK_F5
		const short int KEY_F6           = 287; //SDLK_F6
		const short int KEY_F7           = 288; //SDLK_F7
		const short int KEY_F8           = 289; //SDLK_F8
		const short int KEY_F9           = 290; //SDLK_F9
		const short int KEY_F10          = 291; //SDLK_F10
		const short int KEY_F11          = 292; //SDLK_F11
		const short int KEY_F12          = 293; //SDLK_F12
		const short int KEY_F13          = 294; //SDLK_F13
		const short int KEY_F14          = 295; //SDLK_F14
		const short int KEY_F15          = 296; //SDLK_F15
		const short int KEY_PRINT        = 316; //SDLK_PRINT
		const short int KEY_SCROLLOCK    = 302; //SDLK_SCROLLOCK
		const short int KEY_PAUSE        =  19; //SDLK_PAUSE
		const short int KEY_BACKQUOTE    =  96; //SDLK_BACKQUOTE
		const short int KEY_1            =  49; //SDLK_1
		const short int KEY_2            =  50; //SDLK_2
		const short int KEY_3            =  51; //SDLK_3
		const short int KEY_4            =  52; //SDLK_4
		const short int KEY_5            =  53; //SDLK_5
		const short int KEY_6            =  54; //SDLK_6
		const short int KEY_7            =  55; //SDLK_7
		const short int KEY_8            =  56; //SDLK_8
		const short int KEY_9            =  57; //SDLK_9
		const short int KEY_0            =  48; //SDLK_0
		const short int KEY_MINUS        =  45; //SDLK_MINUS
		const short int KEY_EQUALS       =  61; //SDLK_EQUALS
		const short int KEY_BACKSPACE    =   8; //SDLK_BACKSPACE
		const short int KEY_TAB          =   9; //SDLK_TAB
		const short int KEY_Q            = 113; //SDLK_q
		const short int KEY_W            = 119; //SDLK_w
		const short int KEY_E            = 101; //SDLK_e
		const short int KEY_R            = 114; //SDLK_r
		const short int KEY_T            = 116; //SDLK_t
		const short int KEY_Y            = 121; //SDLK_y
		const short int KEY_U            = 117; //SDLK_u
		const short int KEY_I            = 105; //SDLK_i
		const short int KEY_O            = 111; //SDLK_o
		const short int KEY_P            = 112; //SDLK_p
		const short int KEY_LEFTBRACKET  =  91; //SDLK_LEFTBRACKET
		const short int KEY_RIGHTBRACKET =  93; //SDLK_RIGHTBRACKET
		const short int KEY_CAPSLOCK     = 301; //SDLK_CAPSLOCK
		const short int KEY_A            =  97; //SDLK_a
		const short int KEY_S            = 115; //SDLK_s
		const short int KEY_D            = 100; //SDLK_d
		const short int KEY_F            = 102; //SDLK_f
		const short int KEY_G            = 103; //SDLK_g
		const short int KEY_H            = 104; //SDLK_h
		const short int KEY_J            = 106; //SDLK_j
		const short int KEY_K            = 107; //SDLK_k
		const short int KEY_L            = 108; //SDLK_l
		const short int KEY_SEMICOLON    =  59; //SDLK_SEMICOLON
		const short int KEY_QUOTE        =  39; //SDLK_QUOTE
		const short int KEY_BACKSLASH    =  92; //SDLK_BACKSLASH
		const short int KEY_RETURN       =  13; //SDLK_RETURN
		const short int KEY_LSHIFT       = 304; //SDLK_LSHIFT
		const short int KEY_Z            = 122; //SDLK_z
		const short int KEY_X            = 120; //SDLK_x
		const short int KEY_C            =  99; //SDLK_c
		const short int KEY_V            = 118; //SDLK_v
		const short int KEY_B            =  98; //SDLK_b
		const short int KEY_N            = 110; //SDLK_n
		const short int KEY_M            = 109; //SDLK_m
		const short int KEY_COMMA        =  44; //SDLK_COMMA
		const short int KEY_PERIOD       =  46; //SDLK_PERIOD
		const short int KEY_SLASH        =  47; //SDLK_SLASH
		const short int KEY_RSHIFT       = 303; //SDLK_RSHIFT
		const short int KEY_LCTRL        = 306; //SDLK_LCTRL
		const short int KEY_LALT         = 308; //SDLK_LALT
		const short int KEY_SPACE        =  32; //SDLK_SPACE
		const short int KEY_RALT         = 307; //SDLK_RALT
		const short int KEY_RCTRL        = 305; //SDLK_RCTRL
		const short int KEY_INSERT       = 277; //SDLK_INSERT
		const short int KEY_HOME         = 278; //SDLK_HOME
		const short int KEY_PAGEUP       = 280; //SDLK_PAGEUP
		const short int KEY_DELETE       = 127; //SDLK_DELETE
		const short int KEY_END          = 279; //SDLK_END
		const short int KEY_PAGEDOWN     = 281; //SDLK_PAGEDOWN
		const short int KEY_UP           = 273; //SDLK_UP
		const short int KEY_LEFT         = 276; //SDLK_LEFT
		const short int KEY_DOWN         = 274; //SDLK_DOWN
		const short int KEY_RIGHT        = 275; //SDLK_RIGHT
		const short int KEY_NUMLOCK      = 300; //SDLK_NUMLOCK
		const short int KEY_KP_DIVIDE    = 267; //SDLK_KP_DIVIDE
		const short int KEY_KP_MULTIPLY  = 268; //SDLK_KP_MULTIPLY
		const short int KEY_KP_MINUS     = 269; //SDLK_KP_MINUS
		const short int KEY_KP7          = 263; //SDLK_KP7
		const short int KEY_KP8          = 264; //SDLK_KP8
		const short int KEY_KP9          = 265; //SDLK_KP9
		const short int KEY_KP4          = 260; //SDLK_KP4
		const short int KEY_KP5          = 261; //SDLK_KP5
		const short int KEY_KP6          = 262; //SDLK_KP6
		const short int KEY_KP_PLUS      = 270; //SDLK_KP_PLUS
		const short int KEY_KP1          = 257; //SDLK_KP1
		const short int KEY_KP2          = 258; //SDLK_KP2
		const short int KEY_KP3          = 259; //SDLK_KP3
		const short int KEY_KP0          = 256; //SDLK_KP0
		const short int KEY_KP_PERIOD    = 266; //SDLK_KP_PERIOD
		const short int KEY_KP_ENTER     = 271; //SDLK_KP_ENTER
		const short int KEY_KP_EQUALS    = 272; //SDLK_KP_EQUALS
		
		//----------------------------------------------------------------------------------
		// Other keys values
		//----------------------------------------------------------------------------------
		const short int KEY_UNKNOWN      =   0; //SDLK_UNKNOWN
		const short int KEY_CLEAR        =  12; //SDLK_CLEAR
		const short int KEY_EXCLAIM      =  33; //SDLK_EXCLAIM
		const short int KEY_QUOTEDBL     =  34; //SDLK_QUOTEDBL
		const short int KEY_HASH         =  35; //SDLK_HASH
		const short int KEY_DOLLAR       =  36; //SDLK_DOLLAR
		const short int KEY_AMPERSAND    =  38; //SDLK_AMPERSAND
		const short int KEY_LEFTPAREN    =  40; //SDLK_LEFTPAREN
		const short int KEY_RIGHTPAREN   =  41; //SDLK_RIGHTPAREN
		const short int KEY_ASTERISK     =  42; //SDLK_ASTERISK
		const short int KEY_PLUS         =  43; //SDLK_PLUS
		const short int KEY_COLON        =  58; //SDLK_COLON
		const short int KEY_LESS         =  60; //SDLK_LESS	
		const short int KEY_GREATER      =  62; //SDLK_GREATER
		const short int KEY_QUESTION     =  63; //SDLK_QUESTION
		const short int KEY_AT           =  64; //SDLK_AT
		const short int KEY_CARET        =  94; //SDLK_CARET
		const short int KEY_UNDERSCORE   =  95; //SDLK_UNDERSCORE	
		const short int KEY_RMETA        = 309; //SDLK_RMETA
		const short int KEY_LMETA        = 310; //SDLK_LMETA
		const short int KEY_LSUPER       = 311; //SDLK_LSUPER  -> Left "Windows" key
		const short int KEY_RSUPER       = 312; //SDLK_RSUPER  -> Right "Windows" key
		const short int KEY_MODE         = 313; //SDLK_MODE    -> "Alt Gr" key
		const short int KEY_COMPOSE      = 314; //SDLK_COMPOSE -> Multi-key compose key
		const short int KEY_HELP         = 315; //SDLK_HELP	
		const short int KEY_SYSREQ       = 317; //SDLK_SYSREQ
		const short int KEY_BREAK        = 318; //SDLK_BREAK
		const short int KEY_MENU         = 319; //SDLK_MENU
		const short int KEY_EURO         = 321; //SDLK_EURO
	}

#ifndef _DOC_IN_ENGLISH_
	//**************************************************************************************
	/// Listado de teclas del teclado.
	/**
	 *  El namespace Teclas es un listado de los valores de las teclas del teclado Espa�ol.
	 *  Estos valores pueden ser bastante �tiles para la funci�n GetKey de la clase Input.
	 */
	//**************************************************************************************
#else
	//**************************************************************************************
	/// Listing of keys of the keyboard.
	/**
	 *  The namespace Teclas is a listing of the values of the keys of the Spanish keyboard.
	 *  These values can be enough equipment for the GetKey function of the Input class.
	 */
	//**************************************************************************************
#endif
	namespace Teclas
	{
		//----------------------------------------------------------------------------------
		// Valores del teclado
		//----------------------------------------------------------------------------------
		const short int MAX_TECLAS = 321;

		//----------------------------------------------------------------------------------
		// Valores de las teclas
		//----------------------------------------------------------------------------------
		const short int TECLA_ESC               =     27; //SDLK_ESCAPE
		const short int TECLA_F1                =    282; //SDLK_F1
		const short int TECLA_F2                =    283; //SDLK_F2
		const short int TECLA_F3                =    284; //SDLK_F3
		const short int TECLA_F4                =    285; //SDLK_F4
		const short int TECLA_F5                =    286; //SDLK_F5
		const short int TECLA_F6                =    287; //SDLK_F6
		const short int TECLA_F7                =    288; //SDLK_F7
		const short int TECLA_F8                =    289; //SDLK_F8
		const short int TECLA_F9                =    290; //SDLK_F9
		const short int TECLA_F10               =    291; //SDLK_F10
		const short int TECLA_F11               =    292; //SDLK_F11
		const short int TECLA_F12               =    293; //SDLK_F12
		const short int TECLA_F13               =    294; //SDLK_F13
		const short int TECLA_F14               =    295; //SDLK_F14
		const short int TECLA_F15               =    296; //SDLK_F15
		const short int TECLA_IMPRPANT          =    316; //SDLK_PRINT
		const short int TECLA_BLOQDESPL         =    302; //SDLK_SCROLLOCK
		const short int TECLA_PAUSA             =     19; //SDLK_PAUSE
		const short int TECLA_BARRAINV          =     96; //SDLK_BACKQUOTE
		const short int TECLA_1                 =     49; //SDLK_1
		const short int TECLA_2                 =     50; //SDLK_2
		const short int TECLA_3                 =     51; //SDLK_3
		const short int TECLA_4                 =     52; //SDLK_4
		const short int TECLA_5                 =     53; //SDLK_5
		const short int TECLA_6                 =     54; //SDLK_6
		const short int TECLA_7                 =     55; //SDLK_7
		const short int TECLA_8                 =     56; //SDLK_8
		const short int TECLA_9                 =     57; //SDLK_9
		const short int TECLA_0                 =     48; //SDLK_0
		const short int TECLA_APOSTROFE         =     45; //SDLK_MINUS
		const short int TECLA_EXCLAMACION       =     61; //SDLK_EQUALS
		const short int TECLA_RETROCESO         =      8; //SDLK_BACKSPACE
		const short int TECLA_TABULADOR         =      9; //SDLK_TAB
		const short int TECLA_Q                 =    113; //SDLK_q
		const short int TECLA_W                 =    119; //SDLK_w
		const short int TECLA_E                 =    101; //SDLK_e
		const short int TECLA_R                 =    114; //SDLK_r
		const short int TECLA_T                 =    116; //SDLK_t
		const short int TECLA_Y                 =    121; //SDLK_y
		const short int TECLA_U                 =    117; //SDLK_u
		const short int TECLA_I                 =    105; //SDLK_i
		const short int TECLA_O                 =    111; //SDLK_o
		const short int TECLA_P                 =    112; //SDLK_p
		const short int TECLA_ABRE_CORCHETE     =     91; //SDLK_LEFTBRACKET
		const short int TECLA_CIERRA_CORCHETE   =     93; //SDLK_RIGHTBRACKET
		const short int TECLA_BLOQMAYUS         =    301; //SDLK_CAPSLOCK
		const short int TECLA_A                 =     97; //SDLK_a
		const short int TECLA_S                 =    115; //SDLK_s
		const short int TECLA_D                 =    100; //SDLK_d
		const short int TECLA_F                 =    102; //SDLK_f
		const short int TECLA_G                 =    103; //SDLK_g
		const short int TECLA_H                 =    104; //SDLK_h
		const short int TECLA_J                 =    106; //SDLK_j
		const short int TECLA_K                 =    107; //SDLK_k
		const short int TECLA_L                 =    108; //SDLK_l
		const short int TECLA_NY                =     59; //SDLK_SEMICOLON
		const short int TECLA_ABRE_LLAVE        =     39; //SDLK_QUOTE
		const short int TECLA_CIERRA_LLAVE      =     92; //SDLK_BACKSLASH
		const short int TECLA_ENTER             =     13; //SDLK_RETURN
		const short int TECLA_SHIFT_IZUIERDO    =    304; //SDLK_LSHIFT
		const short int TECLA_MENOR             =     92; //SDLK_BACKSLASH
		const short int TECLA_Z                 =    122; //SDLK_z
		const short int TECLA_X                 =    120; //SDLK_x
		const short int TECLA_C                 =     99; //SDLK_c
		const short int TECLA_V                 =    118; //SDLK_v
		const short int TECLA_B                 =     98; //SDLK_b
		const short int TECLA_N                 =    110; //SDLK_n
		const short int TECLA_M                 =    109; //SDLK_m
		const short int TECLA_COMA              =     44; //SDLK_COMMA
		const short int TECLA_PUNTO             =     46; //SDLK_PERIOD
		const short int TECLA_MENOS             =     47; //SDLK_SLASH
		const short int TECLA_SHIFT_DERECHO     =    303; //SDLK_RSHIFT
		const short int TECLA_CONTROL_IZQUIERDO =    306; //SDLK_LCTRL
		const short int TECLA_ALT_IZQUIERDO     =    308; //SDLK_LALT
		const short int TECLA_ESPACIO           =     32; //SDLK_SPACE
		const short int TECLA_ALT_DERECHO       =    307; //SDLK_RALT
		const short int TECLA_CONTROL_DERECHO   =    305; //SDLK_RCTRL
		const short int TECLA_INSERTAR          =    277; //SDLK_INSERT
		const short int TECLA_INICIO            =    278; //SDLK_HOME
		const short int TECLA_REPAG             =    280; //SDLK_PAGEUP
		const short int TECLA_SUPRIMIR          =    127; //SDLK_DELETE
		const short int TECLA_FIN               =    279; //SDLK_END
		const short int TECLA_AVPAG             =    281; //SDLK_PAGEDOWN
		const short int TECLA_ARRIBA            =    273; //SDLK_UP
		const short int TECLA_IZQUIERDA         =    276; //SDLK_LEFT
		const short int TECLA_ABAJO             =    274; //SDLK_DOWN
		const short int TECLA_DERECHA           =    275; //SDLK_RIGHT
		const short int TECLA_BLOQNUM           =    300; //SDLK_NUMLOCK
		const short int TECLA_NUM_BARRA         =    267; //SDLK_KP_DIVIDE
		const short int TECLA_NUM_ASTERISCO     =    268; //SDLK_KP_MULTIPLY
		const short int TECLA_NUM_MENOS         =    269; //SDLK_KP_MINUS
		const short int TECLA_NUM_7             =    263; //SDLK_KP7
		const short int TECLA_NUM_8             =    264; //SDLK_KP8
		const short int TECLA_NUM_9             =    265; //SDLK_KP9
		const short int TECLA_NUM_4             =    260; //SDLK_KP4
		const short int TECLA_NUM_5             =    261; //SDLK_KP5
		const short int TECLA_NUM_6             =    262; //SDLK_KP6
		const short int TECLA_NUM_MAS           =    270; //SDLK_KP_PLUS
		const short int TECLA_NUM_1             =    257; //SDLK_KP1
		const short int TECLA_NUM_2             =    258; //SDLK_KP2
		const short int TECLA_NUM_3             =    259; //SDLK_KP3
		const short int TECLA_NUM_0             =    256; //SDLK_KP0
		const short int TECLA_NUM_PUNTO         =    266; //SDLK_KP_PERIOD
		const short int TECLA_NUM_ENTER         =    271; //SDLK_KP_ENTER
		const short int TECLA_NUM_IGUAL         =    272; //SDLK_KP_EQUALS
		
		//----------------------------------------------------------------------------------
		// Valores de teclas especiales
		//----------------------------------------------------------------------------------
		const short int TECLA_UNKNOWN           =      0; //SDLK_UNKNOWN
		const short int TECLA_CLEAR             =     12; //SDLK_CLEAR
		const short int TECLA_EXCLAIM           =     33; //SDLK_EXCLAIM
		const short int TECLA_QUOTEDBL          =     34; //SDLK_QUOTEDBL
		const short int TECLA_HASH              =     35; //SDLK_HASH
		const short int TECLA_DOLLAR            =     36; //SDLK_DOLLAR
		const short int TECLA_AMPERSAND         =     38; //SDLK_AMPERSAND
		const short int TECLA_LEFTPAREN         =     40; //SDLK_LEFTPAREN
		const short int TECLA_RIGHTPAREN        =     41; //SDLK_RIGHTPAREN
		const short int TECLA_ASTERISK          =     42; //SDLK_ASTERISK
		const short int TECLA_PLUS              =     43; //SDLK_PLUS
		const short int TECLA_COLON             =     58; //SDLK_COLON
		const short int TECLA_LESS              =     60; //SDLK_LESS	
		const short int TECLA_GREATER           =     62; //SDLK_GREATER
		const short int TECLA_QUESTION          =     63; //SDLK_QUESTION
		const short int TECLA_AT                =     64; //SDLK_AT
		const short int TECLA_CARET             =     94; //SDLK_CARET
		const short int TECLA_UNDERSCORE        =     95; //SDLK_UNDERSCORE	
		const short int TECLA_RMETA             =    309; //SDLK_RMETA
		const short int TECLA_LMETA             =    310; //SDLK_LMETA
		const short int TECLA_LSUPER            =    311; //SDLK_LSUPER  -> Left "Windows" key
		const short int TECLA_RSUPER            =    312; //SDLK_RSUPER  -> Right "Windows" key
		const short int TECLA_MODE              =    313; //SDLK_MODE    -> "Alt Gr" key
		const short int TECLA_COMPOSE           =    314; //SDLK_COMPOSE -> Multi-key compose key
		const short int TECLA_HELP              =    315; //SDLK_HELP	
		const short int TECLA_SYSREQ            =    317; //SDLK_SYSREQ
		const short int TECLA_BREAK             =    318; //SDLK_BREAK
		const short int TECLA_MENU              =    319; //SDLK_MENU
		const short int TECLA_EURO              =    321; //SDLK_EURO
	}
}
//******************************************************************************************
#endif
//******************************************************************************************
// Keys.h
//******************************************************************************************