//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Graphics.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _GRAPHICS_H_
#define _GRAPHICS_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Surface.h"
#include "Sprite.h"
#include "Font.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Graphics Errors
	//--------------------------------------------------------------------------------------
	const UINT GRAPHICS_ERROR_UNDEF        = 100; /**< Error indefinido en las funciones de Graphics. */
	const UINT GRAPHICS_ERROR_VIDEOMODEOK  = 101; /**< Error al comprobar si esta soportada la resoluci�n de video. */
	const UINT GRAPHICS_ERROR_SETVIDEOMODE = 102; /**< Error al cambiar de resoluci�n la pantalla. */
	const UINT GRAPHICS_ERROR_UPDATE       = 103; /**< Error al actualizar el buffer de pantalla. */
	const UINT GRAPHICS_ERROR_BLITSURFACE  = 104; /**< Error al pegar una superficie en el buffer de pantalla. */
	const UINT GRAPHICS_ERROR_COPYSCREEN   = 105; /**< Error al copiar una regi�n del buffer de pantalla. */
	const UINT GRAPHICS_ERROR_FILLRECT     = 106; /**< Error al rellenar una regi�n del buffer de pantalla. */
	const UINT GRAPHICS_ERROR_TTFINIT      = 107; /**< Error al iniciar el sistema base para las fuentes TTF. */
	const UINT GRAPHICS_ERROR_RENDERTEXT   = 108; /**< Error obtener el texto renderizado de la fuente. */

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase que gestiona el sistema de video.
	/**
	 *  La clase Graphics gestiona los temas relacionados con el sistema de video, tales
	 *  como crear la ventana y cambiar la resoluci�n, pintar imagenes contenidas en una
	 *  Surface o un Sprite en pantalla, o pintar texto en una posici�n.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class that manages the video system.
	/**
	 *  The Graphics class manages the subjects related to the video system, such as to
	 *  create the window and to change the resolution, to paint images contained in a
	 *  Surface or a Sprite in screen, or to paint text in a position.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Graphics
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			static Graphics * Instance;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			SDL_Surface * BufferVideo;

			Graphics ();
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para inicializar el objeto Graphics.
			/**
			 *  Esta funci�n sirve para inicializar el objeto Graphics, pas�ndole el ancho,
			 *  el alto, la profundidad de color y si se est� en modo ventana o no.
			 *  @param w       Ancho de la aplicaci�n.
			 *  @param h       Alto de la aplicaci�n.
			 *  @param bpp     Profundidad de color de la aplicaci�n.
			 *  @param winmode Modo ventana activado.
			 *  @see Release().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_VIDEOMODEOK, GRAPHICS_ERROR_SETVIDEOMODE,
			 *          GRAPHICS_ERROR_TTFINIT.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to initialize the object Graphics.
			/**
			 *  This function serves to initialize the object Graphics, passing to him the
			 *  width, the height, the depth of color and if the window mode is activated.
			 *  @param w       Width of the application.
			 *  @param h       Height of the application.
			 *  @param bpp     Depth of color of the application.
			 *  @param winmode Window mode activated.
			 *  @see Release().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_VIDEOMODEOK, GRAPHICS_ERROR_SETVIDEOMODE,
			 *          GRAPHICS_ERROR_TTFINIT.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Init (int w, int h, int bpp = 32, bool winmode = false);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para finalizar el objeto Graphics.
			/**
			 *  Esta funci�n sirve para finalizar el objeto Graphics.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to finalize the object Graphics.
			/**
			 *  This function serves to finalize the object Graphics.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#endif
			void Release (void);

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el t�tulo de la ventana.
			/**
			 *  Esta funci�n sirve para cambiar el t�tulo de la ventana creada, y el icono
			 *  de esta, por otro contenido en un fichero.
			 *  @param title Nuevo t�tulo de la ventana.
			 *  @param icon  Ruta del nuevo icono.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the title of the window.
			/**
			 *  This function serves to change the title of the created window, and the
			 *  icon of this, by another content in a file.
			 *  @param title New title of the window.
			 *  @param icon  Path of the new icon.
			 */
			//------------------------------------------------------------------------------
#endif
			void SetTitle (const char * title, const char * icon = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ocultar el cursor del rat�n.
			/**
			 *  Esta funci�n sirve para ocultar el cursor del rat�n en la aplicaci�n.
			 *  @see ShowCursor().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to hide the cursor of the mouse.
			/**
			 *  This function serves to hide the cursor of the mouse in the application.
			 *  @see ShowCursor().
			 */
			//------------------------------------------------------------------------------
#endif
			void HideCursor (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para mostrar el cursor del rat�n.
			/**
			 *  Esta funci�n sirve para mostrar el cursor del rat�n en la aplicaci�n.
			 *  @see HideCursor().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to show the cursor of the mouse.
			/**
			 *  This function serves to show the cursor of the mouse in the application.
			 *  @see HideCursor().
			 */
			//------------------------------------------------------------------------------
#endif
			void ShowCursor (void);

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para actualizar el contenido de la pantalla.
			/**
			 *  Esta funci�n sirve para actualizar el contenido de la pantalla, ya que la
			 *  librer�a por defecto tiene activado el doble buffering.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_UPDATE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to update the content of the screen.
			/**
			 *  This function serves to update the content of the screen, since the library
			 *  by defect has activated the double buffering.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_UPDATE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Update (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para rellenar con un color una regi�n de la pantalla.
			/**
			 *  Esta funci�n sirve para rellenar una regi�n de la pantalla, con un color.
			 *  @param color Color de relleno.
			 *  @param rect  Regi�n destino a rellenar.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_FILLRECT.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to fill up with a color a region of the screen.
			/**
			 *  This function serves to fill up a region of the screen, with a color.
			 *  @param color Fill color.
			 *  @param rect  Destination area to fill.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_FILLRECT.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Fill (Uint32 color, Rect * rect = NULL);

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla una Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en una regi�n tambi�n determinada de la pantalla.
			 *  @param objsrc Imagen origen.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  region also determined of the screen.
			 *  @param objsrc Source image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Blit (const Surface & objsrc, Rect * dst = NULL, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla una Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en unas coordenadas de la pantalla.
			 *  @param objsrc Imagen origen.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  coordinates of the screen.
			 *  @param objsrc Source image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Blit (const Surface & objsrc, int x, int y, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla una SDL_Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en una regi�n tambi�n determinada de la pantalla.
			 *  @param srfsrc Imagen origen.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a SDL_Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  region also determined of the screen.
			 *  @param srfsrc Source image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Blit (SDL_Surface * srfsrc, Rect * dst = NULL, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla una SDL_Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en unas coordenadas de la pantalla.
			 *  @param srfsrc Imagen origen.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a SDL_Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  coordinates of the screen.
			 *  @param srfsrc Source image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Blit (SDL_Surface * srfsrc, int x, int y, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla un Sprite.
			/**
			 *  Esta funci�n sirve para poner el frame actual del Sprite origen, en una
			 *  regi�n determinada de la pantalla.
			 *  @param objsrc Imagen origen.
			 *  @param dst    Regi�n destino.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a Sprite.
			/**
			 *  This function serves to put frame present of the Sprite origin, in a
			 *  determined region of the screen.
			 *  @param objsrc Source image.
			 *  @param dst    Destination area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Blit (const Sprite & objsrc, Rect * dst = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla un Sprite.
			/**
			 *  Esta funci�n sirve para poner el frame actual del Sprite origen, en unas
			 *  coordenadas de la pantalla.
			 *  @param objsrc Imagen origen.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a Sprite.
			/**
			 *  This function serves to put frame present of the Sprite origin, in a
			 *  coordinates of the screen.
			 *  @param objsrc Source image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Blit (const Sprite & objsrc, int x, int y);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la pantalla en una Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la pantalla, en
			 *  una regi�n tambi�n determinada de una imagen destino.
			 *  @param objdst Imagen destino.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the screen in a Surface.
			/**
			 *  This function serves to copy a determined area of the screen, in a region
			 *  also determined of a destination image.
			 *  @param objdst Destination image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (Surface & objdst, Rect * dst = NULL, Rect * src = NULL) const;

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la pantalla en una Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la pantalla, en
			 *  unas coordenadas de una imagen destino.
			 *  @param objdst Imagen destino.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the screen in a Surface.
			/**
			 *  This function serves to copy a determined area of the screen, in a
			 *  coordinates of a destination image.
			 *  @param objdst Destination image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (Surface & objdst, int x, int y, Rect * src = NULL) const;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la pantalla en una SDL_Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la pantalla, en
			 *  una regi�n tambi�n determinada de una imagen destino.
			 *  @param srfdst Imagen destino.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the screen in a SDL_Surface.
			/**
			 *  This function serves to copy a determined area of the screen, in a region
			 *  also determined of a destination image.
			 *  @param srfdst Destination image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (SDL_Surface * srfdst, Rect * dst = NULL, Rect * src = NULL) const;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la pantalla en una SDL_Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la pantalla, en
			 *  unas coordenadas de una imagen destino.
			 *  @param srfdst Imagen destino.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the screen in a SDL_Surface.
			/**
			 *  This function serves to copy a determined area of the screen, in a
			 *  coordinates of a destination image.
			 *  @param srfdst Destination image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_COPYSCREEN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (SDL_Surface * srfdst, int x, int y, Rect * src = NULL) const;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla un texto.
			/**
			 *  Esta funci�n sirve para poner en pantalla una cadena de texto, con una
			 *  fuente y color determinados, en una regi�n destino de la pantalla.
			 *  @param font Fuente del texto.
			 *  @param text Cadena con el texto.
			 *  @param fc   Color del texto.
			 *  @param dst  Regi�n destino.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a text.
			/**
			 *  This function serves to put in screen a text chain, with a determined
			 *  font and color, in a destination area of the screen.
			 *  @param font Font of the text.
			 *  @param text String with the text.
			 *  @param fc   Color of the text.
			 *  @param dst  Destination area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT PutText (Font & font, const char * text, dword fc, Rect * dst = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla un texto.
			/**
			 *  Esta funci�n sirve para poner en pantalla una cadena de texto, con una
			 *  fuente y color determinados, en unas coordenadas de la pantalla.
			 *  @param font Fuente del texto.
			 *  @param text Cadena con el texto.
			 *  @param fc   Color del texto.
			 *  @param x    Coordenada x.
			 *  @param y    Coordenada y.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen a text.
			/**
			 *  This function serves to put in screen a text chain, with a determined
			 *  font and color, in a coordinates of the screen.
			 *  @param font Font of the text.
			 *  @param text String with the text.
			 *  @param fc   Color of the text.
			 *  @param x    Coordinate x.
			 *  @param y    Coordinate y.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT PutText (Font & font, const char * text, dword fc, int x, int y);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla un texto UNICODE.
			/**
			 *  Esta funci�n sirve para poner en pantalla una cadena de texto, con una
			 *  fuente y color determinados, en una regi�n destino de la pantalla.
			 *  @param font Fuente del texto.
			 *  @param text Cadena con el texto.
			 *  @param fc   Color del texto.
			 *  @param dst  Regi�n destino.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen an UNICODE text.
			/**
			 *  This function serves to put in screen a text chain, with a determined
			 *  font and color, in a destination area of the screen.
			 *  @param font Font of the text.
			 *  @param text String with the text.
			 *  @param fc   Color of the text.
			 *  @param dst  Destination area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT PutUNICODE (Font & font, const word * text, dword fc, Rect * dst = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en pantalla un texto UNICODE.
			/**
			 *  Esta funci�n sirve para poner en pantalla una cadena de texto, con una
			 *  fuente y color determinados, en unas coordenadas de la pantalla.
			 *  @param font Fuente del texto.
			 *  @param text Cadena con el texto.
			 *  @param fc   Color del texto.
			 *  @param x    Coordenada x.
			 *  @param y    Coordenada y.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in screen an UNICODE text.
			/**
			 *  This function serves to put in screen a text chain, with a determined
			 *  font and color, in a coordinates of the screen.
			 *  @param font Font of the text.
			 *  @param text String with the text.
			 *  @param fc   Color of the text.
			 *  @param x    Coordinate x.
			 *  @param y    Coordinate y.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          GRAPHICS_ERROR_RENDERTEXT, GRAPHICS_ERROR_BLITSURFACE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT PutUNICODE (Font & font, const word * text, dword fc, int x, int y);

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el buffer de pantalla.
			/**
			 *  Esta funci�n sirve para obtener el buffer de pantalla.
			 *  @return Devuelve un puntero al buffer de pantalla si todo ha ido bien, en
			 *          caso de no haber memoria para el buffer devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the video buffer.
			/**
			 *  This function serves to obtain the video buffer.
			 *  @return It gives back to a pointer to the video buffer if everything has
			 *          gone well, if there is no memory for the buffer, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			inline SDL_Surface * GetBuffer (void)
			{
				return BufferVideo;
			}

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la instancia de Graphics.
			/**
			 *  Esta funci�n crea una instancia de Graphics, en caso de no estar creada, y
			 *  devuelve un puntero a esta si tiene exito pidiendo memoria.
			 *  @return Devuelve un puntero al objeto Graphics si todo ha ido bien, en caso
			 *          de no haber memoria para el objeto devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the instance of Graphics.
			/**
			 *  This function creates an instance of Graphics, in case of not being created,
			 *  and gives back a pointer of this if memory is successful requesting.
			 *  @return It gives back to a pointer to the object Graphics if everything has
			 *          gone well, if there is no memory for the object, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			static Graphics * GetInstance (void);
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Graphics.h
//******************************************************************************************