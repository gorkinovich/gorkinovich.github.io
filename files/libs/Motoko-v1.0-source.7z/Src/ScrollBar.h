//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_SCROLLBAR_H_
#define _MOTOKO_SCROLLBAR_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "Button.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define MAX_SCROLLBAR_RECTS   3
#define CENTER_SCROLLBAR_RECT 1
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic scrollbar.
	//--------------------------------------------------------------------------------------
	class DLLAPI ScrollBar : public Control
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			int LargeChange; // Desplazamiento al hacer click en el hueco de la barra.
			int SmallChange; // Desplazamiento al hacer click en los botones.
			int Max;
			int Min;
			int Value;

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			SDL_Rect Rects[MAX_SCROLLBAR_RECTS];

			Button * Button01; // Up, left button.
			Button * Button02; // Center button.
			Button * Button03; // Down, right button.

			bool Pressed;

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ScrollBar ();
			ScrollBar (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					   Uint32 backcolor, ControlSkin * appearance = NULL,
					   int min = 0, int max = 1, int value = 0, int large = 1, int small = 1,
					   SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
					   bool transparency = false, bool enable = true, bool visible = true);
			ScrollBar (const ScrollBar & obj);
			virtual ScrollBar & operator = (const ScrollBar & obj);
			~ScrollBar ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void) = 0;
			virtual bool Update (SDL_Event & event) = 0;

			virtual ScrollBar & CopyFrom (const ScrollBar & obj);

			virtual void UpdateButton (void) = 0;
			virtual void UpdateRects (void) = 0;


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get the LargeChange of the control.
			inline int GetLargeChange (void) { return LargeChange; }

			/// Get the SmallChange of the control.
			inline int GetSmallChange (void) { return SmallChange; }

			/// Get the Max of the control.
			inline int GetMax (void) { return Max - 1; }

			/// Get the Min of the control.
			inline int GetMin (void) { return Min; }

			/// Get the Value of the control.
			inline int GetValue (void) { return Value; }

			/// Get the Button01 of the control.
			inline Button * GetButton01 (void) { return Button01; }

			/// Get the Button02 of the control.
			inline Button * GetButton02 (void) { return Button02; }

			/// Get the Button03 of the control.
			inline Button * GetButton03 (void) { return Button03; }
			

			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the LargeChange of the control.
			inline void SetLargeChange (int val) { LargeChange = val; }

			/// Set the SmallChange of the control.
			inline void SetSmallChange (int val) { SmallChange = val; }

			/// Set the Max of the control.
			inline void SetMax (int val) { Max = val + 1; UpdateButton(); }

			/// Set the Min of the control.
			inline void SetMin (int val) { Min = val; UpdateButton(); }

			/// Set the Value of the control.
			inline void SetValue (int val) { Value = val; UpdateButton(); }

			/// Set the name of the control.
			virtual inline void SetName (const char * val) { Name = val; }

			/// Set the appearance of the control.
			virtual inline void SetAppearance (ControlSkin * val) { Appearance = val; }

			/// Set the coordinate X of the control.
			virtual inline void SetX (Sint16 val) { Rect.x = val; UpdateRects(); }

			/// Set the coordinate Y of the control.
			virtual inline void SetY (Sint16 val) { Rect.y = val; UpdateRects(); }

			/// Set the width of the control.
			virtual inline void SetWidth (Uint16 val) { Rect.w = val; UpdateRects(); }

			/// Set the height of the control.
			virtual inline void SetHeight (Uint16 val) { Rect.h = val; UpdateRects(); }

			/// Set the rect of the control.
			virtual inline void SetRect (SDL_Rect & val) { Rect = val; UpdateRects(); }
			
			/// Set the back style of the control.
			virtual inline void SetBackStyle (ControlBackStyle val)
			{
				BackStyle = val;
				Button01->SetBackStyle(val);
				Button02->SetBackStyle(val);
				Button03->SetBackStyle(val);
			}

			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 val)
			{
				BackColor = val;
				Button01->SetBackColor(val);
				Button02->SetBackColor(val);
				Button03->SetBackColor(val);
			}

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * scroll, ControlSkin * button)
			{
				Appearance = scroll;
				Button01->SetAppearance(button);
				Button02->SetAppearance(button);
				Button03->SetAppearance(button);
			}
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// ScrollBar.h
//******************************************************************************************