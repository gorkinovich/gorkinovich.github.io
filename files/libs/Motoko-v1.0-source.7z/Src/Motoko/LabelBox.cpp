//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../LabelBox.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  LabelBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	LabelBox::LabelBox () : Box(), ITextControl()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "LabelBox";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  LabelBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	LabelBox::LabelBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
						Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
						ControlSkin * appearance, SDL_Surface * picture,
						SDL_Surface * mousepointer, AlignmentStyle alignment,
						bool transparency, bool enable, bool visible) :
		Box(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
			transparency, enable, visible),
		ITextControl(text, font, alignment)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "LabelBox";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  LabelBox copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	LabelBox::LabelBox (const LabelBox & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  LabelBox operator =.
	 */
	//--------------------------------------------------------------------------------------
	LabelBox & LabelBox::operator = (const LabelBox & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  LabelBox destructor.
	 */
	//--------------------------------------------------------------------------------------
	LabelBox::~LabelBox ()
	{
	}
	
	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void LabelBox::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned label.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, the function will fill the control
			// with the BackColor (if the transparency isn't true), and after that will
			// draw the surface inside the variable Picture.
			//------------------------------------------------------------------------------
			if(Appearance == NULL)
			{
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

				if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
				
				DrawTextMultiline(CRM32Pro.screen, Rect.y, &Rect);

				return;
			}

			int i;

			//------------------------------------------------------------------------------
			// We read the rects before the center rect, and paint the borders of the box.
			//------------------------------------------------------------------------------
			for(i = 0; i < CENTER_BOX_RECT; ++i)
			{
				BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
							   CRM32Pro.screen, &(Rects[i]));
			}

			//------------------------------------------------------------------------------
			// If the transparency isn't true, we'll fill the center rect with BackColor.
			//------------------------------------------------------------------------------
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER_BOX_RECT]), BackColor);

			//------------------------------------------------------------------------------
			// And we draw the text of the label control in the center rect.
			//------------------------------------------------------------------------------
			DrawTextMultiline(CRM32Pro.screen, Rects[CENTER_BOX_RECT].y, &(Rects[CENTER_BOX_RECT]));

			//------------------------------------------------------------------------------
			// We read the rects after the center rect, and paint the borders of the box.
			//------------------------------------------------------------------------------
			for(i = CENTER_BOX_RECT + 1; i < MAX_BOX_RECTS; ++i)
			{
				BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
							   CRM32Pro.screen, &(Rects[i]));
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, we'll draw this using the back color.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			DrawTextMultiline(CRM32Pro.screen, Rect.y, &Rect);

			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, we'll draw this using the surface in Picture.
		//----------------------------------------------------------------------------------
		case UsePicture:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			
			DrawTextMultiline(CRM32Pro.screen, Rect.y, &Rect);

			break;
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool LabelBox::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	LabelBox & LabelBox::CopyFrom (const LabelBox & obj)
	{
		Box::CopyFrom(obj);

		ITextControl::CopyFrom(obj);

		return (*this);
	}
}
//******************************************************************************************
// LabelBox.cpp
//******************************************************************************************