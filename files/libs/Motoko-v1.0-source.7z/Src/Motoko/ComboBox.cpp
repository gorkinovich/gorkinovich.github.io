//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../ComboBox.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define OPENLISTBUTTON_SIZE 20
//------------------------------------------------------------------------------------------
#define RECTX_SEP 1
#define RECTY_SEP 1
#define RECTW_SEP 2
#define RECTH_SEP 2
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  ComboBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	ComboBox::ComboBox () : Box(), ITextControl()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ComboBox";

		OpenList = new Button();
		List     = new ListBox();
		
		OpenList->SetArrow(DownArrow);

		List->SetVisible(false);

		TextRect  = Rect;
		ColorRect = Rect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		SelBackColor = BackColor;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ComboBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	ComboBox::ComboBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
						Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
						ControlSkin * appearance, SDL_Surface * picture,
						SDL_Surface * mousepointer, AlignmentStyle alignment, 
						bool transparency, bool enable, bool visible) :
		Box(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
			transparency, enable, visible),
		ITextControl(text, font, alignment)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ComboBox";

		OpenList = new Button();
		List     = new ListBox();
		
		OpenList->SetArrow(DownArrow);

		List->SetVisible(false);

		TextRect  = Rect;
		ColorRect = Rect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		SelBackColor = BackColor;

		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ComboBox copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ComboBox::ComboBox (const ComboBox & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ComboBox operator =.
	 */
	//--------------------------------------------------------------------------------------
	ComboBox & ComboBox::operator = (const ComboBox & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ComboBox destructor.
	 */
	//--------------------------------------------------------------------------------------
	ComboBox::~ComboBox ()
	{
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		SelBackColor = 0;

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		delete OpenList;
		delete List;

		TextRect.x = 0;
		TextRect.y = 0;
		TextRect.w = 0;
		TextRect.h = 0;
		ColorRect  = TextRect;
	}
	
	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void ComboBox::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned combobox.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, the function will fill the control
			// with the BackColor (if the transparency isn't true), and after that will
			// draw the surface inside the variable Picture.
			//------------------------------------------------------------------------------
			if(Appearance == NULL)
			{
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

				if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			}
			else
			{
				int i;

				//--------------------------------------------------------------------------
				// We read the rects before the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = 0; i < CENTER_BOX_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// If the transparency is false, we'll fill the center rect with BackColor.
				//--------------------------------------------------------------------------
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER_BOX_RECT]), BackColor);				

				//--------------------------------------------------------------------------
				// We read the rects after the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER_BOX_RECT + 1; i < MAX_BOX_RECTS; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, we'll draw this using the back color.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, we'll draw this using the surface in Picture.
		//----------------------------------------------------------------------------------
		case UsePicture:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			break;
		}

		//----------------------------------------------------------------------------------
		// After paint the back style of the control, we'll fill the combobox with the
		// selected color, and we'll draw the current selected text.
		//----------------------------------------------------------------------------------
		SDL_FillRect(CRM32Pro.screen, &ColorRect, SelBackColor);
		DrawText(CRM32Pro.screen, TextRect.y, &TextRect);

		//----------------------------------------------------------------------------------
		// And finally we'll draw the open list button and the list.
		//----------------------------------------------------------------------------------
		OpenList->Draw();
		List->Draw();
	}

	//--------------------------------------------------------------------------------------
	/// This function looks if the cursor is over the control.
	//--------------------------------------------------------------------------------------
	bool ComboBox::IsCursorOver (void)
	{
		return (Control::IsCursorOver() || (List->GetVisible() && List->IsCursorOver()));
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool ComboBox::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// If we have made click over the open list button, then we show the list.
				//--------------------------------------------------------------------------
				if(OpenList->Update(event))
				{
					if(event.button.button == SDL_BUTTON_LEFT)
					{
						List->SetVisible(!List->GetVisible());
					}
				}
				//--------------------------------------------------------------------------
				// If we have made click over the list, then we take the selected item, and
				// we'll put in the combobox the text and the back color of the selected
				// item. And after this we'll hide the list and clear the selected items. 
				//--------------------------------------------------------------------------
				else if(List->Update(event))
				{
					if((event.button.button == SDL_BUTTON_LEFT) && !List->GetVBar()->IsCursorOver())
					{
						list<int> * selitems = List->GetSelectedItems();

						if(selitems->size() > 0)
						{
							list<int>::iterator it = selitems->begin();
							int sel = *it;

							SetText(List->GetListItem(sel)->Text.c_str());
							SelBackColor = List->GetListItem(sel)->BackColor;
						}
						else
						{
							SetText("");
							SelBackColor = BackColor;
						}

						List->SetVisible(false);
						List->SetNoSelectedItems();
					}
				}
				//--------------------------------------------------------------------------
				// If we have made click over the rest of the control, we'll show the list.
				//--------------------------------------------------------------------------
				else
				{
					if(event.button.button == SDL_BUTTON_LEFT)
					{
						List->SetVisible(!List->GetVisible());
					}
				}

				//--------------------------------------------------------------------------
				// And if MouseButtonDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			//------------------------------------------------------------------------------
			// If the event wasn't for the control, we hide the list.
			//------------------------------------------------------------------------------
			else
			{
				List->SetVisible(false);
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			List->Update(event);

			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	ComboBox & ComboBox::CopyFrom (const ComboBox & obj)
	{
		Box::CopyFrom(obj);

		ITextControl::CopyFrom(obj);
		
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		SelBackColor = obj.SelBackColor;
		
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		OpenList->CopyFrom(*(obj.OpenList));
		List->CopyFrom(*(obj.List));

		TextRect  = obj.TextRect;
		ColorRect = obj.ColorRect;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void ComboBox::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we call the UpdateRects function of the Box class.
		//----------------------------------------------------------------------------------
		Box::UpdateRects();

		//----------------------------------------------------------------------------------
		// Second we check if the control have any correct skin, setting the text's area
		// with the area of the box's center rect, if we have a skin in the control.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_BOX_RECTS))
			TextRect = Rect;
		else
			TextRect = Rects[CENTER_BOX_RECT];
		
		TextRect.w -= OPENLISTBUTTON_SIZE;

		SDL_Rect aux;
		
		//----------------------------------------------------------------------------------
		// Third we'll set the position of the open list button.
		//----------------------------------------------------------------------------------
		aux.x = TextRect.x + TextRect.w;
		aux.y = TextRect.y;
		aux.w = OPENLISTBUTTON_SIZE;
		aux.h = TextRect.h;
		OpenList->SetRect(aux);
		
		//----------------------------------------------------------------------------------
		// Fourth we'll set the position of the list.
		//----------------------------------------------------------------------------------
		aux.x = Rect.x;
		aux.y = Rect.y + Rect.h;
		aux.w = Rect.w;
		aux.h = List->GetHeight();
		List->SetRect(aux);

		//----------------------------------------------------------------------------------
		// Fifth we'll calculate the area of the selected color in the control.
		//----------------------------------------------------------------------------------
		ColorRect.x = TextRect.x + RECTX_SEP;
		ColorRect.y = TextRect.y + RECTY_SEP;
		ColorRect.w = TextRect.w - RECTW_SEP;
		ColorRect.h = TextRect.h - RECTH_SEP;
	}
}
//******************************************************************************************
// ComboBox.cpp
//******************************************************************************************