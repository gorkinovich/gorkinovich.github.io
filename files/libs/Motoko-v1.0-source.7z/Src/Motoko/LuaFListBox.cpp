//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// ListBox functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ListBox::CopyFrom.
		//----------------------------------------------------------------------------------
		static int ListBox_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				ListBox * src = (ListBox *) ControlToCopy;

				if(Controls.size() > 0)
				{
					ListBox * dst = (ListBox *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::UpdateRects.
		//----------------------------------------------------------------------------------
		static int ListBox_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::AddListItem.
		//----------------------------------------------------------------------------------
		static int ListBox_AddListItem (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);
					lua_pushboolean(L, aux->AddListItem(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_AddListItem'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2))
				{
					GetControlsTop(ListBox, aux);
					lua_pushboolean(L, aux->AddListItem(lua_tostring(L, 1), lua_tointeger(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_AddListItem'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_AddListItem'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::DelListItem.
		//----------------------------------------------------------------------------------
		static int ListBox_DelListItem (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->DelListItem(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_DelListItem'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_DelListItem'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::ClearListItems.
		//----------------------------------------------------------------------------------
		static int ListBox_ClearListItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->ClearListItems();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_ClearListItems'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetListItem->Text.
		//----------------------------------------------------------------------------------
		static int ListBox_GetListItemText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					lua_pushstring(L, aux->GetListItem(lua_tointeger(L, 1))->Text.c_str());
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_GetListItemText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetListItemText'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetListItem->BackColor.
		//----------------------------------------------------------------------------------
		static int ListBox_GetListItemBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					lua_pushnumber(L, aux->GetListItem(lua_tointeger(L, 1))->BackColor);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_GetListItemBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetListItemBackColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetMultiSelect.
		//----------------------------------------------------------------------------------
		static int ListBox_GetMultiSelect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushboolean(L, aux->GetMultiSelect());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetMultiSelect'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetSelectedItems.
		//----------------------------------------------------------------------------------
		static int ListBox_GetSelectedItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					list<int>::iterator it = aux->GetSelectedItems()->begin();

					int index = lua_tointeger(L, 1);

					for(int i = 0; (i < index) && (it != aux->GetSelectedItems()->end()); ++i) ++it;

					if(it != aux->GetSelectedItems()->end())
						lua_pushnumber(L, *it);
					else
						lua_pushnumber(L, -1);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_GetSelectedItems'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetSelectedItems'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetSelectedItems->size().
		//----------------------------------------------------------------------------------
		static int ListBox_GetSelectedItemsSize (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetSelectedItems()->size());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetSelectedItemsSize'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetSelColor.
		//----------------------------------------------------------------------------------
		static int ListBox_GetSelColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetSelColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetSelColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetVBar.
		//----------------------------------------------------------------------------------
		static int ListBox_GetVBar (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				Controls.push(aux->GetVBar());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetVBar'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetListItem.
		//----------------------------------------------------------------------------------
		static int ListBox_SetListItem (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isnumber(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(ListBox, aux);
					aux->SetListItem(lua_tointeger(L, 1), lua_tostring(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetListItem'.");
					lua_error(L);
				}
			}
			else if(numargs == 3)
			{
				if(lua_isnumber(L, 1) && lua_isstring(L, 2) && lua_isnumber(L, 3))
				{
					GetControlsTop(ListBox, aux);
					aux->SetListItem(lua_tointeger(L, 1), lua_tostring(L, 2), lua_tointeger(L, 3));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetListItem'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetListItem'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetMultiSelect.
		//----------------------------------------------------------------------------------
		static int ListBox_SetMultiSelect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetMultiSelect(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetMultiSelect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetMultiSelect'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetNoSelectedItems.
		//----------------------------------------------------------------------------------
		static int ListBox_SetNoSelectedItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->SetNoSelectedItems();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetNoSelectedItems'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetSelColor.
		//----------------------------------------------------------------------------------
		static int ListBox_SetSelColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetSelColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetSelColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetSelColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetText.
		//----------------------------------------------------------------------------------
		static int ListBox_SetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetText'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::AddText.
		//----------------------------------------------------------------------------------
		static int ListBox_AddText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->AddText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_AddText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_AddText'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetName.
		//----------------------------------------------------------------------------------
		static int ListBox_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetName'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int ListBox_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetBackColor.
		//----------------------------------------------------------------------------------
		static int ListBox_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2))
				{
					GetControlsTop(ListBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1), lua_tointeger(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetAppearance.
		//----------------------------------------------------------------------------------
		static int ListBox_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(ListBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 6)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) &&
				   lua_isstring(L, 4) && lua_isstring(L, 5) && lua_isstring(L, 6))
				{
					GetControlsTop(ListBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 3), lua_tostring(L, 4)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 5), lua_tostring(L, 6)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 4)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) && lua_isstring(L, 4))
				{
					GetControlsTop(ListBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 3)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 4)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// ITextControl functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ListBox::UpdateWidth.
		//----------------------------------------------------------------------------------
		static int ListBox_UpdateWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->UpdateWidth();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_UpdateWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetAlignment.
		//----------------------------------------------------------------------------------
		static int ListBox_GetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);

				switch(aux->GetAlignment())
				{
				case Left:
					lua_pushstring(L, "Left");
					break;
					
				case Center:
					lua_pushstring(L, "Center");
					break;
					
				case Right:
					lua_pushstring(L, "Right");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetAlignment'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetText.
		//----------------------------------------------------------------------------------
		static int ListBox_GetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushstring(L, aux->GetText());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetText'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetFont.
		//----------------------------------------------------------------------------------
		static int ListBox_GetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushlightuserdata(L, aux->GetFont());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetFont'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetFontHeight.
		//----------------------------------------------------------------------------------
		static int ListBox_GetFontHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetFontHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetFontHeight'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetMaxWidth.
		//----------------------------------------------------------------------------------
		static int ListBox_GetMaxWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetMaxWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetMaxWidth'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetWidthLastLine.
		//----------------------------------------------------------------------------------
		static int ListBox_GetWidthLastLine (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetWidthLastLine());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetWidthLastLine'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetMinNumLines.
		//----------------------------------------------------------------------------------
		static int ListBox_GetMinNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetMinNumLines());
			}
			else if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					lua_pushnumber(L, aux->GetMinNumLines(lua_tointeger(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_GetMinNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetMinNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::GetMaxNumLines.
		//----------------------------------------------------------------------------------
		static int ListBox_GetMaxNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(ListBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else if(numargs == 5)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) && lua_isnumber(L, 5))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(ListBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux, lua_tointeger(L, 5)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetMaxNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetAlignment.
		//----------------------------------------------------------------------------------
		static int ListBox_SetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);

					if(strcmp(lua_tostring(L, 1), "Left") == STR_EQU)
						aux->SetAlignment(Left);
					else if(strcmp(lua_tostring(L, 1), "Center") == STR_EQU)
						aux->SetAlignment(Center);
					else if(strcmp(lua_tostring(L, 1), "Right") == STR_EQU)
						aux->SetAlignment(Right);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetAlignment(Left);
						break;
						
					case 1:
						aux->SetAlignment(Center);
						break;
						
					case 2:
						aux->SetAlignment(Right);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetAlignment'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetAlignment'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ListBox::SetFont.
		//----------------------------------------------------------------------------------
		static int ListBox_SetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetFont(appLuaRef->Resources.GetFont(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetFont'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetFont'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Box functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ListBox::SetX.
		//----------------------------------------------------------------------------------
		static int ListBox_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetX'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetY.
		//----------------------------------------------------------------------------------
		static int ListBox_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetY'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetWidth.
		//----------------------------------------------------------------------------------
		static int ListBox_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetHeight.
		//----------------------------------------------------------------------------------
		static int ListBox_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetRect.
		//----------------------------------------------------------------------------------
		static int ListBox_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(ListBox, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ListBox::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int ListBox_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetFocus.
		//----------------------------------------------------------------------------------
		static int ListBox_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int ListBox_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int ListBox_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int ListBox_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int ListBox_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int ListBox_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetName.
		//----------------------------------------------------------------------------------
		static int ListBox_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetX.
		//----------------------------------------------------------------------------------
		static int ListBox_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetY.
		//----------------------------------------------------------------------------------
		static int ListBox_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetWidth.
		//----------------------------------------------------------------------------------
		static int ListBox_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetHeight.
		//----------------------------------------------------------------------------------
		static int ListBox_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int ListBox_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetAppearance.
		//----------------------------------------------------------------------------------
		static int ListBox_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetBackColor.
		//----------------------------------------------------------------------------------
		static int ListBox_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetPicture.
		//----------------------------------------------------------------------------------
		static int ListBox_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int ListBox_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetEnable.
		//----------------------------------------------------------------------------------
		static int ListBox_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetVisible.
		//----------------------------------------------------------------------------------
		static int ListBox_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetTransparency.
		//----------------------------------------------------------------------------------
		static int ListBox_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::GetType.
		//----------------------------------------------------------------------------------
		static int ListBox_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetPicture.
		//----------------------------------------------------------------------------------
		static int ListBox_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int ListBox_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ListBox, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetEnable.
		//----------------------------------------------------------------------------------
		static int ListBox_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetVisible.
		//----------------------------------------------------------------------------------
		static int ListBox_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ListBox::SetTransparency.
		//----------------------------------------------------------------------------------
		static int ListBox_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ListBox, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ListBox_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ListBox::CreateNew.
		//----------------------------------------------------------------------------------
		static int ListBox_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				ListBox * aux = new ListBox();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ListBox_CreateNew'.");
				lua_error(L);
			}

			return 1;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFListBox (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// ListBox functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ListBox_CopyFrom",             ListBox_CopyFrom);
			lua_register(L, "ListBox_UpdateRects",          ListBox_UpdateRects);
			lua_register(L, "ListBox_AddListItem",          ListBox_AddListItem);
			lua_register(L, "ListBox_DelListItem",          ListBox_DelListItem);
			lua_register(L, "ListBox_ClearListItems",       ListBox_ClearListItems);
			lua_register(L, "ListBox_GetListItemText",      ListBox_GetListItemText);
			lua_register(L, "ListBox_GetListItemBackColor", ListBox_GetListItemBackColor);
			lua_register(L, "ListBox_GetMultiSelect",       ListBox_GetMultiSelect);
			lua_register(L, "ListBox_GetSelectedItems",     ListBox_GetSelectedItems);
			lua_register(L, "ListBox_GetSelectedItemsSize", ListBox_GetSelectedItemsSize);
			lua_register(L, "ListBox_GetSelColor",          ListBox_GetSelColor);
			lua_register(L, "ListBox_GetVBar",              ListBox_GetVBar);
			lua_register(L, "ListBox_SetListItem",          ListBox_SetListItem);
			lua_register(L, "ListBox_SetMultiSelect",       ListBox_SetMultiSelect);
			lua_register(L, "ListBox_SetNoSelectedItems",   ListBox_SetNoSelectedItems);
			lua_register(L, "ListBox_SetSelColor",          ListBox_SetSelColor);
			lua_register(L, "ListBox_SetText",              ListBox_SetText);
			lua_register(L, "ListBox_AddText",              ListBox_AddText);
			lua_register(L, "ListBox_SetName",              ListBox_SetName);
			lua_register(L, "ListBox_SetBackStyle",         ListBox_SetBackStyle);
			lua_register(L, "ListBox_SetBackColor",         ListBox_SetBackColor);
			lua_register(L, "ListBox_SetAppearance",        ListBox_SetAppearance);

			//------------------------------------------------------------------------------
			// ITextControl functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ListBox_UpdateWidth",      ListBox_UpdateWidth);
			lua_register(L, "ListBox_GetAlignment",     ListBox_GetAlignment);
			lua_register(L, "ListBox_GetText",          ListBox_GetText);
			lua_register(L, "ListBox_GetFont",          ListBox_GetFont);
			lua_register(L, "ListBox_GetFontHeight",    ListBox_GetFontHeight);
			lua_register(L, "ListBox_GetMaxWidth",      ListBox_GetMaxWidth);
			lua_register(L, "ListBox_GetWidthLastLine", ListBox_GetWidthLastLine);
			lua_register(L, "ListBox_GetMinNumLines",   ListBox_GetMinNumLines);
			lua_register(L, "ListBox_GetMaxNumLines",   ListBox_GetMaxNumLines);
			lua_register(L, "ListBox_SetAlignment",     ListBox_SetAlignment);
			lua_register(L, "ListBox_SetFont",          ListBox_SetFont);

			//------------------------------------------------------------------------------
			// Box functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ListBox_UpdateRects", ListBox_UpdateRects);
			lua_register(L, "ListBox_SetX",        ListBox_SetX);
			lua_register(L, "ListBox_SetY",        ListBox_SetY);
			lua_register(L, "ListBox_SetWidth",    ListBox_SetWidth);
			lua_register(L, "ListBox_SetHeight",   ListBox_SetHeight);
			lua_register(L, "ListBox_SetRect",     ListBox_SetRect);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ListBox_IsCursorOver",       ListBox_IsCursorOver);
			lua_register(L, "ListBox_GetFocus",           ListBox_GetFocus);
			lua_register(L, "ListBox_SetKeyDown",         ListBox_SetKeyDown);
			lua_register(L, "ListBox_SetKeyUp",           ListBox_SetKeyUp);
			lua_register(L, "ListBox_SetMouseMotion",     ListBox_SetMouseMotion);
			lua_register(L, "ListBox_SetMouseButtonDown", ListBox_SetMouseButtonDown);
			lua_register(L, "ListBox_SetMouseButtonUp",   ListBox_SetMouseButtonUp);
			lua_register(L, "ListBox_GetName",            ListBox_GetName);
			lua_register(L, "ListBox_GetX",               ListBox_GetX);
			lua_register(L, "ListBox_GetY",               ListBox_GetY);
			lua_register(L, "ListBox_GetWidth",           ListBox_GetWidth);
			lua_register(L, "ListBox_GetHeight",          ListBox_GetHeight);
			lua_register(L, "ListBox_GetBackStyle",       ListBox_GetBackStyle);
			lua_register(L, "ListBox_GetAppearance",      ListBox_GetAppearance);
			lua_register(L, "ListBox_GetBackColor",       ListBox_GetBackColor);
			lua_register(L, "ListBox_GetPicture",         ListBox_GetPicture);
			lua_register(L, "ListBox_GetMousePointer",    ListBox_GetMousePointer);
			lua_register(L, "ListBox_GetEnable",          ListBox_GetEnable);
			lua_register(L, "ListBox_GetVisible",         ListBox_GetVisible);
			lua_register(L, "ListBox_GetTransparency",    ListBox_GetTransparency);
			lua_register(L, "ListBox_GetType",            ListBox_GetType);
			lua_register(L, "ListBox_SetPicture",         ListBox_SetPicture);
			lua_register(L, "ListBox_SetMousePointer",    ListBox_SetMousePointer);
			lua_register(L, "ListBox_SetEnable",          ListBox_SetEnable);
			lua_register(L, "ListBox_SetVisible",         ListBox_SetVisible);
			lua_register(L, "ListBox_SetTransparency",    ListBox_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ListBox_CreateNew", ListBox_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFListBox.cpp
//******************************************************************************************