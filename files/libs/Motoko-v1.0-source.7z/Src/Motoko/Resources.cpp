//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Application.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
//******************************************************************************************
// Class ResourcesManager.
//******************************************************************************************

	//--------------------------------------------------------------------------------------
	/**
	 *  ResourcesManager constructor.
	 */
	//--------------------------------------------------------------------------------------
	ResourcesManager::ResourcesManager ()
	{
		Textures.assign(0);
		Fonts.assign(0);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ResourcesManager copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ResourcesManager::ResourcesManager (const ResourcesManager & obj)
	{
		Textures = obj.Textures;
		Fonts    = obj.Fonts;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ResourcesManager operator =.
	 */
	//--------------------------------------------------------------------------------------
	ResourcesManager & ResourcesManager::operator = (const ResourcesManager & obj)
	{
		Textures = obj.Textures;
		Fonts    = obj.Fonts;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ResourcesManager destructor.
	 */
	//--------------------------------------------------------------------------------------
	ResourcesManager::~ResourcesManager ()
	{
		Free();
	}

	//--------------------------------------------------------------------------------------
	/// Add a texture.
	/**
	 *  @param file    Name of the texture.
	 *  @param fileDPF File with with the texture.
	 *  @see RemoveTexture(), FreeTextures().
	 *  @return If no error a pointer to the texture, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	SDL_Surface * ResourcesManager::LoadTexture (const char * file, const char * fileDPF)
	{
		//----------------------------------------------------------------------------------
		// First we create a new instance of the TextureResource struct.
		//----------------------------------------------------------------------------------
		TextureResource * aux = NULL;

		aux = new TextureResource();

		if(aux == NULL) return NULL;

		aux->Data = NULL;
		aux->Name = file;

		//----------------------------------------------------------------------------------
		// After that, we load the texture file.
		//----------------------------------------------------------------------------------
		if(fileDPF != NULL)
			aux->Data = IImage->Load((char *) fileDPF, (char *) file);
		else
			aux->Data = IImage->LoadBMP((char *) file);

		if(aux->Data == NULL)
		{
			delete aux;

			return NULL;
		}

		//----------------------------------------------------------------------------------
		// And finally we must push it, into the vector Textures.
		//----------------------------------------------------------------------------------
		int actsize = Textures.size();
		Textures.push_back(aux);

		if(actsize == Textures.size())
		{
			CRM32Pro.FreeSurface(aux->Data);

			delete aux;

			return NULL;
		}

		return aux->Data;
	}

	//--------------------------------------------------------------------------------------
	/// Remove a texture.
	/**
	 *  @see AddTexture(), FreeTextures().
	 */
	//--------------------------------------------------------------------------------------
	void ResourcesManager::RemoveTexture (const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a texture with the same name. If we
		// find it, then we free the texture and delete the data from memory.
		//----------------------------------------------------------------------------------
		vector<TextureResource *>::iterator i;
		TextureResource * aux;

		for(i = Textures.begin(); i != Textures.end(); ++i)
		{
			aux = *i;
			
			if(aux->Name == name)
			{
				CRM32Pro.FreeSurface(aux->Data);

				delete aux;

				Textures.erase(i);
				return;
			}
		}
	}


	//--------------------------------------------------------------------------------------
	/// Unload the textures.
	/**
	 *  @see AddTexture(), RemoveTexture().
	 */
	//--------------------------------------------------------------------------------------
	void ResourcesManager::FreeTextures  (void)
	{
		TextureResource * aux;

		//----------------------------------------------------------------------------------
		// We take the whole vector and erase each texture of the manager.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Textures.size(); ++i)
		{
			aux = Textures[i];

			if(aux != NULL)
			{
				CRM32Pro.FreeSurface(aux->Data);
				delete aux;
			}
		}

		Textures.erase(Textures.begin(), Textures.end());
	}

	//--------------------------------------------------------------------------------------
	/// Get a pointer to a texture.
	/**
	 *  @param name Name of the texture.
	 *  @return If no error a pointer to the texture, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	SDL_Surface * ResourcesManager::GetTexture (const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a texture with the same name. If we
		// find it, then we return a pointer to that texture.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Textures.size(); ++i)
		{
			if(Textures[i]->Name == name)
			{
				return Textures[i]->Data;
			}
		}

		return NULL;
	}

	//--------------------------------------------------------------------------------------
	/// Get a pointer to a texture.
	/**
	 *  @param i Number of texture in the vector.
	 *  @return If no error a pointer to the texture, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	SDL_Surface * ResourcesManager::GetTexture (int i)
	{
		return Textures[i]->Data;
	}

	//--------------------------------------------------------------------------------------
	/// Add a Font.
	/**
	 *  @param file    Name of the font.
	 *  @param fileDPF File with with the font.
	 *  @see RemoveFont(), FreeFonts().
	 *  @return If no error a pointer to the font, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	CRM32Pro_CFont * ResourcesManager::LoadFont (const char * file, const char * fileDPF)
	{
		//----------------------------------------------------------------------------------
		// First we create a new instance of the FontResource struct.
		//----------------------------------------------------------------------------------
		FontResource * aux = NULL;

		aux = new FontResource();

		if(aux == NULL) return NULL;

		aux->Data = NULL;
		aux->Name = file;

		//----------------------------------------------------------------------------------
		// After that, we load the font from a file.
		//----------------------------------------------------------------------------------
		aux->Data = new CRM32Pro_CFont();

		if(aux->Data == NULL)
		{
			delete aux;

			return NULL;
		}

		if(!aux->Data->Load((char *) fileDPF, (char *) file))
		{
			delete aux->Data;
			delete aux;

			return NULL;
		}

		//----------------------------------------------------------------------------------
		// And finally we must push it, into the vector Fonts.
		//----------------------------------------------------------------------------------
		int actsize = Fonts.size();
		Fonts.push_back(aux);

		if(actsize == Fonts.size())
		{
			delete aux->Data;
			delete aux;

			return NULL;
		}

		return aux->Data;
	}

	//--------------------------------------------------------------------------------------
	/// Remove a font.
	/**
	 *  @see AddFont(), FreeFonts().
	 */
	//--------------------------------------------------------------------------------------
	void ResourcesManager::RemoveFont (const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a texture with the same name. If we
		// find it, then we free the texture and delete the data from memory.
		//----------------------------------------------------------------------------------
		vector<FontResource *>::iterator i;
		FontResource * aux;

		for(i = Fonts.begin(); i != Fonts.end(); ++i)
		{
			aux = *i;
			
			if(aux->Name == name)
			{
				delete aux->Data;
				delete aux;

				Fonts.erase(i);
				return;
			}
		}
	}


	//--------------------------------------------------------------------------------------
	/// Unload the themes.
	/**
	 *  @see AddFont(), RemoveFont().
	 */
	//--------------------------------------------------------------------------------------
	void ResourcesManager::FreeFonts  (void)
	{
		FontResource * aux;

		//----------------------------------------------------------------------------------
		// We take the whole vector and erase each texture of the manager.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Fonts.size(); ++i)
		{
			aux = Fonts[i];

			if(aux != NULL)
			{
				delete aux->Data;
				delete aux;
			}
		}

		Fonts.erase(Fonts.begin(), Fonts.end());
	}

	//--------------------------------------------------------------------------------------
	/// Get a pointer to a font.
	/**
	 *  @param name Name of the font.
	 *  @return If no error a pointer to the font, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	CRM32Pro_CFont * ResourcesManager::GetFont (const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a texture with the same name. If we
		// find it, then we return a pointer to that texture.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Fonts.size(); ++i)
		{
			if(Fonts[i]->Name == name)
			{
				return Fonts[i]->Data;
			}
		}

		return NULL;
	}

	//--------------------------------------------------------------------------------------
	/// Get a pointer to a font.
	/**
	 *  @param i Number of font in the vector.
	 *  @return If no error a pointer to the font, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	CRM32Pro_CFont * ResourcesManager::GetFont (int i)
	{
		return Fonts[i]->Data;
	}

	//--------------------------------------------------------------------------------------
	/// Unload the resources manager.
	//--------------------------------------------------------------------------------------
	void ResourcesManager::Free (void)
	{
		FreeTextures();
		FreeFonts();
	}


//******************************************************************************************
// Functions.
//******************************************************************************************

	//--------------------------------------------------------------------------------------
	// This function create a new TextBox.
	//--------------------------------------------------------------------------------------
	DLLAPI TextBox * GetNewTextBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									ControlBackStyle backstyle, ControlSkin * boxskin, ControlSkin * vscrollskin,
									ControlSkin * hscrollskin, ControlSkin * buttonskin, Uint32 backcolor,
									Uint32 scrollcolor, CRM32Pro_CFont * font, bool multiline, bool locked,
									ControlScrollBars scrollbars)
	{
		TextBox * aux = new TextBox();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(boxskin, vscrollskin, hscrollskin, buttonskin);
		aux->SetBackColor(backcolor, scrollcolor);
		aux->SetMultiLine(multiline);
		aux->SetLocked(locked);
		aux->SetScrollBars(scrollbars);

		aux->SetFont(font);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new LabelBox.
	//--------------------------------------------------------------------------------------
	DLLAPI LabelBox * GetNewLabelBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									  ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
									  CRM32Pro_CFont * font)
	{
		LabelBox * aux = new LabelBox();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(skin);
		aux->SetBackColor(backcolor);

		aux->SetFont(font);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		return aux;
	}

	//--------------------------------------------------------------------------------------
	// This function create a new PictureBox.
	//--------------------------------------------------------------------------------------
	DLLAPI PictureBox * GetNewPictureBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										  ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
										  SDL_Surface * picture)
	{
		PictureBox * aux = new PictureBox();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(skin);
		aux->SetBackColor(backcolor);
		aux->SetPicture(picture);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new ComboBox.
	//--------------------------------------------------------------------------------------
	DLLAPI ComboBox * GetNewComboBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									  Uint16 listheight, ControlBackStyle backstyle, ControlSkin * boxskin,
									  ControlSkin * vscrollskin, ControlSkin * buttonskin, Uint32 backcolor,
									  Uint32 scrollcolor, Uint32 selbackcolor, CRM32Pro_CFont * font)
	{
		ComboBox * aux = new ComboBox();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(boxskin, vscrollskin, buttonskin);
		aux->SetBackColor(backcolor, scrollcolor);
		aux->SetSelBackColor(selbackcolor);

		aux->SetFont(font);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);
		aux->SetListHeight(listheight);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new ListBox.
	//--------------------------------------------------------------------------------------
	DLLAPI ListBox * GetNewListBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									ControlBackStyle backstyle, ControlSkin * boxskin, ControlSkin * vscrollskin,
									ControlSkin * buttonskin, Uint32 backcolor, Uint32 scrollcolor,
									Uint32 selcolor, CRM32Pro_CFont * font, bool multiselect)
	{
		ListBox * aux = new ListBox();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(boxskin, vscrollskin, buttonskin);
		aux->SetBackColor(backcolor, scrollcolor);
		aux->SetSelColor(selcolor);

		aux->SetFont(font);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);
		
		aux->SetMultiSelect(multiselect);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new Button.
	//--------------------------------------------------------------------------------------
	DLLAPI Button * GetNewButton (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
								  ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
								  CRM32Pro_CFont * font, const char * text)
	{
		Button * aux = new Button();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(skin);
		aux->SetBackColor(backcolor);

		aux->SetFont(font);
		aux->SetText(text);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new Button.
	//--------------------------------------------------------------------------------------
	DLLAPI Button * GetNewGraphicalButton (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										   SDL_Surface * picture, SDL_Surface * over, SDL_Surface * down,
										   Uint32 backcolor, CRM32Pro_CFont * font, const char * text)
	{
		Button * aux = new Button();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(UsePicture);
		aux->SetAppearance(NULL);
		aux->SetBackColor(backcolor);

		aux->SetFont(font);
		aux->SetText(text);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);
		
		aux->SetPicture(picture);
		aux->SetPictureOver(over);
		aux->SetPictureDown(down);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new CheckButton.
	//--------------------------------------------------------------------------------------
	DLLAPI CheckButton * GetNewCheckButton (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
											ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
											CRM32Pro_CFont * font, const char * text)
	{
		CheckButton * aux = new CheckButton();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(skin);
		aux->SetBackColor(backcolor);

		aux->SetFont(font);
		aux->SetText(text);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new VScrollBar.
	//--------------------------------------------------------------------------------------
	DLLAPI VScrollBar * GetNewVScrollBar (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										  ControlBackStyle backstyle, ControlSkin * scrollskin,
										  ControlSkin * buttonskin, Uint32 backcolor, int min, int max,
										  int value, int smallchange, int largechange)
	{
		VScrollBar * aux = new VScrollBar();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(scrollskin, buttonskin);
		aux->SetBackColor(backcolor);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		aux->SetMin(min);
		aux->SetMax(max);
		aux->SetValue(value);
		aux->SetSmallChange(smallchange);
		aux->SetLargeChange(largechange);

		return aux;
	}

	//--------------------------------------------------------------------------------------
	// This function create a new HScrollBar.
	//--------------------------------------------------------------------------------------
	DLLAPI HScrollBar * GetNewHScrollBar (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										  ControlBackStyle backstyle, ControlSkin * scrollskin,
										  ControlSkin * buttonskin, Uint32 backcolor, int min, int max,
										  int value, int smallchange, int largechange)
	{
		HScrollBar * aux = new HScrollBar();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(scrollskin, buttonskin);
		aux->SetBackColor(backcolor);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		aux->SetMin(min);
		aux->SetMax(max);
		aux->SetValue(value);
		aux->SetSmallChange(smallchange);
		aux->SetLargeChange(largechange);

		return aux;
	}
	
	//--------------------------------------------------------------------------------------
	// This function create a new Panel.
	//--------------------------------------------------------------------------------------
	DLLAPI Panel * GetNewPanel (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
								SDL_Surface * picture, Uint32 backcolor, bool transparency)
	{
		Panel * aux = new Panel();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetPicture(picture);
		aux->SetBackColor(backcolor);
		aux->SetTransparency(transparency);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		return aux;
	}

	//--------------------------------------------------------------------------------------
	// This function create a new Dialog.
	//--------------------------------------------------------------------------------------
	DLLAPI Dialog * GetNewDialog (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
								  ControlBackStyle backstyle, ControlSkin * winskin, ControlSkin * buttonskin, 
								  Uint32 titlecolor, Uint32 backcolor, CRM32Pro_CFont * font, const char * text)
	{
		Dialog * aux = new Dialog();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(winskin, buttonskin);
		aux->SetTitleColor(titlecolor);
		aux->SetBackColor(backcolor);

		aux->SetFont(font);
		aux->SetText(text);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);

		return aux;
	}

	//--------------------------------------------------------------------------------------
	// This function create a new ControlListBox.
	//--------------------------------------------------------------------------------------
	DLLAPI ControlListBox * GetNewControlListBox (const char * name, Sint16 x, Sint16 y, Uint16 width,
												  Uint16 height, ControlBackStyle backstyle,
												  ControlSkin * boxskin, ControlSkin * vscrollskin,
												  ControlSkin * buttonskin, Uint32 backcolor,
												  Uint32 scrollcolor, Uint32 selcolor, bool multiselect)
	{
		ControlListBox * aux = new ControlListBox();

		if(aux == NULL) return NULL;

		aux->SetName(name);
		aux->SetBackStyle(backstyle);
		aux->SetAppearance(boxskin, vscrollskin, buttonskin);
		aux->SetBackColor(backcolor, scrollcolor);
		aux->SetSelColor(selcolor);

		aux->SetX(x);
		aux->SetY(y);
		aux->SetWidth(width);
		aux->SetHeight(height);
		
		aux->SetMultiSelect(multiselect);

		return aux;
	}
}
//******************************************************************************************
// Resources.cpp
//******************************************************************************************