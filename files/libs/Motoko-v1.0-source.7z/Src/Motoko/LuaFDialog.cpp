//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// Dialog functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Dialog::CopyFrom.
		//----------------------------------------------------------------------------------
		static int Dialog_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Dialog * src = (Dialog *) ControlToCopy;

				if(Controls.size() > 0)
				{
					Dialog * dst = (Dialog *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::UpdateRects.
		//----------------------------------------------------------------------------------
		static int Dialog_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetTitleColor.
		//----------------------------------------------------------------------------------
		static int Dialog_GetTitleColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetTitleColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetTitleColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetClose.
		//----------------------------------------------------------------------------------
		static int Dialog_GetClose (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				Controls.push(aux->GetClose());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetClose'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetX.
		//----------------------------------------------------------------------------------
		static int Dialog_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetX'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetY.
		//----------------------------------------------------------------------------------
		static int Dialog_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetY'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetWidth.
		//----------------------------------------------------------------------------------
		static int Dialog_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetHeight.
		//----------------------------------------------------------------------------------
		static int Dialog_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetRect.
		//----------------------------------------------------------------------------------
		static int Dialog_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(Dialog, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetTitleColor.
		//----------------------------------------------------------------------------------
		static int Dialog_SetTitleColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetTitleColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetTitleColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetTitleColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetName.
		//----------------------------------------------------------------------------------
		static int Dialog_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetName'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int Dialog_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetBackColor.
		//----------------------------------------------------------------------------------
		static int Dialog_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetBackColor'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2))
				{
					GetControlsTop(Dialog, aux);
					aux->SetBackColor(lua_tointeger(L, 1), lua_tointeger(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetAppearance.
		//----------------------------------------------------------------------------------
		static int Dialog_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(Dialog, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 4)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) && lua_isstring(L, 4))
				{
					GetControlsTop(Dialog, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 3), lua_tostring(L, 4)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 3)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3))
				{
					GetControlsTop(Dialog, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 3)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// ITextControl functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Dialog::UpdateWidth.
		//----------------------------------------------------------------------------------
		static int Dialog_UpdateWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->UpdateWidth();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_UpdateWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetAlignment.
		//----------------------------------------------------------------------------------
		static int Dialog_GetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);

				switch(aux->GetAlignment())
				{
				case Left:
					lua_pushstring(L, "Left");
					break;
					
				case Center:
					lua_pushstring(L, "Center");
					break;
					
				case Right:
					lua_pushstring(L, "Right");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetAlignment'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetText.
		//----------------------------------------------------------------------------------
		static int Dialog_GetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushstring(L, aux->GetText());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetText'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetFont.
		//----------------------------------------------------------------------------------
		static int Dialog_GetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushlightuserdata(L, aux->GetFont());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetFont'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetFontHeight.
		//----------------------------------------------------------------------------------
		static int Dialog_GetFontHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetFontHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetFontHeight'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetMaxWidth.
		//----------------------------------------------------------------------------------
		static int Dialog_GetMaxWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetMaxWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetMaxWidth'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetWidthLastLine.
		//----------------------------------------------------------------------------------
		static int Dialog_GetWidthLastLine (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetWidthLastLine());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetWidthLastLine'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetMinNumLines.
		//----------------------------------------------------------------------------------
		static int Dialog_GetMinNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetMinNumLines());
			}
			else if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					lua_pushnumber(L, aux->GetMinNumLines(lua_tointeger(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_GetMinNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetMinNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetMaxNumLines.
		//----------------------------------------------------------------------------------
		static int Dialog_GetMaxNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(Dialog, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else if(numargs == 5)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) && lua_isnumber(L, 5))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(Dialog, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux, lua_tointeger(L, 5)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetMaxNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetAlignment.
		//----------------------------------------------------------------------------------
		static int Dialog_SetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);

					if(strcmp(lua_tostring(L, 1), "Left") == STR_EQU)
						aux->SetAlignment(Left);
					else if(strcmp(lua_tostring(L, 1), "Center") == STR_EQU)
						aux->SetAlignment(Center);
					else if(strcmp(lua_tostring(L, 1), "Right") == STR_EQU)
						aux->SetAlignment(Right);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetAlignment(Left);
						break;
						
					case 1:
						aux->SetAlignment(Center);
						break;
						
					case 2:
						aux->SetAlignment(Right);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetAlignment'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetAlignment'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::SetFont.
		//----------------------------------------------------------------------------------
		static int Dialog_SetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetFont(appLuaRef->Resources.GetFont(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetFont'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetFont'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetText.
		//----------------------------------------------------------------------------------
		static int Dialog_SetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetText'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::AddText.
		//----------------------------------------------------------------------------------
		static int Dialog_AddText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->AddText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_AddText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_AddText'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// Container functions.
	//**************************************************************************************
		
		//----------------------------------------------------------------------------------
		// Dialog::AddControl.
		//----------------------------------------------------------------------------------
		static int Dialog_AddControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(Controls.size() > 0)
				{
					GetControlsTop(Dialog, auxc);
					if(auxc->AddControl(aux) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
						LostControls.push(aux);
					}
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_AddControl'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::AddControlRel.
		//----------------------------------------------------------------------------------
		static int Dialog_AddControlRel (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(Controls.size() > 0)
				{
					GetControlsTop(Dialog, auxc);
					if(auxc->AddControlRel(aux) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
						LostControls.push(aux);
					}
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_AddControlRel'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::RemoveControl.
		//----------------------------------------------------------------------------------
		static int Dialog_RemoveControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->RemoveControl(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_RemoveControl'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_RemoveControl'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::Free.
		//----------------------------------------------------------------------------------
		static int Dialog_Free (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->Free();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_Free'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetControl.
		//----------------------------------------------------------------------------------
		static int Dialog_GetControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					Controls.push(aux->GetControl(lua_tostring(L, 1)));
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(Dialog, aux);
					Controls.push(aux->GetControl(lua_tointeger(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_GetControl'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetControl'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetSize.
		//----------------------------------------------------------------------------------
		static int Dialog_GetSize (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetSize());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetSize'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Dialog::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int Dialog_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Dialog::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int Dialog_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetFocus.
		//----------------------------------------------------------------------------------
		static int Dialog_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int Dialog_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int Dialog_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int Dialog_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int Dialog_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int Dialog_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetName.
		//----------------------------------------------------------------------------------
		static int Dialog_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetX.
		//----------------------------------------------------------------------------------
		static int Dialog_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetY.
		//----------------------------------------------------------------------------------
		static int Dialog_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetWidth.
		//----------------------------------------------------------------------------------
		static int Dialog_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetHeight.
		//----------------------------------------------------------------------------------
		static int Dialog_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int Dialog_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetAppearance.
		//----------------------------------------------------------------------------------
		static int Dialog_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetBackColor.
		//----------------------------------------------------------------------------------
		static int Dialog_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetPicture.
		//----------------------------------------------------------------------------------
		static int Dialog_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetEnable.
		//----------------------------------------------------------------------------------
		static int Dialog_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetVisible.
		//----------------------------------------------------------------------------------
		static int Dialog_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetTransparency.
		//----------------------------------------------------------------------------------
		static int Dialog_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::GetType.
		//----------------------------------------------------------------------------------
		static int Dialog_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetPicture.
		//----------------------------------------------------------------------------------
		static int Dialog_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int Dialog_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Dialog, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetEnable.
		//----------------------------------------------------------------------------------
		static int Dialog_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetVisible.
		//----------------------------------------------------------------------------------
		static int Dialog_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Dialog::SetTransparency.
		//----------------------------------------------------------------------------------
		static int Dialog_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(Dialog, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Dialog_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Dialog::CreateNew.
		//----------------------------------------------------------------------------------
		static int Dialog_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Dialog * aux = new Dialog();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Dialog_CreateNew'.");
				lua_error(L);
			}

			return 0;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFDialog (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// Dialog functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Dialog_CopyFrom",      Dialog_CopyFrom);
			lua_register(L, "Dialog_UpdateRects",   Dialog_UpdateRects);
			lua_register(L, "Dialog_GetTitleColor", Dialog_GetTitleColor);
			lua_register(L, "Dialog_GetClose",      Dialog_GetClose);
			lua_register(L, "Dialog_SetX",          Dialog_SetX);
			lua_register(L, "Dialog_SetY",          Dialog_SetY);
			lua_register(L, "Dialog_SetWidth",      Dialog_SetWidth);
			lua_register(L, "Dialog_SetHeight",     Dialog_SetHeight);
			lua_register(L, "Dialog_SetRect",       Dialog_SetRect);
			lua_register(L, "Dialog_SetTitleColor", Dialog_SetTitleColor);
			lua_register(L, "Dialog_SetName",       Dialog_SetName);
			lua_register(L, "Dialog_SetBackStyle",  Dialog_SetBackStyle);
			lua_register(L, "Dialog_SetBackColor",  Dialog_SetBackColor);
			lua_register(L, "Dialog_SetAppearance", Dialog_SetAppearance);

			//------------------------------------------------------------------------------
			// ITextControl functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Dialog_UpdateWidth",      Dialog_UpdateWidth);
			lua_register(L, "Dialog_GetAlignment",     Dialog_GetAlignment);
			lua_register(L, "Dialog_GetText",          Dialog_GetText);
			lua_register(L, "Dialog_GetFont",          Dialog_GetFont);
			lua_register(L, "Dialog_GetFontHeight",    Dialog_GetFontHeight);
			lua_register(L, "Dialog_GetMaxWidth",      Dialog_GetMaxWidth);
			lua_register(L, "Dialog_GetWidthLastLine", Dialog_GetWidthLastLine);
			lua_register(L, "Dialog_GetMinNumLines",   Dialog_GetMinNumLines);
			lua_register(L, "Dialog_GetMaxNumLines",   Dialog_GetMaxNumLines);
			lua_register(L, "Dialog_SetAlignment",     Dialog_SetAlignment);
			lua_register(L, "Dialog_SetFont",          Dialog_SetFont);
			lua_register(L, "Dialog_SetText",          Dialog_SetText);
			lua_register(L, "Dialog_AddText",          Dialog_AddText);

			//------------------------------------------------------------------------------
			// Container functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Dialog_AddControl",      Dialog_AddControl);
			lua_register(L, "Dialog_AddControlRel",   Dialog_AddControlRel);
			lua_register(L, "Dialog_RemoveControl",   Dialog_RemoveControl);
			lua_register(L, "Dialog_Free",            Dialog_Free);
			lua_register(L, "Dialog_GetControl",      Dialog_GetControl);
			lua_register(L, "Dialog_GetSize",         Dialog_GetSize);
			lua_register(L, "Dialog_GetMousePointer", Dialog_GetMousePointer);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Dialog_IsCursorOver",       Dialog_IsCursorOver);
			lua_register(L, "Dialog_GetFocus",           Dialog_GetFocus);
			lua_register(L, "Dialog_SetKeyDown",         Dialog_SetKeyDown);
			lua_register(L, "Dialog_SetKeyUp",           Dialog_SetKeyUp);
			lua_register(L, "Dialog_SetMouseMotion",     Dialog_SetMouseMotion);
			lua_register(L, "Dialog_SetMouseButtonDown", Dialog_SetMouseButtonDown);
			lua_register(L, "Dialog_SetMouseButtonUp",   Dialog_SetMouseButtonUp);
			lua_register(L, "Dialog_GetName",            Dialog_GetName);
			lua_register(L, "Dialog_GetX",               Dialog_GetX);
			lua_register(L, "Dialog_GetY",               Dialog_GetY);
			lua_register(L, "Dialog_GetWidth",           Dialog_GetWidth);
			lua_register(L, "Dialog_GetHeight",          Dialog_GetHeight);
			lua_register(L, "Dialog_GetBackStyle",       Dialog_GetBackStyle);
			lua_register(L, "Dialog_GetAppearance",      Dialog_GetAppearance);
			lua_register(L, "Dialog_GetBackColor",       Dialog_GetBackColor);
			lua_register(L, "Dialog_GetPicture",         Dialog_GetPicture);
			lua_register(L, "Dialog_GetEnable",          Dialog_GetEnable);
			lua_register(L, "Dialog_GetVisible",         Dialog_GetVisible);
			lua_register(L, "Dialog_GetTransparency",    Dialog_GetTransparency);
			lua_register(L, "Dialog_GetType",            Dialog_GetType);
			lua_register(L, "Dialog_SetPicture",         Dialog_SetPicture);
			lua_register(L, "Dialog_SetMousePointer",    Dialog_SetMousePointer);
			lua_register(L, "Dialog_SetEnable",          Dialog_SetEnable);
			lua_register(L, "Dialog_SetVisible",         Dialog_SetVisible);
			lua_register(L, "Dialog_SetTransparency",    Dialog_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Dialog_CreateNew", Dialog_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFDialog.cpp
//******************************************************************************************