//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// LabelBox functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// LabelBox::CopyFrom.
		//----------------------------------------------------------------------------------
		static int LabelBox_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				LabelBox * src = (LabelBox *) ControlToCopy;

				if(Controls.size() > 0)
				{
					LabelBox * dst = (LabelBox *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}
		
	//**************************************************************************************
	// ITextControl functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// LabelBox::UpdateWidth.
		//----------------------------------------------------------------------------------
		static int LabelBox_UpdateWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->UpdateWidth();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_UpdateWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetAlignment.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);

				switch(aux->GetAlignment())
				{
				case Left:
					lua_pushstring(L, "Left");
					break;
					
				case Center:
					lua_pushstring(L, "Center");
					break;
					
				case Right:
					lua_pushstring(L, "Right");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetAlignment'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetText.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushstring(L, aux->GetText());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetText'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetFont.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushlightuserdata(L, aux->GetFont());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetFont'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetFontHeight.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetFontHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetFontHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetFontHeight'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetMaxWidth.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetMaxWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetMaxWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetMaxWidth'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetWidthLastLine.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetWidthLastLine (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetWidthLastLine());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetWidthLastLine'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetMinNumLines.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetMinNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetMinNumLines());
			}
			else if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					lua_pushnumber(L, aux->GetMinNumLines(lua_tointeger(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_GetMinNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetMinNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::GetMaxNumLines.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetMaxNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(LabelBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else if(numargs == 5)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) && lua_isnumber(L, 5))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(LabelBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux, lua_tointeger(L, 5)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetMaxNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::SetAlignment.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);

					if(strcmp(lua_tostring(L, 1), "Left") == STR_EQU)
						aux->SetAlignment(Left);
					else if(strcmp(lua_tostring(L, 1), "Center") == STR_EQU)
						aux->SetAlignment(Center);
					else if(strcmp(lua_tostring(L, 1), "Right") == STR_EQU)
						aux->SetAlignment(Right);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetAlignment(Left);
						break;
						
					case 1:
						aux->SetAlignment(Center);
						break;
						
					case 2:
						aux->SetAlignment(Right);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetAlignment'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetAlignment'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::SetFont.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetFont(appLuaRef->Resources.GetFont(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetFont'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetFont'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetText.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetText'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// LabelBox::AddText.
		//----------------------------------------------------------------------------------
		static int LabelBox_AddText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->AddText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_AddText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_AddText'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Box functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// LabelBox::UpdateRects.
		//----------------------------------------------------------------------------------
		static int LabelBox_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetX.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetX'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetY.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetY'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetWidth.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetHeight.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetRect.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(LabelBox, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// LabelBox::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int LabelBox_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetFocus.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetName.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetX.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetY.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetWidth.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetHeight.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetAppearance.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetBackColor.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetPicture.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetEnable.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetVisible.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetTransparency.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::GetType.
		//----------------------------------------------------------------------------------
		static int LabelBox_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetName.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetName'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetAppearance.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetBackColor.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetPicture.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(LabelBox, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetEnable.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetVisible.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// LabelBox::SetTransparency.
		//----------------------------------------------------------------------------------
		static int LabelBox_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(LabelBox, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'LabelBox_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// LabelBox::CreateNew.
		//----------------------------------------------------------------------------------
		static int LabelBox_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				LabelBox * aux = new LabelBox();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'LabelBox_CreateNew'.");
				lua_error(L);
			}

			return 0;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFLabelBox (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// LabelBox functions.
			//------------------------------------------------------------------------------
			lua_register(L, "LabelBox_CopyFrom", LabelBox_CopyFrom);

			//------------------------------------------------------------------------------
			// ITextControl functions.
			//------------------------------------------------------------------------------
			lua_register(L, "LabelBox_UpdateWidth",      LabelBox_UpdateWidth);
			lua_register(L, "LabelBox_GetAlignment",     LabelBox_GetAlignment);
			lua_register(L, "LabelBox_GetText",          LabelBox_GetText);
			lua_register(L, "LabelBox_GetFont",          LabelBox_GetFont);
			lua_register(L, "LabelBox_GetFontHeight",    LabelBox_GetFontHeight);
			lua_register(L, "LabelBox_GetMaxWidth",      LabelBox_GetMaxWidth);
			lua_register(L, "LabelBox_GetWidthLastLine", LabelBox_GetWidthLastLine);
			lua_register(L, "LabelBox_GetMinNumLines",   LabelBox_GetMinNumLines);
			lua_register(L, "LabelBox_GetMaxNumLines",   LabelBox_GetMaxNumLines);
			lua_register(L, "LabelBox_SetAlignment",     LabelBox_SetAlignment);
			lua_register(L, "LabelBox_SetFont",          LabelBox_SetFont);
			lua_register(L, "LabelBox_SetText",          LabelBox_SetText);
			lua_register(L, "LabelBox_AddText",          LabelBox_AddText);

			//------------------------------------------------------------------------------
			// Box functions.
			//------------------------------------------------------------------------------
			lua_register(L, "LabelBox_UpdateRects", LabelBox_UpdateRects);
			lua_register(L, "LabelBox_SetX",        LabelBox_SetX);
			lua_register(L, "LabelBox_SetY",        LabelBox_SetY);
			lua_register(L, "LabelBox_SetWidth",    LabelBox_SetWidth);
			lua_register(L, "LabelBox_SetHeight",   LabelBox_SetHeight);
			lua_register(L, "LabelBox_SetRect",     LabelBox_SetRect);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "LabelBox_IsCursorOver",       LabelBox_IsCursorOver);
			lua_register(L, "LabelBox_GetFocus",           LabelBox_GetFocus);
			lua_register(L, "LabelBox_SetKeyDown",         LabelBox_SetKeyDown);
			lua_register(L, "LabelBox_SetKeyUp",           LabelBox_SetKeyUp);
			lua_register(L, "LabelBox_SetMouseMotion",     LabelBox_SetMouseMotion);
			lua_register(L, "LabelBox_SetMouseButtonDown", LabelBox_SetMouseButtonDown);
			lua_register(L, "LabelBox_SetMouseButtonUp",   LabelBox_SetMouseButtonUp);
			lua_register(L, "LabelBox_GetName",            LabelBox_GetName);
			lua_register(L, "LabelBox_GetX",               LabelBox_GetX);
			lua_register(L, "LabelBox_GetY",               LabelBox_GetY);
			lua_register(L, "LabelBox_GetWidth",           LabelBox_GetWidth);
			lua_register(L, "LabelBox_GetHeight",          LabelBox_GetHeight);
			lua_register(L, "LabelBox_GetBackStyle",       LabelBox_GetBackStyle);
			lua_register(L, "LabelBox_GetAppearance",      LabelBox_GetAppearance);
			lua_register(L, "LabelBox_GetBackColor",       LabelBox_GetBackColor);
			lua_register(L, "LabelBox_GetPicture",         LabelBox_GetPicture);
			lua_register(L, "LabelBox_GetMousePointer",    LabelBox_GetMousePointer);
			lua_register(L, "LabelBox_GetEnable",          LabelBox_GetEnable);
			lua_register(L, "LabelBox_GetVisible",         LabelBox_GetVisible);
			lua_register(L, "LabelBox_GetTransparency",    LabelBox_GetTransparency);
			lua_register(L, "LabelBox_GetType",            LabelBox_GetType);
			lua_register(L, "LabelBox_SetName",            LabelBox_SetName);
			lua_register(L, "LabelBox_SetBackStyle",       LabelBox_SetBackStyle);
			lua_register(L, "LabelBox_SetAppearance",      LabelBox_SetAppearance);
			lua_register(L, "LabelBox_SetBackColor",       LabelBox_SetBackColor);
			lua_register(L, "LabelBox_SetPicture",         LabelBox_SetPicture);
			lua_register(L, "LabelBox_SetMousePointer",    LabelBox_SetMousePointer);
			lua_register(L, "LabelBox_SetEnable",          LabelBox_SetEnable);
			lua_register(L, "LabelBox_SetVisible",         LabelBox_SetVisible);
			lua_register(L, "LabelBox_SetTransparency",    LabelBox_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "LabelBox_CreateNew", LabelBox_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFLabelBox.cpp
//******************************************************************************************