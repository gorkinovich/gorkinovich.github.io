//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_LUAFHEADER_H_
#define _MOTOKO_LUAFHEADER_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Application.h"
//******************************************************************************************
// Macros
//******************************************************************************************
#define GetControlsTop(type, var) type * var = (type *) Controls.top()
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// Global variables of the Lua section.
	//**************************************************************************************

		extern Application * appLuaRef;

		extern stack<Control *> Controls;
		extern stack<Control *> LostControls;

		extern Control * ControlToCopy;


	/**
	 * \defgroup LuaEventFunctions Lua event functions
	 */
	/*@{*/

	//**************************************************************************************
	// Event functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		/// Key up event function
		/**
		 *  function \%ControlName\%_KeyUpEvent(scancode, sym, mod)<br>
		 *  &nbsp;&nbsp;&nbsp;-- Code of the function<br>
		 *  end
		 */
		//----------------------------------------------------------------------------------
		bool SDLKeyUpEvent (void * control, SDL_KeyboardEvent & event);

		//----------------------------------------------------------------------------------
		/// Key down event function
		/**
		 *  function \%ControlName\%_KeyDownEvent(scancode, sym, mod)<br>
		 *  &nbsp;&nbsp;&nbsp;-- Code of the function<br>
		 *  end
		 */
		//----------------------------------------------------------------------------------
		bool SDLKeyDownEvent (void * control, SDL_KeyboardEvent & event);

		//----------------------------------------------------------------------------------
		/// Mouse motion event function
		/**
		 *  function \%ControlName\%_MouseMotionEvent(state, mousex, mousey, mousexrel, mouseyrel)<br>
		 *  &nbsp;&nbsp;&nbsp;-- Code of the function<br>
		 *  end
		 */
		//----------------------------------------------------------------------------------
		bool SDLMouseMotionEvent (void * control, SDL_MouseMotionEvent & event);

		//----------------------------------------------------------------------------------
		/// Mouse button up event function
		/**
		 *  function \%ControlName\%_MouseButtonUpEvent(button, mousex, mousey)<br>
		 *  &nbsp;&nbsp;&nbsp;-- Code of the function<br>
		 *  end
		 */
		//----------------------------------------------------------------------------------
		void SDLMouseButtonUpEvent (void * control, SDL_MouseButtonEvent & event);

		//----------------------------------------------------------------------------------
		/// Mouse button down event function
		/**
		 *  function \%ControlName\%_MouseButtonDownEvent(button, mousex, mousey)<br>
		 *  &nbsp;&nbsp;&nbsp;-- Code of the function<br>
		 *  end
		 */
		//----------------------------------------------------------------------------------
		void SDLMouseButtonDownEvent (void * control, SDL_MouseButtonEvent & event);

		//----------------------------------------------------------------------------------
		/// Double click event function
		/**
		 *  function \%ControlName\%_DoubleClickEvent()<br>
		 *  &nbsp;&nbsp;&nbsp;-- Code of the function<br>
		 *  end
		 */
		//----------------------------------------------------------------------------------
		void SDLDoubleClickEvent (void * control);
		
	/*@}*/
	}
}
//******************************************************************************************
#endif
//******************************************************************************************
// LuaFHeader.h
//******************************************************************************************