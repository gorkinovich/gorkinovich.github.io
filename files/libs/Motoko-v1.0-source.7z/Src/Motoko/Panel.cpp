//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Panel.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  Panel constructor.
	 */
	//--------------------------------------------------------------------------------------
	Panel::Panel () : Container()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Panel";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Panel constructor.
	 */
	//--------------------------------------------------------------------------------------
	Panel::Panel (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
				  Uint32 backcolor, ControlSkin * appearance, SDL_Surface * picture,
				  SDL_Surface * mousepointer, bool transparency, bool enable,
				  bool visible) :
		Container(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
				  transparency, enable, visible)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Panel";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Panel copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	Panel::Panel (const Panel & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Panel operator =.
	 */
	//--------------------------------------------------------------------------------------
	Panel & Panel::operator = (const Panel & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Container destructor.
	 */
	//--------------------------------------------------------------------------------------
	Panel::~Panel ()
	{
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	Panel & Panel::CopyFrom (const Panel & obj)
	{
		Container::CopyFrom(obj);

		return (*this);
	}
	
	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void Panel::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		//----------------------------------------------------------------------------------
		// If the panel isn't transparent, we'll fill the control with the back color. And
		// if Picture have a surface pointed, we'll draw it.
		//----------------------------------------------------------------------------------
		if(Transparency == false)
			SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

		if(Picture != NULL)
			BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);

		//----------------------------------------------------------------------------------
		// After draw the panel, we'll draw the controls inside the panel.
		//----------------------------------------------------------------------------------
		for(int i = List.GetSize() - 1; i >= 0 ; --i)
		{
			List.GetControl(i)->Draw();
		}
	}
	
	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool Panel::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		//----------------------------------------------------------------------------------
		// If the panel is active, we'll update every control in the panel. And if one
		// control of the panel catch an event, we'll return true.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.GetSize(); ++i)
		{
			if(List.GetControl(i)->Update(event))
			{
				return true;
			}
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}
}
//******************************************************************************************
// Panel.cpp
//******************************************************************************************