//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Box.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  Box constructor.
	 */
	//--------------------------------------------------------------------------------------
	Box::Box () : Control()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Box";

		for(int i = 0; i < MAX_BOX_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}
		
		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Box constructor.
	 */
	//--------------------------------------------------------------------------------------
	Box::Box (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
			  Uint32 backcolor, ControlSkin * appearance, SDL_Surface * picture,
			  SDL_Surface * mousepointer, bool transparency, bool enable, bool visible) :
		Control(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
				transparency, enable, visible)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Box";
		
		for(int i = 0; i < MAX_BOX_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}
		
		Rects[CENTER_BOX_RECT] = Rect;
		
		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Box copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	Box::Box (const Box & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Box operator =.
	 */
	//--------------------------------------------------------------------------------------
	Box & Box::operator = (const Box & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Box destructor.
	 */
	//--------------------------------------------------------------------------------------
	Box::~Box ()
	{
	}
	
	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void Box::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we check if the control have any correct skin.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_BOX_RECTS))
		{
			return;
		}

		//----------------------------------------------------------------------------------
		// Second we calculate the width and the height of the center rect.
		//----------------------------------------------------------------------------------
		int w = Rect.w - Appearance->Rects[0].w - Appearance->Rects[2].w;
		int h = Rect.h - Appearance->Rects[0].h - Appearance->Rects[6].h;

		if(w < 0) w = 1;
		if(h < 0) h = 1;

		//----------------------------------------------------------------------------------
		// And third we calculate each rect of the final appearance of the box.
		//----------------------------------------------------------------------------------
		Rects[0].x = Rect.x;
		Rects[0].y = Rect.y;
		Rects[0].w = Appearance->Rects[0].w;
		Rects[0].h = Appearance->Rects[0].h;

		Rects[1].x = Rects[0].x + Rects[0].w;
		Rects[1].y = Rect.y;
		Rects[1].w = w;
		Rects[1].h = Appearance->Rects[1].h;
		
		Rects[2].x = Rects[1].x + Rects[1].w;
		Rects[2].y = Rect.y;
		Rects[2].w = Appearance->Rects[2].w;
		Rects[2].h = Appearance->Rects[2].h;

		
		Rects[3].x = Rects[0].x;
		Rects[3].y = Rects[0].y + Rects[0].h;
		Rects[3].w = Appearance->Rects[3].w;
		Rects[3].h = h;
		
		Rects[4].x = Rects[1].x;
		Rects[4].y = Rects[3].y;
		Rects[4].w = w;
		Rects[4].h = h;
		
		Rects[5].x = Rects[2].x;
		Rects[5].y = Rects[3].y;
		Rects[5].w = Appearance->Rects[5].w;
		Rects[5].h = h;

		
		Rects[6].x = Rects[0].x;
		Rects[6].y = Rects[3].y + Rects[3].h;
		Rects[6].w = Appearance->Rects[6].w;
		Rects[6].h = Appearance->Rects[6].h;
		
		Rects[7].x = Rects[1].x;
		Rects[7].y = Rects[6].y;
		Rects[7].w = w;
		Rects[7].h = Appearance->Rects[7].h;
		
		Rects[8].x = Rects[2].x;
		Rects[8].y = Rects[6].y;
		Rects[8].w = Appearance->Rects[8].w;
		Rects[8].h = Appearance->Rects[8].h;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	Box & Box::CopyFrom (const Box & obj)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Control::CopyFrom(obj);

		for(int i = 0; i < MAX_BOX_RECTS; ++i)
		{
			Rects[i] = obj.Rects[i];
		}

		return (*this);
	}
}
//******************************************************************************************
// Box.cpp
//******************************************************************************************