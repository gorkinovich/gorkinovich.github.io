//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// HScrollBar functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// HScrollBar::CopyFrom.
		//----------------------------------------------------------------------------------
		static int HScrollBar_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				HScrollBar * src = (HScrollBar *) ControlToCopy;

				if(Controls.size() > 0)
				{
					HScrollBar * dst = (HScrollBar *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::UpdateButton.
		//----------------------------------------------------------------------------------
		static int HScrollBar_UpdateButton (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->UpdateButton();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_UpdateButton'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::UpdateRects.
		//----------------------------------------------------------------------------------
		static int HScrollBar_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::GetButtonLeft.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetButtonLeft (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				Controls.push(aux->GetButtonLeft());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetButtonLeft'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::GetButtonCenter.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetButtonCenter (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				Controls.push(aux->GetButtonCenter());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetButtonCenter'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::GetButtonRight.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetButtonRight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				Controls.push(aux->GetButtonRight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetButtonRight'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetName.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetName'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// ScrollBar functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// HScrollBar::GetLargeChange.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetLargeChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetLargeChange());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetLargeChange'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::GetSmallChange.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetSmallChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetSmallChange());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetSmallChange'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::GetMax.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetMax (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetMax());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetMax'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::GetMin.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetMin (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetMin());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetMin'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::GetValue.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetValue (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetValue());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetValue'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetLargeChange.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetLargeChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetLargeChange(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetLargeChange'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetLargeChange'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetSmallChange.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetSmallChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetSmallChange(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetSmallChange'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetSmallChange'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetMax.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetMax (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetMax(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetMax'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetMax'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetMin.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetMin (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetMin(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetMin'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetMin'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetValue.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetValue (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetValue(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetValue'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetValue'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetAppearance.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 4)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) && lua_isstring(L, 4))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 3), lua_tostring(L, 4)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 3)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 3)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetX.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetX'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetY.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetY'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetWidth.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetHeight.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetRect.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(HScrollBar, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(HScrollBar, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// HScrollBar::SetBackColor.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// HScrollBar::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int HScrollBar_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetFocus.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetName.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetX.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetY.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetWidth.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetHeight.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetAppearance.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetBackColor.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetPicture.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetEnable.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetVisible.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetTransparency.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::GetType.
		//----------------------------------------------------------------------------------
		static int HScrollBar_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetPicture.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(HScrollBar, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetEnable.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetVisible.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// HScrollBar::SetTransparency.
		//----------------------------------------------------------------------------------
		static int HScrollBar_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(HScrollBar, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'HScrollBar_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// HScrollBar::CreateNew.
		//----------------------------------------------------------------------------------
		static int HScrollBar_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				HScrollBar * aux = new HScrollBar();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'HScrollBar_CreateNew'.");
				lua_error(L);
			}

			return 0;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFHScrollBar (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// HScrollBar functions.
			//------------------------------------------------------------------------------
			lua_register(L, "HScrollBar_CopyFrom",        HScrollBar_CopyFrom);
			lua_register(L, "HScrollBar_UpdateButton",    HScrollBar_UpdateButton);
			lua_register(L, "HScrollBar_UpdateRects",     HScrollBar_UpdateRects);
			lua_register(L, "HScrollBar_GetButtonLeft",   HScrollBar_GetButtonLeft);
			lua_register(L, "HScrollBar_GetButtonCenter", HScrollBar_GetButtonCenter);
			lua_register(L, "HScrollBar_GetButtonRight",  HScrollBar_GetButtonRight);
			lua_register(L, "HScrollBar_SetName",         HScrollBar_SetName);

			//------------------------------------------------------------------------------
			// ScrollBar functions.
			//------------------------------------------------------------------------------
			lua_register(L, "HScrollBar_GetLargeChange", HScrollBar_GetLargeChange);
			lua_register(L, "HScrollBar_GetSmallChange", HScrollBar_GetSmallChange);
			lua_register(L, "HScrollBar_GetMax",         HScrollBar_GetMax);
			lua_register(L, "HScrollBar_GetMin",         HScrollBar_GetMin);
			lua_register(L, "HScrollBar_GetValue",       HScrollBar_GetValue);
			lua_register(L, "HScrollBar_SetLargeChange", HScrollBar_SetLargeChange);
			lua_register(L, "HScrollBar_SetSmallChange", HScrollBar_SetSmallChange);
			lua_register(L, "HScrollBar_SetMax",         HScrollBar_SetMax);
			lua_register(L, "HScrollBar_SetMin",         HScrollBar_SetMin);
			lua_register(L, "HScrollBar_SetValue",       HScrollBar_SetValue);
			lua_register(L, "HScrollBar_SetAppearance",  HScrollBar_SetAppearance);
			lua_register(L, "HScrollBar_SetX",           HScrollBar_SetX);
			lua_register(L, "HScrollBar_SetY",           HScrollBar_SetY);
			lua_register(L, "HScrollBar_SetWidth",       HScrollBar_SetWidth);
			lua_register(L, "HScrollBar_SetHeight",      HScrollBar_SetHeight);
			lua_register(L, "HScrollBar_SetRect",        HScrollBar_SetRect);
			lua_register(L, "HScrollBar_SetBackStyle",   HScrollBar_SetBackStyle);
			lua_register(L, "HScrollBar_SetBackColor",   HScrollBar_SetBackColor);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "HScrollBar_IsCursorOver",       HScrollBar_IsCursorOver);
			lua_register(L, "HScrollBar_GetFocus",           HScrollBar_GetFocus);
			lua_register(L, "HScrollBar_SetKeyDown",         HScrollBar_SetKeyDown);
			lua_register(L, "HScrollBar_SetKeyUp",           HScrollBar_SetKeyUp);
			lua_register(L, "HScrollBar_SetMouseMotion",     HScrollBar_SetMouseMotion);
			lua_register(L, "HScrollBar_SetMouseButtonDown", HScrollBar_SetMouseButtonDown);
			lua_register(L, "HScrollBar_SetMouseButtonUp",   HScrollBar_SetMouseButtonUp);
			lua_register(L, "HScrollBar_GetName",            HScrollBar_GetName);
			lua_register(L, "HScrollBar_GetX",               HScrollBar_GetX);
			lua_register(L, "HScrollBar_GetY",               HScrollBar_GetY);
			lua_register(L, "HScrollBar_GetWidth",           HScrollBar_GetWidth);
			lua_register(L, "HScrollBar_GetHeight",          HScrollBar_GetHeight);
			lua_register(L, "HScrollBar_GetBackStyle",       HScrollBar_GetBackStyle);
			lua_register(L, "HScrollBar_GetAppearance",      HScrollBar_GetAppearance);
			lua_register(L, "HScrollBar_GetBackColor",       HScrollBar_GetBackColor);
			lua_register(L, "HScrollBar_GetPicture",         HScrollBar_GetPicture);
			lua_register(L, "HScrollBar_GetMousePointer",    HScrollBar_GetMousePointer);
			lua_register(L, "HScrollBar_GetEnable",          HScrollBar_GetEnable);
			lua_register(L, "HScrollBar_GetVisible",         HScrollBar_GetVisible);
			lua_register(L, "HScrollBar_GetTransparency",    HScrollBar_GetTransparency);
			lua_register(L, "HScrollBar_GetType",            HScrollBar_GetType);
			lua_register(L, "HScrollBar_SetPicture",         HScrollBar_SetPicture);
			lua_register(L, "HScrollBar_SetMousePointer",    HScrollBar_SetMousePointer);
			lua_register(L, "HScrollBar_SetEnable",          HScrollBar_SetEnable);
			lua_register(L, "HScrollBar_SetVisible",         HScrollBar_SetVisible);
			lua_register(L, "HScrollBar_SetTransparency",    HScrollBar_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "HScrollBar_CreateNew", HScrollBar_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFHScrollBar.cpp
//******************************************************************************************