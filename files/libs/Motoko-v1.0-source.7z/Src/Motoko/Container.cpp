//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Container.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  Container constructor.
	 */
	//--------------------------------------------------------------------------------------
	Container::Container () : Control()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Container";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Container constructor.
	 */
	//--------------------------------------------------------------------------------------
	Container::Container (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
						  Uint32 backcolor, ControlSkin * appearance, SDL_Surface * picture,
						  SDL_Surface * mousepointer, bool transparency, bool enable,
						  bool visible) :
		Control(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
				transparency, enable, visible)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Container";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Container copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	Container::Container (const Container & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Container operator =.
	 */
	//--------------------------------------------------------------------------------------
	Container & Container::operator = (const Container & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Container destructor.
	 */
	//--------------------------------------------------------------------------------------
	Container::~Container ()
	{
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		List.Free();
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	Container & Container::CopyFrom (const Container & obj)
	{
		Control::CopyFrom(obj);

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		List = obj.List;

		return (*this);
	}
	
	//--------------------------------------------------------------------------------------
	/// This function update the controls of the container.
	//--------------------------------------------------------------------------------------
	void Container::UpdateIncX (Sint16 inc)
	{
		//----------------------------------------------------------------------------------
		// This function updates each x coordinate of the controls of the container.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.GetSize(); ++i)
		{
			List.GetControl(i)->SetX(List.GetControl(i)->GetX() + inc);
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function update the controls of the container.
	//--------------------------------------------------------------------------------------
	void Container::UpdateIncY (Sint16 inc)
	{
		//----------------------------------------------------------------------------------
		// This function updates each y coordinate of the controls of the container.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.GetSize(); ++i)
		{
			List.GetControl(i)->SetY(List.GetControl(i)->GetY() + inc);
		}
	}

	//--------------------------------------------------------------------------------------
	// Get the mouse pointer of the control.
	//--------------------------------------------------------------------------------------
	SDL_Surface * Container::GetMousePointer (void)
	{
		//----------------------------------------------------------------------------------
		// This function is to obtain the MousePointer of the control that is under the
		// mouse cursor. To make this posible we check if the cursor is over for all the
		// controls inside the container. If the cursor is over one control, we will return
		// the MousePointer of that control.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.GetSize(); ++i)
		{
			if(List.GetControl(i)->IsCursorOver())
			{
				return List.GetControl(i)->GetMousePointer();
			}
		}

		//----------------------------------------------------------------------------------
		// If there isn't any control, under the mouse cursor, we return the MousePointer
		// of the actual container.
		//----------------------------------------------------------------------------------
		return MousePointer;
	}
	
	//--------------------------------------------------------------------------------------
	// Add a control in the container.
	//--------------------------------------------------------------------------------------
	int Container::AddControl (Control * control)
	{
		//----------------------------------------------------------------------------------
		// This function adds a control inside the container, but dialogs are not allowed
		// to be added inside a container. Why? Because I think it can't be usefull to put
		// one dialog inside other dialog, or things more bizarre.
		//----------------------------------------------------------------------------------
		if(strcmp(control->GetType(), "Dialog") != STR_EQU)
			return List.AddControl(control);
		else
			return LISTCONTROLS_ERROR_BADTYPE;
	}

	
	//--------------------------------------------------------------------------------------
	// Add a control in the container.
	//--------------------------------------------------------------------------------------
	int Container::AddControlRel (Control * control)
	{
		//----------------------------------------------------------------------------------
		// This function is to add a control with a relatives coordinates to the container.
		// So if everything goes well, we will update the x and y coordinate of the control
		// according to the absolute coordinates of the screen.
		//----------------------------------------------------------------------------------
		if(strcmp(control->GetType(), "Dialog") != STR_EQU)
		{
			int error = List.AddControl(control);

			if(!error)
			{
				control->SetX(Rect.x + control->GetX());
				control->SetY(Rect.y + control->GetY());
			}

			return error;
		}
		//----------------------------------------------------------------------------------
		// If you try to add a dialog to the container, an error will be returned.
		//----------------------------------------------------------------------------------
		else
		{
			return LISTCONTROLS_ERROR_BADTYPE;
		}
	}
}
//******************************************************************************************
// Container.cpp
//******************************************************************************************