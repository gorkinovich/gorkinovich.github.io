//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../CheckButton.h"
//------------------------------------------------------------------------------------------
#define SEPARATION_WITH_CHECKTEXTURE 5
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  CheckButton constructor.
	 */
	//--------------------------------------------------------------------------------------
	CheckButton::CheckButton () : Control(), ITextControl()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "CheckButton";

		CheckRect = Rect;
		TextRect  = Rect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		PictureChecked = NULL;
		Value          = false;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  CheckButton constructor.
	 */
	//--------------------------------------------------------------------------------------
	CheckButton::CheckButton (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
							  Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
							  ControlSkin * appearance, SDL_Surface * picture,
							  SDL_Surface * mousepointer, AlignmentStyle alignment,
							  SDL_Surface * picturechecked, bool checked, bool transparency,
							  bool enable, bool visible) :
		Control(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
				transparency, enable, visible),
		ITextControl(text, font, alignment)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "CheckButton";

		CheckRect = Rect;
		TextRect  = Rect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		PictureChecked = picturechecked;
		Value          = checked;

		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  CheckButton copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	CheckButton::CheckButton (const CheckButton & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  CheckButton operator =.
	 */
	//--------------------------------------------------------------------------------------
	CheckButton & CheckButton::operator = (const CheckButton & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  CheckButton destructor.
	 */
	//--------------------------------------------------------------------------------------
	CheckButton::~CheckButton ()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		CheckRect.x = 0;
		CheckRect.y = 0;
		CheckRect.w = 0;
		CheckRect.h = 0;

		TextRect.x = 0;
		TextRect.y = 0;
		TextRect.w = 0;
		TextRect.h = 0;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		PictureChecked = NULL;
		Value          = false;
	}
	
	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void CheckButton::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// We set the area of the text, trying to find a way to center the text.
		//----------------------------------------------------------------------------------
		TextRect = Rect;

		if(Font != NULL)
		{
			TextRect.y += ((Rect.h - Font->GetSurface()->h) / 2);
			TextRect.h -= ((Rect.h - Font->GetSurface()->h) / 2);
		}

		//----------------------------------------------------------------------------------
		// We must check if the control have any correct skin.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_CHECKBUTTON_RECTS))
		{
			CheckRect = Rect;
			return;
		}

		//----------------------------------------------------------------------------------
		// If we have an skin, we'll set the area of the check button.
		//----------------------------------------------------------------------------------
		CheckRect.x = Rect.x;
		CheckRect.y = Rect.y + (Rect.h - Appearance->Rects[0].h) / 2;
		CheckRect.w = Appearance->Rects[0].w;
		CheckRect.h = Appearance->Rects[0].h;

		//----------------------------------------------------------------------------------
		// And after that we must update the area of the text.
		//----------------------------------------------------------------------------------
		TextRect.x += (CheckRect.w + SEPARATION_WITH_CHECKTEXTURE);
		TextRect.w -= (CheckRect.w + SEPARATION_WITH_CHECKTEXTURE);
	}

	//--------------------------------------------------------------------------------------
	// This function draw the button in graphical mode.
	//--------------------------------------------------------------------------------------
	void CheckButton::DrawGraphical (void)
	{
		//----------------------------------------------------------------------------------
		// This function will paint the check button in the graphical mode, and not the
		// skinned mode. First we'll need to know the value, if it is true, we must to
		// paint the PictureChecked if we have one associated with the control.
		//----------------------------------------------------------------------------------
		if(Value)
		{
			if(PictureChecked != NULL)
				BlitWithResize(PictureChecked, NULL, CRM32Pro.screen, &Rect);
			else if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			else if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
		}
		//----------------------------------------------------------------------------------
		// If the value is false, we must paint the Picture.
		//----------------------------------------------------------------------------------
		else
		{
			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			else if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void CheckButton::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned button.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, we'll draw this in graphical mode.
			//------------------------------------------------------------------------------
			if(Appearance == NULL)
			{
				DrawGraphical();
			}
			//------------------------------------------------------------------------------
			// If we have a skin, we'll fill the rect with the back color, and we'll paint
			// the check button according to the value of the control.
			//------------------------------------------------------------------------------
			else
			{
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
				
				BlitWithResize(Appearance->Texture, &(Appearance->Rects[Value]),
							   CRM32Pro.screen, &CheckRect);
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, we'll fill with the back color the rect.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, we'll draw the check in graphical mode.
		//----------------------------------------------------------------------------------
		case UsePicture:
			DrawGraphical();
			break;
		}

		//----------------------------------------------------------------------------------
		// Finally we will draw the text of the control.
		//----------------------------------------------------------------------------------
		DrawText(CRM32Pro.screen, TextRect.y, &TextRect);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool CheckButton::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// If the user have pressed the left button of the mouse, over the check
				// button, we must to change the value of the control.
				//--------------------------------------------------------------------------
				if((event.button.button == SDL_BUTTON_LEFT) &&
				   (CheckRect.x <= CRM32Pro.mouse_x) && (CRM32Pro.mouse_x < CheckRect.x + CheckRect.w) &&
				   (CheckRect.y <= CRM32Pro.mouse_y) && (CRM32Pro.mouse_y < CheckRect.y + CheckRect.h))
				{
					Value = !Value;
				}

				//--------------------------------------------------------------------------
				// And if MouseButtonDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	CheckButton & CheckButton::CopyFrom (const CheckButton & obj)
	{
		Control::CopyFrom(obj);

		ITextControl::CopyFrom(obj);

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		CheckRect = obj.CheckRect;
		TextRect  = obj.TextRect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		PictureChecked = obj.PictureChecked;
		Value          = obj.Value;

		return (*this);
	}
}
//******************************************************************************************
// CheckButton.cpp
//******************************************************************************************