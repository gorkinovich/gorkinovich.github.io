//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Application.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define CLICK_RANGE 5
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	// Global static members of the Application class.
	//--------------------------------------------------------------------------------------
	Application * Application::Instance = NULL;

	//--------------------------------------------------------------------------------------
	/**
	 *  Application constructor.
	 */
	//--------------------------------------------------------------------------------------
	Application::Application ()
	{
		//----------------------------------------------------------------------------------
		// Properties.
		//----------------------------------------------------------------------------------
		MousePointer = NULL;

		Title = "";
		Icon  = "";

		RenderBack = true;

		Picture = NULL;
		ActRect = NULL;

		BackColor = 0x00000000;

		//----------------------------------------------------------------------------------
		// Events
		//----------------------------------------------------------------------------------
		KeyDown         = NULL;
		KeyUp           = NULL;
		MouseMotion     = NULL;
		MouseButtonDown = NULL;
		MouseButtonUp   = NULL;

		//----------------------------------------------------------------------------------
		// Logic.
		//----------------------------------------------------------------------------------
		ActiveControl = NULL;

		ActMousePointer = 0;

		MouseRect.x = 0;
		MouseRect.y = 0;
		MouseRect.w = 0;
		MouseRect.h = 0;

		LuaVM = NULL;

		Quit = false;

		DCState  = DOUBLECLICK_STATE_FIRSTCLICK;
		Interval = DOUBLECLICK_INTERVAL;

		Error = 0;

		IconSurface = NULL;

		Width  = 0;
		Height = 0;
	}

	//--------------------------------------------------------------------------------------
	/// Function to initialize the object Application.
	/**
	 *  @param title Title of the application.
	 *  @see Release().
	 *  @return If no error 0, else an error code.
	 */
	//--------------------------------------------------------------------------------------
	int Application::Init (const char * title)
	{
		//----------------------------------------------------------------------------------
		// Properties.
		//----------------------------------------------------------------------------------
		Title = title;
		Quit  = false;

		//----------------------------------------------------------------------------------
		// Log system.
		//----------------------------------------------------------------------------------
		ILogSystem.Init("application.log", LOG_FILE, LOG_NORMAL, (char *) title);

		//----------------------------------------------------------------------------------
		// Init CRM32Pro.
		//----------------------------------------------------------------------------------
		if(CRM32Pro.Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_TIMER) == SDLFAIL) 
		{
			ILogSystem.Msg(LOG_NORMAL, " � [ERROR] - Couldn�t initialize CRM32Pro: %s\n", SDL_GetError());
			return APPLICATION_ERROR_CRMINIT; 
		}

		//----------------------------------------------------------------------------------
		// Set video mode.
		//----------------------------------------------------------------------------------
		CRM32Pro.Config.Title = (char *) title;

		if(!CRM32Pro.SetVideoMode()) 
		{
			CRM32Pro.Quit();
			return APPLICATION_ERROR_SETVIDEOMODE;
		}

		Width  = CRM32Pro.Config.VideoWidth;
		Height = CRM32Pro.Config.VideoHeight;

		CRM32Pro.VideoInfo();

		//----------------------------------------------------------------------------------
		// Cursor.
		//----------------------------------------------------------------------------------
		ICursor->Init();

		//----------------------------------------------------------------------------------
		// Time system.
		//----------------------------------------------------------------------------------
		ITimeSystem->Init();

		//----------------------------------------------------------------------------------
		// Lua.
		//----------------------------------------------------------------------------------
		if(LuaVM == NULL)
		{
			LuaVM = lua_open();

			if(LuaVM == NULL)
			{
				ILogSystem.Msg(LOG_NORMAL, " � [ERROR] - Couldn�t init Lua.\n");
				return APPLICATION_ERROR_LUAOPEN;
			}

			luaL_openlibs(LuaVM);
			Lua::RegisterMotoko();
		}

		//----------------------------------------------------------------------------------
		// Mouse pointer.
		//----------------------------------------------------------------------------------
		MouseRect.x = CRM32Pro.mouse_x;
		MouseRect.y = CRM32Pro.mouse_y;

		//----------------------------------------------------------------------------------
		// Audio system.
		//----------------------------------------------------------------------------------
		if(ISoundFX->Init() == CRMFAIL)
		{
			ILogSystem.Msg(LOG_NORMAL, " � [ERROR] - Couldn�t init sound system: %s\n", SDL_GetError());
			return APPLICATION_ERROR_SOUNDINIT;
		}

		CRM32Pro.AudioInfo();

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	/// Function to initialize the object Application.
	/**
	 *  @param title     Title of the application.
	 *  @param w         Width of the application.
	 *  @param h         Height of the application.
	 *  @param bpp       Bits per pixel of the application.
	 *  @param window    Window mode activated (true) or fullscreen (false).
	 *  @param frequency Frequency of the audio system.
	 *  @param format    Format of the audio system.
	 *  @param nchannels Number of channels of the audio system.
	 *  @param chunksize Chunk size of the audio system.
	 *  @see Release().
	 *  @return If no error 0, else an error code.
	 */
	//--------------------------------------------------------------------------------------
	int Application::Init (const char * title, Uint16 w, Uint16 h, Uint8 bpp, bool window,
						   int frequency, int format, int nchannels, int chunksize)
	{
		CRM32Pro.Config.Title       = (char *) title;
		CRM32Pro.Config.VideoWidth  = w;
		CRM32Pro.Config.VideoHeight = h;
		CRM32Pro.Config.VideoBPP    = bpp;
		CRM32Pro.Config.VideoWindow = window;
		CRM32Pro.Config.AudioEnable = 1;
		CRM32Pro.Config.AudioFreq   = frequency;
		CRM32Pro.Config.AudioFormat = format;
		CRM32Pro.Config.AudioMode   = nchannels;
		CRM32Pro.Config.AudioBuffer = chunksize;

		return Init(title);
	}

	//--------------------------------------------------------------------------------------
	/// Function to initialize the object Application.
	/**
	 *  @param file    Path of the lua file.
	 *  @param fileDPF Container with the lua file.
	 *  @see Release().
	 *  @return If no error 0, else an error code.
	 */
	//--------------------------------------------------------------------------------------
	int Application::InitFromLua (const char * file, const char * fileDPF)
	{
		Error = EVERYTHING_ALL_RIGHT;

		//----------------------------------------------------------------------------------
		// Lua.
		//----------------------------------------------------------------------------------
		if(LuaVM == NULL)
		{
			LuaVM = lua_open();

			if(LuaVM == NULL)
			{
				ILogSystem.Msg(LOG_NORMAL, " � [ERROR] - Couldn�t init Lua.\n");
				return APPLICATION_ERROR_LUAOPEN;
			}

			luaL_openlibs(LuaVM);
			Lua::RegisterMotoko();
		}

		//----------------------------------------------------------------------------------
		// Here we will call a file with the start code.
		//----------------------------------------------------------------------------------
		if(fileDPF != NULL)
			Lua::ExecFile(file, fileDPF);
		else
			Lua::ExecFile(file);

		return Error;
	}
	
	//--------------------------------------------------------------------------------------
	/// Function to release the object Application.
	/**
	 *  @see Init().
	 */
	//--------------------------------------------------------------------------------------
	void Application::Release (void)
	{
		//----------------------------------------------------------------------------------
		// Objects release.
		//----------------------------------------------------------------------------------
		Skins.Free();
		List.Free();
		DialogList.Free();
		Resources.Free();
		
		Width  = 0;
		Height = 0;

		if(IconSurface != NULL)
		{
			CRM32Pro.FreeSurface(IconSurface);
		}
		
		//----------------------------------------------------------------------------------
		// Lua.
		//----------------------------------------------------------------------------------
		if(LuaVM != NULL)
		{
			lua_close(LuaVM);
			LuaVM = NULL;
		}

		//----------------------------------------------------------------------------------
		// CRM32Pro quit.
		//----------------------------------------------------------------------------------
		CRM32Pro.Quit();
	}
	
	//--------------------------------------------------------------------------------------
	/// Function to draw all the controls of the application.
	//--------------------------------------------------------------------------------------
	void Application::Draw (void)
	{
		int i;

		//----------------------------------------------------------------------------------
		// Here we check if the user want to paint the back of the application. But if you
		// need to paint the GUI over your game, set RenderBack to false.
		//----------------------------------------------------------------------------------
		if(RenderBack)
		{
			if(Picture == NULL)
			{
				SDL_FillRect(CRM32Pro.screen, NULL, BackColor);
			}
			else
			{
				BlitWithResize(Picture, ActRect, CRM32Pro.screen, NULL);
			}
		}

		//----------------------------------------------------------------------------------
		// After paint the back plane, now we have to paint the controls of the aplication.
		// we have to paint them from the last to the first, because the controls are
		// specially ordered inside the list of controls.
		//----------------------------------------------------------------------------------
		for(i = List.GetSize() - 1; i >= 0 ; --i)
		{
			List.GetControl(i)->Draw();
		}

		//----------------------------------------------------------------------------------
		// After paint the controls we will paint the dialogs.
		//----------------------------------------------------------------------------------
		for(i = DialogList.GetSize() - 1; i >= 0 ; --i)
		{
			DialogList.GetControl(i)->Draw();
		}

		//----------------------------------------------------------------------------------
		// And if we have any selected cursor from any control, we'll paint it. But if no
		// cursor from other control was select, we will paint the application's cursor.
		//----------------------------------------------------------------------------------
		if(ActMousePointer != NULL)
			SDL_BlitSurface(ActMousePointer, NULL, CRM32Pro.screen, &MouseRect);
		else if(MousePointer != NULL)
			SDL_BlitSurface(MousePointer, NULL, CRM32Pro.screen, &MouseRect);
	}

	//--------------------------------------------------------------------------------------
	/// Function to update all the controls of the application.
	//--------------------------------------------------------------------------------------
	bool Application::Update (void)
	{
		//----------------------------------------------------------------------------------
		// This function will update the state of all the controls inside the application.
		//----------------------------------------------------------------------------------
		int i;
		SDL_Event event;
		bool actaux = false;
		bool active = false;

		//----------------------------------------------------------------------------------
		// First if we are trying to make a double-click, but the time have passed, the
		// function will reset the state of the double-click algorithm.
		//----------------------------------------------------------------------------------
		if((DCState != DOUBLECLICK_STATE_FIRSTCLICK) && ((Time + Interval) < GetTime()))
		{
			DCState = DOUBLECLICK_STATE_FIRSTCLICK;
		}

		//----------------------------------------------------------------------------------
		// And after check the double-click issue, we'll check all the events inside the
		// SDL queue of events, to update the controls inside the application.
		//----------------------------------------------------------------------------------
		while(CRM32Pro.Update(&event))
		{
			//------------------------------------------------------------------------------
			// Each event we have, we will check if that event have been caught by any
			// control. If the event have been caught we'll set actaux to true, to stop
			// checking more controls for that event.
			//------------------------------------------------------------------------------
			actaux = false;

			switch(event.type)
			{
			//------------------------------------------------------------------------------
			// If the type of the evet is a quit event, we'll set Quit to true.
			//------------------------------------------------------------------------------
			case SDL_QUIT:
				Quit = true;
				break;

			//------------------------------------------------------------------------------
			// If we have an user event we'll take a look to two options.
			//------------------------------------------------------------------------------
			case SDL_USEREVENT:
				//--------------------------------------------------------------------------
				// The first option is an event asking to get the focus of the application.
				//--------------------------------------------------------------------------
				if(event.user.code == CONTROL_GET_FOCUS)
				{
					ActiveControl = (Control *) event.user.data1;
				}
				//--------------------------------------------------------------------------
				// The second option is that the user have make a double-click over the
				// application. In that case we'll check first in the list of dialogs, and
				// if no dialog catch the event, we'll check in the list of controls.
				//--------------------------------------------------------------------------
				else if(event.user.code == CONTROL_DOUBLECLICK)
				{
					for(i = 0; i < DialogList.GetSize(); ++i)
					{
						if(DialogList.GetControl(i)->Update(event))
						{
							actaux = true;
							active = true;
							break;
						}
					}

					if(actaux == false)
					{
						for(i = 0; i < List.GetSize(); ++i)
						{
							if(List.GetControl(i)->Update(event))
							{
								active = true;
								break;
							}
						}
					}
				}
				break;

			//------------------------------------------------------------------------------
			// Any other kind of events will be send here.
			//------------------------------------------------------------------------------
			default:
				//--------------------------------------------------------------------------
				// This variables are to store the position where the user make the first
				// click, to start the sequence of the double-click.
				//--------------------------------------------------------------------------
				static int xstart = 0;
				static int ystart = 0;

				switch(DCState)
				{
				//--------------------------------------------------------------------------
				// In the first state of the double-click algorithm, we'll check if the
				// user have make click with the left button of the mouse. If that is true
				// we'll get the actual time, we'll change the state of the algorithm, and
				// finally we'll get the coordinates of the mouse.
				//--------------------------------------------------------------------------
				case DOUBLECLICK_STATE_FIRSTCLICK:
					if((event.type == SDL_MOUSEBUTTONDOWN) &&
						(event.button.button == SDL_BUTTON_LEFT))
					{
						Time    = GetTime();
						DCState = DOUBLECLICK_STATE_FIRSTUP;

						xstart = event.button.x;
						ystart = event.button.y;
					}
					break;
					
				//--------------------------------------------------------------------------
				// In the second state, we'll check if the user have unpressed the left
				// button of the mouse. If that is true we'll check if the time inteval
				// have passed, and if the mouse haven't been moved from the start
				// coordinates of the mouse, to get to the next state.
				//--------------------------------------------------------------------------
				case DOUBLECLICK_STATE_FIRSTUP:
					if((event.type == SDL_MOUSEBUTTONUP) &&
						(event.button.button == SDL_BUTTON_LEFT))
					{
						if((Time + Interval) >= GetTime() &&
						   (xstart - CLICK_RANGE <= event.button.x) && (event.button.x <= xstart + CLICK_RANGE) &&
						   (ystart - CLICK_RANGE <= event.button.y) && (event.button.y <= ystart + CLICK_RANGE))
							DCState = DOUBLECLICK_STATE_SECONDCLICK;
						else
							DCState = DOUBLECLICK_STATE_FIRSTCLICK;
					}
					break;
					
				//--------------------------------------------------------------------------
				// In the third state of the double-click algorithm, we'll check if the
				// user have make click with the left mouse's button. If that is true we'll
				// check if the time inteval have passed, and if the mouse haven't been
				// moved from the start coordinates of the mouse, to get to the next state.
				//--------------------------------------------------------------------------
				case DOUBLECLICK_STATE_SECONDCLICK:
					if((event.type == SDL_MOUSEBUTTONDOWN) &&
						(event.button.button == SDL_BUTTON_LEFT))
					{
						if((Time + Interval) >= GetTime() &&
						   (xstart - CLICK_RANGE <= event.button.x) && (event.button.x <= xstart + CLICK_RANGE) &&
						   (ystart - CLICK_RANGE <= event.button.y) && (event.button.y <= ystart + CLICK_RANGE))
							DCState = DOUBLECLICK_STATE_SECONDUP;
						else
							DCState = DOUBLECLICK_STATE_FIRSTCLICK;
					}
					break;
					
				//--------------------------------------------------------------------------
				// In the fourth state, we'll check if the user have unpressed the left
				// button of the mouse. If that is true we'll check if the time inteval
				// have passed, and if the mouse haven't been moved from the start
				// coordinates of the mouse, to push finally a double-click in the queue.
				//--------------------------------------------------------------------------
				case DOUBLECLICK_STATE_SECONDUP:
					if((event.type == SDL_MOUSEBUTTONUP) &&
						(event.button.button == SDL_BUTTON_LEFT))
					{
						if((Time + Interval) >= GetTime() &&
						   (xstart - CLICK_RANGE <= event.button.x) && (event.button.x <= xstart + CLICK_RANGE) &&
						   (ystart - CLICK_RANGE <= event.button.y) && (event.button.y <= ystart + CLICK_RANGE))
						{
							SDL_Event auxevent;
						
							auxevent.type = SDL_USEREVENT;
							auxevent.user.code = CONTROL_DOUBLECLICK;
							auxevent.user.data1 = NULL;
							auxevent.user.data2 = NULL;
							SDL_PushEvent(&auxevent);
						}

						DCState = DOUBLECLICK_STATE_FIRSTCLICK;
					}
					break;

				//--------------------------------------------------------------------------
				// Any wrong state value will make to reset the algorithm.
				//--------------------------------------------------------------------------
				default:
					DCState = DOUBLECLICK_STATE_FIRSTCLICK;
				}

				//--------------------------------------------------------------------------
				// And after check the double-click algorithm, we'll update all the dialogs
				// in the application, setting actaux to true, if the event is caught.
				//--------------------------------------------------------------------------
				for(i = 0; i < DialogList.GetSize(); ++i)
				{
					if(DialogList.GetControl(i)->Update(event))
					{
						actaux = true;
						active = true;
						break;
					}
				}

				//--------------------------------------------------------------------------
				// If no event have been caught by any dialog, we'll update all the controls
				// in the application, setting actaux to true, if the event is caught.
				//--------------------------------------------------------------------------
				if(actaux == false)
				{
					for(i = 0; i < List.GetSize(); ++i)
					{
						if(List.GetControl(i)->Update(event))
						{
							actaux = true;
							active = true;
							break;
						}
					}
				}

				//--------------------------------------------------------------------------
				// If no event have been caught, we'll update the application object. And
				// if the event is a mouse's button pressed, we set no active control.
				//--------------------------------------------------------------------------
				if(actaux == false)
				{
					switch(event.type)
					{
					case SDL_MOUSEBUTTONDOWN:
						if(event.button.button == SDL_BUTTON_LEFT)
							NoActiveControl();

						if(MouseButtonDown != NULL)
							MouseButtonDown((void *) this, event.button);
						break;
						
					case SDL_MOUSEBUTTONUP:
						if(MouseButtonUp != NULL)
							MouseButtonUp((void *) this, event.button);
						break;

					case SDL_MOUSEMOTION:
						if(MouseMotion != NULL)
							MouseMotion((void *) this, event.motion);
						break;

					case SDL_KEYDOWN:
						if(KeyDown != NULL)
							KeyDown((void *) this, event.key);
						break;

					case SDL_KEYUP:
						if(KeyUp != NULL)
							KeyUp((void *) this, event.key);
						break;
					}
				}
			}
		}
		
		//----------------------------------------------------------------------------------
		// After update the controls, we take the coordinates of the mouse.
		//----------------------------------------------------------------------------------
		MouseRect.x = CRM32Pro.mouse_x;
		MouseRect.y = CRM32Pro.mouse_y;
		
		//----------------------------------------------------------------------------------
		// And we will check if we are over any control, with a diferent mouse pointer than
		// the current one of the application, to change it.
		//----------------------------------------------------------------------------------
		ActMousePointer = NULL;
		
		for(i = 0; i < DialogList.GetSize(); ++i)
		{
			if(DialogList.GetControl(i)->IsCursorOver())
			{
				ActMousePointer = DialogList.GetControl(i)->GetMousePointer();
				return active;
			}
		}

		//----------------------------------------------------------------------------------
		// If after try into the dialogs, we don't find any mouse pointer, we'll try into
		// the list of controls of the application.
		//----------------------------------------------------------------------------------
		for(i = 0; i < List.GetSize(); ++i)
		{
			if(List.GetControl(i)->IsCursorOver())
			{
				ActMousePointer = List.GetControl(i)->GetMousePointer();
				break;
			}
		}

		//----------------------------------------------------------------------------------
		// At the end we will return the value of active, if that value is true, some
		// control have caught at least one event.
		//----------------------------------------------------------------------------------
		return active;
	}

	//--------------------------------------------------------------------------------------
	/// Function to push up a dialog in the application.
	//--------------------------------------------------------------------------------------
	void Application::PushUpDialog (const Dialog * dialog)
	{
		//----------------------------------------------------------------------------------
		// This function bring to the top of the screen a selected dialog.
		//----------------------------------------------------------------------------------
		if(DialogList.GetControl(0) == (Control *) dialog) return;

		//----------------------------------------------------------------------------------
		// We save the current dialog in an aux variable.
		//----------------------------------------------------------------------------------
		Dialog * aux = (Dialog *) dialog;

		//----------------------------------------------------------------------------------
		// And seek the position of this dialog, to inter-change the first position, with
		// the currect selected dialog.
		//----------------------------------------------------------------------------------
		for(int i = 1; i < DialogList.GetSize(); ++i)
		{
			if(DialogList.GetControl(i) == (Control *) dialog)
			{
				DialogList.SetControl(i, DialogList.GetControl(0));
				DialogList.SetControl(0, aux);
				break;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	/// Function to obtain the instance of Application.
	//--------------------------------------------------------------------------------------
	Application * Application::GetInstance (void)
	{
		//----------------------------------------------------------------------------------
		// If the object haven't been created we create a new one.
		//----------------------------------------------------------------------------------
		if(Application::Instance == NULL)
			Application::Instance = new Application();

		//----------------------------------------------------------------------------------
		// And we return the instance of this singleton class.
		//----------------------------------------------------------------------------------
		return Application::Instance;
	}
}
//******************************************************************************************
// Application.cpp
//******************************************************************************************