//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../VScrollBar.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  VScrollBar constructor.
	 */
	//--------------------------------------------------------------------------------------
	VScrollBar::VScrollBar () : ScrollBar()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "VScrollBar";

		string aux;

		aux = Name + "_Up";     Button01->SetName(aux.c_str());
		aux = Name + "_Center"; Button02->SetName(aux.c_str());
		aux = Name + "_Down";   Button03->SetName(aux.c_str());

		Button01->SetArrow(UpArrow);
		Button03->SetArrow(DownArrow);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  VScrollBar constructor.
	 */
	//--------------------------------------------------------------------------------------
	VScrollBar::VScrollBar (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
							Uint32 backcolor, ControlSkin * appearance, int min, int max,
							int value, int large, int small, SDL_Surface * picture,
							SDL_Surface * mousepointer, bool transparency, bool enable,
							bool visible) :
		ScrollBar(name, rect, backstyle, backcolor, appearance, min, max, value, large,
				  small, picture, mousepointer, transparency, enable, visible)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "VScrollBar";

		string aux;

		aux = Name + "_Up";     Button01->SetName(aux.c_str());
		aux = Name + "_Center"; Button02->SetName(aux.c_str());
		aux = Name + "_Down";   Button03->SetName(aux.c_str());

		Button01->SetArrow(UpArrow);
		Button03->SetArrow(DownArrow);

		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  VScrollBar copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	VScrollBar::VScrollBar (const VScrollBar & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  VScrollBar operator =.
	 */
	//--------------------------------------------------------------------------------------
	VScrollBar & VScrollBar::operator = (const VScrollBar & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  VScrollBar destructor.
	 */
	//--------------------------------------------------------------------------------------
	VScrollBar::~VScrollBar ()
	{
	}

	//--------------------------------------------------------------------------------------
	/// This function update the center button in the actual object.
	//--------------------------------------------------------------------------------------
	void VScrollBar::UpdateButton (void)
	{
		//----------------------------------------------------------------------------------
		// This function is used to update the position of the center button.
		//----------------------------------------------------------------------------------
		SDL_Rect aux;

		//----------------------------------------------------------------------------------
		// First we check that the value isn't outside the min-max range.
		//----------------------------------------------------------------------------------
		if(Value < Min)
			Value = Min;
		else if(Value >= Max)
			Value = Max - 1;

		//----------------------------------------------------------------------------------
		// And we start to set the position of the button.
		//----------------------------------------------------------------------------------
		aux.x = Rect.x;
		aux.w = Rect.w;

		//----------------------------------------------------------------------------------
		// We check if there is a zero division, if we haven't that problem we calculate
		// the y coordinate of the button and its final height, with Value, Max and Min.
		//----------------------------------------------------------------------------------
		if((Max - Min) != 0)
		{
			aux.y = Rect.y + Rect.w + (Rect.h - 2 * Rect.w) * (Value - Min) / (Max - Min);
			aux.h = (Rect.h - 2 * Rect.w) / (Max - Min);
		}
		//----------------------------------------------------------------------------------
		// If there is a zero division we set the values of the rect to "zero".
		//----------------------------------------------------------------------------------
		else
		{
			aux.y = Rect.y + Rect.w;
			aux.h = Rect.h - 2 * Rect.w;
		}

		//----------------------------------------------------------------------------------
		// Finally we set the rect of the button.
		//----------------------------------------------------------------------------------
		Button02->SetRect(aux);
	}
	
	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void VScrollBar::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we'll set the position of the up button.
		//----------------------------------------------------------------------------------
		SDL_Rect aux;

		aux.x = Rect.x;
		aux.y = Rect.y;
		aux.w = Rect.w;
		aux.h = Rect.w;

		Button01->SetRect(aux);

		//----------------------------------------------------------------------------------
		// Second we'll set the position of the center button.
		//----------------------------------------------------------------------------------
		UpdateButton();

		//----------------------------------------------------------------------------------
		// Third we'll set the position of the down button.
		//----------------------------------------------------------------------------------
		aux.x = Rect.x;
		aux.y = Rect.y + Rect.h - Rect.w;
		aux.w = Rect.w;
		aux.h = Rect.w;

		Button03->SetRect(aux);

		//----------------------------------------------------------------------------------
		// Now we check if the control have any correct skin.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_SCROLLBAR_RECTS))
		{
			return;
		}

		//----------------------------------------------------------------------------------
		// Then we calculate the width and the height of the center rect.
		//----------------------------------------------------------------------------------
		int w = Rect.w - Appearance->Rects[0].w - Appearance->Rects[2].w;
		int h = Rect.h - 2 * Rect.w;

		if(w < 0) w = 1;
		if(h < 0) h = 1;

		//----------------------------------------------------------------------------------
		// And finally we calculate each rect of the final appearance of the scrollbar.
		//----------------------------------------------------------------------------------
		Rects[0].x = Rect.x;
		Rects[0].y = Rect.y + Rect.w;
		Rects[0].w = Appearance->Rects[0].w;
		Rects[0].h = h;

		Rects[1].x = Rects[0].x + Rects[0].w;
		Rects[1].y = Rect.y + Rect.w;
		Rects[1].w = w;
		Rects[1].h = h;

		Rects[2].x = Rects[1].x + Rects[1].w;
		Rects[2].y = Rect.y + Rect.w;
		Rects[2].w = Appearance->Rects[2].w;
		Rects[2].h = h;
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void VScrollBar::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned scrollbar.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, the function will draw a scrollbar
			// using the surface stored inside Picture, or the back color.
			//------------------------------------------------------------------------------
			if(Appearance == NULL)
			{
				if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
				else
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			}
			//------------------------------------------------------------------------------
			// If we have it, we will draw the skinned scrollbar, filling the center rect
			// with the actual back color.
			//------------------------------------------------------------------------------
			else
			{
				BlitWithResize(Appearance->Texture, &(Appearance->Rects[0]),
								CRM32Pro.screen, &(Rects[0]));

				SDL_FillRect(CRM32Pro.screen, &(Rects[1]), BackColor);

				BlitWithResize(Appearance->Texture, &(Appearance->Rects[2]),
								CRM32Pro.screen, &(Rects[2]));
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, the function will draw a scrollbar using the
		// back color of the control, filling the area defined in Rect.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, the function will draw a scrollbar using the
		// surface stored inside Picture.
		//----------------------------------------------------------------------------------
		case UsePicture:
			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			else
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			break;
		}

		//----------------------------------------------------------------------------------
		// And finally we'll draw the buttons of the scrollbar.
		//----------------------------------------------------------------------------------
		Button01->Draw();
		Button02->Draw();
		Button03->Draw();
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool VScrollBar::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// We check if the user have pressed the left button of the mouse.
				//--------------------------------------------------------------------------
				if(event.button.button == SDL_BUTTON_LEFT)
				{
					//----------------------------------------------------------------------
					// If the user have pressed with the left button the up button,
					// we'll make a small change in the value of the scrollbar.
					//----------------------------------------------------------------------
					if(Button01->Update(event))
					{
						Value -= SmallChange;
						UpdateButton();
					}
					//----------------------------------------------------------------------
					// If the user have pressed with the left button the center button,
					// we'll set that the center button is pressed.
					//----------------------------------------------------------------------
					else if(Button02->Update(event))
					{
						Pressed = true;
					}
					//----------------------------------------------------------------------
					// If the user have pressed with the left button the down button,
					// we'll make a small change in the value of the scrollbar.
					//----------------------------------------------------------------------
					else if(Button03->Update(event))
					{
						Value += SmallChange;
						UpdateButton();
					}
					//----------------------------------------------------------------------
					// If the user have pressed with the left button up to the center
					// button, we'll make a large change in the value of the scrollbar.
					//----------------------------------------------------------------------
					else if(event.button.y < Button02->GetY())
					{
						Value -= LargeChange;
						UpdateButton();
					}
					//----------------------------------------------------------------------
					// If the user have pressed with the left button down to the center
					// button, we'll make a large change in the value of the scrollbar.
					//----------------------------------------------------------------------
					else if(event.button.y > Button02->GetY())
					{
						Value += LargeChange;
						UpdateButton();
					}
				}

				//--------------------------------------------------------------------------
				// And third if MouseButtonDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// We set that the center button isn't pressed.
				//--------------------------------------------------------------------------
				Pressed = false;

				//--------------------------------------------------------------------------
				// And third if MouseButtonUp isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if(Pressed)
			{
				//--------------------------------------------------------------------------
				// If the mouse's pressed button is the left, we'll move the center button.
				//--------------------------------------------------------------------------
				if(CRM32Pro.mouse_buttons & SDL_BUTTON(SDL_BUTTON_LEFT))
				{
					Value = (CRM32Pro.mouse_y - Rect.y - Rect.w) * (Max - Min) / (Rect.h - 2 * Rect.w) + Min;
					UpdateButton();
				}
				//--------------------------------------------------------------------------
				// If isn't the left button we'll set that the center button isn't pressed.
				//--------------------------------------------------------------------------
				else
				{
					Pressed = false;
				}
			}

			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	VScrollBar & VScrollBar::CopyFrom (const VScrollBar & obj)
	{
		ScrollBar::CopyFrom(obj);

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		string aux;

		aux = Name + "_Up";     Button01->SetName(aux.c_str());
		aux = Name + "_Center"; Button02->SetName(aux.c_str());
		aux = Name + "_Down";   Button03->SetName(aux.c_str());

		return (*this);
	}
}
//******************************************************************************************
// VScrollBar.cpp
//******************************************************************************************