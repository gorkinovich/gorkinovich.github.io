//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../ListBox.h"
#include "../Keys.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define SCROLLBARS_SIZE 20
#define SCB_LARGECHANGE 10
#define SCROLL_FACTOR   10
//------------------------------------------------------------------------------------------
#define RECTX_SEP 1
#define RECTY_SEP 1
#define RECTW_SEP 2
#define RECTH_SEP 2
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  ListBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	ListBox::ListBox () : Box(), ITextControl()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ListBox";

		VBar = new VScrollBar();

		string aux;

		aux = Name + "_VBar"; VBar->SetName(aux.c_str());

		VBar->SetLargeChange(SCB_LARGECHANGE);
		
		VBar->SetMin(0);
		VBar->SetMax(0);
		VBar->SetValue(0);

		TextRect = Rect;

		FirstSelect = -1;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		List.assign(0);
		MultiSelect = false;
		SelectedItems.clear();

		SelColor = 0x00000000;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	ListBox::ListBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					  Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
					  ControlSkin * appearance, SDL_Surface * picture,
					  SDL_Surface * mousepointer, AlignmentStyle alignment, 
					  bool transparency, Uint32 selcolor, bool multisel, bool enable,
					  bool visible) :
		Box(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
			transparency, enable, visible),
		ITextControl(text, font, alignment)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ListBox";

		VBar = new VScrollBar();

		string aux;

		aux = Name + "_VBar"; VBar->SetName(aux.c_str());

		VBar->SetLargeChange(SCB_LARGECHANGE);
		
		VBar->SetMin(0);
		VBar->SetMax(0);
		VBar->SetValue(0);

		TextRect = Rect;

		FirstSelect = -1;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		List.assign(0);
		MultiSelect = multisel;
		SelectedItems.clear();

		SelColor = selcolor;

		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListBox copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ListBox::ListBox (const ListBox & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListBox operator =.
	 */
	//--------------------------------------------------------------------------------------
	ListBox & ListBox::operator = (const ListBox & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListBox destructor.
	 */
	//--------------------------------------------------------------------------------------
	ListBox::~ListBox ()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		delete VBar;

		TextRect.x = 0;
		TextRect.y = 0;
		TextRect.w = 0;
		TextRect.h = 0;

		FirstSelect = -1;
		
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.size(); ++i)
		{
			ListBoxItem * item = List[i];
			delete item;
		}

		List.erase(List.begin(), List.end());
		MultiSelect = false;
		SelectedItems.clear();

		SelColor = 0x00000000;
	}

	//--------------------------------------------------------------------------------------
	/// Add an item in the list.
	//--------------------------------------------------------------------------------------
	inline bool ListBox::AddListItem (string text)
	{
		return AddListItem(text, BackColor);
	}

	//--------------------------------------------------------------------------------------
	/// Add an item in the list.
	//--------------------------------------------------------------------------------------
	bool ListBox::AddListItem (string text, Uint32 color)
	{
		//----------------------------------------------------------------------------------
		// This function will add a new item into the list. First we must to get memory
		// for the new item, and check if everything have gone all right.
		//----------------------------------------------------------------------------------
		ListBoxItem * item = new ListBoxItem;

		if(item == NULL) return false;

		//----------------------------------------------------------------------------------
		// If the item have memory we'll put the data inside it.
		//----------------------------------------------------------------------------------
		item->Text      = text;
		item->BackColor = color;

		//----------------------------------------------------------------------------------
		// And then we'll try to push in the list the item. If the item haven't been pushed
		// then we must delete the item and return that an error happen.
		//----------------------------------------------------------------------------------
		int actsize = List.size();

		List.push_back(item);

		if(actsize == List.size())
		{
			delete item;
			return false;
		}

		//----------------------------------------------------------------------------------
		// Finally we must to update the value of the scrollbar.
		//----------------------------------------------------------------------------------
		UpdateValues();

		return true;
	}

	//--------------------------------------------------------------------------------------
	/// Erase an item in the list.
	//--------------------------------------------------------------------------------------
	void ListBox::DelListItem (int i)
	{
		//----------------------------------------------------------------------------------
		// This function will erase an item inside the list, if that item is in the list.
		//----------------------------------------------------------------------------------
		vector<ListBoxItem *>::iterator it = List.begin();

		//----------------------------------------------------------------------------------
		// To do this mision we must read the whole list, if we find the item, we'll erase
		// it from the memory, and from the list, updating the values of the control.
		//----------------------------------------------------------------------------------
		for(int j = 0; it != List.end(); ++j, ++it)
		{
			if(j == i)
			{
				ListBoxItem * aux = List[i];
				delete aux;

				List.erase(it);

				UpdateValues();
				break;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the items of the control.
	//--------------------------------------------------------------------------------------
	void ListBox::DrawList (void)
	{
		//----------------------------------------------------------------------------------
		// This function will draw the list of items into the control.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return;

		if(List.size() == 0) return;

		//----------------------------------------------------------------------------------
		// We will need some variables, i it's to read the list of items, inch have the
		// height of the font, j it's to read the list of selected items, and aux it's to
		// set the area where we are going to paint the back color of the items.
		//----------------------------------------------------------------------------------
		int i, inch = Font->GetSurface()->h + DEFAULT_SEPARATIONY;
		list<int>::iterator j = SelectedItems.begin();
		SDL_Rect aux;

		//----------------------------------------------------------------------------------
		// Before read the list of items, we need to set the area of filling.
		//----------------------------------------------------------------------------------
		aux.x = TextRect.x + RECTX_SEP;
		aux.y = TextRect.y + RECTY_SEP - VBar->GetValue() * SCROLL_FACTOR;
		aux.w = TextRect.w - RECTW_SEP;
		aux.h = inch - RECTH_SEP;

		//----------------------------------------------------------------------------------
		// And now we'll be able to read the list, if the current position is a selected
		// item in the listbox, we will use the selected color as the back color of that
		// position. If the item isn't selected we will use the item back color.
		//----------------------------------------------------------------------------------
		for(i = 0; i < List.size(); ++i)
		{
			if((j != SelectedItems.end()) && (*j == i))
			{
				FillSurface(SelColor, &aux, CRM32Pro.screen, &TextRect);
				++j;
			}
			else
			{
				FillSurface(List[i]->BackColor, &aux, CRM32Pro.screen, &TextRect);
			}
			aux.y += inch;
		}
		
		//----------------------------------------------------------------------------------
		// Finally we will draw the text using DrawTextMultiline2.
		//----------------------------------------------------------------------------------
		DrawTextMultiline2(CRM32Pro.screen, TextRect.x, TextRect.y - VBar->GetValue() * SCROLL_FACTOR, &TextRect);
	}
	
	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void ListBox::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned listbox.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, the function will fill the control
			// with the BackColor (if the transparency isn't true), and after that will
			// draw the surface inside the variable Picture.
			//------------------------------------------------------------------------------
			if(Appearance == NULL)
			{
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

				if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			}
			//------------------------------------------------------------------------------
			// But if we have a skin, we'll draw a filled box.
			//------------------------------------------------------------------------------
			else
			{
				int i;

				//--------------------------------------------------------------------------
				// We read the rects before the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = 0; i < CENTER_BOX_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// If the transparency is false, we'll fill the center rect with BackColor.
				//--------------------------------------------------------------------------
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER_BOX_RECT]), BackColor);
				
				//--------------------------------------------------------------------------
				// We read the rects after the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER_BOX_RECT + 1; i < MAX_BOX_RECTS; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, we'll draw this using the back color.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, we'll draw this using the surface in Picture.
		//----------------------------------------------------------------------------------
		case UsePicture:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			
			break;
		}

		//----------------------------------------------------------------------------------
		// Finally we'll draw the list of items into the listbox.
		//----------------------------------------------------------------------------------
		DrawList();

		//----------------------------------------------------------------------------------
		// And of course, we will draw the vertical scrollbar.
		//----------------------------------------------------------------------------------
		VBar->Draw();
	}

	//--------------------------------------------------------------------------------------
	/// This function get the item pressed in the control with the mouse.
	//--------------------------------------------------------------------------------------
	int ListBox::GetItemPressed (Uint16 x, Uint16 y)
	{
		//----------------------------------------------------------------------------------
		// This function calculates which item from the list is pressed.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return -1;

		//----------------------------------------------------------------------------------
		// With this operation we obtain a posible position from the list.
		//----------------------------------------------------------------------------------
		int aux = (y - (TextRect.y - VBar->GetValue() * SCROLL_FACTOR)) / (Font->GetSurface()->h + DEFAULT_SEPARATIONY);

		//----------------------------------------------------------------------------------
		// But if that position is outside of the truly range of indexes we return -1.
		//----------------------------------------------------------------------------------
		if((aux < 0) || (List.size() <= aux))
			return -1;
		else
			return aux;
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool ListBox::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		//----------------------------------------------------------------------------------
		// We pass the event to the scrollbar to see if it catches any event.
		//----------------------------------------------------------------------------------
		if(VBar->Update(event)) return true;

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// Here we will make posible for the user to interact with the control,
				// making posible select some of the items inside the list. But this will
				// be posible only with the left button of the mouse.
				//--------------------------------------------------------------------------
				if(event.button.button == SDL_BUTTON_LEFT)
				{
					//----------------------------------------------------------------------
					// First we must to obtain the pressed item.
					//----------------------------------------------------------------------
					int index = GetItemPressed(event.button.x, event.button.y);

					//----------------------------------------------------------------------
					// If no item was pressed we set that there isn't any selected item.
					//----------------------------------------------------------------------
					if(index == -1)
					{
						FirstSelect = -1;
						SetNoSelectedItems();
					}
					//----------------------------------------------------------------------
					// But if an item was pressed we'll need to check a couple of things.
					//----------------------------------------------------------------------
					else
					{
						bool finded = false;
						
						//------------------------------------------------------------------
						// First we need to find, if we have used the mouse with the ctrl
						// key, if the pressed item isn't inside the selected item. If the
						// item was a selected one, we erase it from the select list.
						//------------------------------------------------------------------
						if(CRM32Pro.keystate[Keys::KEY_LCTRL] || CRM32Pro.keystate[Keys::KEY_RCTRL])
						{
							list<int>::iterator i;

							for(i = SelectedItems.begin(); i != SelectedItems.end(); ++i)
							{
								if(*i == index)
								{
									finded = true;
									SelectedItems.erase(i);
									break;
								}
							}
						}

						//------------------------------------------------------------------
						// If we haven't find the pressed index in the select list, we'll
						// add that pressed index into the select list.
						//------------------------------------------------------------------
						if(!finded)
						{
							//--------------------------------------------------------------
							// If the list is multi-select, maybe we can add one or more
							// indexes to the select list.
							//--------------------------------------------------------------
							if(MultiSelect)
							{
								//----------------------------------------------------------
								// We check if the control key is pressed, to permit to
								// select any item of the list.
								//----------------------------------------------------------
								if(CRM32Pro.keystate[Keys::KEY_LCTRL] || CRM32Pro.keystate[Keys::KEY_RCTRL])
								{
									if(FirstSelect == -1) FirstSelect = index;

									SelectedItems.push_back(index);
									SelectedItems.sort();
								}
								//----------------------------------------------------------
								// We check if the shift key is pressed, to permit to
								// select more than one item of the list, with one click.
								//----------------------------------------------------------
								else if(CRM32Pro.keystate[Keys::KEY_LSHIFT] || CRM32Pro.keystate[Keys::KEY_RSHIFT])
								{
									if(FirstSelect == -1)
									{
										FirstSelect = index;
										SetNoSelectedItems();
										SelectedItems.push_back(index);
									}
									else if(FirstSelect < index)
									{
										SetNoSelectedItems();
										for(int i = FirstSelect; i <= index; ++i)
											SelectedItems.push_back(i);
									}
									else if(FirstSelect > index)
									{
										SetNoSelectedItems();
										for(int i = index; i <= FirstSelect; ++i)
											SelectedItems.push_back(i);
									}
								}
								//----------------------------------------------------------
								// Any other option we'll clear the select list, and will
								// add the current selected index.
								//----------------------------------------------------------
								else
								{
									FirstSelect = index;
									SetNoSelectedItems();
									SelectedItems.push_back(index);
								}
							}
							//--------------------------------------------------------------
							// If the listbox isn't a multi-select one, we'll erase al the
							// select list, and will add the current index.
							//--------------------------------------------------------------
							else
							{
								FirstSelect = index;
								SetNoSelectedItems();
								SelectedItems.push_back(index);
							}
						}
					}
				}
				//--------------------------------------------------------------------------
				// If the user press the wheel up, we'll move up the scrollbar.
				//--------------------------------------------------------------------------
				else if(event.button.button == SDL_BUTTON_WHEELUP)
				{
					VBar->SetValue(VBar->GetValue() - VBar->GetSmallChange());
				}
				//--------------------------------------------------------------------------
				// If the user press the wheel down, we'll move down the scrollbar.
				//--------------------------------------------------------------------------
				else if(event.button.button == SDL_BUTTON_WHEELDOWN)
				{
					VBar->SetValue(VBar->GetValue() + VBar->GetSmallChange());
				}

				//--------------------------------------------------------------------------
				// And if MouseButtonDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	ListBox & ListBox::CopyFrom (const ListBox & obj)
	{
		Box::CopyFrom(obj);

		ITextControl::CopyFrom(obj);
		
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		VBar->CopyFrom(*(obj.VBar));

		TextRect = obj.TextRect;

		FirstSelect = obj.FirstSelect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		List          = obj.List;
		MultiSelect   = obj.MultiSelect;
		SelectedItems = obj.SelectedItems;
		SelColor      = obj.SelColor;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the values of the scrollbars.
	//--------------------------------------------------------------------------------------
	void ListBox::UpdateValues (void)
	{
		//----------------------------------------------------------------------------------
		// In this function we delete the whole text, and read all the items from the list,
		// items that we'll add to the Text variable, separated by a jump-line. After read
		// the whole list, we will call a function to update the width of the text.
		//----------------------------------------------------------------------------------
		Text = "";
		for(int i = 0; i < List.size(); ++i)
		{
			Text += List[i]->Text;
			Text += '\n';
		}

		UpdateWidth();

		//----------------------------------------------------------------------------------
		// After update the text, we'll get the minimum number of lines of the current
		// text, to obtain the max value of the vertical scrollbar..
		//----------------------------------------------------------------------------------
		int MinLines = (GetMinNumLines() - TextRect.h) / SCROLL_FACTOR + 1;

		VBar->SetMax((MinLines > 0) ? MinLines : 0);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void ListBox::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we call the UpdateRects function of the Box class.
		//----------------------------------------------------------------------------------
		Box::UpdateRects();

		//----------------------------------------------------------------------------------
		// Second we check if the control have any correct skin, setting the text's area
		// with the area of the box's center rect, if we have a skin in the control.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_BOX_RECTS))
			TextRect = Rect;
		else
			TextRect = Rects[CENTER_BOX_RECT];

		TextRect.w -= SCROLLBARS_SIZE;
		
		SDL_Rect aux;

		//----------------------------------------------------------------------------------
		// Third we'll set the position of the vertical scrollbar.
		//----------------------------------------------------------------------------------
		aux.x = TextRect.x + TextRect.w;
		aux.y = TextRect.y;
		aux.w = SCROLLBARS_SIZE;
		aux.h = TextRect.h;
		VBar->SetRect(aux);

		//----------------------------------------------------------------------------------
		// And after all we will update the value of the listbox's scrollbar.
		//----------------------------------------------------------------------------------
		UpdateValues();
	}
}
//******************************************************************************************
// ListBox.cpp
//******************************************************************************************