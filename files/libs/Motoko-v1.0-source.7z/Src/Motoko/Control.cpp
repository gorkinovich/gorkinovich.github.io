//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Control.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  Control constructor.
	 */
	//--------------------------------------------------------------------------------------
	Control::Control ()
	{
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Name = "";

		Rect.x = 0;
		Rect.y = 0;
		Rect.w = 0;
		Rect.h = 0;

		BackStyle  = UseBackColor;
		Appearance = NULL;
		BackColor  = 0x00000000;
		Picture    = NULL;

		MousePointer = NULL;

		Enable  = true;
		Visible = true;

		Transparency = false;

		//----------------------------------------------------------------------------------
		// Events
		//----------------------------------------------------------------------------------
		KeyDown         = NULL;
		KeyUp           = NULL;
		MouseMotion     = NULL;
		MouseButtonDown = NULL;
		MouseButtonUp   = NULL;

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Control";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Control constructor.
	 */
	//--------------------------------------------------------------------------------------
	Control::Control (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					  Uint32 backcolor, ControlSkin * appearance, SDL_Surface * picture,
					  SDL_Surface * mousepointer, bool transparency, bool enable, bool visible)
	{
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Name = name;

		Rect = rect;

		BackStyle  = backstyle;
		Appearance = appearance;
		BackColor  = backcolor;
		Picture    = picture;

		MousePointer = mousepointer;

		Enable  = enable;
		Visible = visible;

		Transparency = transparency;

		//----------------------------------------------------------------------------------
		// Events
		//----------------------------------------------------------------------------------
		KeyDown         = NULL;
		KeyUp           = NULL;
		MouseMotion     = NULL;
		MouseButtonDown = NULL;
		MouseButtonUp   = NULL;
		
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Control";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Control copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	Control::Control (const Control & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Control operator =.
	 */
	//--------------------------------------------------------------------------------------
	Control & Control::operator = (const Control & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Control destructor.
	 */
	//--------------------------------------------------------------------------------------
	Control::~Control ()
	{
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Name = "";

		Rect.x = 0;
		Rect.y = 0;
		Rect.w = 0;
		Rect.h = 0;

		BackStyle  = UseBackColor;
		Appearance = NULL;
		BackColor  = 0x00000000;
		Picture    = NULL;

		MousePointer = 0;

		Enable  = true;
		Visible = true;
		
		//----------------------------------------------------------------------------------
		// Events
		//----------------------------------------------------------------------------------
		KeyDown         = NULL;
		KeyUp           = NULL;
		MouseMotion     = NULL;
		MouseButtonDown = NULL;
		MouseButtonUp   = NULL;

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Control";
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	Control & Control::CopyFrom (const Control & obj)
	{
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Name = obj.Name + "_Clone";

		Rect = obj.Rect;

		BackStyle  = obj.BackStyle;
		Appearance = obj.Appearance;
		BackColor  = obj.BackColor;
		Picture    = obj.Picture;

		MousePointer = obj.MousePointer;

		Enable  = obj.Enable;
		Visible = obj.Visible;

		Transparency = obj.Transparency;
		
		//----------------------------------------------------------------------------------
		// Events
		//----------------------------------------------------------------------------------
		KeyDown         = obj.KeyDown;
		KeyUp           = obj.KeyUp;
		MouseMotion     = obj.MouseMotion;
		MouseButtonDown = obj.MouseButtonDown;
		MouseButtonUp   = obj.MouseButtonUp;
		
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = obj.Type;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/// This function looks if the cursor is over the control.
	//--------------------------------------------------------------------------------------
	bool Control::IsCursorOver (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously the mouse can't be over it.
		//----------------------------------------------------------------------------------
		if(Visible == false) return false;

		//----------------------------------------------------------------------------------
		// If the control is visible, we check if the cursor of the mouse is inside the
		// area stored in the variable Rect.
		//----------------------------------------------------------------------------------
		return (Rect.x <= CRM32Pro.mouse_x) && (CRM32Pro.mouse_x < Rect.x + Rect.w) &&
			   (Rect.y <= CRM32Pro.mouse_y) && (CRM32Pro.mouse_y < Rect.y + Rect.h);
	}

	//--------------------------------------------------------------------------------------
	/// This function is to get the focus for the control.
	//--------------------------------------------------------------------------------------
	void Control::GetFocus (void)
	{
		//----------------------------------------------------------------------------------
		// This function will send an event to the SDL queue of events. The main purpose
		// of this send, is to give a signal to the application object and change the
		// active control, which give the actual control with the focus.
		//----------------------------------------------------------------------------------
		SDL_Event event;
	
		event.type = SDL_USEREVENT;
		event.user.code = CONTROL_GET_FOCUS;
		event.user.data1 = (void *) this;
		event.user.data2 = NULL;
		SDL_PushEvent(&event);
	}
}
//******************************************************************************************
// Control.cpp
//******************************************************************************************