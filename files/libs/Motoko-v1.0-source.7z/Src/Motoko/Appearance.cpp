//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Appearance.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
//******************************************************************************************
// Class ThemeSkin.
//******************************************************************************************

	//--------------------------------------------------------------------------------------
	/**
	 *  ThemeSkin constructor.
	 */
	//--------------------------------------------------------------------------------------
	ThemeSkin::ThemeSkin ()
	{
		Skins.assign(0);
		Name = "";
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ThemeSkin copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ThemeSkin::ThemeSkin (const ThemeSkin & obj)
	{
		Skins = obj.Skins;
		Name  = obj.Name;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ThemeSkin operator =.
	 */
	//--------------------------------------------------------------------------------------
	ThemeSkin & ThemeSkin::operator = (const ThemeSkin & obj)
	{
		Skins = obj.Skins;
		Name  = obj.Name;
		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ThemeSkin destructor.
	 */
	//--------------------------------------------------------------------------------------
	ThemeSkin::~ThemeSkin ()
	{
		Free();
	}

	//--------------------------------------------------------------------------------------
	/// Load a theme.
	/**
	 *  @param fileDPF File with the theme.
	 *  @param fileXML File with the parameters.
	 *  @see Free().
	 *  @return If no error 0, else an error code.
	 */
	//--------------------------------------------------------------------------------------
	int ThemeSkin::Load (const char * fileDPF, const char * fileXML)
	{
		try
		{
			char * straux;
			int numaux;
			ControlSkin * csaux = NULL;

			//------------------------------------------------------------------------------
			// Open the XML file.
			//------------------------------------------------------------------------------
			int id = CRM32Pro.XMLOpen((char *) fileDPF, (char *) fileXML);

			if(id == CRMFAIL)
			{
				return THEMESKIN_ERROR_XMLOPEN;
			}

			//------------------------------------------------------------------------------
			// Go to the root node and read the name.
			//------------------------------------------------------------------------------
			CRM32Pro.XMLNodeFirst(id);

			if(strcmp(CRM32Pro.XMLNodeGetName(id), "motokoskin") != STR_EQU)
			{
				return THEMESKIN_ERROR_XMLTYPE;
			}

			//------------------------------------------------------------------------------
			// Read the name of the theme.
			//------------------------------------------------------------------------------
			CRM32Pro.XMLAttributeGet(id, "name", (char **) &straux);

			Name = straux;

			CRM32Pro.XMLNodeChild(id);

			do{
				//--------------------------------------------------------------------------
				// Read the skins of the theme.
				//--------------------------------------------------------------------------
				if(strcmp(CRM32Pro.XMLNodeGetName(id), "controlskin") == STR_EQU)
				{
					//----------------------------------------------------------------------
					// Create a new control.
					//----------------------------------------------------------------------
					csaux = NULL;
					csaux = new ControlSkin;

					if(csaux != NULL)
					{
						//------------------------------------------------------------------
						// Read the name of the skin.
						//------------------------------------------------------------------
						CRM32Pro.XMLAttributeGet(id, "name", (char **) &straux);
						csaux->Name = straux;

						//------------------------------------------------------------------
						// Load the texture of the skin.
						//------------------------------------------------------------------
						CRM32Pro.XMLAttributeGet(id, "texture", (char **) &straux);
						csaux->Texture = IImage->Load((char *) fileDPF, straux);
						SDL_SetColorKey(csaux->Texture, SDL_SRCCOLORKEY, 0x00FF00FF);

						//------------------------------------------------------------------
						// Read the number of rects of the skin.
						//------------------------------------------------------------------
						CRM32Pro.XMLAttributeGet(id, "rects", &numaux);
						csaux->NumRects = numaux;

						//------------------------------------------------------------------
						// Read the rects of the skin.
						//------------------------------------------------------------------
						csaux->Rects = new SDL_Rect[csaux->NumRects];

						CRM32Pro.XMLNodeChild(id);
						for(int i = 0; i < csaux->NumRects; ++i)
						{
							if(strcmp(CRM32Pro.XMLNodeGetName(id), "skinrect") == STR_EQU)
							{
								CRM32Pro.XMLAttributeGet(id, "x", &numaux);
								csaux->Rects[i].x = numaux;
								CRM32Pro.XMLAttributeGet(id, "y", &numaux);
								csaux->Rects[i].y = numaux;
								CRM32Pro.XMLAttributeGet(id, "w", &numaux);
								csaux->Rects[i].w = numaux;
								CRM32Pro.XMLAttributeGet(id, "h", &numaux);
								csaux->Rects[i].h = numaux;
							}

							CRM32Pro.XMLNodeNext(id);
						}
						CRM32Pro.XMLNodeParent(id);
					}

					//----------------------------------------------------------------------
					// Push it into the vector.
					//----------------------------------------------------------------------
					Skins.push_back(csaux);
				}
			}while(CRM32Pro.XMLNodeNext(id) != 0);

			CRM32Pro.XMLNodeParent(id);

			//------------------------------------------------------------------------------
			// Close XML file.
			//------------------------------------------------------------------------------
			CRM32Pro.XMLClose(id);

			return EVERYTHING_ALL_RIGHT;
		}
		catch(...)
		{
			return THEMESKIN_ERROR_UNDEF;
		}
	}

	//--------------------------------------------------------------------------------------
	/// Unload the skins.
	/**
	 *  @see Load().
	 */
	//--------------------------------------------------------------------------------------
	void ThemeSkin::Free (void)
	{
		ControlSkin * aux;
		//----------------------------------------------------------------------------------
		// For every position in the vector Skins, we must take the pointer, make sure it
		// is not a NULL pointer, free the texture, delete the rects of the skin, and
		// finally delete the main pointer.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Skins.size(); ++i)
		{
			aux = Skins[i];

			if(aux != NULL)
			{
				CRM32Pro.FreeSurface(aux->Texture);
				delete aux->Rects;

				delete aux;
			}
		}

		//----------------------------------------------------------------------------------
		// At the end we erase the whole vector, and the name.
		//----------------------------------------------------------------------------------
		Skins.erase(Skins.begin(), Skins.end());
		Name = "";
	}

	//--------------------------------------------------------------------------------------
	/// Get a pointer to a skin.
	/**
	 *  @param name Name of the skin.
	 *  @return If no error a pointer to the skin, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	ControlSkin * ThemeSkin::GetSkin (const char * name)
	{
		//----------------------------------------------------------------------------------
		// To find a skin, using a name, we must check every position in the vector, and
		// if the name of the actual position, is the same that the name parameter, then
		// we must return that position to the user.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Skins.size(); ++i)
		{
			if(Skins[i]->Name == name)
			{
				return Skins[i];
			}
		}

		//----------------------------------------------------------------------------------
		// But if after check the whole vector, we don't find anything, we return NULL.
		//----------------------------------------------------------------------------------
		return NULL;
	}

//******************************************************************************************
// Class SkinsManager.
//******************************************************************************************
	
	//--------------------------------------------------------------------------------------
	/**
	 *  SkinsManager constructor.
	 */
	//--------------------------------------------------------------------------------------
	SkinsManager::SkinsManager ()
	{
		Skins.assign(0);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  SkinsManager copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	SkinsManager::SkinsManager (const SkinsManager & obj)
	{
		Skins = obj.Skins;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  SkinsManager operator =.
	 */
	//--------------------------------------------------------------------------------------
	SkinsManager & SkinsManager::operator = (const SkinsManager & obj)
	{
		Skins = obj.Skins;
		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  SkinsManager destructor.
	 */
	//--------------------------------------------------------------------------------------
	SkinsManager::~SkinsManager ()
	{
		Free();
	}

	//--------------------------------------------------------------------------------------
	/// Add a theme.
	/**
	 *  @param fileDPF File with the theme.
	 *  @param fileXML File with the parameters.
	 *  @see RemoveTheme(), Free().
	 *  @return If no error 0, else an error code.
	 */
	//--------------------------------------------------------------------------------------
	int SkinsManager::AddTheme (const char * fileDPF, const char * fileXML)
	{
		//----------------------------------------------------------------------------------
		// First we create a new instance of the ThemeSkin class.
		//----------------------------------------------------------------------------------
		ThemeSkin * aux = NULL;

		aux = new ThemeSkin();

		if(aux == NULL)
		{
			return SKINSMANAGER_ERROR_NEWTHEME;
		}

		//----------------------------------------------------------------------------------
		// After that, we load the theme from a DPF file.
		//----------------------------------------------------------------------------------
		int error = aux->Load(fileDPF, fileXML);

		if(error)
		{
			return error;
		}

		//----------------------------------------------------------------------------------
		// And finally we must push it, into the vector Skins.
		//----------------------------------------------------------------------------------
		int actsize = Skins.size();
		Skins.push_back(aux);

		if(actsize == Skins.size())
		{
			return SKINSMANAGER_ERROR_PUSHBACK;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	/// Add a theme.
	/**
	 *  @param theme New theme.
	 *  @see RemoveTheme(), Free().
	 *  @return If no error 0, else an error code.
	 */
	//--------------------------------------------------------------------------------------
	int SkinsManager::AddTheme (ThemeSkin * theme)
	{
		//----------------------------------------------------------------------------------
		// Like the other AddTheme function, we have an object created, and we only need
		// to push it into the vector Skins, and check everything goes right.
		//----------------------------------------------------------------------------------
		int actsize = Skins.size();
		Skins.push_back(theme);

		if(actsize == Skins.size())
		{
			return SKINSMANAGER_ERROR_PUSHBACK;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	/// Remove a theme.
	/**
	 *  @see AddTheme(), Free().
	 */
	//--------------------------------------------------------------------------------------
	void SkinsManager::RemoveTheme (const char * theme)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a theme with the same name. If we find
		// it, then we free the theme and delete the object from memory.
		//----------------------------------------------------------------------------------
		vector<ThemeSkin *>::iterator i;
		ThemeSkin * aux;

		for(i = Skins.begin(); i != Skins.end(); ++i)
		{
			aux = *i;
			
			if(strcmp(aux->GetName(), theme) == STR_EQU)
			{
				aux->Free();
				delete aux;

				Skins.erase(i);
				return;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	/// Unload the themes.
	/**
	 *  @see AddTheme(), RemoveTheme().
	 */
	//--------------------------------------------------------------------------------------
	void SkinsManager::Free (void)
	{
		ThemeSkin * aux;

		//----------------------------------------------------------------------------------
		// We take the whole vector and erase each theme inside Skins.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Skins.size(); ++i)
		{
			aux = Skins[i];

			if(aux != NULL)
			{
				aux->Free();
				delete aux;
			}
		}

		Skins.erase(Skins.begin(), Skins.end());
	}

	//--------------------------------------------------------------------------------------
	/// Get a pointer to a skin.
	/**
	 *  @param theme Name of the theme.
	 *  @param name  Name of the skin.
	 *  @return If no error a pointer to the skin, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	ControlSkin * SkinsManager::GetSkin (const char * theme, const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a theme with the same name. If we find
		// it, then we return a pointer to that object.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Skins.size(); ++i)
		{
			if(strcmp(Skins[i]->GetName(), theme) == STR_EQU)
			{
				return Skins[i]->GetSkin(name);
			}
		}

		return NULL;
	}

	//--------------------------------------------------------------------------------------
	/// Set a new name to the theme.
	/**
	 *  @param theme Name of the theme.
	 *  @param name  New name of the theme.
	 */
	//--------------------------------------------------------------------------------------
	void SkinsManager::SetThemeName (const char * theme, const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a theme with the same name. If we find
		// it, then we set the new name for the theme.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Skins.size(); ++i)
		{
			if(strcmp(Skins[i]->GetName(), theme) == STR_EQU)
			{
				Skins[i]->SetName(name);
				return;
			}
		}
	}
}
//******************************************************************************************
// Appearance.cpp
//******************************************************************************************