//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Base.h"
#include "../Keys.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	// Set a region froma an SDL_Rect.
	//--------------------------------------------------------------------------------------
	inline void SetIniMax (SDL_Surface * surf, SDL_Rect * rect, Sint16 & inix, Sint16 & iniy,
						   Sint16 & maxx, Sint16 & maxy)
	{
		//----------------------------------------------------------------------------------
		// If the rect is NULL, the region will be the whole surface.
		//----------------------------------------------------------------------------------
		if(rect == NULL)
		{
			iniy = 0;
			inix = 0;
			maxy = surf->h;
			maxx = surf->w;
		}
		//----------------------------------------------------------------------------------
		// If the rect is not NULL then we take the data from it. We must be carefull with
		// the maximum x, y coordinate, to not get one outside the surface. The same with
		// the minimum x, y coordinate.
		//----------------------------------------------------------------------------------
		else
		{
			iniy = ((rect->y < 0) ? 0 : rect->y);
			inix = ((rect->x < 0) ? 0 : rect->x);
			maxy = ((rect->y + rect->h) > surf->h) ? surf->h : (rect->y + rect->h);
			maxx = ((rect->x + rect->w) > surf->w) ? surf->w : (rect->x + rect->w);
		}
	}

	//--------------------------------------------------------------------------------------
	// Blit a surface with resize.
	//--------------------------------------------------------------------------------------
	inline void BlitWithResize8 (SDL_Surface * src, SDL_Rect * srcrect, SDL_Surface * dst, SDL_Rect * dstrect)
	{
		//----------------------------------------------------------------------------------
		// i and j are to move inside the source surface.
		// k and m are to move inside the destine surface.
		// inix, iniy, maxy and maxx are the delimited region in the source.
		// inix2, iniy2, maxy2 and maxx2 are the delimited region in the destine.
		//----------------------------------------------------------------------------------
		Uint32 i, j, k, m;
		Sint16 inix, iniy, maxy, maxx;
		Sint16 inix2, iniy2, maxy2, maxx2;
		int offset;

		//----------------------------------------------------------------------------------
		// We need this pointers to access the pixels of the surfaces.
		//----------------------------------------------------------------------------------
		Uint8 * pixsrc = (Uint8 *) src->pixels;
		Uint8 * pixdst = (Uint8 *) dst->pixels;

		//----------------------------------------------------------------------------------
		// Set the destine region.
		//----------------------------------------------------------------------------------
		SetIniMax(dst, dstrect, inix2, iniy2, maxx2, maxy2);

		//----------------------------------------------------------------------------------
		// Set the source region.
		//----------------------------------------------------------------------------------
		SetIniMax(src, srcrect, inix, iniy, maxx, maxy);

		//----------------------------------------------------------------------------------
		// Set the new size percent, taking the width (difx) and the height (dify) of the
		// source, and using it to store in sizex and sizey that percent. contx and conty
		// will be used to control when we must draw a pixel or a row of them.
		//----------------------------------------------------------------------------------
		Sint16 difx = maxx - inix;
		Sint16 dify = maxy - iniy;

		float sizex, sizey;
		float contx = 0;
		float conty = 0;

		if(difx == 0)
			sizex = 0;
		else
			sizex = float(maxx2 - inix2) / float(difx);
		
		if(dify == 0)
			sizey = 0;
		else
			sizey = float(maxy2 - iniy2) / float(dify);

		//----------------------------------------------------------------------------------
		// Blit the source surface into the destine, doing the next. First we add to conty
		// the percent of the height. Why? Because if the percent is 0.5 we make sure a row
		// will be not blitted, because we only will draw a row when conty is 1 or more. In
		// that way if sizey is 2, we will draw the same row 2 times. But we must be
		// careful to don't get out the destine surface.
		//----------------------------------------------------------------------------------
		for(i = iniy, k = iniy2; (i < maxy) && (k < maxy2); ++i)
		{
			conty += sizey;
			while((conty >= 1) && (k < maxy2))
			{
				//--------------------------------------------------------------------------
				// In the same way that the rows we use the same algorithm for the pixels
				// inside a row. First we get the final offset inside the source surface,
				// the we add to contx the width percent, in the same way that we did with
				// conty. And we make sure to paint the pixel in the destine, the times we
				// need. Of course we must be careful to don't get outside the destine.
				//--------------------------------------------------------------------------
				for(j = inix, m = inix2; (j < maxx) && (m < maxx2); ++j)
				{
					offset = (i * src->w) + j;

					contx += sizex;

					while((contx >= 1) && (m < maxx2))
					{
						if((src->format->colorkey == 0) ||
							(pixsrc[offset] != src->format->colorkey))
							pixdst[(k * dst->w) + m] = pixsrc[offset];

						--contx;
						++m;
					}
				}

				--conty;
				++k;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	// Blit a surface with resize.
	//--------------------------------------------------------------------------------------
	inline void BlitWithResize16 (SDL_Surface * src, SDL_Rect * srcrect, SDL_Surface * dst, SDL_Rect * dstrect)
	{
		//----------------------------------------------------------------------------------
		// i and j are to move inside the source surface.
		// k and m are to move inside the destine surface.
		// inix, iniy, maxy and maxx are the delimited region in the source.
		// inix2, iniy2, maxy2 and maxx2 are the delimited region in the destine.
		//----------------------------------------------------------------------------------
		Uint32 i, j, k, m;
		Sint16 inix, iniy, maxy, maxx;
		Sint16 inix2, iniy2, maxy2, maxx2;
		int offset;

		//----------------------------------------------------------------------------------
		// We need this pointers to access the pixels of the surfaces.
		//----------------------------------------------------------------------------------
		Uint16 * pixsrc = (Uint16 *) src->pixels;
		Uint16 * pixdst = (Uint16 *) dst->pixels;

		//----------------------------------------------------------------------------------
		// Set the destine region.
		//----------------------------------------------------------------------------------
		SetIniMax(dst, dstrect, inix2, iniy2, maxx2, maxy2);

		//----------------------------------------------------------------------------------
		// Set the source region.
		//----------------------------------------------------------------------------------
		SetIniMax(src, srcrect, inix, iniy, maxx, maxy);

		//----------------------------------------------------------------------------------
		// Set the new size percent, taking the width (difx) and the height (dify) of the
		// source, and using it to store in sizex and sizey that percent. contx and conty
		// will be used to control when we must draw a pixel or a row of them.
		//----------------------------------------------------------------------------------
		Sint16 difx = maxx - inix;
		Sint16 dify = maxy - iniy;

		float sizex, sizey;
		float contx = 0;
		float conty = 0;

		if(difx == 0)
			sizex = 0;
		else
			sizex = float(maxx2 - inix2) / float(difx);
		
		if(dify == 0)
			sizey = 0;
		else
			sizey = float(maxy2 - iniy2) / float(dify);

		//----------------------------------------------------------------------------------
		// Blit the source surface into the destine, doing the next. First we add to conty
		// the percent of the height. Why? Because if the percent is 0.5 we make sure a row
		// will be not blitted, because we only will draw a row when conty is 1 or more. In
		// that way if sizey is 2, we will draw the same row 2 times. But we must be
		// careful to don't get out the destine surface.
		//----------------------------------------------------------------------------------
		for(i = iniy, k = iniy2; (i < maxy) && (k < maxy2); ++i)
		{
			conty += sizey;
			while((conty >= 1) && (k < maxy2))
			{
				//--------------------------------------------------------------------------
				// In the same way that the rows we use the same algorithm for the pixels
				// inside a row. First we get the final offset inside the source surface,
				// the we add to contx the width percent, in the same way that we did with
				// conty. And we make sure to paint the pixel in the destine, the times we
				// need. Of course we must be careful to don't get outside the destine.
				//--------------------------------------------------------------------------
				for(j = inix, m = inix2; (j < maxx) && (m < maxx2); ++j)
				{
					offset = (i * src->w) + j;

					contx += sizex;

					while((contx >= 1) && (m < maxx2))
					{
						if((src->format->colorkey == 0) ||
							(pixsrc[offset] != src->format->colorkey))
							pixdst[(k * dst->w) + m] = pixsrc[offset];

						--contx;
						++m;
					}
				}

				--conty;
				++k;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	// Blit a surface with resize.
	//--------------------------------------------------------------------------------------
	inline void BlitWithResize32 (SDL_Surface * src, SDL_Rect * srcrect, SDL_Surface * dst, SDL_Rect * dstrect)
	{
		//----------------------------------------------------------------------------------
		// i and j are to move inside the source surface.
		// k and m are to move inside the destine surface.
		// inix, iniy, maxy and maxx are the delimited region in the source.
		// inix2, iniy2, maxy2 and maxx2 are the delimited region in the destine.
		//----------------------------------------------------------------------------------
		Uint32 i, j, k, m;
		Sint16 inix, iniy, maxy, maxx;
		Sint16 inix2, iniy2, maxy2, maxx2;
		int offset;

		//----------------------------------------------------------------------------------
		// We need this pointers to access the pixels of the surfaces.
		//----------------------------------------------------------------------------------
		Uint32 * pixsrc = (Uint32 *) src->pixels;
		Uint32 * pixdst = (Uint32 *) dst->pixels;

		//----------------------------------------------------------------------------------
		// Set the destine region.
		//----------------------------------------------------------------------------------
		SetIniMax(dst, dstrect, inix2, iniy2, maxx2, maxy2);

		//----------------------------------------------------------------------------------
		// Set the source region.
		//----------------------------------------------------------------------------------
		SetIniMax(src, srcrect, inix, iniy, maxx, maxy);

		//----------------------------------------------------------------------------------
		// Set the new size percent, taking the width (difx) and the height (dify) of the
		// source, and using it to store in sizex and sizey that percent. contx and conty
		// will be used to control when we must draw a pixel or a row of them.
		//----------------------------------------------------------------------------------
		Sint16 difx = maxx - inix;
		Sint16 dify = maxy - iniy;

		float sizex, sizey;
		float contx = 0;
		float conty = 0;

		if(difx == 0)
			sizex = 0;
		else
			sizex = float(maxx2 - inix2) / float(difx);
		
		if(dify == 0)
			sizey = 0;
		else
			sizey = float(maxy2 - iniy2) / float(dify);

		//----------------------------------------------------------------------------------
		// Blit the source surface into the destine, doing the next. First we add to conty
		// the percent of the height. Why? Because if the percent is 0.5 we make sure a row
		// will be not blitted, because we only will draw a row when conty is 1 or more. In
		// that way if sizey is 2, we will draw the same row 2 times. But we must be
		// careful to don't get out the destine surface.
		//----------------------------------------------------------------------------------
		for(i = iniy, k = iniy2; (i < maxy) && (k < maxy2); ++i)
		{
			conty += sizey;
			while((conty >= 1) && (k < maxy2))
			{
				//--------------------------------------------------------------------------
				// In the same way that the rows we use the same algorithm for the pixels
				// inside a row. First we get the final offset inside the source surface,
				// the we add to contx the width percent, in the same way that we did with
				// conty. And we make sure to paint the pixel in the destine, the times we
				// need. Of course we must be careful to don't get outside the destine.
				//--------------------------------------------------------------------------
				for(j = inix, m = inix2; (j < maxx) && (m < maxx2); ++j)
				{
					offset = (i * src->w) + j;

					contx += sizex;

					while((contx >= 1) && (m < maxx2))
					{
						if((src->format->colorkey == 0) ||
							(pixsrc[offset] != src->format->colorkey))
							pixdst[(k * dst->w) + m] = pixsrc[offset];

						--contx;
						++m;
					}
				}

				--conty;
				++k;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	/// Blit a surface like the SDL_BlitSurface function with resize.
	//--------------------------------------------------------------------------------------
	void DLLAPI BlitWithResize (SDL_Surface * src, SDL_Rect * srcrect, SDL_Surface * dst, SDL_Rect * dstrect)
	{
		if((((src != NULL) ? src->w : srcrect->w) == ((dst != NULL) ? dst->w : dstrect->w)) &&
		   (((src != NULL) ? src->h : srcrect->h) == ((dst != NULL) ? dst->h : dstrect->h)))
		   CRM32Pro.Blit(src, srcrect, dst, dstrect);
		else
		{
			SDL_LockSurface(dst);
			SDL_LockSurface(src);

			if((src->format->BitsPerPixel == 32) && (dst->format->BitsPerPixel == 32))
				BlitWithResize32(src, srcrect, dst, dstrect);
			else if((src->format->BitsPerPixel == 16) && (dst->format->BitsPerPixel == 16))
				BlitWithResize16(src, srcrect, dst, dstrect);
			else if((src->format->BitsPerPixel == 8) && (dst->format->BitsPerPixel == 8))
				BlitWithResize8(src, srcrect, dst, dstrect);

			SDL_UnlockSurface(src);
			SDL_UnlockSurface(dst);
		}
	}

	//--------------------------------------------------------------------------------------
	/// Fill a surface with a limitated area in the destine.
	//--------------------------------------------------------------------------------------
	void DLLAPI FillSurface (dword color, SDL_Rect * rect, SDL_Surface * dst, SDL_Rect * limits)
	{
		//----------------------------------------------------------------------------------
		// The explanation about this is just quite simple, we have to fill one destine
		// area in a surface. Well the area is rect, but we need to put some limits, to
		// make usefull this function, and those are in limits. So we store in aux, the
		// intersection between rect and limits, and fill with color, the final area.
		//----------------------------------------------------------------------------------
		SDL_Rect aux;
		Sint16 y2 = rect->y + rect->h;
		Sint16 x2 = rect->x + rect->w;
		Sint16 ly2 = limits->y + limits->h;
		Sint16 lx2 = limits->x + limits->w;

		//----------------------------------------------------------------------------------
		// To make this come true, we need to check the x, y coordinate, and the maximum
		// x, y coordinate, of rect with the same corners of limits. First we see the y
		// coordinate, then the maximum y coordinate. After this we make the same with the
		// x coordinate and the maximum x coordinate. If we see that it's imposible to make
		// any kind of intersection (rect and limits == 0), we get out the function.
		//----------------------------------------------------------------------------------
		if(rect->y < limits->y)
		{
			if(y2 < limits->y)
			{
				return;
			}
			else if(y2 < ly2)
			{
				if(rect->x < limits->x)
				{
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 < ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					if(x2 < limits->x)
					{
						return;
					}
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 < ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else if(x2 < lx2)
					{
						aux.y = limits->y;
						aux.h = y2 - limits->y;

						aux.x = limits->x;
						aux.w = x2 - limits->x;
					}
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 < ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else
					{
						aux.y = limits->y;
						aux.h = y2 - limits->y;

						aux.x = limits->x;
						aux.w = limits->w;
					}
				}
				else if(rect->x < lx2)
				{
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 < ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					if(x2 < lx2)
					{
						aux.y = limits->y;
						aux.h = y2 - limits->y;
						
						aux.x = rect->x;
						aux.w = rect->w;
					}
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 < ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					else
					{
						aux.y = limits->y;
						aux.h = y2 - limits->y;
						
						aux.x = rect->x;
						aux.w = lx2 - rect->x;
					}
				}
				else
				{
					return;
				}
			}
			else
			{
				if(rect->x < limits->x)
				{
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 > ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					if(x2 < limits->x)
					{
						return;
					}
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 > ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else if(x2 < lx2)
					{
						aux.y = limits->y;
						aux.h = limits->h;

						aux.x = limits->x;
						aux.w = x2 - limits->x;
					}
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 > ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else
					{
						aux.y = limits->y;
						aux.h = limits->h;

						aux.x = limits->x;
						aux.w = limits->w;
					}
				}
				else if(rect->x < lx2)
				{
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 > ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					if(x2 < lx2)
					{
						aux.y = limits->y;
						aux.h = limits->h;
						
						aux.x = rect->x;
						aux.w = rect->w;
					}
					//----------------------------------------------------------------------
					//(rect->y < limits->y)
					//(y2 > ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					else
					{
						aux.y = limits->y;
						aux.h = limits->h;
						
						aux.x = rect->x;
						aux.w = lx2 - rect->x;
					}
				}
				else
				{
					return;
				}
			}
		}
		else if(rect->y < ly2)
		{
			if(y2 < ly2)
			{
				if(rect->x < limits->x)
				{
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 < ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					if(x2 < limits->x)
					{
						return;
					}
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 < ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else if(x2 < lx2)
					{
						aux.y = rect->y;
						aux.h = rect->h;

						aux.x = limits->x;
						aux.w = x2 - limits->x;
					}
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 < ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else
					{
						aux.y = rect->y;
						aux.h = rect->h;

						aux.x = limits->x;
						aux.w = limits->w;
					}
				}
				else if(rect->x < lx2)
				{
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 < ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					if(x2 < lx2)
					{
						aux.y = rect->y;
						aux.h = rect->h;
						
						aux.x = rect->x;
						aux.w = rect->w;
					}
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 < ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					else
					{
						aux.y = rect->y;
						aux.h = rect->h;
						
						aux.x = rect->x;
						aux.w = lx2 - rect->x;
					}
				}
				else
				{
					return;
				}
			}
			else
			{
				if(rect->x < limits->x)
				{
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 > ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					if(x2 < limits->x)
					{
						return;
					}
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 > ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else if(x2 < lx2)
					{
						aux.y = rect->y;
						aux.h = ly2 - rect->y;

						aux.x = limits->x;
						aux.w = x2 - limits->x;
					}
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 > ly2)
					//(rect->x < limits->x)
					//----------------------------------------------------------------------
					else
					{
						aux.y = rect->y;
						aux.h = ly2 - rect->y;

						aux.x = limits->x;
						aux.w = limits->w;
					}
				}
				else if(rect->x < lx2)
				{
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 > ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					if(x2 < lx2)
					{
						aux.y = rect->y;
						aux.h = ly2 - rect->y;
						
						aux.x = rect->x;
						aux.w = rect->w;
					}
					//----------------------------------------------------------------------
					//(rect->y < ly2)
					//(y2 > ly2)
					//(rect->x < lx2)
					//----------------------------------------------------------------------
					else
					{
						aux.y = rect->y;
						aux.h = ly2 - rect->y;
						
						aux.x = rect->x;
						aux.w = lx2 - rect->x;
					}
				}
				else
				{
					return;
				}
			}
		}
		else
		{
			return;
		}

		//----------------------------------------------------------------------------------
		// If everything goes well, we finally fill the final rect stored in aux.
		//----------------------------------------------------------------------------------
		SDL_FillRect(dst, &aux, color);
	}
	
	//--------------------------------------------------------------------------------------
	/// Get the character in event from a spanish keyboard.
	//--------------------------------------------------------------------------------------
	char DLLAPI GetSpanishKBChar (SDL_keysym & event)
	{
		if(event.sym == Teclas::TECLA_RETROCESO)
		{
			return CHAR_DELETE;
		}
		else if(event.sym == Teclas::TECLA_ENTER)
		{
			return '\n';
		}
		else if(event.sym == Teclas::TECLA_TABULADOR)
		{
			return '\t';
		}
		else if(event.sym == Teclas::TECLA_ESPACIO)
		{
			return ' ';
		}
		else if((Teclas::TECLA_A <= event.sym) && (event.sym <= Teclas::TECLA_Z))
		{
			if(event.mod & (KMOD_CAPS | KMOD_RSHIFT | KMOD_LSHIFT))
				return (event.sym - Teclas::TECLA_A + 'A');
			else
				return (event.sym - Teclas::TECLA_A + 'a');
		}
		else if(event.sym == Teclas::TECLA_NY)
		{
			if(event.mod & (KMOD_CAPS | KMOD_RSHIFT | KMOD_LSHIFT))
				return '�';
			else
				return '�';
		}
		else if(event.sym == Teclas::TECLA_BARRAINV)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '�';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '\\';
			else
				return '�';
		}
		else if(event.sym == Teclas::TECLA_1)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '!';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '|';
			else
				return '1';
		}
		else if(event.sym == Teclas::TECLA_2)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '"';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '@';
			else
				return '2';
		}
		else if(event.sym == Teclas::TECLA_3)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '�';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '#';
			else
				return '3';
		}
		else if(event.sym == Teclas::TECLA_4)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '$';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '~';
			else
				return '4';
		}
		else if(event.sym == Teclas::TECLA_5)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '%';
			else
				return '5';
		}
		else if(event.sym == Teclas::TECLA_6)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '&';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '�';
			else
				return '6';
		}
		else if(event.sym == Teclas::TECLA_7)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '/';
			else
				return '7';
		}
		else if(event.sym == Teclas::TECLA_8)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '(';
			else
				return '8';
		}
		else if(event.sym == Teclas::TECLA_9)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return ')';
			else
				return '9';
		}
		else if(event.sym == Teclas::TECLA_0)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '=';
			else
				return '0';
		}
		else if(event.sym == Teclas::TECLA_APOSTROFE)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '?';
			else
				return '\'';
		}
		else if(event.sym == Teclas::TECLA_EXCLAMACION)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '�';
			else
				return '�';
		}
		else if(event.sym == Teclas::TECLA_ABRE_CORCHETE)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '^';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '[';
			else
				return '`';
		}
		else if(event.sym == Teclas::TECLA_CIERRA_CORCHETE)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '*';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return ']';
			else
				return '+';
		}
		else if(event.sym == Teclas::TECLA_ABRE_LLAVE)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '�';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '{';
			else
				return '�';
		}
		else if(event.sym == Teclas::TECLA_CIERRA_LLAVE)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '�';
			else if(((event.mod & KMOD_CTRL) && (event.mod & KMOD_LALT)) || (event.mod & KMOD_RALT))
				return '}';
			else
				return '�';
		}
		else if(event.sym == Teclas::TECLA_MENOR)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '>';
			else
				return '<';
		}
		else if(event.sym == Teclas::TECLA_COMA)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return ';';
			else
				return ',';
		}
		else if(event.sym == Teclas::TECLA_PUNTO)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return ':';
			else
				return '.';
		}
		else if(event.sym == Teclas::TECLA_MENOS)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '_';
			else
				return '-';
		}
		else if(event.sym == Teclas::TECLA_NUM_BARRA)
		{
			return '/';
		}
		else if(event.sym == Teclas::TECLA_NUM_ASTERISCO)
		{
			return '*';
		}
		else if(event.sym == Teclas::TECLA_NUM_MENOS)
		{
			return '-';
		}
		else if(event.sym == Teclas::TECLA_NUM_MAS)
		{
			return '+';
		}
		else if(event.sym == Teclas::TECLA_NUM_PUNTO)
		{
			return '.';
		}
		else if(event.sym == Teclas::TECLA_NUM_ENTER)
		{
			return '\n';
		}
		else if(event.sym == Teclas::TECLA_NUM_IGUAL)
		{
			return '=';
		}
		else if((Teclas::TECLA_NUM_0 <= event.sym) && (event.sym <= Teclas::TECLA_NUM_9))
		{
			return (event.sym - Teclas::TECLA_NUM_0 + '0');
		}
		else
		{
			return 0;
		}
	}

	//--------------------------------------------------------------------------------------
	/// Get the character in event from a english keyboard.
	//--------------------------------------------------------------------------------------
	char DLLAPI GetEnglishKBChar (SDL_keysym & event)
	{
		if(event.sym == Keys::KEY_BACKSPACE)
		{
			return CHAR_DELETE;
		}
		else if(event.sym == Keys::KEY_RETURN)
		{
			return '\n';
		}
		else if(event.sym == Keys::KEY_TAB)
		{
			return '\t';
		}
		else if(event.sym == Keys::KEY_SPACE)
		{
			return ' ';
		}
		else if((Keys::KEY_A <= event.sym) && (event.sym <= Keys::KEY_Z))
		{
			if(event.mod & (KMOD_CAPS | KMOD_RSHIFT | KMOD_LSHIFT))
				return (event.sym - Keys::KEY_A + 'A');
			else
				return (event.sym - Keys::KEY_A + 'a');
		}
		else if(event.sym == Keys::KEY_BACKQUOTE)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '~';
			else
				return '`';
		}
		else if(event.sym == Keys::KEY_1)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '!';
			else
				return '1';
		}
		else if(event.sym == Keys::KEY_2)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '@';
			else
				return '2';
		}
		else if(event.sym == Keys::KEY_3)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '#';
			else
				return '3';
		}
		else if(event.sym == Keys::KEY_4)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '$';
			else
				return '4';
		}
		else if(event.sym == Keys::KEY_5)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '%';
			else
				return '5';
		}
		else if(event.sym == Keys::KEY_6)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '^';
			else
				return '6';
		}
		else if(event.sym == Keys::KEY_7)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '&';
			else
				return '7';
		}
		else if(event.sym == Keys::KEY_8)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '*';
			else
				return '8';
		}
		else if(event.sym == Keys::KEY_9)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '(';
			else
				return '9';
		}
		else if(event.sym == Keys::KEY_0)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return ')';
			else
				return '0';
		}
		else if(event.sym == Keys::KEY_MINUS)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '_';
			else
				return '-';
		}
		else if(event.sym == Keys::KEY_EQUALS)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '+';
			else
				return '=';
		}
		else if(event.sym == Keys::KEY_LEFTBRACKET)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '{';
			else
				return '[';
		}
		else if(event.sym == Keys::KEY_RIGHTBRACKET)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '}';
			else
				return ']';
		}
		else if(event.sym == Keys::KEY_SEMICOLON)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return ':';
			else
				return ';';
		}
		else if(event.sym == Keys::KEY_QUOTE)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '"';
			else
				return '\'';
		}
		else if(event.sym == Keys::KEY_BACKSLASH)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '|';
			else
				return '\\';
		}
		else if(event.sym == Keys::KEY_COMMA)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '<';
			else
				return ',';
		}
		else if(event.sym == Keys::KEY_PERIOD)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '>';
			else
				return '.';
		}
		else if(event.sym == Keys::KEY_SLASH)
		{
			if(event.mod & (KMOD_RSHIFT | KMOD_LSHIFT))
				return '?';
			else
				return '/';
		}
		else if(event.sym == Keys::KEY_KP_DIVIDE)
		{
			return '/';
		}
		else if(event.sym == Keys::KEY_KP_MULTIPLY)
		{
			return '*';
		}
		else if(event.sym == Keys::KEY_KP_MINUS)
		{
			return '-';
		}
		else if(event.sym == Keys::KEY_KP_PLUS)
		{
			return '+';
		}
		else if(event.sym == Keys::KEY_KP_PERIOD)
		{
			return '.';
		}
		else if(event.sym == Keys::KEY_KP_ENTER)
		{
			return '\n';
		}
		else if(event.sym == Keys::KEY_KP_EQUALS)
		{
			return '=';
		}
		else if((Keys::KEY_KP0 <= event.sym) && (event.sym <= Keys::KEY_KP9))
		{
			return (event.sym - Keys::KEY_KP0 + '0');
		}
		else
		{
			return 0;
		}
	}
}
//******************************************************************************************
// Base.cpp
//******************************************************************************************