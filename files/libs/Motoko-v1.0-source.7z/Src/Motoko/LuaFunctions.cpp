//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Application.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// Global variables of the Lua section.
	//**************************************************************************************

		Application * appLuaRef = Application::GetInstance();

		stack<Control *> Controls;
		stack<Control *> LostControls;

		Control * ControlToCopy;


	//**************************************************************************************
	// Event functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Key up event for the control.
		//----------------------------------------------------------------------------------
		bool SDLKeyUpEvent (void * control, SDL_KeyboardEvent & event)
		{
			char buffer[300];
			Control * aux = (Control *) control;

			sprintf(buffer, "%s_KeyUpEvent(%d, %d, %d)", aux->GetName(),
					event.keysym.scancode, event.keysym.sym, event.keysym.mod);

			ExecString(buffer);

			return false;
		}

		//----------------------------------------------------------------------------------
		// Key down event for the control.
		//----------------------------------------------------------------------------------
		bool SDLKeyDownEvent (void * control, SDL_KeyboardEvent & event)
		{
			char buffer[300];
			Control * aux = (Control *) control;

			sprintf(buffer, "%s_KeyDownEvent(%d, %d, %d)", aux->GetName(),
					event.keysym.scancode, event.keysym.sym, event.keysym.mod);

			ExecString(buffer);

			return false;
		}

		//----------------------------------------------------------------------------------
		// Mouse motion event for the control.
		//----------------------------------------------------------------------------------
		bool SDLMouseMotionEvent (void * control, SDL_MouseMotionEvent & event)
		{
			char buffer[300];
			Control * aux = (Control *) control;

			sprintf(buffer, "%s_MouseMotionEvent(%d, %d, %d, %d, %d)", aux->GetName(),
					event.state, event.x, event.y, event.xrel, event.yrel);

			ExecString(buffer);

			return false;
		}

		//----------------------------------------------------------------------------------
		// Mouse button up event for the control.
		//----------------------------------------------------------------------------------
		void SDLMouseButtonUpEvent (void * control, SDL_MouseButtonEvent & event)
		{
			char buffer[300];
			Control * aux = (Control *) control;

			sprintf(buffer, "%s_MouseButtonUpEvent(%d, %d, %d)", aux->GetName(),
					event.button, event.x, event.y);

			ExecString(buffer);
		}

		//----------------------------------------------------------------------------------
		// Mouse button down event for the control.
		//----------------------------------------------------------------------------------
		void SDLMouseButtonDownEvent (void * control, SDL_MouseButtonEvent & event)
		{
			char buffer[300];
			Control * aux = (Control *) control;

			sprintf(buffer, "%s_MouseButtonDownEvent(%d, %d, %d)", aux->GetName(),
					event.button, event.x, event.y);

			ExecString(buffer);
		}

		//----------------------------------------------------------------------------------
		// Double click event for the control.
		//----------------------------------------------------------------------------------
		void SDLDoubleClickEvent (void * control)
		{
			char buffer[300];
			Control * aux = (Control *) control;

			sprintf(buffer, "%s_DoubleClickEvent()", aux->GetName());

			ExecString(buffer);
		}
		
		//----------------------------------------------------------------------------------
		// Key up event for the application.
		//----------------------------------------------------------------------------------
		bool AppKeyUpEvent (void * control, SDL_KeyboardEvent & event)
		{
			char buffer[300];
			sprintf(buffer, "Application_KeyUpEvent(%d, %d, %d)", event.keysym.scancode,
					event.keysym.sym, event.keysym.mod);

			ExecString(buffer);

			return false;
		}

		//----------------------------------------------------------------------------------
		// Key down event for the application.
		//----------------------------------------------------------------------------------
		bool AppKeyDownEvent (void * control, SDL_KeyboardEvent & event)
		{
			char buffer[300];
			sprintf(buffer, "Application_KeyDownEvent(%d, %d, %d)", event.keysym.scancode,
					event.keysym.sym, event.keysym.mod);

			ExecString(buffer);

			return false;
		}

		//----------------------------------------------------------------------------------
		// Mouse motion event for the application.
		//----------------------------------------------------------------------------------
		bool AppMouseMotionEvent (void * control, SDL_MouseMotionEvent & event)
		{
			char buffer[300];
			sprintf(buffer, "Application_MouseMotionEvent(%d, %d, %d, %d, %d)", event.state,
					event.x, event.y, event.xrel, event.yrel);

			ExecString(buffer);

			return false;
		}

		//----------------------------------------------------------------------------------
		// Mouse button up event for the application.
		//----------------------------------------------------------------------------------
		void AppMouseButtonUpEvent (void * control, SDL_MouseButtonEvent & event)
		{
			char buffer[300];
			sprintf(buffer, "Application_MouseButtonUpEvent(%d, %d, %d)", event.button,
					event.x, event.y);

			ExecString(buffer);
		}

		//----------------------------------------------------------------------------------
		// Mouse button down event for the application.
		//----------------------------------------------------------------------------------
		void AppMouseButtonDownEvent (void * control, SDL_MouseButtonEvent & event)
		{
			char buffer[300];
			sprintf(buffer, "Application_MouseButtonDownEvent(%d, %d, %d)", event.button,
					event.x, event.y);

			ExecString(buffer);
		}


	//**************************************************************************************
	// Application functions.
	//**************************************************************************************
		
		//----------------------------------------------------------------------------------
		// Application::List.AddControl.
		//----------------------------------------------------------------------------------
		static int Application_AddControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(appLuaRef->List.AddControl(aux) == RESULT_OK)
				{
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_AddControl'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Application::DialogList.AddControl.
		//----------------------------------------------------------------------------------
		static int Application_AddDialog (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Dialog * aux = (Dialog *) Controls.top();
				Controls.pop();

				if(appLuaRef->DialogList.AddControl(aux) == RESULT_OK)
				{
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_AddDialog'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Application::Config.
		//----------------------------------------------------------------------------------
		static int Application_Config (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1))
				{
					if(strcmp(lua_tostring(L, 1), "Title") == STR_EQU)
					{
						if(lua_isstring(L, 2))
						{
							CRM32Pro.Config.Title = (char *) lua_tostring(L, 2);
						}
						else
						{
							lua_pushstring(L, "'Title' it's a string in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "bMTFriendly") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.bMTFriendly = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'bMTFriendly' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "VideoRenderer") == STR_EQU)
					{
						if(lua_isstring(L, 2))
						{
							if(strcmp(lua_tostring(L, 2), "RENDER_DEFAULT") == STR_EQU)
								CRM32Pro.Config.VideoRenderer = RENDER_DEFAULT;
							else if(strcmp(lua_tostring(L, 2), "RENDER_WINDIB") == STR_EQU)
								CRM32Pro.Config.VideoRenderer = RENDER_WINDIB;
							else if(strcmp(lua_tostring(L, 2), "RENDER_DIRECTX") == STR_EQU)
								CRM32Pro.Config.VideoRenderer = RENDER_DIRECTX;
							else if(strcmp(lua_tostring(L, 2), "RENDER_X11") == STR_EQU)
								CRM32Pro.Config.VideoRenderer = RENDER_X11;
							else if(strcmp(lua_tostring(L, 2), "RENDER_FBCON") == STR_EQU)
								CRM32Pro.Config.VideoRenderer = RENDER_FBCON;
							else if(strcmp(lua_tostring(L, 2), "RENDER_DGA") == STR_EQU)
								CRM32Pro.Config.VideoRenderer = RENDER_DGA;
							else if(strcmp(lua_tostring(L, 2), "RENDER_OPENGL") == STR_EQU)
								CRM32Pro.Config.VideoRenderer = RENDER_OPENGL;
						}
						else
						{
							lua_pushstring(L, "'VideoRenderer' it's a string in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "VideoAccel") == STR_EQU)
					{
						if(lua_isstring(L, 2))
						{
							if(strcmp(lua_tostring(L, 2), "ACCEL_SOFTWARE") == STR_EQU)
								CRM32Pro.Config.VideoAccel = ACCEL_SOFTWARE;
							else if(strcmp(lua_tostring(L, 2), "ACCEL_HARDSMOOTH") == STR_EQU)
								CRM32Pro.Config.VideoAccel = ACCEL_HARDSMOOTH;
							else if(strcmp(lua_tostring(L, 2), "ACCEL_HARDSPEED") == STR_EQU)
								CRM32Pro.Config.VideoAccel = ACCEL_HARDSPEED;
						}
						else
						{
							lua_pushstring(L, "'VideoAccel' it's a string in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "VideoWindow") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.VideoWindow = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'VideoWindow' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "VideoBPP") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.VideoBPP = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'VideoBPP' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "VideoWidth") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.VideoWidth = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'VideoWidth' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "VideoHeight") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.VideoHeight = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'VideoHeight' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "AudioEnable") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.AudioEnable = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'AudioEnable' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "AudioFormat") == STR_EQU)
					{
						if(lua_isstring(L, 2))
						{
							if(strcmp(lua_tostring(L, 2), "AUDIO_S8") == STR_EQU)
								CRM32Pro.Config.AudioFormat = AUDIO_S8;
							else if(strcmp(lua_tostring(L, 2), "AUDIO_S16") == STR_EQU)
								CRM32Pro.Config.AudioFormat = AUDIO_S16;
						}
						else
						{
							lua_pushstring(L, "'AudioFormat' it's a string in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "AudioFreq") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.AudioFreq = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'AudioFreq' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "AudioMode") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.AudioMode = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'AudioMode' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "AudioBuffer") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.AudioBuffer = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'AudioBuffer' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "AudioMusicVol") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.AudioMusicVol = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'AudioMusicVol' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
					else if(strcmp(lua_tostring(L, 1), "AudioSoundVol") == STR_EQU)
					{
						if(lua_isnumber(L, 2))
						{
							CRM32Pro.Config.AudioSoundVol = lua_tointeger(L, 2);
						}
						else
						{
							lua_pushstring(L, "'AudioSoundVol' it's a number in the function 'Application_Config'.");
							lua_error(L);
						}
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Config'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_Config'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::Init.
		//----------------------------------------------------------------------------------
		static int Application_Init (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else if(numargs == 3)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else if(numargs == 4)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3),
													   lua_tointeger(L, 4));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else if(numargs == 5)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) &&
				   lua_isboolean(L, 5))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3),
													   lua_tointeger(L, 4), (lua_toboolean(L, 5) ? true : false));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else if(numargs == 6)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) &&
				   lua_isboolean(L, 5) && lua_isnumber(L, 6))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3),
													   lua_tointeger(L, 4), (lua_toboolean(L, 5) ? true : false),
													   lua_tointeger(L, 6));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else if(numargs == 7)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) &&
				   lua_isboolean(L, 5) && lua_isnumber(L, 6) && lua_isnumber(L, 7))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3),
													   lua_tointeger(L, 4), (lua_toboolean(L, 5) ? true : false),
													   lua_tointeger(L, 6), lua_tointeger(L, 7));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else if(numargs == 8)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) &&
				   lua_isboolean(L, 5) && lua_isnumber(L, 6) && lua_isnumber(L, 7) && lua_isnumber(L, 8))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3),
													   lua_tointeger(L, 4), (lua_toboolean(L, 5) ? true : false),
													   lua_tointeger(L, 6), lua_tointeger(L, 7), lua_tointeger(L, 8));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else if(numargs == 9)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) &&
				   lua_isboolean(L, 5) && lua_isnumber(L, 6) && lua_isnumber(L, 7) && lua_isnumber(L, 8) &&
				   lua_isnumber(L, 9))
				{
					appLuaRef->Error = appLuaRef->Init(lua_tostring(L, 1), lua_tointeger(L, 2), lua_tointeger(L, 3),
													   lua_tointeger(L, 4), (lua_toboolean(L, 5) ? true : false),
													   lua_tointeger(L, 6), lua_tointeger(L, 7), lua_tointeger(L, 8),
													   lua_tointeger(L, 9));
					lua_pushnumber(L, appLuaRef->Error);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Init'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_Init'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::Release.
		//----------------------------------------------------------------------------------
		static int Application_Release (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->Release();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_Release'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::PushUpDialog.
		//----------------------------------------------------------------------------------
		static int Application_PushUpDialog (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					Dialog * aux = (Dialog *) appLuaRef->DialogList.GetControl(lua_tostring(L, 1));

					if(aux != NULL)
					{
						appLuaRef->PushUpDialog(aux);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_PushUpDialog'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_PushUpDialog'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::Exit.
		//----------------------------------------------------------------------------------
		static int Application_Exit (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->Exit();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_Exit'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::GetTime.
		//----------------------------------------------------------------------------------
		static int Application_GetTime (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushnumber(L, appLuaRef->GetTime());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetTime'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::Delay.
		//----------------------------------------------------------------------------------
		static int Application_Delay (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					appLuaRef->Delay(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_Delay'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_Delay'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int Application_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->SetKeyDown(AppKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int Application_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->SetKeyUp(AppKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int Application_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->SetMouseMotion(AppMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int Application_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->SetMouseButtonDown(AppMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int Application_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->SetMouseButtonUp(AppMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int Application_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushlightuserdata(L, appLuaRef->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetTitle.
		//----------------------------------------------------------------------------------
		static int Application_GetTitle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushstring(L, appLuaRef->GetTitle());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetTitle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetIcon.
		//----------------------------------------------------------------------------------
		static int Application_GetIcon (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushstring(L, appLuaRef->GetIcon());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetIcon'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetRenderBack.
		//----------------------------------------------------------------------------------
		static int Application_GetRenderBack (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushboolean(L, appLuaRef->GetRenderBack());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetRenderBack'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetPicture.
		//----------------------------------------------------------------------------------
		static int Application_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushlightuserdata(L, appLuaRef->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetActRect.
		//----------------------------------------------------------------------------------
		static int Application_GetActRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushinteger(L, appLuaRef->GetActRect()->x);
				lua_pushinteger(L, appLuaRef->GetActRect()->y);
				lua_pushinteger(L, appLuaRef->GetActRect()->w);
				lua_pushinteger(L, appLuaRef->GetActRect()->h);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetActRect'.");
				lua_error(L);
			}

			return 4;
		}

		//----------------------------------------------------------------------------------
		// Application::GetBackColor.
		//----------------------------------------------------------------------------------
		static int Application_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_tointeger(L, appLuaRef->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetQuit.
		//----------------------------------------------------------------------------------
		static int Application_GetQuit (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushboolean(L, appLuaRef->GetQuit());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetQuit'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetActiveControl.
		//----------------------------------------------------------------------------------
		static int Application_GetActiveControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = appLuaRef->GetActiveControl();
				
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetActiveControl'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetInterval.
		//----------------------------------------------------------------------------------
		static int Application_GetInterval (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushnumber(L, appLuaRef->GetInterval());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetInterval'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetWidth.
		//----------------------------------------------------------------------------------
		static int Application_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushnumber(L, appLuaRef->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::GetHeight.
		//----------------------------------------------------------------------------------
		static int Application_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				lua_pushnumber(L, appLuaRef->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Application::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int Application_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetTitle.
		//----------------------------------------------------------------------------------
		static int Application_SetTitle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->SetTitle(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetTitle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetTitle'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetIcon.
		//----------------------------------------------------------------------------------
		static int Application_SetIcon (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->SetIcon(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetIcon'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetIcon'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetRenderBack.
		//----------------------------------------------------------------------------------
		static int Application_SetRenderBack (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					appLuaRef->SetRenderBack(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetRenderBack'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetRenderBack'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetPicture.
		//----------------------------------------------------------------------------------
		static int Application_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetActRect.
		//----------------------------------------------------------------------------------
		static int Application_SetActRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					appLuaRef->SetActRect(&raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetActRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetActRect'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetBackColor.
		//----------------------------------------------------------------------------------
		static int Application_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					appLuaRef->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::SetInterval.
		//----------------------------------------------------------------------------------
		static int Application_SetInterval (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					appLuaRef->SetInterval(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Application_SetInterval'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_SetInterval'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Application::NoActiveControl.
		//----------------------------------------------------------------------------------
		static int Application_NoActiveControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->NoActiveControl();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Application_NoActiveControl'.");
				lua_error(L);
			}

			return 0;
		}


	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************

		DLLAPI void RegisterLuaFUtil           (lua_State * L);
		DLLAPI void RegisterLuaFComboBox       (lua_State * L);
		DLLAPI void RegisterLuaFControlListBox (lua_State * L);
		DLLAPI void RegisterLuaFLabelBox       (lua_State * L);
		DLLAPI void RegisterLuaFListBox        (lua_State * L);
		DLLAPI void RegisterLuaFPictureBox     (lua_State * L);
		DLLAPI void RegisterLuaFTextBox        (lua_State * L);
		DLLAPI void RegisterLuaFHScrollBar     (lua_State * L);
		DLLAPI void RegisterLuaFVScrollBar     (lua_State * L);
		DLLAPI void RegisterLuaFButton         (lua_State * L);
		DLLAPI void RegisterLuaFCheckButton    (lua_State * L);
		DLLAPI void RegisterLuaFPanel          (lua_State * L);
		DLLAPI void RegisterLuaFDialog         (lua_State * L);

		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterMotoko (void)
		{
			ControlToCopy = NULL;

			//------------------------------------------------------------------------------
			// Register functions.
			//------------------------------------------------------------------------------
			RegisterLuaFUtil(appLuaRef->GetLua());
			RegisterLuaFComboBox(appLuaRef->GetLua());
			RegisterLuaFControlListBox(appLuaRef->GetLua());
			RegisterLuaFLabelBox(appLuaRef->GetLua());
			RegisterLuaFListBox(appLuaRef->GetLua());
			RegisterLuaFPictureBox(appLuaRef->GetLua());
			RegisterLuaFTextBox(appLuaRef->GetLua());
			RegisterLuaFHScrollBar(appLuaRef->GetLua());
			RegisterLuaFVScrollBar(appLuaRef->GetLua());
			RegisterLuaFButton(appLuaRef->GetLua());
			RegisterLuaFCheckButton(appLuaRef->GetLua());
			RegisterLuaFPanel(appLuaRef->GetLua());
			RegisterLuaFDialog(appLuaRef->GetLua());
			
			//------------------------------------------------------------------------------
			// Application functions.
			//------------------------------------------------------------------------------
			lua_register(appLuaRef->GetLua(), "Application_AddControl",         Application_AddControl);
			lua_register(appLuaRef->GetLua(), "Application_AddDialog",          Application_AddDialog);
			lua_register(appLuaRef->GetLua(), "Application_Config",             Application_Config);
			lua_register(appLuaRef->GetLua(), "Application_Init",               Application_Init);
			lua_register(appLuaRef->GetLua(), "Application_Release",            Application_Release);
			lua_register(appLuaRef->GetLua(), "Application_PushUpDialog",       Application_PushUpDialog);
			lua_register(appLuaRef->GetLua(), "Application_Exit",               Application_Exit);
			lua_register(appLuaRef->GetLua(), "Application_GetTime",            Application_GetTime);
			lua_register(appLuaRef->GetLua(), "Application_Delay",              Application_Delay);
			lua_register(appLuaRef->GetLua(), "Application_SetKeyDown",         Application_SetKeyDown);
			lua_register(appLuaRef->GetLua(), "Application_SetKeyUp",           Application_SetKeyUp);
			lua_register(appLuaRef->GetLua(), "Application_SetMouseMotion",     Application_SetMouseMotion);
			lua_register(appLuaRef->GetLua(), "Application_SetMouseButtonDown", Application_SetMouseButtonDown);
			lua_register(appLuaRef->GetLua(), "Application_SetMouseButtonUp",   Application_SetMouseButtonUp);
			lua_register(appLuaRef->GetLua(), "Application_GetMousePointer",    Application_GetMousePointer);
			lua_register(appLuaRef->GetLua(), "Application_GetTitle",           Application_GetTitle);
			lua_register(appLuaRef->GetLua(), "Application_GetIcon",            Application_GetIcon);
			lua_register(appLuaRef->GetLua(), "Application_GetRenderBack",      Application_GetRenderBack);
			lua_register(appLuaRef->GetLua(), "Application_GetPicture",         Application_GetPicture);
			lua_register(appLuaRef->GetLua(), "Application_GetActRect",         Application_GetActRect);
			lua_register(appLuaRef->GetLua(), "Application_GetBackColor",       Application_GetBackColor);
			lua_register(appLuaRef->GetLua(), "Application_GetQuit",            Application_GetQuit);
			lua_register(appLuaRef->GetLua(), "Application_GetActiveControl",   Application_GetActiveControl);
			lua_register(appLuaRef->GetLua(), "Application_GetInterval",        Application_GetInterval);
			lua_register(appLuaRef->GetLua(), "Application_GetWidth",           Application_GetWidth);
			lua_register(appLuaRef->GetLua(), "Application_GetHeight",          Application_GetHeight);
			lua_register(appLuaRef->GetLua(), "Application_SetMousePointer",    Application_SetMousePointer);
			lua_register(appLuaRef->GetLua(), "Application_SetTitle",           Application_SetTitle);
			lua_register(appLuaRef->GetLua(), "Application_SetIcon",            Application_SetIcon);
			lua_register(appLuaRef->GetLua(), "Application_SetRenderBack",      Application_SetRenderBack);
			lua_register(appLuaRef->GetLua(), "Application_SetPicture",         Application_SetPicture);
			lua_register(appLuaRef->GetLua(), "Application_SetActRect",         Application_SetActRect);
			lua_register(appLuaRef->GetLua(), "Application_SetBackColor",       Application_SetBackColor);
			lua_register(appLuaRef->GetLua(), "Application_SetInterval",        Application_SetInterval);
			lua_register(appLuaRef->GetLua(), "Application_NoActiveControl",    Application_NoActiveControl);
		}

		//----------------------------------------------------------------------------------
		// This function register a C function.
		//----------------------------------------------------------------------------------
		inline DLLAPI void Register (const char * name, lua_CFunction func)
		{
			lua_register(appLuaRef->GetLua(), name, func);
		}

		//----------------------------------------------------------------------------------
		// This function execute a lua script stored in a string.
		//----------------------------------------------------------------------------------
		inline DLLAPI void ExecString (const char * str)
		{
			luaL_dostring(appLuaRef->GetLua(), str);
		}

		//----------------------------------------------------------------------------------
		// This function execute a lua script stored in a file.
		//----------------------------------------------------------------------------------
		inline DLLAPI void ExecFile (const char * file)
		{
			luaL_dofile(appLuaRef->GetLua(), file);
		}

		//----------------------------------------------------------------------------------
		// This function execute a lua script stored in a file.
		//----------------------------------------------------------------------------------
		DLLAPI void ExecFile (const char * file, const char * fileDPF)
		{
			int id = IStuffDPF->Open((char *) fileDPF);

			if(id)
			{
				DPF_BlockData * luadata = new DPF_BlockData;
				string str = "";

				IStuffDPF->LoadBlock(id, "FILE", (char *) file, luadata);

				for(int i = 0; i < luadata->size; ++i)
				{
					str += luadata->data[i];
				}

				luaL_dostring(appLuaRef->GetLua(), str.c_str());

				IStuffDPF->FreeBlock(luadata);
				IStuffDPF->Close(id);
			}
		}
	}
}
//******************************************************************************************
// LuaFunctions.cpp
//******************************************************************************************