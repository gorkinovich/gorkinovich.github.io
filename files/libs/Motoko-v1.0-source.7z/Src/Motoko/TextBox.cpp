//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Application.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define BLINK_INTERVAL  500
#define SCROLLBARS_SIZE 20
#define SCB_LARGECHANGE 10
#define SCROLL_FACTOR   10
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	Application * appTextBoxRef = Application::GetInstance();

	//--------------------------------------------------------------------------------------
	/**
	 *  TextBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	TextBox::TextBox () : Box(), ITextControl()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "TextBox";

		HBar = new HScrollBar();
		VBar = new VScrollBar();

		string aux;

		aux = Name + "_HBar"; HBar->SetName(aux.c_str());
		aux = Name + "_VBar"; VBar->SetName(aux.c_str());

		HBar->SetLargeChange(SCB_LARGECHANGE);
		VBar->SetLargeChange(SCB_LARGECHANGE);
		
		HBar->SetMin(0);
		HBar->SetMax(0);
		HBar->SetValue(0);
		
		VBar->SetMin(0);
		VBar->SetMax(0);
		VBar->SetValue(0);

		TextRect   = Rect;
		Time       = appTextBoxRef->GetTime();
		TimeAcum   = 0;
		ShowCursor = false;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Locked     = false;
		MultiLine  = false;
		MaxLength  = NO_LIMIT;
		ScrollBars = NoneScrollBars;
		Language   = SpanishLanguage;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  TextBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	TextBox::TextBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					  Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
					  ControlSkin * appearance, SDL_Surface * picture,
					  SDL_Surface * mousepointer, AlignmentStyle alignment, 
					  bool locked, bool multiline, int maxlen, ControlScrollBars scrollbars,
					  KeyboardLanguage language, bool transparency, bool enable, bool visible) :
		Box(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
			transparency, enable, visible),
		ITextControl(text, font, alignment)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "TextBox";

		HBar = new HScrollBar();
		VBar = new VScrollBar();

		string aux;

		aux = Name + "_HBar"; HBar->SetName(aux.c_str());
		aux = Name + "_VBar"; VBar->SetName(aux.c_str());
		
		HBar->SetLargeChange(SCB_LARGECHANGE);
		VBar->SetLargeChange(SCB_LARGECHANGE);
				
		HBar->SetMin(0);
		HBar->SetMax(0);
		HBar->SetValue(0);
		
		VBar->SetMin(0);
		VBar->SetMax(0);
		VBar->SetValue(0);

		TextRect   = Rect;
		Time       = appTextBoxRef->GetTime();
		TimeAcum   = 0;
		ShowCursor = false;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Locked     = locked;
		MultiLine  = multiline;
		MaxLength  = maxlen;
		ScrollBars = scrollbars;
		Language   = language;

		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  TextBox copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	TextBox::TextBox (const TextBox & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  TextBox operator =.
	 */
	//--------------------------------------------------------------------------------------
	TextBox & TextBox::operator = (const TextBox & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  TextBox destructor.
	 */
	//--------------------------------------------------------------------------------------
	TextBox::~TextBox ()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		delete HBar;
		delete VBar;

		TextRect.x = 0;
		TextRect.y = 0;
		TextRect.w = 0;
		TextRect.h = 0;
		
		Time       = 0;
		TimeAcum   = 0;
		ShowCursor = false;
		
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Locked     = false;
		MultiLine  = false;
		MaxLength  = NO_LIMIT;
		ScrollBars = NoneScrollBars;
		Language   = SpanishLanguage;
	}
	
	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void TextBox::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		//----------------------------------------------------------------------------------
		// If the control isn't locked, and this text box is the current active control,
		// we will check if we have to show or hide the cursor of the text.
		//----------------------------------------------------------------------------------
		if(!Locked && (appTextBoxRef->GetActiveControl() == this))
		{
			//------------------------------------------------------------------------------
			// First we need to get how much time have been passed since the last draw.
			//------------------------------------------------------------------------------
			int acttime = appTextBoxRef->GetTime();
			TimeAcum += (acttime - Time);
			Time = acttime;

			//------------------------------------------------------------------------------
			// Second if the cursor is hidden, and the accumulated time is greater than the
			// blink interval, we will add the cursor to the text.
			//------------------------------------------------------------------------------
			if(!ShowCursor && (TimeAcum > BLINK_INTERVAL))
			{
				Text += "|";
				TimeAcum = 0;
				ShowCursor = !ShowCursor;
			}
			//------------------------------------------------------------------------------
			// And third if the cursor is showed, and the accumulated time is greater than
			// the blink interval, we will remove the cursor from the text.
			//------------------------------------------------------------------------------
			else if(ShowCursor && (TimeAcum > BLINK_INTERVAL))
			{
				Text.erase(Text.size() - 1, 1);
				TimeAcum = 0;
				ShowCursor = !ShowCursor;
			}
		}
		//----------------------------------------------------------------------------------
		// If the cursor is visible now, we'll hide it, erasing it from the text.
		//----------------------------------------------------------------------------------
		else if(ShowCursor)
		{
			Text.erase(Text.size() - 1, 1);
			TimeAcum = 0;
			ShowCursor = !ShowCursor;
		}

		//----------------------------------------------------------------------------------
		// Paint the box of the control.
		//----------------------------------------------------------------------------------
		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned textbox.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, the function will fill the control
			// with the BackColor (if the transparency isn't true), and after that will
			// draw the surface inside the variable Picture.
			//------------------------------------------------------------------------------
			if(Appearance == NULL)
			{
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

				if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			}
			//------------------------------------------------------------------------------
			// But if we have a skin, we'll draw a filled box.
			//------------------------------------------------------------------------------
			else
			{
				int i;

				//--------------------------------------------------------------------------
				// We read the rects before the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = 0; i < CENTER_BOX_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// If the transparency is false, we'll fill the center rect with BackColor.
				//--------------------------------------------------------------------------
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER_BOX_RECT]), BackColor);

				//--------------------------------------------------------------------------
				// We read the rects after the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER_BOX_RECT + 1; i < MAX_BOX_RECTS; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, we'll draw this using the back color.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, we'll draw this using the surface in Picture.
		//----------------------------------------------------------------------------------
		case UsePicture:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);

			break;
		}
		
		//----------------------------------------------------------------------------------
		// And now we'll draw the text, but we need to check if the text is multi-line.
		//----------------------------------------------------------------------------------
		if(MultiLine)
		{
			int x = 1;
			int y = 1;

			switch(ScrollBars)
			{
			//------------------------------------------------------------------------------
			// If we have the both scrollbars, we'll draw the text with the function
			// DrawTextMultiline2, and we'll draw the two scrollbars of the textbox.
			//------------------------------------------------------------------------------
			case BothScrollBars:
				DrawTextMultiline2(CRM32Pro.screen, TextRect.x - HBar->GetValue() * SCROLL_FACTOR,
								   TextRect.y - VBar->GetValue() * SCROLL_FACTOR, &TextRect);
				HBar->Draw();
				VBar->Draw();
				break;

			//------------------------------------------------------------------------------
			// If we have the horizontal scrollbar, we'll draw the text with the function
			// DrawTextMultiline2, and we'll draw only the horizontal scrollbar.
			//------------------------------------------------------------------------------
			case OnlyHScrollBars:
				DrawTextMultiline2(CRM32Pro.screen, TextRect.x - HBar->GetValue() * SCROLL_FACTOR,
								   TextRect.y - VBar->GetValue() * SCROLL_FACTOR, &TextRect);
				HBar->Draw();
				break;

			//------------------------------------------------------------------------------
			// If we have the vertical scrollbar, we'll draw the text with the function
			// DrawTextMultiline, and we'll draw only the vertical scrollbar.
			//------------------------------------------------------------------------------
			case OnlyVScrollBars:
				DrawTextMultiline(CRM32Pro.screen, TextRect.y - VBar->GetValue() * SCROLL_FACTOR, &TextRect);
				VBar->Draw();
				break;

			//------------------------------------------------------------------------------
			// If we have no scrollbar, we'll draw the text with DrawTextMultiline.
			//------------------------------------------------------------------------------
			case NoneScrollBars:
				DrawTextMultiline(CRM32Pro.screen, TextRect.y - VBar->GetValue() * SCROLL_FACTOR, &TextRect);
				break;
			}
		}
		//----------------------------------------------------------------------------------
		// If the textbox isn't multi-line, we will use DrawText2 to draw the text.
		//----------------------------------------------------------------------------------
		else
		{
			DrawText2(CRM32Pro.screen, TextRect.y, &TextRect);
		}

	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool TextBox::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		//----------------------------------------------------------------------------------
		// We pass the event to the scrollbars to see if they catch any event.
		//----------------------------------------------------------------------------------
		if(HBar->Update(event)) return true;
		if(VBar->Update(event)) return true;

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// If the textbox isn't the active control, and we make click on it, we'll
				// send the signal to get the focus in the application.
				//--------------------------------------------------------------------------
				if((appTextBoxRef->GetActiveControl() != this) && ((event.button.button == SDL_BUTTON_LEFT) ||
					(event.button.button == SDL_BUTTON_RIGHT) || (event.button.button == SDL_BUTTON_MIDDLE)))
				{
					GetFocus();
				}

				//--------------------------------------------------------------------------
				// If we have a multi-line textbox we can check if the wheel of the mouse
				// have been pressed, to move the vertical scrollbar, and move the text.
				//--------------------------------------------------------------------------
				if(MultiLine)
				{
					if(event.button.button == SDL_BUTTON_WHEELUP)
					{
						VBar->SetValue(VBar->GetValue() - VBar->GetSmallChange());
					}
					else if(event.button.button == SDL_BUTTON_WHEELDOWN)
					{
						VBar->SetValue(VBar->GetValue() + VBar->GetSmallChange());
					}
				}

				//--------------------------------------------------------------------------
				// And if MouseButtonDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			//------------------------------------------------------------------------------
			// If the textbox isn't locked, and the active control is this textbox, we'll
			// get the pressed key from the key down event, and add it to the text.
			//------------------------------------------------------------------------------
			if(!Locked && (appTextBoxRef->GetActiveControl() == this))
			{
				//--------------------------------------------------------------------------
				// If the cursor is showed, we must to erase it from the text.
				//--------------------------------------------------------------------------
				if(ShowCursor)
				{
					Text.erase(Text.size() - 1, 1);
					TimeAcum = 0;
					ShowCursor = !ShowCursor;
				}

				//--------------------------------------------------------------------------
				// Then we must transform the value from the event in a character.
				//--------------------------------------------------------------------------
				char character[2];
				character[1] = 0;

				switch(Language)
				{
				case EnglishLanguage:
					character[0] = GetEnglishKBChar(event.key.keysym);
					break;

				case SpanishLanguage:
					character[0] = GetSpanishKBChar(event.key.keysym);
					break;
				}

				//--------------------------------------------------------------------------
				// If the returned character is not zero, we can have some options.
				//--------------------------------------------------------------------------
				if(character[0])
				{
					//----------------------------------------------------------------------
					// If the character is the backspace key, we'll erase the last
					// character in the text of the textbox.
					//----------------------------------------------------------------------
					if(character[0] == CHAR_DELETE)
					{
						Text.erase(Text.size() - 1, 1);
					}
					//----------------------------------------------------------------------
					// If the character is the return key, we'll add a '\n' in the text of
					// the textbox, only if this textbox is a multi-line one.
					//----------------------------------------------------------------------
					else if(character[0] == '\n')
					{
						if(MultiLine) AddText(character[0]);
					}
					//----------------------------------------------------------------------
					// Any other character will be checked to see if it's supported by the
					// actual font, if it's a valid character we'll add it to the text.
					//----------------------------------------------------------------------
					else if(Font->StringWidth(character) > 0)
					{
						AddText(character[0]);
					}
					
					//----------------------------------------------------------------------
					// And after any change we will update the scrollbars of the textbox.
					//----------------------------------------------------------------------
					UpdateValues();
				}
				
				//--------------------------------------------------------------------------
				// And if KeyDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(KeyDown != NULL)
					KeyDown((void *) this, event.key);

				return true;
			}
			else
			{
				//--------------------------------------------------------------------------
				// And if KeyDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(KeyDown != NULL)
					return KeyDown((void *) this, event.key);
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	TextBox & TextBox::CopyFrom (const TextBox & obj)
	{
		Box::CopyFrom(obj);

		ITextControl::CopyFrom(obj);

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		HBar->CopyFrom(*(obj.HBar));
		VBar->CopyFrom(*(obj.VBar));

		TextRect   = obj.TextRect;
		Time       = obj.Time;
		TimeAcum   = obj.TimeAcum;
		ShowCursor = obj.ShowCursor;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Locked     = obj.Locked;
		MultiLine  = obj.MultiLine;
		MaxLength  = obj.MaxLength;
		ScrollBars = obj.ScrollBars;
		Language   = obj.Language;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the values of the scrollbars.
	//--------------------------------------------------------------------------------------
	void TextBox::UpdateValues (void)
	{
		//----------------------------------------------------------------------------------
		// This function is to update the scrollbars of a multi-line textbox.
		//----------------------------------------------------------------------------------
		if(!MultiLine) return;

		int MaxWidth;
		int Lines;
		
		switch(ScrollBars)
		{
		//----------------------------------------------------------------------------------
		// If we have the both scrollbars, we'll calculate the maximum width of the text,
		// and the minimum number of lines of the text, setting visible both scrollbars.
		//----------------------------------------------------------------------------------
		case BothScrollBars:
			HBar->SetVisible(true);
			VBar->SetVisible(true);

			MaxWidth = (GetMaxWidth() - TextRect.w) / SCROLL_FACTOR + 2;
			Lines    = (GetMinNumLines() - TextRect.h) / SCROLL_FACTOR + 1;

			HBar->SetMax((MaxWidth > 0) ? MaxWidth : 0);
			VBar->SetMax((Lines    > 0) ? Lines    : 0);
			break;

		//----------------------------------------------------------------------------------
		// If we have the horizontal scrollbar, we'll calculate the text's maximum width,
		// and the text's minimum number of lines, setting visible the horizontal scrollbar.
		//----------------------------------------------------------------------------------
		case OnlyHScrollBars:
			HBar->SetVisible(true);
			VBar->SetVisible(false);

			MaxWidth = (GetMaxWidth() - TextRect.w) / SCROLL_FACTOR + 2;
			Lines    = (GetMinNumLines() - TextRect.h) / SCROLL_FACTOR + 1;

			HBar->SetMax((MaxWidth > 0) ? MaxWidth : 0);
			VBar->SetMax((Lines    > 0) ? Lines    : 0);
			break;

		//----------------------------------------------------------------------------------
		// If we have the vertical scrollbar, we'll calculate the text's maximum number of
		// lines, setting visible the vertical scrollbar.
		//----------------------------------------------------------------------------------
		case OnlyVScrollBars:
			HBar->SetVisible(false);
			VBar->SetVisible(true);

			Lines = (GetMaxNumLines(&TextRect) - TextRect.h) / SCROLL_FACTOR + 1;

			HBar->SetMax(0);
			VBar->SetMax((Lines > 0) ? Lines : 0);
			break;

		//----------------------------------------------------------------------------------
		// If we have no scrollbar, we'll calculate the text's maximum number of lines.
		//----------------------------------------------------------------------------------
		case NoneScrollBars:
			HBar->SetVisible(false);
			VBar->SetVisible(false);

			Lines = (GetMaxNumLines(&TextRect) - TextRect.h) / SCROLL_FACTOR + 1;

			HBar->SetMax(0);
			VBar->SetMax((Lines > 0) ? Lines : 0);
			break;
		}

		//----------------------------------------------------------------------------------
		// And finally we set the current value of both scrollbars.
		//----------------------------------------------------------------------------------
		VBar->SetValue(VBar->GetMax());
		HBar->SetValue((GetWidthLastLine() - TextRect.w) / SCROLL_FACTOR + SCROLL_FACTOR);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void TextBox::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we call the UpdateRects function of the Box class.
		//----------------------------------------------------------------------------------
		Box::UpdateRects();

		//----------------------------------------------------------------------------------
		// Second we check if the control have any correct skin, setting the text's area
		// with the area of the box's center rect, if we have a skin in the control.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_BOX_RECTS))
			TextRect = Rect;
		else
			TextRect = Rects[CENTER_BOX_RECT];
		
		//----------------------------------------------------------------------------------
		// If the textbox isn't multi-line we exit here from the function.
		//----------------------------------------------------------------------------------
		if(!MultiLine) return;

		SDL_Rect aux;

		switch(ScrollBars)
		{
		//----------------------------------------------------------------------------------
		// If we have the both scrollbars, we'll adjust the area of the text, and will set
		// the position and size of both scrollbars.
		//----------------------------------------------------------------------------------
		case BothScrollBars:
			TextRect.h -= SCROLLBARS_SIZE;
			TextRect.w -= SCROLLBARS_SIZE;

			aux.x = TextRect.x;
			aux.y = TextRect.y + TextRect.h;
			aux.w = TextRect.w;
			aux.h = SCROLLBARS_SIZE;
			HBar->SetRect(aux);

			aux.x = TextRect.x + TextRect.w;
			aux.y = TextRect.y;
			aux.w = SCROLLBARS_SIZE;
			aux.h = TextRect.h + SCROLLBARS_SIZE;
			VBar->SetRect(aux);
			break;

		//----------------------------------------------------------------------------------
		// If we have the horizontal scrollbar, we'll adjust the area of the text, and will
		// set the position and size of the horizontal scrollbar.
		//----------------------------------------------------------------------------------
		case OnlyHScrollBars:
			TextRect.h -= SCROLLBARS_SIZE;

			aux.x = TextRect.x;
			aux.y = TextRect.y + TextRect.h;
			aux.w = TextRect.w;
			aux.h = SCROLLBARS_SIZE;
			HBar->SetRect(aux);
			break;

		//----------------------------------------------------------------------------------
		// If we have the vertical scrollbar, we'll adjust the area of the text, and will
		// set the position and size of the vertical scrollbar.
		//----------------------------------------------------------------------------------
		case OnlyVScrollBars:
			TextRect.w -= SCROLLBARS_SIZE;

			aux.x = TextRect.x + TextRect.w;
			aux.y = TextRect.y;
			aux.w = SCROLLBARS_SIZE;
			aux.h = TextRect.h;
			VBar->SetRect(aux);
			break;
		}

		//----------------------------------------------------------------------------------
		// And after all we will update the values of the textbox's scrollbars.
		//----------------------------------------------------------------------------------
		UpdateValues();
	}
}
//******************************************************************************************
// LabelBox.cpp
//******************************************************************************************