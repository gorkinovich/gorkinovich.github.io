//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// PictureBox functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// PictureBox::CopyFrom.
		//----------------------------------------------------------------------------------
		static int PictureBox_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				PictureBox * src = (PictureBox *) ControlToCopy;

				if(Controls.size() > 0)
				{
					PictureBox * dst = (PictureBox *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetDoubleClick.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetDoubleClick (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->SetDoubleClick(SDLDoubleClickEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetDoubleClick'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Box functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// PictureBox::UpdateRects.
		//----------------------------------------------------------------------------------
		static int PictureBox_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetX.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetX'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetY.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetY'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetWidth.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetHeight.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetRect.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(PictureBox, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// PictureBox::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int PictureBox_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetFocus.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetName.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetX.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetY.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetWidth.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetHeight.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetAppearance.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetBackColor.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetPicture.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetEnable.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetVisible.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetTransparency.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::GetType.
		//----------------------------------------------------------------------------------
		static int PictureBox_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetName.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetName'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(PictureBox, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(PictureBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetAppearance.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetBackColor.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetPicture.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(PictureBox, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetEnable.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetVisible.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// PictureBox::SetTransparency.
		//----------------------------------------------------------------------------------
		static int PictureBox_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(PictureBox, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'PictureBox_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// PictureBox::CreateNew.
		//----------------------------------------------------------------------------------
		static int PictureBox_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				PictureBox * aux = new PictureBox();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'PictureBox_CreateNew'.");
				lua_error(L);
			}

			return 0;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFPictureBox (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// PictureBox functions.
			//------------------------------------------------------------------------------
			lua_register(L, "PictureBox_CopyFrom",       PictureBox_CopyFrom);
			lua_register(L, "PictureBox_SetDoubleClick", PictureBox_SetDoubleClick);

			//------------------------------------------------------------------------------
			// Box functions.
			//------------------------------------------------------------------------------
			lua_register(L, "PictureBox_UpdateRects",    PictureBox_UpdateRects);
			lua_register(L, "PictureBox_SetX",           PictureBox_SetX);
			lua_register(L, "PictureBox_SetY",           PictureBox_SetY);
			lua_register(L, "PictureBox_SetWidth",       PictureBox_SetWidth);
			lua_register(L, "PictureBox_SetHeight",      PictureBox_SetHeight);
			lua_register(L, "PictureBox_SetRect",        PictureBox_SetRect);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "PictureBox_IsCursorOver",       PictureBox_IsCursorOver);
			lua_register(L, "PictureBox_GetFocus",           PictureBox_GetFocus);
			lua_register(L, "PictureBox_SetKeyDown",         PictureBox_SetKeyDown);
			lua_register(L, "PictureBox_SetKeyUp",           PictureBox_SetKeyUp);
			lua_register(L, "PictureBox_SetMouseMotion",     PictureBox_SetMouseMotion);
			lua_register(L, "PictureBox_SetMouseButtonDown", PictureBox_SetMouseButtonDown);
			lua_register(L, "PictureBox_SetMouseButtonUp",   PictureBox_SetMouseButtonUp);
			lua_register(L, "PictureBox_GetName",            PictureBox_GetName);
			lua_register(L, "PictureBox_GetX",               PictureBox_GetX);
			lua_register(L, "PictureBox_GetY",               PictureBox_GetY);
			lua_register(L, "PictureBox_GetWidth",           PictureBox_GetWidth);
			lua_register(L, "PictureBox_GetHeight",          PictureBox_GetHeight);
			lua_register(L, "PictureBox_GetBackStyle",       PictureBox_GetBackStyle);
			lua_register(L, "PictureBox_GetAppearance",      PictureBox_GetAppearance);
			lua_register(L, "PictureBox_GetBackColor",       PictureBox_GetBackColor);
			lua_register(L, "PictureBox_GetPicture",         PictureBox_GetPicture);
			lua_register(L, "PictureBox_GetMousePointer",    PictureBox_GetMousePointer);
			lua_register(L, "PictureBox_GetEnable",          PictureBox_GetEnable);
			lua_register(L, "PictureBox_GetVisible",         PictureBox_GetVisible);
			lua_register(L, "PictureBox_GetTransparency",    PictureBox_GetTransparency);
			lua_register(L, "PictureBox_GetType",            PictureBox_GetType);
			lua_register(L, "PictureBox_SetName",            PictureBox_SetName);
			lua_register(L, "PictureBox_SetBackStyle",       PictureBox_SetBackStyle);
			lua_register(L, "PictureBox_SetAppearance",      PictureBox_SetAppearance);
			lua_register(L, "PictureBox_SetBackColor",       PictureBox_SetBackColor);
			lua_register(L, "PictureBox_SetPicture",         PictureBox_SetPicture);
			lua_register(L, "PictureBox_SetMousePointer",    PictureBox_SetMousePointer);
			lua_register(L, "PictureBox_SetEnable",          PictureBox_SetEnable);
			lua_register(L, "PictureBox_SetVisible",         PictureBox_SetVisible);
			lua_register(L, "PictureBox_SetTransparency",    PictureBox_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "PictureBox_CreateNew",      PictureBox_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFPictureBox.cpp
//******************************************************************************************