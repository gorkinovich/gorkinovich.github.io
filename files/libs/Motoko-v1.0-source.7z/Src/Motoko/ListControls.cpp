//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../ListControls.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  ListControls constructor.
	 */
	//--------------------------------------------------------------------------------------
	ListControls::ListControls ()
	{
		Controls.assign(0);
		NumComboBox = 0;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListControls copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ListControls::ListControls (const ListControls & obj)
	{
		Controls    = obj.Controls;
		NumComboBox = obj.NumComboBox;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListControls operator =.
	 */
	//--------------------------------------------------------------------------------------
	ListControls & ListControls::operator = (const ListControls & obj)
	{
		Controls    = obj.Controls;
		NumComboBox = obj.NumComboBox;
		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListControls destructor.
	 */
	//--------------------------------------------------------------------------------------
	ListControls::~ListControls ()
	{
		Free();
	}

	//--------------------------------------------------------------------------------------
	/// Add a control.
	/**
	 *  @param control New control.
	 *  @see RemoveControl(), Free().
	 *  @return If no error 0, else an error code.
	 */
	//--------------------------------------------------------------------------------------
	int ListControls::AddControl (Control * control)
	{
		//----------------------------------------------------------------------------------
		// The variable actsize is to check if we have not any problem pushing the data.
		//----------------------------------------------------------------------------------
		int actsize = Controls.size();

		//----------------------------------------------------------------------------------
		// First we check that the control to push in is not a ComboBox, because we need
		// to insert them into the beginning of the vector. That is necesary to not have
		// problems catching the event in the ComboBox, when this control is expanded.
		//----------------------------------------------------------------------------------
		if(strcmp(control->GetType(), "ComboBox") != STR_EQU)
		{
			//------------------------------------------------------------------------------
			// If the control isn't a Dialog we push it back and check the new size.
			//------------------------------------------------------------------------------
			if(strcmp(control->GetType(), "Dialog") != STR_EQU)
			{
				Controls.push_back(control);

				if(actsize == Controls.size())
				{
					return LISTCONTROLS_ERROR_PUSHBACK;
				}
			}
			//------------------------------------------------------------------------------
			// But if the control is a Dialog we insert it at the beginning, just to put it
			// at the top of the screen when we draw the scene.
			//------------------------------------------------------------------------------
			else
			{
				Controls.insert(Controls.begin(), control);

				if(actsize == Controls.size())
				{
					return LISTCONTROLS_ERROR_PUSHBACK;
				}
			}
		}
		//----------------------------------------------------------------------------------
		// If we have a ComboBox control, we must put them in the beginning of the vector.
		// Why? Because in the Update sequence, it's important that the ComboBoxes must be
		// in order at the beginning, to catch the events correctly.
		//----------------------------------------------------------------------------------
		else
		{
			//------------------------------------------------------------------------------
			// First we insert the control at the begining, and we increment the actual
			// number of ComboBoxes in the list.
			//------------------------------------------------------------------------------
			Controls.insert(Controls.begin(), control);

			if(actsize == Controls.size())
			{
				return LISTCONTROLS_ERROR_PUSHBACK;
			}

			NumComboBox++;

			//------------------------------------------------------------------------------
			// After add the control correctly we sort the ComboBoxes in the vector,
			// using the y coordinate as the main factor in the sort.
			//------------------------------------------------------------------------------
			Control * aux;
			int miny, mini;
			int i, j;

			for(i = 0; i < NumComboBox - 1; ++i)
			{
				miny = Controls[i]->GetY();
				mini = i;

				for(j = i + 1; j < NumComboBox; ++j)
				{
					if(miny > Controls[j]->GetY())
					{
						miny = Controls[j]->GetY();
						mini = j;

					}
				}

				aux = Controls[i];
				Controls[i] = Controls[mini];
				Controls[mini] = aux;
			}
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	/// Remove a control.
	/**
	 *  @see AddControl(), Free().
	 */
	//--------------------------------------------------------------------------------------
	void ListControls::RemoveControl (const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a control with the same name. If we find
		// it, then we free the control and delete the position from the vector.
		//----------------------------------------------------------------------------------
		vector<Control *>::iterator i;
		Control * aux;

		for(i = Controls.begin(); i != Controls.end(); ++i)
		{
			aux = *i;
			
			if(strcmp(aux->GetName(), name) == STR_EQU)
			{
				if(strcmp(aux->GetType(), "ComboBox") == STR_EQU) NumComboBox--;
				delete aux;

				Controls.erase(i);
				return;
			}
		}
	}

	//--------------------------------------------------------------------------------------
	/// Unload the controls.
	/**
	 *  @see AddControl(), RemoveControl().
	 */
	//--------------------------------------------------------------------------------------
	void ListControls::Free (void)
	{
		Control * aux;

		//----------------------------------------------------------------------------------
		// We take the whole vector and erase each control inside it.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Controls.size(); ++i)
		{
			aux = Controls[i];

			if(aux != NULL)
			{
				delete aux;
			}
		}

		Controls.erase(Controls.begin(), Controls.end());
		NumComboBox = 0;
	}

	//--------------------------------------------------------------------------------------
	/// Get a pointer to a control.
	/**
	 *  @param name Name of the control.
	 *  @return If no error a pointer to the skin, else NULL.
	 */
	//--------------------------------------------------------------------------------------
	Control * ListControls::GetControl (const char * name)
	{
		//----------------------------------------------------------------------------------
		// We make a search in the vector, to find a control with the same name. If we find
		// it, then we return a pointer to that object.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Controls.size(); ++i)
		{
			if(strcmp(Controls[i]->GetName(), name) == STR_EQU)
			{
				return Controls[i];
			}
		}

		return NULL;
	}
}
//******************************************************************************************
// ListControls.cpp
//******************************************************************************************