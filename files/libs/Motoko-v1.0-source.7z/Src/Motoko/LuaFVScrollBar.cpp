//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// VScrollBar functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// VScrollBar::CopyFrom.
		//----------------------------------------------------------------------------------
		static int VScrollBar_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				VScrollBar * src = (VScrollBar *) ControlToCopy;

				if(Controls.size() > 0)
				{
					VScrollBar * dst = (VScrollBar *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::UpdateButton.
		//----------------------------------------------------------------------------------
		static int VScrollBar_UpdateButton (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->UpdateButton();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_UpdateButton'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::UpdateRects.
		//----------------------------------------------------------------------------------
		static int VScrollBar_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::GetButtonUp.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				Controls.push(aux->GetButtonUp());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetButtonUp'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::GetButtonCenter.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetButtonCenter (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				Controls.push(aux->GetButtonCenter());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetButtonCenter'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::GetButtonDown.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				Controls.push(aux->GetButtonDown());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetButtonDown'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetName.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetName'.");
				lua_error(L);
			}

			return 0;
		}
	
	//**************************************************************************************
	// ScrollBar functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// VScrollBar::GetLargeChange.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetLargeChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetLargeChange());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetLargeChange'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::GetSmallChange.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetSmallChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetSmallChange());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetSmallChange'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::GetMax.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetMax (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetMax());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetMax'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::GetMin.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetMin (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetMin());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetMin'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::GetValue.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetValue (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetValue());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetValue'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetLargeChange.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetLargeChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetLargeChange(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetLargeChange'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetLargeChange'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetSmallChange.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetSmallChange (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetSmallChange(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetSmallChange'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetSmallChange'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetMax.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetMax (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetMax(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetMax'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetMax'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetMin.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetMin (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetMin(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetMin'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetMin'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetValue.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetValue (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetValue(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetValue'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetValue'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetAppearance.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 4)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) && lua_isstring(L, 4))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 3), lua_tostring(L, 4)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 3)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 3)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetX.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetX'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetY.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetY'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetWidth.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetHeight.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetRect.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(VScrollBar, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(VScrollBar, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// VScrollBar::SetBackColor.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}
	
	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// VScrollBar::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int VScrollBar_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetFocus.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetName.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetX.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetY.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetWidth.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetHeight.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetAppearance.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetBackColor.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetPicture.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetEnable.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetVisible.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetTransparency.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::GetType.
		//----------------------------------------------------------------------------------
		static int VScrollBar_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetPicture.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(VScrollBar, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetEnable.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetVisible.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// VScrollBar::SetTransparency.
		//----------------------------------------------------------------------------------
		static int VScrollBar_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(VScrollBar, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'VScrollBar_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// VScrollBar::CreateNew.
		//----------------------------------------------------------------------------------
		static int VScrollBar_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				VScrollBar * aux = new VScrollBar();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'VScrollBar_CreateNew'.");
				lua_error(L);
			}

			return 0;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFVScrollBar (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// VScrollBar functions.
			//------------------------------------------------------------------------------
			lua_register(L, "VScrollBar_CopyFrom",        VScrollBar_CopyFrom);
			lua_register(L, "VScrollBar_UpdateButton",    VScrollBar_UpdateButton);
			lua_register(L, "VScrollBar_UpdateRects",     VScrollBar_UpdateRects);
			lua_register(L, "VScrollBar_GetButtonUp",     VScrollBar_GetButtonUp);
			lua_register(L, "VScrollBar_GetButtonCenter", VScrollBar_GetButtonCenter);
			lua_register(L, "VScrollBar_GetButtonDown",   VScrollBar_GetButtonDown);
			lua_register(L, "VScrollBar_SetName",         VScrollBar_SetName);

			//------------------------------------------------------------------------------
			// ScrollBar functions.
			//------------------------------------------------------------------------------
			lua_register(L, "VScrollBar_GetLargeChange", VScrollBar_GetLargeChange);
			lua_register(L, "VScrollBar_GetSmallChange", VScrollBar_GetSmallChange);
			lua_register(L, "VScrollBar_GetMax",         VScrollBar_GetMax);
			lua_register(L, "VScrollBar_GetMin",         VScrollBar_GetMin);
			lua_register(L, "VScrollBar_GetValue",       VScrollBar_GetValue);
			lua_register(L, "VScrollBar_SetLargeChange", VScrollBar_SetLargeChange);
			lua_register(L, "VScrollBar_SetSmallChange", VScrollBar_SetSmallChange);
			lua_register(L, "VScrollBar_SetMax",         VScrollBar_SetMax);
			lua_register(L, "VScrollBar_SetMin",         VScrollBar_SetMin);
			lua_register(L, "VScrollBar_SetValue",       VScrollBar_SetValue);
			lua_register(L, "VScrollBar_SetAppearance",  VScrollBar_SetAppearance);
			lua_register(L, "VScrollBar_SetX",           VScrollBar_SetX);
			lua_register(L, "VScrollBar_SetY",           VScrollBar_SetY);
			lua_register(L, "VScrollBar_SetWidth",       VScrollBar_SetWidth);
			lua_register(L, "VScrollBar_SetHeight",      VScrollBar_SetHeight);
			lua_register(L, "VScrollBar_SetRect",        VScrollBar_SetRect);
			lua_register(L, "VScrollBar_SetBackStyle",   VScrollBar_SetBackStyle);
			lua_register(L, "VScrollBar_SetBackColor",   VScrollBar_SetBackColor);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "VScrollBar_IsCursorOver",       VScrollBar_IsCursorOver);
			lua_register(L, "VScrollBar_GetFocus",           VScrollBar_GetFocus);
			lua_register(L, "VScrollBar_SetKeyDown",         VScrollBar_SetKeyDown);
			lua_register(L, "VScrollBar_SetKeyUp",           VScrollBar_SetKeyUp);
			lua_register(L, "VScrollBar_SetMouseMotion",     VScrollBar_SetMouseMotion);
			lua_register(L, "VScrollBar_SetMouseButtonDown", VScrollBar_SetMouseButtonDown);
			lua_register(L, "VScrollBar_SetMouseButtonUp",   VScrollBar_SetMouseButtonUp);
			lua_register(L, "VScrollBar_GetName",            VScrollBar_GetName);
			lua_register(L, "VScrollBar_GetX",               VScrollBar_GetX);
			lua_register(L, "VScrollBar_GetY",               VScrollBar_GetY);
			lua_register(L, "VScrollBar_GetWidth",           VScrollBar_GetWidth);
			lua_register(L, "VScrollBar_GetHeight",          VScrollBar_GetHeight);
			lua_register(L, "VScrollBar_GetBackStyle",       VScrollBar_GetBackStyle);
			lua_register(L, "VScrollBar_GetAppearance",      VScrollBar_GetAppearance);
			lua_register(L, "VScrollBar_GetBackColor",       VScrollBar_GetBackColor);
			lua_register(L, "VScrollBar_GetPicture",         VScrollBar_GetPicture);
			lua_register(L, "VScrollBar_GetMousePointer",    VScrollBar_GetMousePointer);
			lua_register(L, "VScrollBar_GetEnable",          VScrollBar_GetEnable);
			lua_register(L, "VScrollBar_GetVisible",         VScrollBar_GetVisible);
			lua_register(L, "VScrollBar_GetTransparency",    VScrollBar_GetTransparency);
			lua_register(L, "VScrollBar_GetType",            VScrollBar_GetType);
			lua_register(L, "VScrollBar_SetPicture",         VScrollBar_SetPicture);
			lua_register(L, "VScrollBar_SetMousePointer",    VScrollBar_SetMousePointer);
			lua_register(L, "VScrollBar_SetEnable",          VScrollBar_SetEnable);
			lua_register(L, "VScrollBar_SetVisible",         VScrollBar_SetVisible);
			lua_register(L, "VScrollBar_SetTransparency",    VScrollBar_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "VScrollBar_CreateNew", VScrollBar_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFVScrollBar.cpp
//******************************************************************************************