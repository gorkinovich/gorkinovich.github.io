//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Button.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  PictureBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	Button::Button () : Control(), ITextControl()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Button";
		
		for(int i = 0; i < MAX_BUTTON_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Arrow = NoneArrow;

		PictureOver = NULL;
		PictureDown = NULL;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  PictureBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	Button::Button (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
					ControlSkin * appearance, SDL_Surface * picture, SDL_Surface * over,
					SDL_Surface * down, ButtonArrow arrow, SDL_Surface * mousepointer,
					AlignmentStyle alignment, bool transparency, bool enable, bool visible) :
		Control(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
				transparency, enable, visible),
		ITextControl(text, font, alignment)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Button";
		
		for(int i = 0; i < MAX_BUTTON_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}
		
		Rects[CENTER_BUTTON_RECT] = Rect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Arrow = arrow;

		PictureOver = over;
		PictureDown = down;
		
		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  PictureBox copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	Button::Button (const Button & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  PictureBox operator =.
	 */
	//--------------------------------------------------------------------------------------
	Button & Button::operator = (const Button & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  PictureBox destructor.
	 */
	//--------------------------------------------------------------------------------------
	Button::~Button ()
	{
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Arrow = NoneArrow;

		PictureOver = NULL;
		PictureDown = NULL;
	}
	
	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void Button::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we check if the control have any correct skin.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_BUTTON_SKINRECTS))
		{
			return;
		}

		//----------------------------------------------------------------------------------
		// Second we calculate the width and the height of the center rect.
		//----------------------------------------------------------------------------------
		int w = Rect.w - Appearance->Rects[0].w - Appearance->Rects[2].w;
		int h = Rect.h - Appearance->Rects[0].h - Appearance->Rects[6].h;

		if(w < 0) w = 1;
		if(h < 0) h = 1;

		//----------------------------------------------------------------------------------
		// And third we calculate each rect of the final appearance of the box.
		//----------------------------------------------------------------------------------
		Rects[0].x = Rect.x;
		Rects[0].y = Rect.y;
		Rects[0].w = Appearance->Rects[0].w;
		Rects[0].h = Appearance->Rects[0].h;

		Rects[1].x = Rects[0].x + Rects[0].w;
		Rects[1].y = Rect.y;
		Rects[1].w = w;
		Rects[1].h = Appearance->Rects[1].h;
		
		Rects[2].x = Rects[1].x + Rects[1].w;
		Rects[2].y = Rect.y;
		Rects[2].w = Appearance->Rects[2].w;
		Rects[2].h = Appearance->Rects[2].h;

		
		Rects[3].x = Rects[0].x;
		Rects[3].y = Rects[0].y + Rects[0].h;
		Rects[3].w = Appearance->Rects[3].w;
		Rects[3].h = h;
		
		Rects[4].x = Rects[1].x;
		Rects[4].y = Rects[3].y;
		Rects[4].w = w;
		Rects[4].h = h;
		
		Rects[5].x = Rects[2].x;
		Rects[5].y = Rects[3].y;
		Rects[5].w = Appearance->Rects[5].w;
		Rects[5].h = h;

		
		Rects[6].x = Rects[0].x;
		Rects[6].y = Rects[3].y + Rects[3].h;
		Rects[6].w = Appearance->Rects[6].w;
		Rects[6].h = Appearance->Rects[6].h;
		
		Rects[7].x = Rects[1].x;
		Rects[7].y = Rects[6].y;
		Rects[7].w = w;
		Rects[7].h = Appearance->Rects[7].h;
		
		Rects[8].x = Rects[2].x;
		Rects[8].y = Rects[6].y;
		Rects[8].w = Appearance->Rects[8].w;
		Rects[8].h = Appearance->Rects[8].h;
	}

	//--------------------------------------------------------------------------------------
	// This function draw the button in graphical mode.
	//--------------------------------------------------------------------------------------
	void Button::DrawGraphical (void)
	{
		//----------------------------------------------------------------------------------
		// This function will paint the button in the graphical mode, and not the skinned
		// mode. First we'll need to know if the cursor is over.
		//----------------------------------------------------------------------------------
		if(IsCursorOver())
		{
			//------------------------------------------------------------------------------
			// If the cursor is really over the button, we'll check if it is pressed.
			//------------------------------------------------------------------------------
			if(CRM32Pro.mouse_buttons & SDL_BUTTON(SDL_BUTTON_LEFT))
			{
				if(PictureDown != NULL)
					BlitWithResize(PictureDown, NULL, CRM32Pro.screen, &Rect);
				else if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
				else if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			}
			//------------------------------------------------------------------------------
			// If it isn't pressed, the mouse is just over the button.
			//------------------------------------------------------------------------------
			else
			{
				if(PictureOver != NULL)
					BlitWithResize(PictureOver, NULL, CRM32Pro.screen, &Rect);
				else if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
				else if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
			}
		}
		//----------------------------------------------------------------------------------
		// If the cursor isn't over the button, we'll draw the surface in Picture.
		//----------------------------------------------------------------------------------
		else
		{
			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			else if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);
		}

		//----------------------------------------------------------------------------------
		// And at the end we'll paint the text in the center of the button.
		//----------------------------------------------------------------------------------
		DrawTextCenter(CRM32Pro.screen, &(Rects[CENTER_BUTTON_RECT]));
	}

	//--------------------------------------------------------------------------------------
	// This function draw the center of the button.
	//--------------------------------------------------------------------------------------
	void Button::DrawArror (void)
	{
		//----------------------------------------------------------------------------------
		// First we check if the back side isn't transparent and fill it with BackColor.
		//----------------------------------------------------------------------------------
		if(Transparency == false)
			SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER_BUTTON_RECT]), BackColor);

		//----------------------------------------------------------------------------------
		// After check the transparency, we check if we have to paint an arrow.
		//----------------------------------------------------------------------------------
		switch(Arrow)
		{
		//----------------------------------------------------------------------------------
		// In this case we have to paint the text of the button.
		//----------------------------------------------------------------------------------
		case NoneArrow:
			DrawTextCenter(CRM32Pro.screen, &(Rects[CENTER_BUTTON_RECT]));
			break;

		//----------------------------------------------------------------------------------
		// In this case we have to paint the up arror of the button.
		//----------------------------------------------------------------------------------
		case UpArrow:
			BlitWithResize(Appearance->Texture, &(Appearance->Rects[UpArrow]),
						   CRM32Pro.screen, &(Rects[CENTER_BUTTON_RECT]));
			break;

		//----------------------------------------------------------------------------------
		// In this case we have to paint the down arror of the button.
		//----------------------------------------------------------------------------------
		case DownArrow:
			BlitWithResize(Appearance->Texture, &(Appearance->Rects[DownArrow]),
						   CRM32Pro.screen, &(Rects[CENTER_BUTTON_RECT]));
			break;

		//----------------------------------------------------------------------------------
		// In this case we have to paint the right arror of the button.
		//----------------------------------------------------------------------------------
		case RightArrow:
			BlitWithResize(Appearance->Texture, &(Appearance->Rects[RightArrow]),
						   CRM32Pro.screen, &(Rects[CENTER_BUTTON_RECT]));
			break;

		//----------------------------------------------------------------------------------
		// In this case we have to paint the left arror of the button.
		//----------------------------------------------------------------------------------
		case LeftArrow:
			BlitWithResize(Appearance->Texture, &(Appearance->Rects[LeftArrow]),
						   CRM32Pro.screen, &(Rects[CENTER_BUTTON_RECT]));
			break;
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void Button::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned button.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, the function will draw a button.
			//------------------------------------------------------------------------------		
			if(Appearance == NULL)
			{
				DrawGraphical();
				return;
			}

			int i;

			//------------------------------------------------------------------------------
			// If the cursor of the mouse is over the control, and the left mouse button
			// is pressed, we'll paint the button pressed.
			//------------------------------------------------------------------------------
			if(IsCursorOver() && (CRM32Pro.mouse_buttons & SDL_BUTTON(SDL_BUTTON_LEFT)))
			{
				//--------------------------------------------------------------------------
				// We read the rects before the center rect, and paint the button's borders.
				//--------------------------------------------------------------------------
				for(i = 0; i < CENTER_BUTTON_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i + INI_BUTTON_PRESSED]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// With this function the center will be painted.
				//--------------------------------------------------------------------------
				DrawArror();

				//--------------------------------------------------------------------------
				// We read the rects after the center rect, and paint the button's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER_BUTTON_RECT + 1; i < MAX_BUTTON_RECTS; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i + INI_BUTTON_PRESSED]),
								   CRM32Pro.screen, &(Rects[i]));
				}
			}
			//------------------------------------------------------------------------------
			// If not, we'll paint the button unpressed.
			//------------------------------------------------------------------------------
			else
			{
				//--------------------------------------------------------------------------
				// We read the rects before the center rect, and paint the button's borders.
				//--------------------------------------------------------------------------
				for(i = 0; i < CENTER_BUTTON_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// With this function the center will be painted.
				//--------------------------------------------------------------------------
				DrawArror();

				//--------------------------------------------------------------------------
				// We read the rects after the center rect, and paint the button's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER_BUTTON_RECT + 1; i < MAX_BUTTON_RECTS; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor or UsePicture, the function will draw a button.
		//----------------------------------------------------------------------------------
		case UseBackColor:
		case UsePicture:
			DrawGraphical();
			break;
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool Button::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	Button & Button::CopyFrom (const Button & obj)
	{
		Control::CopyFrom(obj);
		
		ITextControl::CopyFrom(obj);

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		for(int i = 0; i < MAX_BUTTON_RECTS; ++i)
		{
			Rects[i] = obj.Rects[i];
		}

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		Arrow = obj.Arrow;

		PictureOver = obj.PictureOver;
		PictureDown = obj.PictureDown;
		
		return (*this);
	}
}
//******************************************************************************************
// Button.cpp
//******************************************************************************************