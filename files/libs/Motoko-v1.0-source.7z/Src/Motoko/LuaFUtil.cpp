//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// ResourcesManager functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ResourcesManager::LoadTexture.
		//----------------------------------------------------------------------------------
		static int ResourcesLoadTexture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					if(appLuaRef->Resources.LoadTexture(lua_tostring(L, 1)))
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ResourcesLoadTexture'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					if(appLuaRef->Resources.LoadTexture(lua_tostring(L, 1), lua_tostring(L, 2)))
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ResourcesLoadTexture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ResourcesLoadTexture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ResourcesManager::RemoveTexture.
		//----------------------------------------------------------------------------------
		static int ResourcesRemoveTexture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->Resources.RemoveTexture(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ResourcesRemoveTexture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ResourcesRemoveTexture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ResourcesManager::FreeTextures.
		//----------------------------------------------------------------------------------
		static int ResourcesFreeTextures (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->Resources.FreeTextures();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ResourcesFreeTextures'.");
				lua_error(L);
			}

			return 0;
		}
		//----------------------------------------------------------------------------------
		// ResourcesManager::LoadFont.
		//----------------------------------------------------------------------------------
		static int ResourcesLoadFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					if(appLuaRef->Resources.LoadFont(lua_tostring(L, 1), lua_tostring(L, 2)))
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ResourcesLoadFont'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ResourcesLoadFont'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ResourcesManager::RemoveFont.
		//----------------------------------------------------------------------------------
		static int ResourcesRemoveFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->Resources.RemoveFont(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ResourcesRemoveFont'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ResourcesRemoveFont'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ResourcesManager::FreeFonts.
		//----------------------------------------------------------------------------------
		static int ResourcesFreeFonts (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				appLuaRef->Resources.FreeFonts();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ResourcesFreeFonts'.");
				lua_error(L);
			}

			return 0;
		}


	//**************************************************************************************
	// SkinsManager functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// SkinsManager::AddTheme.
		//----------------------------------------------------------------------------------
		static int SkinsAddTheme (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					if(appLuaRef->Skins.AddTheme(lua_tostring(L, 1)) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'SkinsAddTheme'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					if(appLuaRef->Skins.AddTheme(lua_tostring(L, 1), lua_tostring(L, 2)) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'SkinsAddTheme'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'SkinsAddTheme'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// SkinsManager::RemoveTheme.
		//----------------------------------------------------------------------------------
		static int SkinsRemoveTheme (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					appLuaRef->Skins.RemoveTheme(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'SkinsRemoveTheme'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'SkinsRemoveTheme'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// SkinsManager::SetThemeName.
		//----------------------------------------------------------------------------------
		static int SkinsSetThemeName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					appLuaRef->Skins.SetThemeName(lua_tostring(L, 1), lua_tostring(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'SkinsSetThemeName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'SkinsSetThemeName'.");
				lua_error(L);
			}

			return 0;
		}


	//**************************************************************************************
	// ListControls functions.
	//**************************************************************************************
		
		//----------------------------------------------------------------------------------
		// SelectControl.
		//----------------------------------------------------------------------------------
		static int SelectControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					Control * aux = appLuaRef->List.GetControl(lua_tostring(L, 1));
					
					if(aux != NULL)
					{
						Controls.push(aux);
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'SelectControl'.");
					lua_error(L);
				}
			}
			else if(numargs > 1)
			{
				if(lua_isstring(L, 1))
				{
					Container * auxc = (Container *) appLuaRef->List.GetControl(lua_tostring(L, 1));

					for(int i = 2; i < numargs; ++i)
					{
						if(auxc == NULL)
						{
							lua_pushboolean(L, false);
							return 1;
						}

						if(!lua_isstring(L, i)) goto SelectControlError;

						auxc = (Container *) auxc->GetControl(lua_tostring(L, i));
					}

					if(auxc != NULL)
					{
						if(!lua_isstring(L, numargs)) goto SelectControlError;

						Control * aux = auxc->GetControl(lua_tostring(L, numargs));

						if(aux != NULL)
						{
							Controls.push(aux);
							lua_pushboolean(L, true);
						}
						else
						{
							lua_pushboolean(L, false);
						}
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
SelectControlError:
					lua_pushstring(L, "Incorrect type of argument in the function 'SelectControl'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'SelectControl'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// SelectControlFromDialog.
		//----------------------------------------------------------------------------------
		static int SelectControlFromDialog (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					Control * aux = appLuaRef->DialogList.GetControl(lua_tostring(L, 1));
					
					if(aux != NULL)
					{
						Controls.push(aux);
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'SelectControlFromDialog'.");
					lua_error(L);
				}
			}
			else if(numargs > 1)
			{
				if(lua_isstring(L, 1))
				{
					Container * auxc = (Container *) appLuaRef->DialogList.GetControl(lua_tostring(L, 1));

					for(int i = 2; i < numargs; ++i)
					{
						if(auxc == NULL)
						{
							lua_pushboolean(L, false);
							return 1;
						}

						if(!lua_isstring(L, i)) goto SelectControlFromDialogError;

						auxc = (Container *) auxc->GetControl(lua_tostring(L, i));
					}

					if(auxc != NULL)
					{
						if(!lua_isstring(L, numargs)) goto SelectControlFromDialogError;

						Control * aux = auxc->GetControl(lua_tostring(L, numargs));

						if(aux != NULL)
						{
							Controls.push(aux);
							lua_pushboolean(L, true);
						}
						else
						{
							lua_pushboolean(L, false);
						}
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
SelectControlFromDialogError:
					lua_pushstring(L, "Incorrect type of argument in the function 'SelectControlFromDialog'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'SelectControlFromDialog'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// UnselectControl.
		//----------------------------------------------------------------------------------
		static int UnselectControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Controls.pop();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'UnselectControl'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// AddControlToContainer.
		//----------------------------------------------------------------------------------
		static int AddControlToContainer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(Controls.size() > 0)
				{
					Container * auxc = (Container *) Controls.top();
					if(auxc->AddControl(aux) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
						LostControls.push(aux);
					}
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'AddControlToContainer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// AddControlRelToContainer.
		//----------------------------------------------------------------------------------
		static int AddControlRelToContainer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(Controls.size() > 0)
				{
					Container * auxc = (Container *) Controls.top();
					if(auxc->AddControlRel(aux) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
						LostControls.push(aux);
					}
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'AddControlToContainer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// RecoverLostControl.
		//----------------------------------------------------------------------------------
		static int RecoverLostControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Controls.push(LostControls.top());
				LostControls.pop();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'RecoverLostControl'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// SetControlToCopy.
		//----------------------------------------------------------------------------------
		static int SetControlToCopy (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				ControlToCopy = Controls.top();
				Controls.pop();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'SetControlToCopy'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// ListControls functions.
	//**************************************************************************************
		
		//----------------------------------------------------------------------------------
		// CheckAndGetFocus.
		//----------------------------------------------------------------------------------
		static int CheckAndGetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Control, aux);
				if(appLuaRef->GetActiveControl() != aux) aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'CheckAndGetFocus'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ExecFileInLua.
		//----------------------------------------------------------------------------------
		static int ExecFileInLua (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					ExecFile(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ExecFile'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					ExecFile(lua_tostring(L, 1), lua_tostring(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ExecFile'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ExecFile'.");
				lua_error(L);
			}

			return 0;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFUtil (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// SkinsManager functions.
			//------------------------------------------------------------------------------
			lua_register(L, "SkinsAddTheme",     SkinsAddTheme);
			lua_register(L, "SkinsRemoveTheme",  SkinsRemoveTheme);
			lua_register(L, "SkinsSetThemeName", SkinsSetThemeName);

			//------------------------------------------------------------------------------
			// ResourcesManager functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ResourcesLoadTexture",   ResourcesLoadTexture);
			lua_register(L, "ResourcesRemoveTexture", ResourcesRemoveTexture);
			lua_register(L, "ResourcesFreeTextures",  ResourcesFreeTextures);
			lua_register(L, "ResourcesLoadFont",      ResourcesLoadFont);
			lua_register(L, "ResourcesRemoveFont",    ResourcesRemoveFont);
			lua_register(L, "ResourcesFreeFonts",     ResourcesFreeFonts);
			
			//------------------------------------------------------------------------------
			// ListControls functions.
			//------------------------------------------------------------------------------
			lua_register(L, "SelectControl",            SelectControl);
			lua_register(L, "SelectControlFromDialog",  SelectControlFromDialog);
			lua_register(L, "UnselectControl",          UnselectControl);
			lua_register(L, "AddControlToContainer",    AddControlToContainer);
			lua_register(L, "AddControlRelToContainer", AddControlRelToContainer);
			lua_register(L, "RecoverLostControl",       RecoverLostControl);
			lua_register(L, "SetControlToCopy",         SetControlToCopy);

			//------------------------------------------------------------------------------
			// Other functions.
			//------------------------------------------------------------------------------
			lua_register(L, "CheckAndGetFocus", CheckAndGetFocus);
			lua_register(L, "ExecFile",         ExecFileInLua);
		}
	}
}
//******************************************************************************************
// LuaFUtil.cpp
//******************************************************************************************