//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../ScrollBar.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  ScrollBar constructor.
	 */
	//--------------------------------------------------------------------------------------
	ScrollBar::ScrollBar () : Control()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ScrollBar";

		Button01 = new Button();
		Button02 = new Button();
		Button03 = new Button();

		Pressed = false;

		for(int i = 0; i < MAX_SCROLLBAR_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}
		
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		LargeChange = 1;
		SmallChange = 1;
		Max         = 2;
		Min         = 0;
		Value       = 0;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ScrollBar constructor.
	 */
	//--------------------------------------------------------------------------------------
	ScrollBar::ScrollBar (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
						  Uint32 backcolor, ControlSkin * appearance, int min, int max,
						  int value, int large, int small, SDL_Surface * picture,
						  SDL_Surface * mousepointer, bool transparency, bool enable,
						  bool visible) :
		Control(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
				transparency, enable, visible)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ScrollBar";

		Button01 = new Button();
		Button02 = new Button();
		Button03 = new Button();

		Pressed = false;
		
		for(int i = 0; i < MAX_SCROLLBAR_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}
		
		Rects[CENTER_SCROLLBAR_RECT] = Rect;

		
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		LargeChange = large;
		SmallChange = small;
		Max         = max + 1;
		Min         = min;
		Value       = value;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ScrollBar copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ScrollBar::ScrollBar (const ScrollBar & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ScrollBar operator =.
	 */
	//--------------------------------------------------------------------------------------
	ScrollBar & ScrollBar::operator = (const ScrollBar & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ScrollBar destructor.
	 */
	//--------------------------------------------------------------------------------------
	ScrollBar::~ScrollBar ()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		delete Button01;
		delete Button02;
		delete Button03;

		Pressed = false;
		
		for(int i = 0; i < MAX_SCROLLBAR_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		LargeChange = 0;
		SmallChange = 0;
		Max         = 0;
		Min         = 0;
		Value       = 0;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	ScrollBar & ScrollBar::CopyFrom (const ScrollBar & obj)
	{
		Control::CopyFrom(obj);

		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Button01->CopyFrom(*(obj.Button01));
		Button02->CopyFrom(*(obj.Button02));
		Button03->CopyFrom(*(obj.Button03));

		Pressed = obj.Pressed;

		for(int i = 0; i < MAX_SCROLLBAR_RECTS; ++i)
		{
			Rects[i] = obj.Rects[i];
		}

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		LargeChange = obj.LargeChange;
		SmallChange = obj.SmallChange;
		Max         = obj.Max;
		Min         = obj.Min;
		Value       = obj.Value;

		return (*this);
	}
}
//******************************************************************************************
// ScrollBar.cpp
//******************************************************************************************