//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// Panel functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Panel::CopyFrom.
		//----------------------------------------------------------------------------------
		static int Panel_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Panel * src = (Panel *) ControlToCopy;

				if(Controls.size() > 0)
				{
					Panel * dst = (Panel *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}
		
	//**************************************************************************************
	// Container functions.
	//**************************************************************************************
		
		//----------------------------------------------------------------------------------
		// Panel::AddControl.
		//----------------------------------------------------------------------------------
		static int Panel_AddControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(Controls.size() > 0)
				{
					GetControlsTop(Panel, auxc);
					if(auxc->AddControl(aux) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
						LostControls.push(aux);
					}
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_AddControl'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::AddControlRel.
		//----------------------------------------------------------------------------------
		static int Panel_AddControlRel (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(Controls.size() > 0)
				{
					GetControlsTop(Panel, auxc);
					if(auxc->AddControlRel(aux) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
						LostControls.push(aux);
					}
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_AddControlRel'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::RemoveControl.
		//----------------------------------------------------------------------------------
		static int Panel_RemoveControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->RemoveControl(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_RemoveControl'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_RemoveControl'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::Free.
		//----------------------------------------------------------------------------------
		static int Panel_Free (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->Free();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_Free'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::GetControl.
		//----------------------------------------------------------------------------------
		static int Panel_GetControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Panel, aux);
					Controls.push(aux->GetControl(lua_tostring(L, 1)));
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(Panel, aux);
					Controls.push(aux->GetControl(lua_tointeger(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_GetControl'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetControl'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::GetSize.
		//----------------------------------------------------------------------------------
		static int Panel_GetSize (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushnumber(L, aux->GetSize());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetSize'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int Panel_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::SetX.
		//----------------------------------------------------------------------------------
		static int Panel_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetX'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::SetY.
		//----------------------------------------------------------------------------------
		static int Panel_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetY'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// Panel::SetRect.
		//----------------------------------------------------------------------------------
		static int Panel_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(Panel, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetRect'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Panel::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int Panel_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetFocus.
		//----------------------------------------------------------------------------------
		static int Panel_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int Panel_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int Panel_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int Panel_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int Panel_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int Panel_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetName.
		//----------------------------------------------------------------------------------
		static int Panel_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetX.
		//----------------------------------------------------------------------------------
		static int Panel_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetY.
		//----------------------------------------------------------------------------------
		static int Panel_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetWidth.
		//----------------------------------------------------------------------------------
		static int Panel_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetHeight.
		//----------------------------------------------------------------------------------
		static int Panel_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int Panel_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetAppearance.
		//----------------------------------------------------------------------------------
		static int Panel_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetBackColor.
		//----------------------------------------------------------------------------------
		static int Panel_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetPicture.
		//----------------------------------------------------------------------------------
		static int Panel_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetEnable.
		//----------------------------------------------------------------------------------
		static int Panel_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetVisible.
		//----------------------------------------------------------------------------------
		static int Panel_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetTransparency.
		//----------------------------------------------------------------------------------
		static int Panel_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::GetType.
		//----------------------------------------------------------------------------------
		static int Panel_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetName.
		//----------------------------------------------------------------------------------
		static int Panel_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetName'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetWidth.
		//----------------------------------------------------------------------------------
		static int Panel_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetHeight.
		//----------------------------------------------------------------------------------
		static int Panel_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int Panel_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Panel, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(Panel, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetAppearance.
		//----------------------------------------------------------------------------------
		static int Panel_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(Panel, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetBackColor.
		//----------------------------------------------------------------------------------
		static int Panel_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetPicture.
		//----------------------------------------------------------------------------------
		static int Panel_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int Panel_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(Panel, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetEnable.
		//----------------------------------------------------------------------------------
		static int Panel_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetVisible.
		//----------------------------------------------------------------------------------
		static int Panel_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// Panel::SetTransparency.
		//----------------------------------------------------------------------------------
		static int Panel_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(Panel, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'Panel_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// Panel::CreateNew.
		//----------------------------------------------------------------------------------
		static int Panel_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Panel * aux = new Panel();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'Panel_CreateNew'.");
				lua_error(L);
			}

			return 0;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFPanel (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// Panel functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Panel_CopyFrom", Panel_CopyFrom);

			//------------------------------------------------------------------------------
			// Container functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Panel_AddControl",      Panel_AddControl);
			lua_register(L, "Panel_AddControlRel",   Panel_AddControlRel);
			lua_register(L, "Panel_RemoveControl",   Panel_RemoveControl);
			lua_register(L, "Panel_Free",            Panel_Free);
			lua_register(L, "Panel_GetControl",      Panel_GetControl);
			lua_register(L, "Panel_GetSize",         Panel_GetSize);
			lua_register(L, "Panel_GetMousePointer", Panel_GetMousePointer);
			lua_register(L, "Panel_SetX",            Panel_SetX);
			lua_register(L, "Panel_SetY",            Panel_SetY);
			lua_register(L, "Panel_SetRect",         Panel_SetRect);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Panel_IsCursorOver",       Panel_IsCursorOver);
			lua_register(L, "Panel_GetFocus",           Panel_GetFocus);
			lua_register(L, "Panel_SetKeyDown",         Panel_SetKeyDown);
			lua_register(L, "Panel_SetKeyUp",           Panel_SetKeyUp);
			lua_register(L, "Panel_SetMouseMotion",     Panel_SetMouseMotion);
			lua_register(L, "Panel_SetMouseButtonDown", Panel_SetMouseButtonDown);
			lua_register(L, "Panel_SetMouseButtonUp",   Panel_SetMouseButtonUp);
			lua_register(L, "Panel_GetName",            Panel_GetName);
			lua_register(L, "Panel_GetX",               Panel_GetX);
			lua_register(L, "Panel_GetY",               Panel_GetY);
			lua_register(L, "Panel_GetWidth",           Panel_GetWidth);
			lua_register(L, "Panel_GetHeight",          Panel_GetHeight);
			lua_register(L, "Panel_GetBackStyle",       Panel_GetBackStyle);
			lua_register(L, "Panel_GetAppearance",      Panel_GetAppearance);
			lua_register(L, "Panel_GetBackColor",       Panel_GetBackColor);
			lua_register(L, "Panel_GetPicture",         Panel_GetPicture);
			lua_register(L, "Panel_GetEnable",          Panel_GetEnable);
			lua_register(L, "Panel_GetVisible",         Panel_GetVisible);
			lua_register(L, "Panel_GetTransparency",    Panel_GetTransparency);
			lua_register(L, "Panel_GetType",            Panel_GetType);
			lua_register(L, "Panel_SetName",            Panel_SetName);
			lua_register(L, "Panel_SetWidth",           Panel_SetWidth);
			lua_register(L, "Panel_SetHeight",          Panel_SetHeight);
			lua_register(L, "Panel_SetBackStyle",       Panel_SetBackStyle);
			lua_register(L, "Panel_SetAppearance",      Panel_SetAppearance);
			lua_register(L, "Panel_SetBackColor",       Panel_SetBackColor);
			lua_register(L, "Panel_SetPicture",         Panel_SetPicture);
			lua_register(L, "Panel_SetMousePointer",    Panel_SetMousePointer);
			lua_register(L, "Panel_SetEnable",          Panel_SetEnable);
			lua_register(L, "Panel_SetVisible",         Panel_SetVisible);
			lua_register(L, "Panel_SetTransparency",    Panel_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "Panel_CreateNew", Panel_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFPanel.cpp
//******************************************************************************************