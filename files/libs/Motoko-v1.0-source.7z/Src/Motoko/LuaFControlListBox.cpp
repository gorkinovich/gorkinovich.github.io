//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// ControlListBox functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ControlListBox::CopyFrom.
		//----------------------------------------------------------------------------------
		static int ControlListBox_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				ControlListBox * src = (ControlListBox *) ControlToCopy;

				if(Controls.size() > 0)
				{
					ControlListBox * dst = (ControlListBox *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::UpdateRects.
		//----------------------------------------------------------------------------------
		static int ControlListBox_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::AddControl.
		//----------------------------------------------------------------------------------
		static int ControlListBox_AddControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				Control * aux = Controls.top();
				Controls.pop();

				if(Controls.size() > 0)
				{
					ControlListBox * auxc = (ControlListBox *) Controls.top();
					if(auxc->AddControl(aux) == RESULT_OK)
					{
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
						LostControls.push(aux);
					}
				}
				else
				{
					lua_pushboolean(L, false);
					LostControls.push(aux);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_AddControl'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::RemoveControl.
		//----------------------------------------------------------------------------------
		static int ControlListBox_RemoveControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->RemoveControl(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_RemoveControl'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_RemoveControl'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::Free.
		//----------------------------------------------------------------------------------
		static int ControlListBox_Free (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->Free();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_Free'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetControl.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetControl (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					Control * auxc = aux->GetControl(lua_tostring(L, 1));
					
					if(auxc != NULL)
					{
						Controls.push(auxc);
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					Control * auxc = aux->GetControl(lua_tointeger(L, 1));
					
					if(auxc != NULL)
					{
						Controls.push(auxc);
						lua_pushboolean(L, true);
					}
					else
					{
						lua_pushboolean(L, false);
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_GetControl'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetControl'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetSize.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetSize (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetSize());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetSize'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetMultiSelect.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetMultiSelect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushboolean(L, aux->GetMultiSelect());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetMultiSelect'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetSelectedItems.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetSelectedItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					list<int>::iterator it = aux->GetSelectedItems()->begin();

					int index = lua_tointeger(L, 1);

					for(int i = 0; (i < index) && (it != aux->GetSelectedItems()->end()); ++i) ++it;

					if(it != aux->GetSelectedItems()->end())
						lua_pushnumber(L, *it);
					else
						lua_pushnumber(L, -1);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_GetSelectedItems'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetSelectedItems'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetSelectedItems->size().
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetSelectedItemsSize (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetSelectedItems()->size());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetSelectedItemsSize'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetSelColor.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetSelColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetSelColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetSelColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::GetVBar.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetVBar (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				Controls.push(aux->GetVBar());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetVBar'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::SetMultiSelect.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetMultiSelect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetMultiSelect(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetMultiSelect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetMultiSelect'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::SetNoSelectedItems.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetNoSelectedItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->SetNoSelectedItems();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetNoSelectedItems'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::SetSelColor.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetSelColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetSelColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetSelColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetSelColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::SetName.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetName'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ControlListBox, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::SetBackColor.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1), lua_tointeger(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ControlListBox::SetAppearance.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 6)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) &&
				   lua_isstring(L, 4) && lua_isstring(L, 5) && lua_isstring(L, 6))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 3), lua_tostring(L, 4)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 5), lua_tostring(L, 6)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 4)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) && lua_isstring(L, 4))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 3)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 4)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Box functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ControlListBox::SetX.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetX'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetY.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetY'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetWidth.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetHeight.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetRect.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(ControlListBox, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ControlListBox::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int ControlListBox_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetFocus.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetName.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetX.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetY.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetWidth.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetHeight.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetAppearance.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetBackColor.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetPicture.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetEnable.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetVisible.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetTransparency.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::GetType.
		//----------------------------------------------------------------------------------
		static int ControlListBox_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetPicture.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ControlListBox, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetEnable.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetVisible.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ControlListBox::SetTransparency.
		//----------------------------------------------------------------------------------
		static int ControlListBox_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ControlListBox, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ControlListBox_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ControlListBox::CreateNew.
		//----------------------------------------------------------------------------------
		static int ControlListBox_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				ControlListBox * aux = new ControlListBox();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ControlListBox_CreateNew'.");
				lua_error(L);
			}

			return 1;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFControlListBox (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// ControlListBox functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ControlListBox_CopyFrom",             ControlListBox_CopyFrom);
			lua_register(L, "ControlListBox_UpdateRects",          ControlListBox_UpdateRects);
			lua_register(L, "ControlListBox_AddControl",           ControlListBox_AddControl);
			lua_register(L, "ControlListBox_RemoveControl",        ControlListBox_RemoveControl);
			lua_register(L, "ControlListBox_Free",                 ControlListBox_Free);
			lua_register(L, "ControlListBox_GetControl",           ControlListBox_GetControl);
			lua_register(L, "ControlListBox_GetSize",              ControlListBox_GetSize);
			lua_register(L, "ControlListBox_GetMousePointer",      ControlListBox_GetMousePointer);
			lua_register(L, "ControlListBox_GetMultiSelect",       ControlListBox_GetMultiSelect);
			lua_register(L, "ControlListBox_GetSelectedItems",     ControlListBox_GetSelectedItems);
			lua_register(L, "ControlListBox_GetSelectedItemsSize", ControlListBox_GetSelectedItemsSize);
			lua_register(L, "ControlListBox_GetSelColor",          ControlListBox_GetSelColor);
			lua_register(L, "ControlListBox_GetVBar",              ControlListBox_GetVBar);
			lua_register(L, "ControlListBox_SetMultiSelect",       ControlListBox_SetMultiSelect);
			lua_register(L, "ControlListBox_SetNoSelectedItems",   ControlListBox_SetNoSelectedItems);
			lua_register(L, "ControlListBox_SetSelColor",          ControlListBox_SetSelColor);
			lua_register(L, "ControlListBox_SetName",              ControlListBox_SetName);
			lua_register(L, "ControlListBox_SetBackStyle",         ControlListBox_SetBackStyle);
			lua_register(L, "ControlListBox_SetBackColor",         ControlListBox_SetBackColor);
			lua_register(L, "ControlListBox_SetAppearance",        ControlListBox_SetAppearance);

			//------------------------------------------------------------------------------
			// Box functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ControlListBox_UpdateRects",          ControlListBox_UpdateRects);
			lua_register(L, "ControlListBox_SetX",                 ControlListBox_SetX);
			lua_register(L, "ControlListBox_SetY",                 ControlListBox_SetY);
			lua_register(L, "ControlListBox_SetWidth",             ControlListBox_SetWidth);
			lua_register(L, "ControlListBox_SetHeight",            ControlListBox_SetHeight);
			lua_register(L, "ControlListBox_SetRect",              ControlListBox_SetRect);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ControlListBox_IsCursorOver",       ControlListBox_IsCursorOver);
			lua_register(L, "ControlListBox_GetFocus",           ControlListBox_GetFocus);
			lua_register(L, "ControlListBox_SetKeyDown",         ControlListBox_SetKeyDown);
			lua_register(L, "ControlListBox_SetKeyUp",           ControlListBox_SetKeyUp);
			lua_register(L, "ControlListBox_SetMouseMotion",     ControlListBox_SetMouseMotion);
			lua_register(L, "ControlListBox_SetMouseButtonDown", ControlListBox_SetMouseButtonDown);
			lua_register(L, "ControlListBox_SetMouseButtonUp",   ControlListBox_SetMouseButtonUp);
			lua_register(L, "ControlListBox_GetName",            ControlListBox_GetName);
			lua_register(L, "ControlListBox_GetX",               ControlListBox_GetX);
			lua_register(L, "ControlListBox_GetY",               ControlListBox_GetY);
			lua_register(L, "ControlListBox_GetWidth",           ControlListBox_GetWidth);
			lua_register(L, "ControlListBox_GetHeight",          ControlListBox_GetHeight);
			lua_register(L, "ControlListBox_GetBackStyle",       ControlListBox_GetBackStyle);
			lua_register(L, "ControlListBox_GetAppearance",      ControlListBox_GetAppearance);
			lua_register(L, "ControlListBox_GetBackColor",       ControlListBox_GetBackColor);
			lua_register(L, "ControlListBox_GetPicture",         ControlListBox_GetPicture);
			lua_register(L, "ControlListBox_GetEnable",          ControlListBox_GetEnable);
			lua_register(L, "ControlListBox_GetVisible",         ControlListBox_GetVisible);
			lua_register(L, "ControlListBox_GetTransparency",    ControlListBox_GetTransparency);
			lua_register(L, "ControlListBox_GetType",            ControlListBox_GetType);
			lua_register(L, "ControlListBox_SetPicture",         ControlListBox_SetPicture);
			lua_register(L, "ControlListBox_SetMousePointer",    ControlListBox_SetMousePointer);
			lua_register(L, "ControlListBox_SetEnable",          ControlListBox_SetEnable);
			lua_register(L, "ControlListBox_SetVisible",         ControlListBox_SetVisible);
			lua_register(L, "ControlListBox_SetTransparency",    ControlListBox_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ControlListBox_CreateNew",            ControlListBox_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFControlListBox.cpp
//******************************************************************************************