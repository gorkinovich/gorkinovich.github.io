//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../Application.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define BUTTONX_SEP 2
#define BUTTONY_SEP 2
#define BUTTON_SEP  4
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	Application * appDialogRef = Application::GetInstance();

	//--------------------------------------------------------------------------------------
	/**
	 *  Dialog constructor.
	 */
	//--------------------------------------------------------------------------------------
	Dialog::Dialog () : Container(), ITextControl()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Dialog";

		Close = new Button();

		Close->SetTransparency(true);

		Pressed = false;
		
		for(int i = 0; i < MAX_DIALOG_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		TitleColor = BackColor;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Dialog constructor.
	 */
	//--------------------------------------------------------------------------------------
	Dialog::Dialog (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					Uint32 backcolor, Uint32 titlecolor, const char * text, CRM32Pro_CFont * font,
					ControlSkin * appearance, SDL_Surface * picture,
					SDL_Surface * mousepointer, AlignmentStyle alignment,
					bool transparency, bool enable, bool visible) :
		Container(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
				  transparency, enable, visible),
		ITextControl(text, font, alignment)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "Dialog";

		Close = new Button();

		Close->SetTransparency(true);

		Pressed = false;
		
		for(int i = 0; i < MAX_DIALOG_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		TitleColor = titlecolor;

		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Dialog copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	Dialog::Dialog (const Dialog & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Dialog operator =.
	 */
	//--------------------------------------------------------------------------------------
	Dialog & Dialog::operator = (const Dialog & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  Dialog destructor.
	 */
	//--------------------------------------------------------------------------------------
	Dialog::~Dialog ()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		delete Close;

		Pressed = false;
		
		for(int i = 0; i < MAX_DIALOG_RECTS; ++i)
		{
			Rects[i].x = 0;
			Rects[i].y = 0;
			Rects[i].w = 0;
			Rects[i].h = 0;
		}
		
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		TitleColor = 0;
	}
	
	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void Dialog::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		int i;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned dialog.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			if(Appearance == NULL)
			{
				//--------------------------------------------------------------------------
				// If the dialog haven't a skin, we'll try to paint the surface inside
				// Picture, and also we will use the back color.
				//--------------------------------------------------------------------------
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

				if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
				
				//--------------------------------------------------------------------------
				// And after use the picture or the back color, we'll draw the title text.
				//--------------------------------------------------------------------------
				DrawText(CRM32Pro.screen, Rect.y, &Rect);
			}
			else
			{
				//--------------------------------------------------------------------------
				// We read the rects before the title rect, and paint the dialog's borders.
				//--------------------------------------------------------------------------
				for(i = 0; i < CENTER1_DIALOG_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// Now we'll paint the title rect, filling it first with the title color,
				// and then drawing the title's text inside this rect.
				//--------------------------------------------------------------------------
				SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER1_DIALOG_RECT]), TitleColor);

				DrawText(CRM32Pro.screen, Rects[CENTER1_DIALOG_RECT].y, &(Rects[CENTER1_DIALOG_RECT]));
				

				//--------------------------------------------------------------------------
				// We read the rects after the title rect, and paint the dialog's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER1_DIALOG_RECT + 1; i < CENTER2_DIALOG_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// Now we'll fill with the back color the center rect.
				//--------------------------------------------------------------------------
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER2_DIALOG_RECT]), BackColor);

				//--------------------------------------------------------------------------
				// We read the rects after the center rect, and paint the dialog's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER2_DIALOG_RECT + 1; i < MAX_DIALOG_RECTS; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, the function will draw a dialog using the
		// back color of the control, filling the area defined in Rect.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			DrawText(CRM32Pro.screen, Rect.y, &Rect);

			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, the function will draw a dialog using the
		// surface stored inside Picture.
		//----------------------------------------------------------------------------------
		case UsePicture:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			
			DrawText(CRM32Pro.screen, Rect.y, &Rect);

			break;
		}

		//----------------------------------------------------------------------------------
		// After draw the dialog, we'll draw the controls inside the dialog.
		//----------------------------------------------------------------------------------
		for(i = List.GetSize() - 1; i >= 0 ; --i)
		{
			List.GetControl(i)->Draw();
		}

		//----------------------------------------------------------------------------------
		// And finally we'll draw the close button.
		//----------------------------------------------------------------------------------
		Close->Draw();
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool Dialog::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;
		
		//----------------------------------------------------------------------------------
		// If the dialog is active, we'll update every control in the dialog. And if one
		// control of the dialog catch an event, we'll push to the top of the screen this
		// dialog, and we'll return true.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.GetSize(); ++i)
		{
			if(List.GetControl(i)->Update(event))
			{
				if(event.type == SDL_MOUSEBUTTONDOWN)
					appDialogRef->PushUpDialog(this);

				return true;
			}
		}

		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// First we'll push to the top of the screen this dialog.
				//--------------------------------------------------------------------------
				appDialogRef->PushUpDialog(this);

				//--------------------------------------------------------------------------
				// Second we check if the user have pressed the left button of the mouse
				// over the close button, if that is true we'll hide the dialog. But if the
				// dialog have a skin, and the user have pressed the title bar, we set that
				// the title of the dialog is pressed.
				//--------------------------------------------------------------------------
				if(event.button.button == SDL_BUTTON_LEFT)
				{
					if(Close->Update(event))
					{
						Visible = false;
					}
					else if((BackStyle == UseAppearance) && (Rects[3].x <= CRM32Pro.mouse_x) &&
							(CRM32Pro.mouse_x < Rects[3].x + Rects[3].w) &&
							(Rects[3].y <= CRM32Pro.mouse_y) && (CRM32Pro.mouse_y < Rects[3].y + Rects[3].h))
					{
						Pressed = true;
					}
				}

				//--------------------------------------------------------------------------
				// And third if MouseButtonDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// We set that the title of the dialog isn't pressed.
				//--------------------------------------------------------------------------
				Pressed = false;

				//--------------------------------------------------------------------------
				// And third if MouseButtonUp isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if(Pressed)
			{
				//--------------------------------------------------------------------------
				// If the pressed button of the mouse is the left, we'll move the dialog.
				//--------------------------------------------------------------------------
				if(CRM32Pro.mouse_buttons & SDL_BUTTON(SDL_BUTTON_LEFT))
				{
					SetX(Rect.x + event.motion.xrel);
					SetY(Rect.y + event.motion.yrel);
				}
				//--------------------------------------------------------------------------
				// If isn't the left button we'll set that the dialog isn't pressed.
				//--------------------------------------------------------------------------
				else
				{
					Pressed = false;
				}
			}

			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}
	
	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void Dialog::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we check if the control have any correct skin.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_DIALOG_RECTS) ||
		   (Font == NULL))
		{
			return;
		}

		//----------------------------------------------------------------------------------
		// Second we calculate the width and the height of the title and center rect.
		//----------------------------------------------------------------------------------
		SDL_Rect aux;

		int w  = Rect.w - Appearance->Rects[0].w - Appearance->Rects[2].w;
		int h1 = Font->GetSurface()->h + DEFAULT_SEPARATIONY * 2;
		int h2 = Rect.h - Appearance->Rects[0].h - Appearance->Rects[8].h;
		int h3 = h2 - h1 - Appearance->Rects[4].h;

		if(w  < Appearance->Rects[11].w + BUTTON_SEP * 2) w  = Appearance->Rects[11].w + BUTTON_SEP * 2;
		if(h1 < Appearance->Rects[11].h + BUTTON_SEP * 2) h1 = Appearance->Rects[11].h + BUTTON_SEP * 2;
		if(h3 < 0) h3 = 1;

		//----------------------------------------------------------------------------------
		// Third we calculate each rect of the final appearance of the box.
		//----------------------------------------------------------------------------------
		Rects[0].x = Rect.x;
		Rects[0].y = Rect.y;
		Rects[0].w = Appearance->Rects[0].w;
		Rects[0].h = Appearance->Rects[0].h;

		Rects[1].x = Rects[0].x + Rects[0].w;
		Rects[1].y = Rect.y;
		Rects[1].w = w;
		Rects[1].h = Appearance->Rects[1].h;
		
		Rects[2].x = Rects[1].x + Rects[1].w;
		Rects[2].y = Rect.y;
		Rects[2].w = Appearance->Rects[2].w;
		Rects[2].h = Appearance->Rects[2].h;

		
		Rects[3].x = Rects[1].x;
		Rects[3].y = Rects[1].y + Rects[1].h;
		Rects[3].w = w;
		Rects[3].h = h1;

		
		Rects[4].x = Rects[0].x;
		Rects[4].y = Rects[0].y + Rects[0].h;
		Rects[4].w = Appearance->Rects[4].w;
		Rects[4].h = h2;
		
		Rects[5].x = Rects[1].x;
		Rects[5].y = Rects[3].y + Rects[3].h;
		Rects[5].w = w;
		Rects[5].h = Appearance->Rects[5].h;

		Rects[6].x = Rects[2].x;
		Rects[6].y = Rects[4].y;
		Rects[6].w = Appearance->Rects[6].w;
		Rects[6].h = h2;
		
		
		Rects[7].x = Rects[1].x;
		Rects[7].y = Rects[5].y + Rects[5].h;
		Rects[7].w = w;
		Rects[7].h = h3;

		
		Rects[8].x = Rects[0].x;
		Rects[8].y = Rects[4].y + Rects[4].h;
		Rects[8].w = Appearance->Rects[8].w;
		Rects[8].h = Appearance->Rects[8].h;
		
		Rects[9].x = Rects[1].x;
		Rects[9].y = Rects[8].y;
		Rects[9].w = w;
		Rects[9].h = Appearance->Rects[9].h;
		
		Rects[10].x = Rects[2].x;
		Rects[10].y = Rects[8].y;
		Rects[10].w = Appearance->Rects[10].w;
		Rects[10].h = Appearance->Rects[10].h;
		
		
		Rects[11].w = Appearance->Rects[11].w;
		Rects[11].h = Appearance->Rects[11].h;
		Rects[11].x = Rects[2].x - Rects[11].w - BUTTON_SEP;
		Rects[11].y = Rects[3].y + BUTTON_SEP;

		//----------------------------------------------------------------------------------
		// And fourth we'll set the position of the close button.
		//----------------------------------------------------------------------------------
		aux.x = Rects[11].x - BUTTONX_SEP;
		aux.y = Rects[11].y - BUTTONY_SEP;
		aux.w = Rects[11].w + BUTTON_SEP;
		aux.h = Rects[11].h + BUTTON_SEP;

		Close->SetRect(aux);
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	Dialog & Dialog::CopyFrom (const Dialog & obj)
	{
		Container::CopyFrom(obj);

		ITextControl::CopyFrom(obj);
		
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		for(int i = 0; i < MAX_DIALOG_RECTS; ++i)
		{
			Rects[i] = obj.Rects[i];
		}

		Close->CopyFrom(*(obj.Close));
		Pressed = obj.Pressed;
		
		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		TitleColor = obj.TitleColor;

		return (*this);
	}
}
//******************************************************************************************
// Dialog.cpp
//******************************************************************************************