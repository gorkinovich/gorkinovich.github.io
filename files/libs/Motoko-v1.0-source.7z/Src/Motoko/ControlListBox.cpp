//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../ControlListBox.h"
#include "../Keys.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define SCROLLBARS_SIZE 20
#define SCB_LARGECHANGE 10
#define SCROLL_FACTOR   10
//------------------------------------------------------------------------------------------
#define RECTXCTRL_SEP 5
#define RECTYCTRL_SEP 5
//------------------------------------------------------------------------------------------
#define RECTX_SEP 2
#define RECTY_SEP 2
#define RECTW_SEP 4
#define RECTH_SEP 4
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  ListBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	ControlListBox::ControlListBox () : Box()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ControlListBox";

		VBar = new VScrollBar();

		string aux;

		aux = Name + "_VBar"; VBar->SetName(aux.c_str());

		VBar->SetLargeChange(SCB_LARGECHANGE);
		
		VBar->SetMin(0);
		VBar->SetMax(0);
		VBar->SetValue(0);

		MaxWidth  = 0;
		MaxHeight = 0;

		NumCols = 0;
		NumRows = 0;

		FirstSelect = -1;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		MultiSelect = false;
		SelectedItems.clear();

		SelColor = 0x00000000;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ListBox constructor.
	 */
	//--------------------------------------------------------------------------------------
	ControlListBox::ControlListBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					  Uint32 backcolor,  ControlSkin * appearance, SDL_Surface * picture,
					  SDL_Surface * mousepointer, bool transparency, Uint32 selcolor,
					  bool multisel, bool enable, bool visible) :
		Box(name, rect, backstyle, backcolor, appearance, picture, mousepointer,
			transparency, enable, visible)
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		Type = "ControlListBox";

		VBar = new VScrollBar();

		string aux;

		aux = Name + "_VBar"; VBar->SetName(aux.c_str());

		VBar->SetLargeChange(SCB_LARGECHANGE);
		
		VBar->SetMin(0);
		VBar->SetMax(0);
		VBar->SetValue(0);

		MaxWidth  = 0;
		MaxHeight = 0;

		NumCols = 0;
		NumRows = 0;

		FirstSelect = -1;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		MultiSelect = multisel;
		SelectedItems.clear();

		SelColor = selcolor;

		UpdateRects();
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ControlListBox copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ControlListBox::ControlListBox (const ControlListBox & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ControlListBox operator =.
	 */
	//--------------------------------------------------------------------------------------
	ControlListBox & ControlListBox::operator = (const ControlListBox & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ControlListBox destructor.
	 */
	//--------------------------------------------------------------------------------------
	ControlListBox::~ControlListBox ()
	{
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		MaxWidth  = 0;
		MaxHeight = 0;

		NumCols = 0;
		NumRows = 0;

		delete VBar;

		FirstSelect = -1;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		List.Free();
		MultiSelect = false;
		SelectedItems.clear();

		SelColor = 0x00000000;
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the items of the control.
	//--------------------------------------------------------------------------------------
	void ControlListBox::DrawList (void)
	{
		//----------------------------------------------------------------------------------
		// This function will draw the list of items into the control.
		//----------------------------------------------------------------------------------
		if(List.GetSize() <= 0) return;

		//----------------------------------------------------------------------------------
		// We will need some variables, i it's to control the actual row, j it's to control
		// the actual colum, k it's to read the visible controls in the list, it it's to
		// read the list of selected items, caux is a pointer to the actual control to be
		// drawn, and aux it's to set the area of the filling rect for a selected item.
		//----------------------------------------------------------------------------------
		int i, j, k;
		list<int>::iterator it = SelectedItems.begin();
		SDL_Rect aux;
		Control * caux;
		
		aux.y = Rect.y - RECTY_SEP + RECTYCTRL_SEP;

		k = VBar->GetValue() * NumCols;
		
		//----------------------------------------------------------------------------------
		// The previous controls that will not be drawn, will be hidden.
		//----------------------------------------------------------------------------------
		for(i = 0; i < k; ++i)
		{
			List.GetControl(i)->SetVisible(false);
		}

		//----------------------------------------------------------------------------------
		// Here we seek the first visible selected item in the control.
		//----------------------------------------------------------------------------------
		while((it != SelectedItems.end()) && (*it < k)) ++it;

		//----------------------------------------------------------------------------------
		// We'll draw the maximum number of rows available.
		//----------------------------------------------------------------------------------
		for(i = 0; i < NumRows; ++i)
		{
			//------------------------------------------------------------------------------
			// Before we start to draw the row, we need to initialize the x coordinate.
			//------------------------------------------------------------------------------
			aux.x = Rect.x - RECTX_SEP + RECTXCTRL_SEP;

			//------------------------------------------------------------------------------
			// We'll draw the maximum number of colums available.
			//------------------------------------------------------------------------------
			for(j = 0; j < NumCols; ++j)
			{
				//--------------------------------------------------------------------------
				// If we get at the end of the list of controls we get out the function.
				//--------------------------------------------------------------------------
				if(k >= List.GetSize()) return;

				//--------------------------------------------------------------------------
				// We take the actual control and set it visible.
				//--------------------------------------------------------------------------
				caux = List.GetControl(k);

				caux->SetVisible(true);

				//--------------------------------------------------------------------------
				// If the current control is an item selected, we calculate the dimensions
				// of the fill area, and fill that area with the selection color.
				//--------------------------------------------------------------------------
				if((it != SelectedItems.end()) && (*it == k))
				{
					aux.w = caux->GetWidth() + RECTW_SEP;
					aux.h = caux->GetHeight() + RECTH_SEP;

					FillSurface(SelColor, &aux, CRM32Pro.screen, &(Rects[CENTER_BOX_RECT]));
					++it;
				}

				//--------------------------------------------------------------------------
				// Now we must calculate the coordinates where the control will be drawn.
				//--------------------------------------------------------------------------
				caux->SetX(aux.x + RECTX_SEP);
				caux->SetY(aux.y + RECTY_SEP);

				//--------------------------------------------------------------------------
				// And after the operations we draw the control.
				//--------------------------------------------------------------------------
				caux->Draw();

				//--------------------------------------------------------------------------
				// So we get the next position of the list of controls, and we calculate
				// the next x coordinate, where the control will be drawn.
				//--------------------------------------------------------------------------
				++k;
				
				aux.x += MaxHeight + RECTXCTRL_SEP;
			}

			//------------------------------------------------------------------------------
			// After paint a row, we must calculate the coordinate of the next row.
			//------------------------------------------------------------------------------
			aux.y += MaxWidth + RECTYCTRL_SEP;
		}

		//----------------------------------------------------------------------------------
		// The nexts controls that will not be drawn, will be hidden.
		//----------------------------------------------------------------------------------
		for(; k < List.GetSize(); ++k)
		{
			List.GetControl(k)->SetVisible(false);
		}
	}
	
	//--------------------------------------------------------------------------------------
	/// This function draw the control.
	//--------------------------------------------------------------------------------------
	void ControlListBox::Draw (void)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't be drawn.
		//----------------------------------------------------------------------------------
		if(Visible == false) return;

		switch(BackStyle)
		{
		//----------------------------------------------------------------------------------
		// If the BackStyle is UseAppearance, the function will draw a skinned listbox.
		//----------------------------------------------------------------------------------
		case UseAppearance:
			//------------------------------------------------------------------------------
			// If we haven't a skin for the control, the function will fill the control
			// with the BackColor (if the transparency isn't true), and after that will
			// draw the surface inside the variable Picture.
			//------------------------------------------------------------------------------
			if(Appearance == NULL)
			{
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

				if(Picture != NULL)
					BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			}
			//------------------------------------------------------------------------------
			// But if we have a skin, we'll draw a filled box.
			//------------------------------------------------------------------------------
			else
			{
				int i;

				//--------------------------------------------------------------------------
				// We read the rects before the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = 0; i < CENTER_BOX_RECT; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}

				//--------------------------------------------------------------------------
				// If the transparency is false, we'll fill the center rect with BackColor.
				//--------------------------------------------------------------------------
				if(Transparency == false)
					SDL_FillRect(CRM32Pro.screen, &(Rects[CENTER_BOX_RECT]), BackColor);
				
				//--------------------------------------------------------------------------
				// We read the rects after the center rect, and paint the box's borders.
				//--------------------------------------------------------------------------
				for(i = CENTER_BOX_RECT + 1; i < MAX_BOX_RECTS; ++i)
				{
					BlitWithResize(Appearance->Texture, &(Appearance->Rects[i]),
								   CRM32Pro.screen, &(Rects[i]));
				}
			}
			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UseBackColor, we'll draw this using the back color.
		//----------------------------------------------------------------------------------
		case UseBackColor:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			break;

		//----------------------------------------------------------------------------------
		// If the BackStyle is UsePicture, we'll draw this using the surface in Picture.
		//----------------------------------------------------------------------------------
		case UsePicture:
			if(Transparency == false)
				SDL_FillRect(CRM32Pro.screen, &Rect, BackColor);

			if(Picture != NULL)
				BlitWithResize(Picture, NULL, CRM32Pro.screen, &Rect);
			
			break;
		}

		//----------------------------------------------------------------------------------
		// Finally we'll draw the list of items into the listbox.
		//----------------------------------------------------------------------------------
		DrawList();

		//----------------------------------------------------------------------------------
		// And of course, we will draw the vertical scrollbar.
		//----------------------------------------------------------------------------------
		VBar->Draw();
	}

	//--------------------------------------------------------------------------------------
	/// This function update the control.
	//--------------------------------------------------------------------------------------
	bool ControlListBox::Update (SDL_Event & event)
	{
		//----------------------------------------------------------------------------------
		// If the control is not visible, obviously it can't handle any event.
		//----------------------------------------------------------------------------------
		if((Visible == false) || (Enable == false)) return false;

		//----------------------------------------------------------------------------------
		// We pass the event to the scrollbar to see if it catches any event.
		//----------------------------------------------------------------------------------
		if(VBar->Update(event)) return true;

		//----------------------------------------------------------------------------------
		// If the list is active, we'll update every control in the list. And if one
		// control of the list catch an event, we'll push to the top of the screen this
		// dialog, and we'll return true.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.GetSize(); ++i)
		{
			if(List.GetControl(i)->Update(event))
			{
				//--------------------------------------------------------------------------
				// Here we will make posible for the user to interact with the control,
				// making posible select some of the items inside the list. But this will
				// be posible only with the left button of the mouse.
				//--------------------------------------------------------------------------
				if(event.type == SDL_MOUSEBUTTONDOWN)
				{
					if(event.button.button == SDL_BUTTON_LEFT)
					{
						bool finded = false;
						
						//------------------------------------------------------------------
						// First we need to find, if we have used the mouse with the ctrl
						// key, if the pressed item isn't inside the selected item. If the
						// item was a selected one, we erase it from the selected list.
						//------------------------------------------------------------------
						if(CRM32Pro.keystate[Keys::KEY_LCTRL] || CRM32Pro.keystate[Keys::KEY_RCTRL])
						{
							list<int>::iterator it;

							for(it = SelectedItems.begin(); it != SelectedItems.end(); ++it)
							{
								if(*it == i)
								{
									finded = true;
									SelectedItems.erase(it);
									break;
								}
							}
						}

						//------------------------------------------------------------------
						// If we haven't find the pressed index in the select list, we'll
						// add that pressed index into the select list.
						//------------------------------------------------------------------
						if(!finded)
						{
							//--------------------------------------------------------------
							// If the list is multi-select, maybe we can add one or more
							// indexes to the select list.
							//--------------------------------------------------------------
							if(MultiSelect)
							{
								//----------------------------------------------------------
								// We check if the control key is pressed, to permit to
								// select any item of the list.
								//----------------------------------------------------------
								if(CRM32Pro.keystate[Keys::KEY_LCTRL] || CRM32Pro.keystate[Keys::KEY_RCTRL])
								{
									if(FirstSelect == -1) FirstSelect = i;

									SelectedItems.push_back(i);
									SelectedItems.sort();
								}
								//----------------------------------------------------------
								// We check if the shift key is pressed, to permit to
								// select more than one item of the list, with one click.
								//----------------------------------------------------------
								else if(CRM32Pro.keystate[Keys::KEY_LSHIFT] || CRM32Pro.keystate[Keys::KEY_RSHIFT])
								{
									if(FirstSelect == -1)
									{
										FirstSelect = i;
										SetNoSelectedItems();
										SelectedItems.push_back(i);
									}
									else if(FirstSelect < i)
									{
										SetNoSelectedItems();
										for(int j = FirstSelect; j <= i; ++j)
											SelectedItems.push_back(j);
									}
									else if(FirstSelect > i)
									{
										SetNoSelectedItems();
										for(int j = i; j <= FirstSelect; ++j)
											SelectedItems.push_back(j);
									}
								}
								//----------------------------------------------------------
								// Any other option we'll clear the select list, and will
								// add the current selected index.
								//----------------------------------------------------------
								else
								{
									FirstSelect = i;
									SetNoSelectedItems();
									SelectedItems.push_back(i);
								}
							}
							//--------------------------------------------------------------
							// If the listbox isn't a multi-select one, we'll erase al the
							// select list, and will add the current index.
							//--------------------------------------------------------------
							else
							{
								FirstSelect = i;
								SetNoSelectedItems();
								SelectedItems.push_back(i);
							}
						}
					}
					//----------------------------------------------------------------------
					// If the user press the wheel up, we'll move up the scrollbar.
					//----------------------------------------------------------------------
					else if(event.button.button == SDL_BUTTON_WHEELUP)
					{
						VBar->SetValue(VBar->GetValue() - VBar->GetSmallChange());
					}
					//----------------------------------------------------------------------
					// If the user press the wheel down, we'll move down the scrollbar.
					//----------------------------------------------------------------------
					else if(event.button.button == SDL_BUTTON_WHEELDOWN)
					{
						VBar->SetValue(VBar->GetValue() + VBar->GetSmallChange());
					}
				}

				return true;
			}
		}


		switch(event.type)
		{
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse pressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONDOWN:
			if(IsCursorOver())
			{
				//--------------------------------------------------------------------------
				// If no item was pressed, after check if any control inside the list, we
				// set that there isn't any selected item in the control.
				//--------------------------------------------------------------------------
				if(event.button.button == SDL_BUTTON_LEFT)
				{
					FirstSelect = -1;
					SetNoSelectedItems();
				}
				//--------------------------------------------------------------------------
				// If the user press the wheel up, we'll move up the scrollbar.
				//--------------------------------------------------------------------------
				else if(event.button.button == SDL_BUTTON_WHEELUP)
				{
					VBar->SetValue(VBar->GetValue() - VBar->GetSmallChange());
				}
				//--------------------------------------------------------------------------
				// If the user press the wheel down, we'll move down the scrollbar.
				//--------------------------------------------------------------------------
				else if(event.button.button == SDL_BUTTON_WHEELDOWN)
				{
					VBar->SetValue(VBar->GetValue() + VBar->GetSmallChange());
				}

				//--------------------------------------------------------------------------
				// And if MouseButtonDown isn't NULL, we call that function.
				//--------------------------------------------------------------------------
				if(MouseButtonDown != NULL)
					MouseButtonDown((void *) this, event.button);
				
				return true;
			}
			break;
			
		//----------------------------------------------------------------------------------
		// The event is a button of the mouse unpressed over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEBUTTONUP:
			if(IsCursorOver())
			{
				if(MouseButtonUp != NULL)
					MouseButtonUp((void *) this, event.button);
				
				return true;
			}
			break;

		//----------------------------------------------------------------------------------
		// The event is a movement of the mouse over the control.
		//----------------------------------------------------------------------------------
		case SDL_MOUSEMOTION:
			if((MouseMotion != NULL) && IsCursorOver())
				return MouseMotion((void *) this, event.motion);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard pressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYDOWN:
			if(KeyDown != NULL)
				return KeyDown((void *) this, event.key);
			break;

		//----------------------------------------------------------------------------------
		// The event is a key of the keyboard unpressed.
		//----------------------------------------------------------------------------------
		case SDL_KEYUP:
			if(KeyUp != NULL)
				return KeyUp((void *) this, event.key);
			break;
		}

		//----------------------------------------------------------------------------------
		// If no event is caught, the we return false.
		//----------------------------------------------------------------------------------
		return false;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	ControlListBox & ControlListBox::CopyFrom (const ControlListBox & obj)
	{
		Box::CopyFrom(obj);
		
		//----------------------------------------------------------------------------------
		// Logic
		//----------------------------------------------------------------------------------
		VBar->CopyFrom(*(obj.VBar));

		MaxWidth  = obj.MaxWidth;
		MaxHeight = obj.MaxHeight;

		NumCols = obj.NumCols;
		NumRows = obj.NumRows;

		FirstSelect = obj.FirstSelect;

		//----------------------------------------------------------------------------------
		// Properties
		//----------------------------------------------------------------------------------
		List          = obj.List;
		MultiSelect   = obj.MultiSelect;
		SelectedItems = obj.SelectedItems;
		SelColor      = obj.SelColor;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the values of the scrollbars.
	//--------------------------------------------------------------------------------------
	void ControlListBox::UpdateValues (void)
	{
		//----------------------------------------------------------------------------------
		// First we must to calculate how much colums and rows will be posible to draw
		// inside the actual dimension of the control.
		//----------------------------------------------------------------------------------
		NumCols = Rect.w / (MaxWidth + RECTXCTRL_SEP);
		NumRows = Rect.h / (MaxHeight + RECTYCTRL_SEP);

		//----------------------------------------------------------------------------------
		// And second we'll check how will be the final maximum value of the scrollbar.
		//----------------------------------------------------------------------------------
		int val = ((NumCols != 0) ? (List.GetSize() / NumCols + 1 - NumRows) : 0);
		VBar->SetMax(val >= 0 ? val : 0);
	}

	//--------------------------------------------------------------------------------------
	/// This function update the rects in the actual object.
	//--------------------------------------------------------------------------------------
	void ControlListBox::UpdateRects (void)
	{
		//----------------------------------------------------------------------------------
		// First we call the UpdateRects function of the Box class.
		//----------------------------------------------------------------------------------
		Box::UpdateRects();

		SDL_Rect aux;

		//----------------------------------------------------------------------------------
		// Second we check if the control have any correct skin, setting the position
		// of the vertical scrollbar in the list, if we have a skin in the control.
		//----------------------------------------------------------------------------------
		if((Appearance == NULL) || (Appearance->NumRects != MAX_BOX_RECTS))
		{
			aux.x = Rect.x - SCROLLBARS_SIZE;
			aux.y = Rect.y;
			aux.w = SCROLLBARS_SIZE;
			aux.h = Rect.h;
		}
		else
		{
			aux.x = Rects[CENTER_BOX_RECT + 1].x - SCROLLBARS_SIZE;
			aux.y = Rects[CENTER_BOX_RECT].y;
			aux.w = SCROLLBARS_SIZE;
			aux.h = Rects[CENTER_BOX_RECT].h;
		}

		VBar->SetRect(aux);

		//----------------------------------------------------------------------------------
		// And after all we will update the value of the listbox's scrollbar.
		//----------------------------------------------------------------------------------
		UpdateValues();
	}

	//--------------------------------------------------------------------------------------
	// Get the mouse pointer of the control.
	//--------------------------------------------------------------------------------------
	SDL_Surface * ControlListBox::GetMousePointer (void)
	{
		//----------------------------------------------------------------------------------
		// This function is to obtain the MousePointer of the control that is under the
		// mouse cursor. To make this posible we check if the cursor is over for all the
		// controls inside the container. If the cursor is over one control, we will return
		// the MousePointer of that control.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < List.GetSize(); ++i)
		{
			if(List.GetControl(i)->IsCursorOver())
			{
				return List.GetControl(i)->GetMousePointer();
			}
		}

		//----------------------------------------------------------------------------------
		// If there isn't any control, under the mouse cursor, we return the MousePointer
		// of the actual container.
		//----------------------------------------------------------------------------------
		return MousePointer;
	}
	
	//--------------------------------------------------------------------------------------
	// Add a control in the container.
	//--------------------------------------------------------------------------------------
	int ControlListBox::AddControl (Control * control)
	{
		//----------------------------------------------------------------------------------
		// This function adds a control inside the container, but dialogs are not allowed
		// to be added inside a container. Why? Because I think it can't be usefull to put
		// one dialog inside other dialog, or things more bizarre.
		//----------------------------------------------------------------------------------
		if(strcmp(control->GetType(), "Dialog") != STR_EQU)
		{
			int error = List.AddControl(control);

			//------------------------------------------------------------------------------
			// If there isn't any error we must update the maximum height and width in the
			// control, and update the values of the scrollbar.
			//------------------------------------------------------------------------------
			if(!error)
			{
				if(MaxWidth < control->GetWidth())
					MaxWidth = control->GetWidth();

				if(MaxHeight < control->GetHeight())
					MaxHeight = control->GetHeight();

				UpdateValues();
			}

			return error;
		}
		//----------------------------------------------------------------------------------
		// If you try to add a dialog to the container, an error will be returned.
		//----------------------------------------------------------------------------------
		else
		{
			return LISTCONTROLS_ERROR_BADTYPE;
		}
	}
}
//******************************************************************************************
// ControlListBox.cpp
//******************************************************************************************