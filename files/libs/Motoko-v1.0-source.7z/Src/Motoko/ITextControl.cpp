//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "../ITextControl.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/**
	 *  ITextControl constructor.
	 */
	//--------------------------------------------------------------------------------------
	ITextControl::ITextControl ()
	{
		Alignment = Left;
		Text      = "";
		Font      = NULL;
		WidthText = 0;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ITextControl constructor.
	 */
	//--------------------------------------------------------------------------------------
	ITextControl::ITextControl (const char * text, CRM32Pro_CFont * font, AlignmentStyle alignment)
	{
		Alignment = alignment;
		Text      = text;
		Font      = font;
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ITextControl copy constructor.
	 */
	//--------------------------------------------------------------------------------------
	ITextControl::ITextControl (const ITextControl & obj)
	{
		CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ITextControl operator =.
	 */
	//--------------------------------------------------------------------------------------
	ITextControl & ITextControl::operator = (const ITextControl & obj)
	{
		return CopyFrom(obj);
	}

	//--------------------------------------------------------------------------------------
	/**
	 *  ITextControl destructor.
	 */
	//--------------------------------------------------------------------------------------
	ITextControl::~ITextControl ()
	{
		Alignment = Left;
		Text      = "";
		Font      = NULL;
		WidthText = 0;
	}

	//--------------------------------------------------------------------------------------
	/// This function copies obj in the actual object.
	/**
	 *  @param obj Object to copy.
	 *  @return A reference to the actual object.
	 */
	//--------------------------------------------------------------------------------------
	ITextControl & ITextControl::CopyFrom (const ITextControl & obj)
	{
		Alignment = obj.Alignment;
		Text      = obj.Text;
		Font      = obj.Font;
		WidthText = obj.WidthText;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the text.
	//--------------------------------------------------------------------------------------
	void ITextControl::DrawText (SDL_Surface * buffer, int y, SDL_Rect * rect, int sepy, int sepx)
	{
		//----------------------------------------------------------------------------------
		// This function draw a text in a limited area, with a specific alignment in that
		// text. We also can chose in what position of the y-axis we want to put the text.
		// But the x-axis will be determinated by the alignment, in the next cases:
		// + Left: We only will need to take the x coordinate of the rect.
		// + Center: We will need to take the width of the text, to substract it to the
		//           width of the area, and divide all by 2. This will give us a distance,
		//           that we will use to add it to the x coordinate of the rect, and we
		//           will obtain the final center x coordinate.
		// + Right: First we obtain the maximum x coordinate of the area, adding the width
		//          of the rect to the x coordinate of this. After that, we will substract
		//          the width of the text and the value in sepx, this is the "separation
		//          from the border in the x coordinate" (the sepy is the same but in the
		//          y coordinate).
		// After calculate the final x coordinate, we will draw the string with Font.
		//----------------------------------------------------------------------------------
		if(Font != NULL)
		{
			int x;

			switch(Alignment)
			{
			case Left:
				x = rect->x + sepx / 2;
				break;

			case Center:
				x = rect->x + (rect->w - WidthText) / 2;
				break;
					
			case Right:
				x = rect->x + rect->w - WidthText - sepx;
				break;
			}

			Font->PutString(buffer, x, y + sepy, (char *) Text.c_str(), rect);
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the text for a TextBox.
	//--------------------------------------------------------------------------------------
	void ITextControl::DrawText2 (SDL_Surface * buffer, int y, SDL_Rect * rect, int sepy, int sepx)
	{
		//----------------------------------------------------------------------------------
		// This function is like DrawText, but with a litle diference, if we have a text
		// with a width greater than the width of the area in rect, the text will be
		// aligned to the right. Why can be this usefull? Well if you have a TextBox,
		// probably you would like to see what are you writing.
		//----------------------------------------------------------------------------------
		if(Font != NULL)
		{
			int x;

			if(WidthText < rect->w)
			{
				switch(Alignment)
				{
				case Left:
					x = rect->x + sepx / 2;
					break;

				case Center:
					x = rect->x + (rect->w - WidthText) / 2;
					break;
						
				case Right:
					x = rect->x + rect->w - WidthText - sepx;
					break;
				}
			}
			else
			{
				x = rect->x + rect->w - WidthText - sepx;
			}

			Font->PutString(buffer, x, y + sepy, (char *) Text.c_str(), rect);
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the text.
	//--------------------------------------------------------------------------------------
	void ITextControl::DrawString (SDL_Surface * buffer, string & txt, int x, int y,
								   SDL_Rect * rect, int sepy, int sepx)
	{
		//----------------------------------------------------------------------------------
		// xdst is the final x coordinate where we will draw the text.
		// width is the width of the txt string in the actual font.
		//----------------------------------------------------------------------------------
		int xdst, width = Font->StringWidth((char *) txt.c_str());

		//----------------------------------------------------------------------------------
		// This function is like DrawText, but we will be able to choose which text we want
		// to draw, and what will be the base x coordinate.
		//----------------------------------------------------------------------------------
		switch(Alignment)
		{
		case Left:
			xdst = x + sepx / 2;
			break;

		case Center:
			xdst = x + (rect->w - width) / 2;
			break;
				
		case Right:
			xdst = x + rect->w - width - sepx;
			break;
		}

		Font->PutString(buffer, xdst, y + sepy, (char *) txt.c_str(), rect);
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the text.
	//--------------------------------------------------------------------------------------
	void ITextControl::DrawTextMultiline (SDL_Surface * buffer, int y, SDL_Rect * rect,
										  int sepy, int sepx)
	{
		//----------------------------------------------------------------------------------
		// Basically this function well be use to draw a multi-line text. To make this
		// posible, we need to take the Text variable and read each line, one by one.
		// Every time we read one line, we will draw it. And there are two posible
		// conditions that make a jump-line, the \n character or if we have a line more
		// longer than the actual area width.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return;

		string line, aux;

		int i, width, inch = Font->GetSurface()->h;
		
		width = 0;
		line  = "";
		aux   = "";

		//----------------------------------------------------------------------------------
		// This loop read the whole Text string, taking each word inside the string. Every
		// new word taken from Text, will be added to line if there isn't the second
		// jump-line condition (the line is longer than the actual area), and that line
		// will be drawn after complete it.
		//----------------------------------------------------------------------------------
		for(i = 0; i < Text.size(); ++i)
		{
			//------------------------------------------------------------------------------
			// We read characters from Text, putting them into aux, to obtain a word.
			//------------------------------------------------------------------------------
			while((i < Text.size()) && (Text[i] != ' ') && (Text[i] != '\n'))
			{
				aux += Text[i];
				++i;
			}

			//------------------------------------------------------------------------------
			// We check if we have got to the end of the string.
			//------------------------------------------------------------------------------
			if(i < Text.size())
			{
				//--------------------------------------------------------------------------
				// If the last read character is a blank space, we add it to the word.
				//--------------------------------------------------------------------------
				if(Text[i] != '\n')
					aux += Text[i];

				//--------------------------------------------------------------------------
				// First we take a look to the width of the word.
				//--------------------------------------------------------------------------
				width += Font->StringWidth((char *) aux.c_str());

				//--------------------------------------------------------------------------
				// If the actual width of the line is less than the width of the area, or
				// the line is empty, we add the word to the line. This is to prevent an
				// innecesary jump of line, when we have an empty line, but a word longer
				// than the width of the actual area.
				//--------------------------------------------------------------------------
				if((width < rect->w) || (line.size() == 0))
				{
					//----------------------------------------------------------------------
					// We add the word to the line, and reset the aux variable.
					//----------------------------------------------------------------------
					line += aux;
					aux = "";

					//----------------------------------------------------------------------
					// And if the last character is a jump-line, then we draw the line,
					// actualize the y coordinate, and reset the line variable.
					//----------------------------------------------------------------------
					if(Text[i] == '\n')
					{
						DrawString(buffer, line, rect->x, y, rect, sepy, sepx);
						y += (inch + sepy);
						
						width = 0;
						line  = "";
					}
				}
				//--------------------------------------------------------------------------
				// But if the line if not empty, we draw the actual line, actualize the y
				// coordinate, and write over the line variable, with the value of aux.
				//--------------------------------------------------------------------------
				else
				{
					//----------------------------------------------------------------------
					// We draw the actual line stored. And after that we actualize the y
					// coordinate, overwrite line with the word in aux, and reset aux.
					//----------------------------------------------------------------------
					DrawString(buffer, line, rect->x, y, rect, sepy, sepx);
					y += (inch + sepy);
					
					width = Font->StringWidth((char *) aux.c_str());
					line  = aux;
					aux   = "";

					//----------------------------------------------------------------------
					// And if the last character is a jump-line, then we draw the line,
					// actualize the y coordinate, and reset the line variable.
					//----------------------------------------------------------------------
					if(Text[i] == '\n')
					{
						DrawString(buffer, line, rect->x, y, rect, sepy, sepx);
						y += (inch + sepy);
						
						width = 0;
						line  = "";
					}
				}
			}
			//------------------------------------------------------------------------------
			// If there isn't more inside the string, we have to complete the final line.
			//------------------------------------------------------------------------------
			else
			{
				//--------------------------------------------------------------------------
				// First we take a look to the width of the word.
				//--------------------------------------------------------------------------
				width += Font->StringWidth((char *) aux.c_str());

				//--------------------------------------------------------------------------
				// If the actual width of the line is less than the width of the area, or
				// the line is empty, we add the word to the line. This is to prevent an
				// innecesary jump of line, when we have an empty line, but a word longer
				// than the width of the actual area.
				//--------------------------------------------------------------------------
				if((width < rect->w) || (line.size() == 0))
				{
					line += aux;
				}
				//--------------------------------------------------------------------------
				// But if the line if not empty, we draw the actual line, actualize the y
				// coordinate, and write over the line variable, with the value of aux.
				//--------------------------------------------------------------------------
				else
				{
					DrawString(buffer, line, rect->x, y, rect, sepy, sepx);
					y += (inch + sepy);
					
					line = aux;
				}
			}
		}

		//----------------------------------------------------------------------------------
		// If the line is not empty we call to DrawString to paint on screen the line.
		//----------------------------------------------------------------------------------
		if(line.size() > 0)
		{
			DrawString(buffer, line, rect->x, y, rect, sepy, sepx);
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the text for TextBox.
	//--------------------------------------------------------------------------------------
	void ITextControl::DrawTextMultiline2 (SDL_Surface * buffer, int x, int y, SDL_Rect * rect,
										   int sepy, int sepx)
	{
		//----------------------------------------------------------------------------------
		// Basically this function well be use to draw a multi-line text. To make this
		// posible, we need to take the Text variable and read each line, one by one.
		// Every time we read one line, we will draw it. And in this version there are
		// only one posible condition that make a jump-line, the \n character.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return;

		string line;

		int i, inch = Font->GetSurface()->h;
		
		line  = "";

		//----------------------------------------------------------------------------------
		// This loop read the whole Text string, taking each line inside the string.
		//----------------------------------------------------------------------------------
		for(i = 0; i < Text.size(); ++i)
		{
			//------------------------------------------------------------------------------
			// If the actual character is a jump-line, we draw the string, actualize the
			// y coordinate, and reset the line variable.
			//------------------------------------------------------------------------------
			if(Text[i] == '\n')
			{
				DrawString(buffer, line, x, y, rect, sepy, sepx);
				y += (inch + sepy);
				
				line = "";
			}
			//------------------------------------------------------------------------------
			// With the other characters, we add them to the actual line.
			//------------------------------------------------------------------------------
			else
			{
				line += Text[i];
			}
		}

		//----------------------------------------------------------------------------------
		// If the line is not empty we call to DrawString to paint on screen the line.
		//----------------------------------------------------------------------------------
		if(line.size() > 0)
		{
			DrawString(buffer, line, x, y, rect, sepy, sepx);
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function draw the text.
	//--------------------------------------------------------------------------------------
	void ITextControl::DrawTextCenter (SDL_Surface * buffer, SDL_Rect * rect)
	{
		//----------------------------------------------------------------------------------
		// This function calculates the x and y coordinate to draw the text in the center
		// of the rect, this is used in controls like Button.
		//----------------------------------------------------------------------------------
		if(Font != NULL)
		{
			int x = rect->x + (rect->w - WidthText) / 2;
			int y = rect->y + (rect->h - Font->GetSurface()->h) / 2;

			Font->PutString(buffer, x, y, (char *) Text.c_str(), rect);
		}
	}

	//--------------------------------------------------------------------------------------
	/// This function update the width of the text.
	//--------------------------------------------------------------------------------------
	void ITextControl::UpdateWidth (void)
	{
		//----------------------------------------------------------------------------------
		// Each time we change the Text, the object calls this function, that update the
		// actual width of the text in pixels, with the actual font.
		//----------------------------------------------------------------------------------
		if(Font != NULL)
		{
			WidthText = Font->StringWidth((char *) Text.c_str());
		}
		else
		{
			WidthText = 0;
		}
	}

	//--------------------------------------------------------------------------------------
	// Get the height of the font.
	//--------------------------------------------------------------------------------------
	int ITextControl::GetFontHeight (void)
	{
		//----------------------------------------------------------------------------------
		// This function gives the actual height of the current font.
		//----------------------------------------------------------------------------------
		if(Font != NULL)
		{
			return Font->GetSurface()->h;
		}
		else
		{
			return 0;
		}
	}

	//--------------------------------------------------------------------------------------
	// Get the max width of the text in a multiline context.
	//--------------------------------------------------------------------------------------
	int ITextControl::GetMaxWidth (void)
	{
		//----------------------------------------------------------------------------------
		// This function is used to calculate what is the maximum width of a multi-line
		// text, reading all the lines and checking their widths.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return 0;

		string line;

		int i, maxwidth, actwidth;
		
		maxwidth = 0;
		actwidth = 0;

		//----------------------------------------------------------------------------------
		// This loop read the whole Text string, taking each line inside the string.
		//----------------------------------------------------------------------------------
		for(i = 0; i < Text.size(); ++i)
		{
			//------------------------------------------------------------------------------
			// First we reset the line variable.
			//------------------------------------------------------------------------------
			line = "";

			//------------------------------------------------------------------------------
			// Second we read a whole line.
			//------------------------------------------------------------------------------
			while((i < Text.size()) && (Text[i] != '\n'))
			{
				line += Text[i];
				++i;
			}

			//------------------------------------------------------------------------------
			// Third we calculate the width of the actual line.
			//------------------------------------------------------------------------------
			actwidth = Font->StringWidth((char *) line.c_str());

			//------------------------------------------------------------------------------
			// And if this width is greater than the maximum, we overwrite maxwidth.
			//------------------------------------------------------------------------------
			if(maxwidth < actwidth)
				maxwidth = actwidth;
		}

		//----------------------------------------------------------------------------------
		// After the process we return the value of maxwidth.
		//----------------------------------------------------------------------------------
		return maxwidth;
	}

	//--------------------------------------------------------------------------------------
	// Get the width of the last line of the text.
	//--------------------------------------------------------------------------------------
	int ITextControl::GetWidthLastLine (void)
	{
		//----------------------------------------------------------------------------------
		// This function is used to calculate the width of the last line in the text. This
		// is used in the TextBox to update the value of the horizontal scrollbar.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return 0;

		string line = "";

		//----------------------------------------------------------------------------------
		// We read the text from the end to the beginning, adding character to the line
		// variable, until we get the end or a jump-line character.
		//----------------------------------------------------------------------------------
		for(int i = Text.size() - 1; i >= 0; --i)
		{
			if(Text[i] == '\n') break;

			line += Text[i];
		}

		//----------------------------------------------------------------------------------
		// And after obtain the last line, we return the width of that line.
		//----------------------------------------------------------------------------------
		return Font->StringWidth((char *) line.c_str());
	}

	//--------------------------------------------------------------------------------------
	// Get the min number of lines of the text in a multiline context.
	//--------------------------------------------------------------------------------------
	int ITextControl::GetMinNumLines (int sepy)
	{
		//----------------------------------------------------------------------------------
		// This function calculates the minimum number of lines in a multi-line TextBox. We
		// use this when a multi-line TextBox have the horizontal scrollbar.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return 0;

		int numlines = 1;

		//----------------------------------------------------------------------------------
		// We read the whole string searching the \n character.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Text.size(); ++i)
		{
			if(Text[i] == '\n') numlines++;
		}

		//----------------------------------------------------------------------------------
		// After find them all, we calculate the height of the multi-line text.
		//----------------------------------------------------------------------------------
		return numlines * (Font->GetSurface()->h + sepy);
	}

	//--------------------------------------------------------------------------------------
	// Get the max number of lines of the text in a multiline context.
	//--------------------------------------------------------------------------------------
	int ITextControl::GetMaxNumLines (SDL_Rect * rect, int sepy)
	{
		//----------------------------------------------------------------------------------
		// This function calculates the maximum number of lines in a multi-line TextBox. We
		// use this when a multi-line TextBox haven't the horizontal scrollbar.
		//----------------------------------------------------------------------------------
		if(Font == NULL) return 0;

		string line, aux;

		int i, width, numlines = 1;
		
		width = 0;
		line  = "";
		aux   = "";

		//----------------------------------------------------------------------------------
		// This loop read the whole Text string, taking each word inside the string. Every
		// new word taken from Text, will be added to line if there isn't the second
		// jump-line condition (the line is longer than the actual area).
		//----------------------------------------------------------------------------------
		for(i = 0; i < Text.size(); ++i)
		{
			//------------------------------------------------------------------------------
			// We read characters from Text, putting them into aux, to obtain a word.
			//------------------------------------------------------------------------------
			while((i < Text.size()) && (Text[i] != ' ') && (Text[i] != '\n'))
			{
				aux += Text[i];
				++i;
			}

			//------------------------------------------------------------------------------
			// We check if we have got to the end of the string.
			//------------------------------------------------------------------------------
			if(i < Text.size())
			{
				//--------------------------------------------------------------------------
				// If the last read character is a blank space, we add it to the word.
				//--------------------------------------------------------------------------
				if(Text[i] != '\n')
					aux += Text[i];

				//--------------------------------------------------------------------------
				// First we take a look to the width of the word.
				//--------------------------------------------------------------------------
				width += Font->StringWidth((char *) aux.c_str());

				//--------------------------------------------------------------------------
				// If the actual width of the line is less than the width of the area, or
				// the line is empty, we add the word to the line. This is to prevent an
				// innecesary jump of line, when we have an empty line, but a word longer
				// than the width of the actual area.
				//--------------------------------------------------------------------------
				if((width < rect->w) || (line.size() == 0))
				{
					//----------------------------------------------------------------------
					// We add the word to the line, and reset the aux variable.
					//----------------------------------------------------------------------
					line += aux;
					aux = "";

					//----------------------------------------------------------------------
					// And if the last character is a jump-line, then we add a line to the
					// varible with the number of lines and reset the line variable.
					//----------------------------------------------------------------------
					if(Text[i] == '\n')
					{
						numlines++;
						
						width = 0;
						line  = "";
					}
				}
				//--------------------------------------------------------------------------
				// But if the line if not empty, we add a line to the varible with the
				// number of lines, and overwrite the line variable, with the value of aux.
				//--------------------------------------------------------------------------
				else
				{
					//----------------------------------------------------------------------
					// We add a line to the varible with the number of lines. And after
					// that we  overwrite line with the word in aux, and reset aux.
					//----------------------------------------------------------------------
					numlines++;
					
					width = Font->StringWidth((char *) aux.c_str());
					line  = aux;
					aux   = "";

					//----------------------------------------------------------------------
					// And if the last character is a jump-line, then we add a line to the
					// varible with the number of lines and reset the line variable.
					//----------------------------------------------------------------------
					if(Text[i] == '\n')
					{
						numlines++;
						line  = "";
					}
				}
			}
			//------------------------------------------------------------------------------
			// If there isn't more inside the string, we have to complete the final line.
			//------------------------------------------------------------------------------
			else
			{
				//--------------------------------------------------------------------------
				// First we take a look to the width of the word.
				//--------------------------------------------------------------------------
				width += Font->StringWidth((char *) aux.c_str());

				//--------------------------------------------------------------------------
				// If the line if not empty and the width is greater than the area, we must
				// to add a line to the varible with the number of lines.
				//--------------------------------------------------------------------------
				if((width >= rect->w) && (line.size() != 0))
				{
					numlines++;
				}
			}
		}

		//----------------------------------------------------------------------------------
		// After obtain the number of lines, we return the height of the multi-line text.
		//----------------------------------------------------------------------------------
		return numlines * (Font->GetSurface()->h + sepy);
	}
}
//******************************************************************************************
// ITextControl.cpp
//******************************************************************************************