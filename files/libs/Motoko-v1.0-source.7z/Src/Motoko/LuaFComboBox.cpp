//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// ComboBox functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ComboBox::CopyFrom.
		//----------------------------------------------------------------------------------
		static int ComboBox_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				ComboBox * src = (ComboBox *) ControlToCopy;

				if(Controls.size() > 0)
				{
					ComboBox * dst = (ComboBox *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::UpdateRects.
		//----------------------------------------------------------------------------------
		static int ComboBox_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::UpdateRects.
		//----------------------------------------------------------------------------------
		static int ComboBox_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::AddListItem.
		//----------------------------------------------------------------------------------
		static int ComboBox_AddListItem (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					lua_pushboolean(L, aux->AddListItem(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_AddListItem'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isnumber(L, 2))
				{
					GetControlsTop(ComboBox, aux);
					lua_pushboolean(L, aux->AddListItem(lua_tostring(L, 1), lua_tointeger(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_AddListItem'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_AddListItem'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::DelListItem.
		//----------------------------------------------------------------------------------
		static int ComboBox_DelListItem (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->DelListItem(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_DelListItem'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_DelListItem'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::ClearListItems.
		//----------------------------------------------------------------------------------
		static int ComboBox_ClearListItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->ClearListItems();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_DelListItem'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetListItem->Text.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetListItemText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					lua_pushstring(L, aux->GetListItem(lua_tointeger(L, 1))->Text.c_str());
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_GetListItemText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetListItemText'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetListItem->BackColor.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetListItemBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					lua_pushnumber(L, aux->GetListItem(lua_tointeger(L, 1))->BackColor);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_GetListItemBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetListItemBackColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetSelectedItems.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetSelectedItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					list<int>::iterator it = aux->GetSelectedItems()->begin();

					int index = lua_tointeger(L, 1);

					for(int i = 0; (i < index) && (it != aux->GetSelectedItems()->end()); ++i) ++it;

					if(it != aux->GetSelectedItems()->end())
						lua_pushnumber(L, *it);
					else
						lua_pushnumber(L, -1);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_GetListItemBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetListItemBackColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetSelectedItems->size().
		//----------------------------------------------------------------------------------
		static int ComboBox_GetSelectedItemsSize (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetSelectedItems()->size());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetSelectedItemsSize'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetSelColor.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetSelColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetSelColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetSelColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetListHeight.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetListHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetListHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetListHeight'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetSelBackColor.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetSelBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetSelBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetSelBackColor'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetList.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetList (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				Controls.push(aux->GetList());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetList'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetOpenList.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetOpenList (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				Controls.push(aux->GetOpenList());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetOpenList'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetListItem.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetListItem (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isnumber(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetListItem(lua_tointeger(L, 1), lua_tostring(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetListItem'.");
					lua_error(L);
				}
			}
			else if(numargs == 3)
			{
				if(lua_isnumber(L, 1) && lua_isstring(L, 2) && lua_isnumber(L, 3))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetListItem(lua_tointeger(L, 1), lua_tostring(L, 2), lua_tointeger(L, 3));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetListItem'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetListItem'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetNoSelectedItems.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetNoSelectedItems (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->SetNoSelectedItems();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetNoSelectedItems'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetSelColor.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetSelColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetSelColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetSelColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetSelColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetListHeight.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetListHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetListHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetListHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetListHeight'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetSelBackColor.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetSelBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetSelBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetSelBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetSelBackColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetFont.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetFont(appLuaRef->Resources.GetFont(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetFont'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetFont'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetName.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetName'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetBackColor.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1), lua_tointeger(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetAppearance.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 6)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) &&
				   lua_isstring(L, 4) && lua_isstring(L, 5) && lua_isstring(L, 6))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 3), lua_tostring(L, 4)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 5), lua_tostring(L, 6)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 4)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) && lua_isstring(L, 4))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 3)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 4)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// ITextControl functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ComboBox::UpdateWidth.
		//----------------------------------------------------------------------------------
		static int ComboBox_UpdateWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->UpdateWidth();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_UpdateWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetAlignment.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);

				switch(aux->GetAlignment())
				{
				case Left:
					lua_pushstring(L, "Left");
					break;
					
				case Center:
					lua_pushstring(L, "Center");
					break;
					
				case Right:
					lua_pushstring(L, "Right");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetAlignment'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetText.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushstring(L, aux->GetText());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetText'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetFont.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushlightuserdata(L, aux->GetFont());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetFont'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetFontHeight.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetFontHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetFontHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetFontHeight'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetMaxWidth.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetMaxWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetMaxWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetMaxWidth'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetWidthLastLine.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetWidthLastLine (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetWidthLastLine());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetWidthLastLine'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetMinNumLines.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetMinNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetMinNumLines());
			}
			else if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					lua_pushnumber(L, aux->GetMinNumLines(lua_tointeger(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_GetMinNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetMinNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::GetMaxNumLines.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetMaxNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(ComboBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else if(numargs == 5)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) && lua_isnumber(L, 5))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(ComboBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux, lua_tointeger(L, 5)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetMaxNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetAlignment.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);

					if(strcmp(lua_tostring(L, 1), "Left") == STR_EQU)
						aux->SetAlignment(Left);
					else if(strcmp(lua_tostring(L, 1), "Center") == STR_EQU)
						aux->SetAlignment(Center);
					else if(strcmp(lua_tostring(L, 1), "Right") == STR_EQU)
						aux->SetAlignment(Right);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetAlignment(Left);
						break;
						
					case 1:
						aux->SetAlignment(Center);
						break;
						
					case 2:
						aux->SetAlignment(Right);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetAlignment'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetAlignment'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::SetText.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetText'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// ComboBox::AddText.
		//----------------------------------------------------------------------------------
		static int ComboBox_AddText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->AddText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_AddText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_AddText'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Box functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ComboBox::SetX.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetX'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetY.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetY'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetWidth.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetHeight.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetRect.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(ComboBox, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ComboBox::GetFocus.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetName.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetX.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetY.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetWidth.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetHeight.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetAppearance.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetBackColor.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetPicture.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetEnable.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetVisible.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetTransparency.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::GetType.
		//----------------------------------------------------------------------------------
		static int ComboBox_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetPicture.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(ComboBox, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetEnable.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetVisible.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// ComboBox::SetTransparency.
		//----------------------------------------------------------------------------------
		static int ComboBox_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(ComboBox, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'ComboBox_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// ComboBox::CreateNew.
		//----------------------------------------------------------------------------------
		static int ComboBox_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				ComboBox * aux = new ComboBox();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'ComboBox_CreateNew'.");
				lua_error(L);
			}

			return 1;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFComboBox (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// ComboBox functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ComboBox_CopyFrom",             ComboBox_CopyFrom);
			lua_register(L, "ComboBox_IsCursorOver",         ComboBox_IsCursorOver);
			lua_register(L, "ComboBox_UpdateRects",          ComboBox_UpdateRects);
			lua_register(L, "ComboBox_AddListItem",          ComboBox_AddListItem);
			lua_register(L, "ComboBox_DelListItem",          ComboBox_DelListItem);
			lua_register(L, "ComboBox_ClearListItems",       ComboBox_ClearListItems);
			lua_register(L, "ComboBox_GetListItemText",      ComboBox_GetListItemText);
			lua_register(L, "ComboBox_GetListItemBackColor", ComboBox_GetListItemBackColor);
			lua_register(L, "ComboBox_GetSelectedItems",     ComboBox_GetSelectedItems);
			lua_register(L, "ComboBox_GetSelectedItemsSize", ComboBox_GetSelectedItemsSize);
			lua_register(L, "ComboBox_GetSelColor",          ComboBox_GetSelColor);
			lua_register(L, "ComboBox_GetListHeight",        ComboBox_GetListHeight);
			lua_register(L, "ComboBox_GetSelBackColor",      ComboBox_GetSelBackColor);
			lua_register(L, "ComboBox_GetList",              ComboBox_GetList);
			lua_register(L, "ComboBox_GetOpenList",          ComboBox_GetOpenList);
			lua_register(L, "ComboBox_SetListItem",          ComboBox_SetListItem);
			lua_register(L, "ComboBox_SetNoSelectedItems",   ComboBox_SetNoSelectedItems);
			lua_register(L, "ComboBox_SetSelColor",          ComboBox_SetSelColor);
			lua_register(L, "ComboBox_SetListHeight",        ComboBox_SetListHeight);
			lua_register(L, "ComboBox_SetSelBackColor",      ComboBox_SetSelBackColor);
			lua_register(L, "ComboBox_SetFont",              ComboBox_SetFont);
			lua_register(L, "ComboBox_SetName",              ComboBox_SetName);
			lua_register(L, "ComboBox_SetBackStyle",         ComboBox_SetBackStyle);
			lua_register(L, "ComboBox_SetBackColor",         ComboBox_SetBackColor);
			lua_register(L, "ComboBox_SetAppearance",        ComboBox_SetAppearance);

			//------------------------------------------------------------------------------
			// ITextControl functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ComboBox_UpdateWidth",      ComboBox_UpdateWidth);
			lua_register(L, "ComboBox_GetAlignment",     ComboBox_GetAlignment);
			lua_register(L, "ComboBox_GetText",          ComboBox_GetText);
			lua_register(L, "ComboBox_GetFont",          ComboBox_GetFont);
			lua_register(L, "ComboBox_GetFontHeight",    ComboBox_GetFontHeight);
			lua_register(L, "ComboBox_GetMaxWidth",      ComboBox_GetMaxWidth);
			lua_register(L, "ComboBox_GetWidthLastLine", ComboBox_GetWidthLastLine);
			lua_register(L, "ComboBox_GetMinNumLines",   ComboBox_GetMinNumLines);
			lua_register(L, "ComboBox_GetMaxNumLines",   ComboBox_GetMaxNumLines);
			lua_register(L, "ComboBox_SetAlignment",     ComboBox_SetAlignment);
			lua_register(L, "ComboBox_SetText",          ComboBox_SetText);
			lua_register(L, "ComboBox_AddText",          ComboBox_AddText);

			//------------------------------------------------------------------------------
			// Box functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ComboBox_SetX",      ComboBox_SetX);
			lua_register(L, "ComboBox_SetY",      ComboBox_SetY);
			lua_register(L, "ComboBox_SetWidth",  ComboBox_SetWidth);
			lua_register(L, "ComboBox_SetHeight", ComboBox_SetHeight);
			lua_register(L, "ComboBox_SetRect",   ComboBox_SetRect);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ComboBox_GetFocus",           ComboBox_GetFocus);
			lua_register(L, "ComboBox_SetKeyDown",         ComboBox_SetKeyDown);
			lua_register(L, "ComboBox_SetKeyUp",           ComboBox_SetKeyUp);
			lua_register(L, "ComboBox_SetMouseMotion",     ComboBox_SetMouseMotion);
			lua_register(L, "ComboBox_SetMouseButtonDown", ComboBox_SetMouseButtonDown);
			lua_register(L, "ComboBox_SetMouseButtonUp",   ComboBox_SetMouseButtonUp);
			lua_register(L, "ComboBox_GetName",            ComboBox_GetName);
			lua_register(L, "ComboBox_GetX",               ComboBox_GetX);
			lua_register(L, "ComboBox_GetY",               ComboBox_GetY);
			lua_register(L, "ComboBox_GetWidth",           ComboBox_GetWidth);
			lua_register(L, "ComboBox_GetHeight",          ComboBox_GetHeight);
			lua_register(L, "ComboBox_GetBackStyle",       ComboBox_GetBackStyle);
			lua_register(L, "ComboBox_GetAppearance",      ComboBox_GetAppearance);
			lua_register(L, "ComboBox_GetBackColor",       ComboBox_GetBackColor);
			lua_register(L, "ComboBox_GetPicture",         ComboBox_GetPicture);
			lua_register(L, "ComboBox_GetMousePointer",    ComboBox_GetMousePointer);
			lua_register(L, "ComboBox_GetEnable",          ComboBox_GetEnable);
			lua_register(L, "ComboBox_GetVisible",         ComboBox_GetVisible);
			lua_register(L, "ComboBox_GetTransparency",    ComboBox_GetTransparency);
			lua_register(L, "ComboBox_GetType",            ComboBox_GetType);
			lua_register(L, "ComboBox_SetPicture",         ComboBox_SetPicture);
			lua_register(L, "ComboBox_SetMousePointer",    ComboBox_SetMousePointer);
			lua_register(L, "ComboBox_SetEnable",          ComboBox_SetEnable);
			lua_register(L, "ComboBox_SetVisible",         ComboBox_SetVisible);
			lua_register(L, "ComboBox_SetTransparency",    ComboBox_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "ComboBox_CreateNew", ComboBox_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFComboBox.cpp
//******************************************************************************************