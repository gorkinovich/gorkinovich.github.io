//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "LuaFHeader.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	namespace Lua
	{
	//**************************************************************************************
	// TextBox functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// TextBox::CopyFrom.
		//----------------------------------------------------------------------------------
		static int TextBox_CopyFrom (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				TextBox * src = (TextBox *) ControlToCopy;

				if(Controls.size() > 0)
				{
					TextBox * dst = (TextBox *) Controls.top();
					dst->CopyFrom(*src);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_CopyFrom'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::UpdateRects.
		//----------------------------------------------------------------------------------
		static int TextBox_UpdateRects (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->UpdateRects();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_UpdateRects'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetLocked.
		//----------------------------------------------------------------------------------
		static int TextBox_GetLocked (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushboolean(L, aux->GetLocked());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetLocked'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetMultiLine.
		//----------------------------------------------------------------------------------
		static int TextBox_GetMultiLine (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushboolean(L, aux->GetMultiLine());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetMultiLine'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetMaxLength.
		//----------------------------------------------------------------------------------
		static int TextBox_GetMaxLength (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetMaxLength());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetMaxLength'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetScrollBars.
		//----------------------------------------------------------------------------------
		static int TextBox_GetScrollBars (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				switch(aux->GetScrollBars())
				{
				case NoneScrollBars:
					lua_pushstring(L, "NoneScrollBars");
					break;

				case BothScrollBars:
					lua_pushstring(L, "BothScrollBars");
					break;

				case OnlyHScrollBars:
					lua_pushstring(L, "OnlyHScrollBars");
					break;

				case OnlyVScrollBars:
					lua_pushstring(L, "OnlyVScrollBars");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetScrollBars'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetLanguage.
		//----------------------------------------------------------------------------------
		static int TextBox_GetLanguage (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				switch(aux->GetLanguage())
				{
				case SpanishLanguage:
					lua_pushstring(L, "Spanish");
					break;

				case EnglishLanguage:
					lua_pushstring(L, "English");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetLanguage'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetHBar.
		//----------------------------------------------------------------------------------
		static int TextBox_GetHBar (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				Controls.push(aux->GetHBar());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetHBar'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetVBar.
		//----------------------------------------------------------------------------------
		static int TextBox_GetVBar (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				Controls.push(aux->GetVBar());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetVBar'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetLocked.
		//----------------------------------------------------------------------------------
		static int TextBox_SetLocked (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
				GetControlsTop(TextBox, aux);
					aux->SetLocked(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetLocked'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetLocked'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetMultiLine.
		//----------------------------------------------------------------------------------
		static int TextBox_SetMultiLine (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetMultiLine(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetMultiLine'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetMultiLine'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetMaxLength.
		//----------------------------------------------------------------------------------
		static int TextBox_SetMaxLength (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetMaxLength(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetMaxLength'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetMaxLength'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetScrollBars.
		//----------------------------------------------------------------------------------
		static int TextBox_SetScrollBars (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);

					if(strcmp(lua_tostring(L, 1), "NoneScrollBars") == STR_EQU)
						aux->SetScrollBars(NoneScrollBars);
					else if(strcmp(lua_tostring(L, 1), "BothScrollBars") == STR_EQU)
						aux->SetScrollBars(BothScrollBars);
					else if(strcmp(lua_tostring(L, 1), "OnlyHScrollBars") == STR_EQU)
						aux->SetScrollBars(OnlyHScrollBars);
					else if(strcmp(lua_tostring(L, 1), "OnlyVScrollBars") == STR_EQU)
						aux->SetScrollBars(OnlyVScrollBars);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetScrollBars(NoneScrollBars);
						break;
						
					case 1:
						aux->SetScrollBars(BothScrollBars);
						break;
						
					case 2:
						aux->SetScrollBars(OnlyHScrollBars);
						break;
						
					case 4:
						aux->SetScrollBars(OnlyVScrollBars);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetScrollBars'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetScrollBars'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetLanguage.
		//----------------------------------------------------------------------------------
		static int TextBox_SetLanguage (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);

					if(strcmp(lua_tostring(L, 1), "Spanish") == STR_EQU)
						aux->SetLanguage(SpanishLanguage);
					else if(strcmp(lua_tostring(L, 1), "English") == STR_EQU)
						aux->SetLanguage(EnglishLanguage);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetLanguage(SpanishLanguage);
						break;
						
					case 1:
						aux->SetLanguage(EnglishLanguage);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetLanguage'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetLanguage'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetText.
		//----------------------------------------------------------------------------------
		static int TextBox_SetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetText'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::AddText.
		//----------------------------------------------------------------------------------
		static int TextBox_AddText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->AddText(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_AddText'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_AddText'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetName.
		//----------------------------------------------------------------------------------
		static int TextBox_SetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetName(lua_tostring(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetName'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetName'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetBackStyle.
		//----------------------------------------------------------------------------------
		static int TextBox_SetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);

					if(strcmp(lua_tostring(L, 1), "UseAppearance") == STR_EQU)
						aux->SetBackStyle(UseAppearance);
					else if(strcmp(lua_tostring(L, 1), "UseBackColor") == STR_EQU)
						aux->SetBackStyle(UseBackColor);
					else if(strcmp(lua_tostring(L, 1), "UsePicture") == STR_EQU)
						aux->SetBackStyle(UsePicture);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetBackStyle(UseAppearance);
						break;
						
					case 1:
						aux->SetBackStyle(UseBackColor);
						break;
						
					case 2:
						aux->SetBackStyle(UsePicture);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetBackStyle'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetBackStyle'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetBackColor.
		//----------------------------------------------------------------------------------
		static int TextBox_SetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else if(numargs == 2)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2))
				{
					GetControlsTop(TextBox, aux);
					aux->SetBackColor(lua_tointeger(L, 1), lua_tointeger(L, 2));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetBackColor'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetBackColor'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetAppearance.
		//----------------------------------------------------------------------------------
		static int TextBox_SetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 2)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2))
				{
					GetControlsTop(TextBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 8)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) && lua_isstring(L, 4) &&
				   lua_isstring(L, 5) && lua_isstring(L, 6) && lua_isstring(L, 7) && lua_isstring(L, 8))
				{
					GetControlsTop(TextBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 3), lua_tostring(L, 4)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 5), lua_tostring(L, 6)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 7), lua_tostring(L, 8)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else if(numargs == 5)
			{
				if(lua_isstring(L, 1) && lua_isstring(L, 2) && lua_isstring(L, 3) &&
				   lua_isstring(L, 4) && lua_isstring(L, 5))
				{
					GetControlsTop(TextBox, aux);
					aux->SetAppearance(appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 2)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 3)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 4)),
									   appLuaRef->Skins.GetSkin(lua_tostring(L, 1), lua_tostring(L, 5)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetAppearance'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetAppearance'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// ITextControl functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// TextBox::UpdateWidth.
		//----------------------------------------------------------------------------------
		static int TextBox_UpdateWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->UpdateWidth();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_UpdateWidth'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetAlignment.
		//----------------------------------------------------------------------------------
		static int TextBox_GetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);

				switch(aux->GetAlignment())
				{
				case Left:
					lua_pushstring(L, "Left");
					break;
					
				case Center:
					lua_pushstring(L, "Center");
					break;
					
				case Right:
					lua_pushstring(L, "Right");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetAlignment'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetText.
		//----------------------------------------------------------------------------------
		static int TextBox_GetText (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushstring(L, aux->GetText());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetText'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetFont.
		//----------------------------------------------------------------------------------
		static int TextBox_GetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushlightuserdata(L, aux->GetFont());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetFont'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetFontHeight.
		//----------------------------------------------------------------------------------
		static int TextBox_GetFontHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetFontHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetFontHeight'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetMaxWidth.
		//----------------------------------------------------------------------------------
		static int TextBox_GetMaxWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetMaxWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetMaxWidth'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetWidthLastLine.
		//----------------------------------------------------------------------------------
		static int TextBox_GetWidthLastLine (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetWidthLastLine());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetWidthLastLine'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetMinNumLines.
		//----------------------------------------------------------------------------------
		static int TextBox_GetMinNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetMinNumLines());
			}
			else if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);
					lua_pushnumber(L, aux->GetMinNumLines(lua_tointeger(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_GetMinNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetMinNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::GetMaxNumLines.
		//----------------------------------------------------------------------------------
		static int TextBox_GetMaxNumLines (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(TextBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else if(numargs == 5)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4) && lua_isnumber(L, 5))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(TextBox, aux);
					lua_pushnumber(L, aux->GetMaxNumLines(&raux, lua_tointeger(L, 5)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_GetMaxNumLines'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetMaxNumLines'.");
				lua_error(L);
			}

			return 1;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetAlignment.
		//----------------------------------------------------------------------------------
		static int TextBox_SetAlignment (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);

					if(strcmp(lua_tostring(L, 1), "Left") == STR_EQU)
						aux->SetAlignment(Left);
					else if(strcmp(lua_tostring(L, 1), "Center") == STR_EQU)
						aux->SetAlignment(Center);
					else if(strcmp(lua_tostring(L, 1), "Right") == STR_EQU)
						aux->SetAlignment(Right);
				}
				else if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);

					switch((int) lua_tointeger(L, 1))
					{
					case 0:
						aux->SetAlignment(Left);
						break;
						
					case 1:
						aux->SetAlignment(Center);
						break;
						
					case 2:
						aux->SetAlignment(Right);
						break;
					}
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetAlignment'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetAlignment'.");
				lua_error(L);
			}

			return 0;
		}
		
		//----------------------------------------------------------------------------------
		// TextBox::SetFont.
		//----------------------------------------------------------------------------------
		static int TextBox_SetFont (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetFont(appLuaRef->Resources.GetFont(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetFont'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetFont'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Box functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// TextBox::SetX.
		//----------------------------------------------------------------------------------
		static int TextBox_SetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetX(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetX'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetX'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetY.
		//----------------------------------------------------------------------------------
		static int TextBox_SetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetY(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetY'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetY'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetWidth.
		//----------------------------------------------------------------------------------
		static int TextBox_SetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetWidth(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetWidth'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetWidth'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetHeight.
		//----------------------------------------------------------------------------------
		static int TextBox_SetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isnumber(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetHeight(lua_tointeger(L, 1));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetHeight'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetHeight'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetRect.
		//----------------------------------------------------------------------------------
		static int TextBox_SetRect (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 4)
			{
				if(lua_isnumber(L, 1) && lua_isnumber(L, 2) && lua_isnumber(L, 3) && lua_isnumber(L, 4))
				{
					SDL_Rect raux;

					raux.x = lua_tointeger(L, 1);
					raux.y = lua_tointeger(L, 2);
					raux.w = lua_tointeger(L, 3);
					raux.h = lua_tointeger(L, 4);

					GetControlsTop(TextBox, aux);
					aux->SetRect(raux);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetRect'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetRect'.");
				lua_error(L);
			}

			return 0;
		}
		
	//**************************************************************************************
	// Control functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// TextBox::IsCursorOver.
		//----------------------------------------------------------------------------------
		static int TextBox_IsCursorOver (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushboolean(L, aux->IsCursorOver());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_IsCursorOver'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetFocus.
		//----------------------------------------------------------------------------------
		static int TextBox_GetFocus (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->GetFocus();
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetFocus'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetKeyDown.
		//----------------------------------------------------------------------------------
		static int TextBox_SetKeyDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->SetKeyDown(SDLKeyDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetKeyDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetKeyUp.
		//----------------------------------------------------------------------------------
		static int TextBox_SetKeyUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->SetKeyUp(SDLKeyUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetKeyUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetMouseMotion.
		//----------------------------------------------------------------------------------
		static int TextBox_SetMouseMotion (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->SetMouseMotion(SDLMouseMotionEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetMouseMotion'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetMouseButtonDown.
		//----------------------------------------------------------------------------------
		static int TextBox_SetMouseButtonDown (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->SetMouseButtonDown(SDLMouseButtonDownEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetMouseButtonDown'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetMouseButtonUp.
		//----------------------------------------------------------------------------------
		static int TextBox_SetMouseButtonUp (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->SetMouseButtonUp(SDLMouseButtonUpEvent);
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetMouseButtonUp'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetName.
		//----------------------------------------------------------------------------------
		static int TextBox_GetName (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushstring(L, aux->GetName());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetName'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetX.
		//----------------------------------------------------------------------------------
		static int TextBox_GetX (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetX());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetX'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetY.
		//----------------------------------------------------------------------------------
		static int TextBox_GetY (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetY());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetY'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetWidth.
		//----------------------------------------------------------------------------------
		static int TextBox_GetWidth (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetWidth());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetWidth'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetHeight.
		//----------------------------------------------------------------------------------
		static int TextBox_GetHeight (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetHeight());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetHeight'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetBackStyle.
		//----------------------------------------------------------------------------------
		static int TextBox_GetBackStyle (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				switch(aux->GetBackStyle())
				{
				case UseAppearance:
					lua_pushstring(L, "UseAppearance");
					break;

				case UseBackColor:
					lua_pushstring(L, "UseBackColor");
					break;

				case UsePicture:
					lua_pushstring(L, "UsePicture");
					break;
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetBackStyle'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetAppearance.
		//----------------------------------------------------------------------------------
		static int TextBox_GetAppearance (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushstring(L, aux->GetAppearance()->Name.c_str());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetAppearance'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetBackColor.
		//----------------------------------------------------------------------------------
		static int TextBox_GetBackColor (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushnumber(L, aux->GetBackColor());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetBackColor'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetPicture.
		//----------------------------------------------------------------------------------
		static int TextBox_GetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushlightuserdata(L, aux->GetPicture());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetPicture'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetMousePointer.
		//----------------------------------------------------------------------------------
		static int TextBox_GetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushlightuserdata(L, aux->GetMousePointer());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetMousePointer'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetEnable.
		//----------------------------------------------------------------------------------
		static int TextBox_GetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushboolean(L, aux->GetEnable());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetEnable'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetVisible.
		//----------------------------------------------------------------------------------
		static int TextBox_GetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushboolean(L, aux->GetVisible());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetVisible'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetTransparency.
		//----------------------------------------------------------------------------------
		static int TextBox_GetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushboolean(L, aux->GetTransparency());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetTransparency'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::GetType.
		//----------------------------------------------------------------------------------
		static int TextBox_GetType (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				lua_pushstring(L, aux->GetType());
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_GetType'.");
				lua_error(L);
			}

			return 1;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetPicture.
		//----------------------------------------------------------------------------------
		static int TextBox_SetPicture (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetPicture(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetPicture'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetPicture'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetMousePointer.
		//----------------------------------------------------------------------------------
		static int TextBox_SetMousePointer (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				GetControlsTop(TextBox, aux);
				aux->SetMousePointer(NULL);
			}
			else if(numargs == 1)
			{
				if(lua_isstring(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetMousePointer(appLuaRef->Resources.GetTexture(lua_tostring(L, 1)));
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetMousePointer'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetMousePointer'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetEnable.
		//----------------------------------------------------------------------------------
		static int TextBox_SetEnable (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetEnable(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetEnable'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetEnable'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetVisible.
		//----------------------------------------------------------------------------------
		static int TextBox_SetVisible (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetVisible(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetVisible'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetVisible'.");
				lua_error(L);
			}

			return 0;
		}

		//----------------------------------------------------------------------------------
		// TextBox::SetTransparency.
		//----------------------------------------------------------------------------------
		static int TextBox_SetTransparency (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 1)
			{
				if(lua_isboolean(L, 1))
				{
					GetControlsTop(TextBox, aux);
					aux->SetTransparency(lua_toboolean(L, 1) ? true : false);
				}
				else
				{
					lua_pushstring(L, "Incorrect type of argument in the function 'TextBox_SetTransparency'.");
					lua_error(L);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_SetTransparency'.");
				lua_error(L);
			}

			return 0;
		}

	//**************************************************************************************
	// Util functions.
	//**************************************************************************************

		//----------------------------------------------------------------------------------
		// TextBox::CreateNew.
		//----------------------------------------------------------------------------------
		static int TextBox_CreateNew (lua_State * L)
		{
			int numargs = lua_gettop(L);

			if(numargs == 0)
			{
				TextBox * aux = new TextBox();
				if(aux != NULL)
				{
					Controls.push(aux);
					lua_pushboolean(L, true);
				}
				else
				{
					lua_pushboolean(L, false);
				}
			}
			else
			{
				lua_pushstring(L, "Incorrect number of arguments in the function 'TextBox_CreateNew'.");
				lua_error(L);
			}

			return 1;
		}

	
	//**************************************************************************************
	// Lua functions.
	//**************************************************************************************
	
		//----------------------------------------------------------------------------------
		// This function register in LUA some functions of Motoko.
		//----------------------------------------------------------------------------------
		DLLAPI void RegisterLuaFTextBox (lua_State * L)
		{
			//------------------------------------------------------------------------------
			// TextBox functions.
			//------------------------------------------------------------------------------
			lua_register(L, "TextBox_CopyFrom",      TextBox_CopyFrom);
			lua_register(L, "TextBox_UpdateRects",   TextBox_UpdateRects);
			lua_register(L, "TextBox_GetLocked",     TextBox_GetLocked);
			lua_register(L, "TextBox_GetMultiLine",  TextBox_GetMultiLine);
			lua_register(L, "TextBox_GetMaxLength",  TextBox_GetMaxLength);
			lua_register(L, "TextBox_GetScrollBars", TextBox_GetScrollBars);
			lua_register(L, "TextBox_GetLanguage",   TextBox_GetLanguage);
			lua_register(L, "TextBox_GetHBar",       TextBox_GetHBar);
			lua_register(L, "TextBox_GetVBar",       TextBox_GetVBar);
			lua_register(L, "TextBox_SetLocked",     TextBox_SetLocked);
			lua_register(L, "TextBox_SetMultiLine",  TextBox_SetMultiLine);
			lua_register(L, "TextBox_SetMaxLength",  TextBox_SetMaxLength);
			lua_register(L, "TextBox_SetScrollBars", TextBox_SetScrollBars);
			lua_register(L, "TextBox_SetLanguage",   TextBox_SetLanguage);
			lua_register(L, "TextBox_SetText",       TextBox_SetText);
			lua_register(L, "TextBox_AddText",       TextBox_AddText);
			lua_register(L, "TextBox_SetName",       TextBox_SetName);
			lua_register(L, "TextBox_SetBackStyle",  TextBox_SetBackStyle);
			lua_register(L, "TextBox_SetBackColor",  TextBox_SetBackColor);
			lua_register(L, "TextBox_SetAppearance", TextBox_SetAppearance);

			//------------------------------------------------------------------------------
			// ITextControl functions.
			//------------------------------------------------------------------------------
			lua_register(L, "TextBox_UpdateWidth",      TextBox_UpdateWidth);
			lua_register(L, "TextBox_GetAlignment",     TextBox_GetAlignment);
			lua_register(L, "TextBox_GetText",          TextBox_GetText);
			lua_register(L, "TextBox_GetFont",          TextBox_GetFont);
			lua_register(L, "TextBox_GetFontHeight",    TextBox_GetFontHeight);
			lua_register(L, "TextBox_GetMaxWidth",      TextBox_GetMaxWidth);
			lua_register(L, "TextBox_GetWidthLastLine", TextBox_GetWidthLastLine);
			lua_register(L, "TextBox_GetMinNumLines",   TextBox_GetMinNumLines);
			lua_register(L, "TextBox_GetMaxNumLines",   TextBox_GetMaxNumLines);
			lua_register(L, "TextBox_SetAlignment",     TextBox_SetAlignment);
			lua_register(L, "TextBox_SetFont",          TextBox_SetFont);

			//------------------------------------------------------------------------------
			// Box functions.
			//------------------------------------------------------------------------------
			lua_register(L, "TextBox_SetX",      TextBox_SetX);
			lua_register(L, "TextBox_SetY",      TextBox_SetY);
			lua_register(L, "TextBox_SetWidth",  TextBox_SetWidth);
			lua_register(L, "TextBox_SetHeight", TextBox_SetHeight);
			lua_register(L, "TextBox_SetRect",   TextBox_SetRect);

			//------------------------------------------------------------------------------
			// Control functions.
			//------------------------------------------------------------------------------
			lua_register(L, "TextBox_IsCursorOver",       TextBox_IsCursorOver);
			lua_register(L, "TextBox_GetFocus",           TextBox_GetFocus);
			lua_register(L, "TextBox_SetKeyDown",         TextBox_SetKeyDown);
			lua_register(L, "TextBox_SetKeyUp",           TextBox_SetKeyUp);
			lua_register(L, "TextBox_SetMouseMotion",     TextBox_SetMouseMotion);
			lua_register(L, "TextBox_SetMouseButtonDown", TextBox_SetMouseButtonDown);
			lua_register(L, "TextBox_SetMouseButtonUp",   TextBox_SetMouseButtonUp);
			lua_register(L, "TextBox_GetName",            TextBox_GetName);
			lua_register(L, "TextBox_GetX",               TextBox_GetX);
			lua_register(L, "TextBox_GetY",               TextBox_GetY);
			lua_register(L, "TextBox_GetWidth",           TextBox_GetWidth);
			lua_register(L, "TextBox_GetHeight",          TextBox_GetHeight);
			lua_register(L, "TextBox_GetBackStyle",       TextBox_GetBackStyle);
			lua_register(L, "TextBox_GetAppearance",      TextBox_GetAppearance);
			lua_register(L, "TextBox_GetBackColor",       TextBox_GetBackColor);
			lua_register(L, "TextBox_GetPicture",         TextBox_GetPicture);
			lua_register(L, "TextBox_GetMousePointer",    TextBox_GetMousePointer);
			lua_register(L, "TextBox_GetEnable",          TextBox_GetEnable);
			lua_register(L, "TextBox_GetVisible",         TextBox_GetVisible);
			lua_register(L, "TextBox_GetTransparency",    TextBox_GetTransparency);
			lua_register(L, "TextBox_GetType",            TextBox_GetType);
			lua_register(L, "TextBox_SetPicture",         TextBox_SetPicture);
			lua_register(L, "TextBox_SetMousePointer",    TextBox_SetMousePointer);
			lua_register(L, "TextBox_SetEnable",          TextBox_SetEnable);
			lua_register(L, "TextBox_SetVisible",         TextBox_SetVisible);
			lua_register(L, "TextBox_SetTransparency",    TextBox_SetTransparency);

			//------------------------------------------------------------------------------
			// Util functions.
			//------------------------------------------------------------------------------
			lua_register(L, "TextBox_CreateNew", TextBox_CreateNew);
		}
	}
}
//******************************************************************************************
// LuaFTextBox.cpp
//******************************************************************************************