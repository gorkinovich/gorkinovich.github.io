//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_COMBOBOX_H_
#define _MOTOKO_COMBOBOX_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "Box.h"
#include "ITextControl.h"
#include "Button.h"
#include "ListBox.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic combo box.
	//--------------------------------------------------------------------------------------
	class DLLAPI ComboBox : public Box, public ITextControl
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			Uint32 SelBackColor;
			
			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			Button * OpenList;
			ListBox * List;

			SDL_Rect TextRect;
			SDL_Rect ColorRect;


		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ComboBox ();
			ComboBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					  Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
					  ControlSkin * appearance = NULL, SDL_Surface * picture = NULL,
					  SDL_Surface * mousepointer = NULL, AlignmentStyle alignment = Left, 
					  bool transparency = false, bool enable = true, bool visible = true);
			ComboBox (const ComboBox & obj);
			virtual ComboBox & operator = (const ComboBox & obj);
			~ComboBox ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual ComboBox & CopyFrom (const ComboBox & obj);
			
			virtual bool IsCursorOver (void);

			virtual void UpdateRects (void);


			/// Add an item in the list.
			bool AddListItem (string text) { return List->AddListItem(text); }

			/// Add an item in the list.
			bool AddListItem (string text, Uint32 color) { return List->AddListItem(text, color); }

			/// Erase an item in the list.
			void DelListItem (int i) { List->DelListItem(i); }
			
			/// Erase all the items in the list.
			inline void ClearListItems (void) { List->ClearListItems(); }


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get an item of the list.
			inline ListBoxItem * GetListItem (int i) { return List->GetListItem(i); }

			/// Get the selected items of the list.
			inline list<int> * GetSelectedItems (void) { return List->GetSelectedItems(); }

			/// Get the color of selection of the list.
			inline Uint32 GetSelColor (void) { return List->GetSelColor(); }

			/// Get the height of the list.
			inline Uint16 GetListHeight (void) { return List->GetHeight(); }

			/// Get the selected color of the combo.
			inline Uint32 GetSelBackColor (void) { return SelBackColor; }

			/// Get the List of the control.
			inline ListBox * GetList (void) { return List; }

			/// Get the OpenList of the control.
			inline Button * GetOpenList (void) { return OpenList; }
			

			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set an item of the list.
			virtual inline void SetListItem (int i, ListBoxItem * val) { List->SetListItem(i, val); }

			/// Set an item of the list.
			virtual inline void SetListItem (int i, string text, Uint32 color) { List->SetListItem(i, text, color); }

			/// Set an item of the list.
			virtual inline void SetListItem (int i, string text) { List->SetListItem(i, text); }

			/// Set no selected items of the list.
			virtual inline void SetNoSelectedItems (void) { List->SetNoSelectedItems(); }

			/// Set the color of selection of the list.
			virtual inline void SetSelColor (Uint32 val) { List->SetSelColor(val); }

			/// Set the height of the list.
			virtual inline void SetListHeight (Uint16 val) { List->SetHeight(val); }

			/// Set the selected color of the combo.
			virtual inline void SetSelBackColor (Uint32 val) { SelBackColor = val; }
			
			/// Set the font of the control.
			virtual inline void SetFont (CRM32Pro_CFont * val)
			{
				ITextControl::SetFont(val);
				List->SetFont(val);
			}

			/// Set the name of the control.
			virtual inline void SetName (const char * val)
			{
				Name = val;

				string aux;

				aux = Name + "_List";     List->SetName(aux.c_str());
				aux = Name + "_OpenList"; OpenList->SetName(aux.c_str());
			}
			
			/// Set the back style of the control.
			virtual inline void SetBackStyle (ControlBackStyle val)
			{
				BackStyle = val;
				List->SetBackStyle(val);
				OpenList->SetBackStyle(val);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 box, Uint32 scrolls)
			{
				BackColor = box;
				List->SetBackColor(box, scrolls);
				OpenList->SetBackColor(scrolls);
			}

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * box, ControlSkin * vscroll, ControlSkin * button)
			{
				Appearance = box;
				List->SetAppearance(box, vscroll, button);
				OpenList->SetAppearance(button);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 val) { BackColor = val; }

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * val) { Appearance = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// ComboBox.h
//******************************************************************************************