//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_PICTUREBOX_H_
#define _MOTOKO_PICTUREBOX_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "Box.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic picture box.
	//--------------------------------------------------------------------------------------
	class DLLAPI PictureBox : public Box
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			
			SDL_DOUBLECLICK_EVENT DoubleClick;

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			PictureBox ();
			PictureBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
						Uint32 backcolor, ControlSkin * appearance = NULL,
						SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
						bool transparency = false, bool enable = true, bool visible = true);
			PictureBox (const PictureBox & obj);
			virtual PictureBox & operator = (const PictureBox & obj);
			~PictureBox ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual PictureBox & CopyFrom (const PictureBox & obj);
			

			//------------------------------------------------------------------------------
			// Events
			//------------------------------------------------------------------------------
			
			/// Get the double click function of the control.
			inline SDL_DOUBLECLICK_EVENT GetDoubleClick (void) { return DoubleClick; }
			
			/// Set the double click function of the control.
			inline void SetDoubleClick (SDL_DOUBLECLICK_EVENT val) { DoubleClick = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// PictureBox.h
//******************************************************************************************