//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_RESOURCES_H_
#define _MOTOKO_RESOURCES_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//------------------------------------------------------------------------------------------
#include "TextBox.h"
#include "LabelBox.h"
#include "PictureBox.h"
#include "ComboBox.h"
#include "ListBox.h"
//------------------------------------------------------------------------------------------
#include "Button.h"
#include "CheckButton.h"
//------------------------------------------------------------------------------------------
#include "VScrollBar.h"
#include "HScrollBar.h"
//------------------------------------------------------------------------------------------
#include "Panel.h"
#include "Dialog.h"
#include "ControlListBox.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Struct with information of a loaded texture.
	//--------------------------------------------------------------------------------------
	struct TextureResource
	{
		string        Name; //!< Name of the texture.
		SDL_Surface * Data; //!< Data of the texture.
	};

	//--------------------------------------------------------------------------------------
	/// Struct with information of a loaded font.
	//--------------------------------------------------------------------------------------
	struct FontResource
	{
		string           Name; //!< Name of the font.
		CRM32Pro_CFont * Data; //!< Data of the font.
	};

	//--------------------------------------------------------------------------------------
	/// Class to handle the library resources.
	//--------------------------------------------------------------------------------------
	class DLLAPI ResourcesManager
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			template class DLLAPI std::allocator<TextureResource *>;
			template class DLLAPI std::vector<TextureResource *, std::allocator<TextureResource *> >;
			
			template class DLLAPI std::allocator<FontResource *>;
			template class DLLAPI std::vector<FontResource *, std::allocator<FontResource *> >;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			vector<TextureResource *> Textures;
			vector<FontResource *>    Fonts;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ResourcesManager ();
			ResourcesManager (const ResourcesManager & obj);
			virtual ResourcesManager & operator = (const ResourcesManager & obj);
			~ResourcesManager ();

			
			//------------------------------------------------------------------------------
			// Textures
			//------------------------------------------------------------------------------
			SDL_Surface * LoadTexture   (const char * file, const char * fileDPF = NULL);
			void          RemoveTexture (const char * name);
			void          FreeTextures  (void);
			
			SDL_Surface * GetTexture (const char * name);
			SDL_Surface * GetTexture (int i);

			inline int GetNumTextures (void) { return Textures.size(); }

			
			//------------------------------------------------------------------------------
			// Fonts
			//------------------------------------------------------------------------------
			CRM32Pro_CFont * LoadFont   (const char * file, const char * fileDPF);
			void             RemoveFont (const char * name);
			void             FreeFonts  (void);
			
			CRM32Pro_CFont * GetFont (const char * name);
			CRM32Pro_CFont * GetFont (int i);

			inline int GetNumFonts (void) { return Fonts.size(); }
			
			
			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			void Free (void);
	};
	

	//--------------------------------------------------------------------------------------
	// Functions
	//--------------------------------------------------------------------------------------

	/// This function create a new TextBox.
	DLLAPI TextBox * GetNewTextBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									ControlBackStyle backstyle, ControlSkin * boxskin, ControlSkin * vscrollskin,
									ControlSkin * hscrollskin, ControlSkin * buttonskin, Uint32 backcolor,
									Uint32 scrollcolor, CRM32Pro_CFont * font, bool multiline, bool locked,
									ControlScrollBars scrollbars);

	/// This function create a new LabelBox.
	DLLAPI LabelBox * GetNewLabelBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									  ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
									  CRM32Pro_CFont * font);

	/// This function create a new PictureBox.
	DLLAPI PictureBox * GetNewPictureBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										  ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
										  SDL_Surface * picture);

	/// This function create a new ComboBox.
	DLLAPI ComboBox * GetNewComboBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									  Uint16 listheight, ControlBackStyle backstyle, ControlSkin * boxskin,
									  ControlSkin * vscrollskin, ControlSkin * buttonskin, Uint32 backcolor,
									  Uint32 scrollcolor, Uint32 selbackcolor, CRM32Pro_CFont * font);

	/// This function create a new ListBox.
	DLLAPI ListBox * GetNewListBox (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
									ControlBackStyle backstyle, ControlSkin * boxskin, ControlSkin * vscrollskin,
									ControlSkin * buttonskin, Uint32 backcolor, Uint32 scrollcolor,
									Uint32 selcolor, CRM32Pro_CFont * font, bool multiselect);

	/// This function create a new Button.
	DLLAPI Button * GetNewButton (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
								  ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
								  CRM32Pro_CFont * font, const char * text);
	
	/// This function create a new Button.
	DLLAPI Button * GetNewGraphicalButton (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										   SDL_Surface * picture, SDL_Surface * over, SDL_Surface * down,
										   Uint32 backcolor, CRM32Pro_CFont * font, const char * text);

	/// This function create a new CheckButton.
	DLLAPI CheckButton * GetNewCheckButton (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
											ControlBackStyle backstyle, ControlSkin * skin, Uint32 backcolor,
											CRM32Pro_CFont * font, const char * text);

	/// This function create a new VScrollBar.
	DLLAPI VScrollBar * GetNewVScrollBar (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										  ControlBackStyle backstyle, ControlSkin * scrollskinscroll,
										  ControlSkin * buttonskin, Uint32 backcolor, int min, int max,
										  int value, int smallchange, int largechange);

	/// This function create a new HScrollBar.
	DLLAPI HScrollBar * GetNewHScrollBar (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
										  ControlBackStyle backstyle, ControlSkin * scrollskin,
										  ControlSkin * buttonskin, Uint32 backcolor, int min, int max,
										  int value, int smallchange, int largechange);

	/// This function create a new Panel.
	DLLAPI Panel * GetNewPanel (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
								SDL_Surface * picture, Uint32 backcolor, bool transparency);

	/// This function create a new Dialog.
	DLLAPI Dialog * GetNewDialog (const char * name, Sint16 x, Sint16 y, Uint16 width, Uint16 height,
								  ControlBackStyle backstyle, ControlSkin * winskin, ControlSkin * buttonskin, 
								  Uint32 titlecolor, Uint32 backcolor, CRM32Pro_CFont * font, const char * text);

	/// This function create a new ControlListBox.
	DLLAPI ControlListBox * GetNewControlListBox (const char * name, Sint16 x, Sint16 y, Uint16 width,
												  Uint16 height, ControlBackStyle backstyle,
												  ControlSkin * boxskin, ControlSkin * vscrollskin,
												  ControlSkin * buttonskin, Uint32 backcolor,
												  Uint32 scrollcolor, Uint32 selcolor, bool multiselect);
	

	//--------------------------------------------------------------------------------------
	/// Lua functions.
	//--------------------------------------------------------------------------------------
	namespace Lua
	{
		/// This function register in LUA some functions of Motoko.
		DLLAPI void RegisterMotoko (void);

		/// This function register a C function.
		DLLAPI void Register (const char * name, lua_CFunction func);

		/// This function execute a lua script stored in a string.
		DLLAPI void ExecString (const char * str);

		/// This function execute a lua script stored in a file.
		DLLAPI void ExecFile (const char * file);

		/// This function execute a lua script stored in a file.
		DLLAPI void ExecFile (const char * file, const char * fileDPF);
	}
}
//******************************************************************************************
#endif
//******************************************************************************************
// Resources.h
//******************************************************************************************