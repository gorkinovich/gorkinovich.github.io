//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_BOX_H_
#define _MOTOKO_BOX_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define MAX_BOX_RECTS   9
#define CENTER_BOX_RECT 4
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic box.
	//--------------------------------------------------------------------------------------
	class DLLAPI Box : public Control
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			SDL_Rect Rects[MAX_BOX_RECTS];

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			Box ();
			Box (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
				 Uint32 backcolor, ControlSkin * appearance = NULL,
				 SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
				 bool transparency = false, bool enable = true, bool visible = true);
			Box (const Box & obj);
			virtual Box & operator = (const Box & obj);
			~Box ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void) = 0;
			virtual bool Update (SDL_Event & event) = 0;

			virtual Box & CopyFrom (const Box & obj);

			virtual void UpdateRects (void);


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the coordinate X of the control.
			virtual inline void SetX (Sint16 val) { Rect.x = val; UpdateRects(); }

			/// Set the coordinate Y of the control.
			virtual inline void SetY (Sint16 val) { Rect.y = val; UpdateRects(); }

			/// Set the width of the control.
			virtual inline void SetWidth (Uint16 val) { Rect.w = val; UpdateRects(); }

			/// Set the height of the control.
			virtual inline void SetHeight (Uint16 val) { Rect.h = val; UpdateRects(); }

			/// Set the rect of the control.
			virtual inline void SetRect (SDL_Rect & val) { Rect = val; UpdateRects(); }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Box.h
//******************************************************************************************