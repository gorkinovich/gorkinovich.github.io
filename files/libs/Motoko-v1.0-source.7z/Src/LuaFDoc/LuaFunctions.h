//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFunctiones Lua functions
 */
//******************************************************************************************
/*@{*/

//------------------------------------------------------------------------------------------
// Application functions.
//------------------------------------------------------------------------------------------
bool Application_AddControl (); //!< Add a control to the application.
bool Application_AddDialog (); //!< Add a control to the application.
void Application_Config (string property, string val); //!< Set the CRM32Pro configuration.
void Application_Config (string property, int val); //!< Set the CRM32Pro configuration.
int Application_Init (string title); //!< Initialize the Motoko library.
int Application_Init (string title, int w, int h, int bpp = 32,
					  bool window = true, int frequency = DEFAULT_FREQUENCY,
					  int format = DEFAULT_FORMAT, int nchannels = DEFAULT_NCHANNELS,
					  int chunksize = DEFAULT_CHUNKSIZE); //!< Initialize the Motoko library.
void Application_Release (); //!< Release the library.
void Application_PushUpDialog (string name); //!< Push to the top a dialog.
void Application_Exit (); //!< Exit the application.
int Application_GetTime (); //!< Get the actual time.
void Application_Delay (int ms); //!< Delay the application.
void Application_SetKeyDown (); //!< Set the event key down.
void Application_SetKeyUp (); //!< Set the event key up.
void Application_SetMouseMotion (); //!< Set the event mouse motion.
void Application_SetMouseButtonDown (); //!< Set the event mouse button down.
void Application_SetMouseButtonUp (); //!< Set the event mouse button up.
ludata Application_GetMousePointer (); //!< Get the mouse pointer (ludata == lightuserdata).
string Application_GetTitle (); //!< Get the title.
string Application_GetIcon (); //!< Get the name of the icon.
bool Application_GetRenderBack (); //!< Get the render back mode.
ludata Application_GetPicture (); //!< Get the picture.
SDL_Rect Application_GetActRect (); //!< Get the actual rect.
int Application_GetBackColor (); //!< Get the back color.
bool Application_GetQuit (); //!< Get the quit state.
bool Application_GetActiveControl (); //!< Get the active control.
int Application_GetInterval (); //!< Get the maximum interval for double-click.
int Application_GetWidth (); //!< Get the width of the application.
int Application_GetHeight (); //!< Get the height of the application.
void Application_SetMousePointer (string val); //!< Set the mouse pointer.
void Application_SetTitle (string val); //!< Set the title.
void Application_SetIcon (string val); //!< Set the icon.
void Application_SetRenderBack (bool val); //!< Set the render back mode.
void Application_SetPicture (string val); //!< Set the picture.
void Application_SetActRect (int x, int y, int w, int h); //!< Set the actual rect.
void Application_SetBackColor (int val); //!< Set the back color.
void Application_SetInterval (int val); //!< Set the maximum interval for double-click.
void Application_NoActiveControl (); //!< Set no active control.

/*@}*/
//******************************************************************************************
// LuaFunctions.h
//******************************************************************************************