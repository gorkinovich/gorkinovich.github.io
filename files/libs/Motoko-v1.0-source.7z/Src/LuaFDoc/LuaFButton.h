//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFButton Lua Button functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFButton01 Button functions.
 *  \ingroup LuaFButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Button_CopyFrom (); //!< Copy the actual selected control to be copied.
void Button_UpdateRects (); //!< Update the internal state of the control.
string Button_GetArrow (); //!< Get the type of arrow.
ludata Button_GetPictureOver (); //!< Get the picture when the mouse is over.
ludata Button_GetPictureDown (); //!< Get the picture when the mouse is down.
void Button_SetX (int val); //!< Set the X coordinate.
void Button_SetY (int val); //!< Set the Y coordinate.
void Button_SetWidth (int val); //!< Set the width.
void Button_SetHeight (int val); //!< Set the height.
void Button_SetRect (int x, int y, int w, int h); //!< Set the rect.
void Button_SetArrow (string val); //!< Set the type of arrow.
void Button_SetArrow (int val); //!< Set the type of arrow.
void Button_SetPictureOver (string val); //!< Set the picture when the mouse is over.
void Button_SetPictureDown (string val); //!< Set the picture when the mouse is down.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFButton02 ITextControl functions.
 *  \ingroup LuaFButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
void Button_UpdateWidth (); //!< Update the internal state of the text control.
string Button_GetAlignment (); //!< Get the alignment.
string Button_GetText (); //!< Get the text.
ludata Button_GetFont (); //!< Get the font.
int Button_GetFontHeight (); //!< Get the font height.
int Button_GetMaxWidth (); //!< Get the maximum width.
int Button_GetWidthLastLine (); //!< Get the width of the last line.
int Button_GetMinNumLines (); //!< Get minimum number of lines.
int Button_GetMinNumLines (int sepy); //!< Get minimum number of lines.
int Button_GetMaxNumLines (int x, int y, int w, int h); //!< Get the maximum number of lines.
int Button_GetMaxNumLines (int x, int y, int w, int h, int sepy); //!< Get the maximum number of lines.
void Button_SetAlignment (string val); //!< Set the alignment.
void Button_SetAlignment (int val); //!< Set the alignment.
void Button_SetFont (string val); //!< Set the font.
void Button_SetText (string val); //!< Set the text.
void Button_AddText (string val); //!< Add text.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFButton03 Control functions.
 *  \ingroup LuaFButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Button_IsCursorOver (); //!< Is the mouse cursor over the control.
void Button_GetFocus (); //!< Get the focus.
void Button_SetKeyDown (); //!< Set the event key down.
void Button_SetKeyUp (); //!< Set the event key up.
void Button_SetMouseMotion (); //!< Set the event mouse motion.
void Button_SetMouseButtonDown (); //!< Set the event mouse button down.
void Button_SetMouseButtonUp (); //!< Set the event mouse button up.
string Button_GetName (); //!< Get the name.
int Button_GetX (); //!< Get the X coordinate.
int Button_GetY (); //!< Get the Y coordinate.
int Button_GetWidth (); //!< Get the width.
int Button_GetHeight (); //!< Get the height.
string Button_GetBackStyle (); //!< Get the back style.
string Button_GetAppearance (); //!< Get the appearance.
int Button_GetBackColor (); //!< Get the back color.
ludata Button_GetPicture (); //!< Get the picture.
ludata Button_GetMousePointer (); //!< Get the mouse pointer.
bool Button_GetEnable (); //!< Get the enable.
bool Button_GetVisible (); //!< Get the visible.
void Button_GetTransparency (); //!< Get the transparency.
string Button_GetType (); //!< Get the type.
void Button_SetName (string val); //!< Set the name.
void Button_SetBackStyle (string val); //!< Set the back style.
void Button_SetBackStyle (int val); //!< Set the back style.
void Button_SetAppearance (string theme, string skin); //!< Set the appearance.
void Button_SetBackColor (int val); //!< Set the back color.
void Button_SetPicture (string val); //!< Set the picture.
void Button_SetMousePointer (string val); //!< Set the mouse pointer.
void Button_SetMousePointer (); //!< Set the mouse pointer.
void Button_SetEnable (bool val); //!< Set the enable.
void Button_SetVisible (bool val); //!< Set the visible.
void Button_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFButton04 Util functions.
 *  \ingroup LuaFButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Button_CreateNew (); //!< Create new Button.
/*@}*/

//******************************************************************************************
// LuaFButton.h
//******************************************************************************************