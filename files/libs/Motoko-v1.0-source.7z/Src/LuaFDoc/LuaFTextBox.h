//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFTextBox Lua TextBox functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFTextBox01 TextBox functions.
 *  \ingroup LuaFTextBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool TextBox_CopyFrom (); //!< Copy the actual selected control to be copied.
void TextBox_UpdateRects (); //!< Update the internal state of the control.
bool TextBox_GetLocked (); //!< Get the locked status.
bool TextBox_GetMultiLine (); //!< Get the multiline status.
int TextBox_GetMaxLength (); //!< Get the maximum length.
string TextBox_GetScrollBars (); //!< Get the scrollbars.
string TextBox_GetLanguage (); //!< Get the language.
void TextBox_GetHBar (); //!< Push into the stack of controls the horizontal scrollbar.
void TextBox_GetVBar (); //!< Push into the stack of controls the vertical scrollbar.
void TextBox_SetLocked (bool val); //!< Set the locked status.
void TextBox_SetMultiLine (bool val); //!< Set the multiline status.
void TextBox_SetMaxLength (int val); //!< Set the maximum length.
void TextBox_SetScrollBars (string val); //!< Set the scrollbars.
void TextBox_SetScrollBars (int val); //!< Set the scrollbars.
void TextBox_SetLanguage (string val); //!< Set the language.
void TextBox_SetLanguage (int val); //!< Set the language.
void TextBox_SetText (string val); //!< Set the text.
void TextBox_AddText (string val); //!< Add text.
void TextBox_SetName (string val); //!< Set the name.
void TextBox_SetBackStyle (string val); //!< Set the back style.
void TextBox_SetBackStyle (int val); //!< Set the back style.
void TextBox_SetBackColor (int val); //!< Set the back color.
void TextBox_SetBackColor (int backcolor, int bcvsb); //!< Set the back color.
void TextBox_SetAppearance (string themebox, string skinbox); //!< Set the appearance.
void TextBox_SetAppearance (string themebox, string skinbox, string themevsb, string skinvsb, string themehsb,
							 string skinhsb, string themebut, string skinbut); //!< Set the appearance.
void TextBox_SetAppearance (string theme, string skinbox, string skinvsb, string skinhsb, string skinbut); //!< Set the appearance.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFTextBox02 ITextControl functions.
 *  \ingroup LuaFTextBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void TextBox_UpdateWidth (); //!< Update the internal state of the text control.
string TextBox_GetAlignment (); //!< GetAlignment.
string TextBox_GetText (); //!< Get the text.
ludata TextBox_GetFont (); //!< Get the font.
int TextBox_GetFontHeight (); //!< Get the font height.
int TextBox_GetMaxWidth (); //!< Get the maximum width.
int TextBox_GetWidthLastLine (); //!< Get the width of the last line.
int TextBox_GetMinNumLines (); //!< Get minimum number of lines.
int TextBox_GetMinNumLines (int sepy); //!< Get minimum number of lines.
int TextBox_GetMaxNumLines (int x, int y, int w, int h); //!< Get the maximum number of lines.
int TextBox_GetMaxNumLines (int x, int y, int w, int h, int sepy); //!< Get the maximum number of lines.
void TextBox_SetAlignment (string val); //!< Set the alignment.
void TextBox_SetAlignment (int val); //!< Set the alignment.
void TextBox_SetFont (string val); //!< Set the font.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFTextBox03 Box functions.
 *  \ingroup LuaFTextBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void TextBox_SetX (int val); //!< Set the X coordinate.
void TextBox_SetY (int val); //!< Set the Y coordinate.
void TextBox_SetWidth (int val); //!< Set the width.
void TextBox_SetHeight (int val); //!< Set the height.
void TextBox_SetRect (int x, int y, int w, int h); //!< Set the rect.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFTextBox04 Control functions.
 *  \ingroup LuaFTextBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool TextBox_IsCursorOver (); //!< Is the mouse cursor over the control.
void TextBox_GetFocus (); //!< Get the focus.
void TextBox_SetKeyDown (); //!< Set the event key down.
void TextBox_SetKeyUp (); //!< Set the event key up.
void TextBox_SetMouseMotion (); //!< Set the event mouse motion.
void TextBox_SetMouseButtonDown (); //!< Set the event mouse button down.
void TextBox_SetMouseButtonUp (); //!< Set the event mouse button up.
string TextBox_GetName (); //!< Get the name.
int TextBox_GetX (); //!< Get the X coordinate.
int TextBox_GetY (); //!< Get the Y coordinate.
int TextBox_GetWidth (); //!< Get the width.
int TextBox_GetHeight (); //!< Get the height.
string TextBox_GetBackStyle (); //!< Get the back style.
string TextBox_GetAppearance (); //!< Get the appearance.
int TextBox_GetBackColor (); //!< Get the back color.
ludata TextBox_GetPicture (); //!< Get the picture.
ludata TextBox_GetMousePointer (); //!< Get the mouse pointer.
bool TextBox_GetEnable (); //!< Get the enable.
bool TextBox_GetVisible (); //!< Get the visible.
void TextBox_GetTransparency (); //!< Get the transparency.
string TextBox_GetType (); //!< Get the type.
void TextBox_SetPicture (string val); //!< Set the picture.
void TextBox_SetMousePointer (string val); //!< Set the mouse pointer.
void TextBox_SetMousePointer (); //!< Set the mouse pointer.
void TextBox_SetEnable (bool val); //!< Set the enable.
void TextBox_SetVisible (bool val); //!< Set the visible.
void TextBox_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFTextBox05 Util functions.
 *  \ingroup LuaFTextBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool TextBox_CreateNew (); //!< Create new TextBox.
/*@}*/

//******************************************************************************************
// LuaFTextBox.h
//******************************************************************************************