//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFUtil Lua util functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFUtil01 ResourcesManager functions.
 *  \ingroup LuaFUtil
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ResourcesLoadTexture (string file); //!< Load a texture from a file.
bool ResourcesLoadTexture (string file, string filedpf); //!< Load a texture from a file.
void ResourcesRemoveTexture (string name); //!< Remove a texture from memory.
void ResourcesFreeTextures (); //!< Remove all the textures from memory.
bool ResourcesLoadFont (string name, string filedpf); //!< Load a font from a dpf file.
void ResourcesRemoveFont (string name); //!< Remove a font from memory.
void ResourcesFreeFonts (); //!< Remove all the fonts from memory.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFUtil02 SkinsManager functions.
 *  \ingroup LuaFUtil
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool SkinsAddTheme (string filedpf); //!< Load a theme from a dpf file.
bool SkinsAddTheme (string filedpf, string filexml); //!< Load a theme from a dpf file.
void SkinsRemoveTheme (string name); //!< Remove a theme from memory.
void SkinsSetThemeName (string oldname, string newname); //!< Change the name of a theme.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFUtil03 ListControls functions.
 *  \ingroup LuaFUtil
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool SelectControl (string name, ...); //!< Select a control from Application::List.
bool SelectControlFromDialog (string name, ...); //!< Select a control from Application::DialogList.
void UnselectControl (); //!< Pop a control from the stack of controls.
bool AddControlToContainer (); //!< Add a control from the stack to a container.
bool AddControlRelToContainer (); //!< Add a control from the stack to a container, with relative coordinates.
void RecoverLostControl (); //!< Recover a control from the stack of lost controls.
void SetControlToCopy (); //!< Take a control from the stack of controls to make it the main control to copy.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFUtil04 Auxiliar functions.
 *  \ingroup LuaFUtil
 */
//------------------------------------------------------------------------------------------
/*@{*/
void CheckAndGetFocus (); //!< Check and get the focus for a control.
void ExecFileInLua (string file); //!< Execute a lua file.
void ExecFileInLua (string file, string filedpf); //!< Execute a lua file in a dpf file.
/*@}*/
//******************************************************************************************
// LuaFUtil.h
//******************************************************************************************