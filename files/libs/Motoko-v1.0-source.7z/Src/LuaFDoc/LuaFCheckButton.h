//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFCheckButton Lua CheckButton functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFCheckButton01 CheckButton functions.
 *  \ingroup LuaFCheckButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool CheckButton_CopyFrom (); //!< Copy the actual selected control to be copied.
void CheckButton_UpdateRects (); //!< Update the internal state of the control.
bool CheckButton_GetValue (); //!< Get the value.
ludata CheckButton_GetPictureChecked (); //!< Get the picture when the control is checked.
void CheckButton_SetX (int val); //!< Set the X coordinate.
void CheckButton_SetY (int val); //!< Set the Y coordinate.
void CheckButton_SetWidth (int val); //!< Set the width.
void CheckButton_SetHeight (int val); //!< Set the height.
void CheckButton_SetRect (int x, int y, int w, int h); //!< Set the rect.
void CheckButton_SetValue (bool val); //!< Set the value.
void CheckButton_SetPictureChecked (string val); //!< Set the picture when the control is checked.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFCheckButton02 ITextControl functions.
 *  \ingroup LuaFCheckButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
void CheckButton_UpdateWidth (); //!< Update the internal state of the text control.
string CheckButton_GetAlignment (); //!< Get the alignment.
string CheckButton_GetText (); //!< Get the text.
ludata CheckButton_GetFont (); //!< Get the font.
int CheckButton_GetFontHeight (); //!< Get the font height.
int CheckButton_GetMaxWidth (); //!< Get the maximum width.
int CheckButton_GetWidthLastLine (); //!< Get the width of the last line.
int CheckButton_GetMinNumLines (); //!< Get minimum number of lines.
int CheckButton_GetMinNumLines (int sepy); //!< Get minimum number of lines.
int CheckButton_GetMaxNumLines (int x, int y, int w, int h); //!< Get the maximum number of lines.
int CheckButton_GetMaxNumLines (int x, int y, int w, int h, int sepy); //!< Get the maximum number of lines.
void CheckButton_SetAlignment (string val); //!< Set the alignment.
void CheckButton_SetAlignment (int val); //!< Set the alignment.
void CheckButton_SetFont (string val); //!< Set the font.
void CheckButton_SetText (string val); //!< Set the text.
void CheckButton_AddText (string val); //!< Add text.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFCheckButton03 Control functions.
 *  \ingroup LuaFCheckButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool CheckButton_IsCursorOver (); //!< Is the mouse cursor over the control.
void CheckButton_GetFocus (); //!< Get the focus.
void CheckButton_SetKeyDown (); //!< Set the event key down.
void CheckButton_SetKeyUp (); //!< Set the event key up.
void CheckButton_SetMouseMotion (); //!< Set the event mouse motion.
void CheckButton_SetMouseButtonDown (); //!< Set the event mouse button down.
void CheckButton_SetMouseButtonUp (); //!< Set the event mouse button up.
string CheckButton_GetName (); //!< Get the name.
int CheckButton_GetX (); //!< Get the X coordinate.
int CheckButton_GetY (); //!< Get the Y coordinate.
int CheckButton_GetWidth (); //!< Get the width.
int CheckButton_GetHeight (); //!< Get the height.
string CheckButton_GetBackStyle (); //!< Get the back style.
string CheckButton_GetAppearance (); //!< Get the appearance.
int CheckButton_GetBackColor (); //!< Get the back color.
ludata CheckButton_GetPicture (); //!< Get the picture.
ludata CheckButton_GetMousePointer (); //!< Get the mouse pointer.
bool CheckButton_GetEnable (); //!< Get the enable.
bool CheckButton_GetVisible (); //!< Get the visible.
void CheckButton_GetTransparency (); //!< Get the transparency.
string CheckButton_GetType (); //!< Get the type.
void CheckButton_SetName (string val); //!< Set the name.
void CheckButton_SetBackStyle (string val); //!< Set the back the style.
void CheckButton_SetBackStyle (int val); //!< Set the back the style.
void CheckButton_SetAppearance (string theme, string skin); //!< Set the appearance.
void CheckButton_SetBackColor (int val); //!< Set the back color.
void CheckButton_SetPicture (string val); //!< Set the picture.
void CheckButton_SetMousePointer (string val); //!< Set the mouse pointer.
void CheckButton_SetMousePointer (); //!< Set the mouse pointer.
void CheckButton_SetEnable (bool val); //!< Set the enable.
void CheckButton_SetVisible (bool val); //!< Set the visible.
void CheckButton_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFCheckButton04 Util functions.
 *  \ingroup LuaFCheckButton
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool CheckButton_CreateNew (); //!< Create new CheckButton.
/*@}*/

//******************************************************************************************
// LuaFCheckButton.cpp
//******************************************************************************************