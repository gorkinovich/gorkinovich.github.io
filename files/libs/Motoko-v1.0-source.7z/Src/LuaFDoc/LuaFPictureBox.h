//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFPictureBox Lua PictureBox functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPictureBox01 PictureBox functions.
 *  \ingroup LuaFPictureBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool PictureBox_CopyFrom (); //!< Copy the actual selected control to be copied.
void PictureBox_SetDoubleClick (); //!< Set the event double click.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPictureBox02 Box functions.
 *  \ingroup LuaFPictureBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void PictureBox_UpdateRects (); //!< Update the internal state of the control.
void PictureBox_SetX (int val); //!< Set the X coordinate.
void PictureBox_SetY (int val); //!< Set the Y coordinate.
void PictureBox_SetWidth (int val); //!< Set the width.
void PictureBox_SetHeight (int val); //!< Set the height.
void PictureBox_SetRect (int x, int y, int w, int h); //!< Set the rect.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPictureBox03 Control functions.
 *  \ingroup LuaFPictureBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool PictureBox_IsCursorOver (); //!< Is the mouse cursor over the control.
void PictureBox_GetFocus (); //!< Get the focus.
void PictureBox_SetKeyDown (); //!< Set the event key down.
void PictureBox_SetKeyUp (); //!< Set the event key up.
void PictureBox_SetMouseMotion (); //!< Set the event mouse motion.
void PictureBox_SetMouseButtonDown (); //!< Set the event mouse button down.
void PictureBox_SetMouseButtonUp (); //!< Set the event mouse button up.
string PictureBox_GetName (); //!< Get the name.
int PictureBox_GetX (); //!< Get the X coordinate.
int PictureBox_GetY (); //!< Get the Y coordinate.
int PictureBox_GetWidth (); //!< Get the width.
int PictureBox_GetHeight (); //!< Get the height.
string PictureBox_GetBackStyle (); //!< Get the back style.
string PictureBox_GetAppearance (); //!< Get the appearance.
int PictureBox_GetBackColor (); //!< Get the back color.
ludata PictureBox_GetPicture (); //!< Get the picture.
ludata PictureBox_GetMousePointer (); //!< Get the mouse pointer.
bool PictureBox_GetEnable (); //!< Get the enable.
bool PictureBox_GetVisible (); //!< Get the visible.
void PictureBox_GetTransparency (); //!< Get the transparency.
string PictureBox_GetType (); //!< Get the type.
void PictureBox_SetName (string val); //!< Set the name.
void PictureBox_SetBackStyle (string val); //!< Set the back style.
void PictureBox_SetBackStyle (int val); //!< Set the back style.
void PictureBox_SetAppearance (string theme, string skin); //!< Set the appearance.
void PictureBox_SetBackColor (int val); //!< Set the back color.
void PictureBox_SetPicture (string val); //!< Set the picture.
void PictureBox_SetMousePointer (string val); //!< Set the mouse pointer.
void PictureBox_SetMousePointer (); //!< Set the mouse pointer.
void PictureBox_SetEnable (bool val); //!< Set the enable.
void PictureBox_SetVisible (bool val); //!< Set the visible.
void PictureBox_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPictureBox04 Util functions.
 *  \ingroup LuaFPictureBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool PictureBox_CreateNew (); //!< Create new PictureBox.
/*@}*/

//******************************************************************************************
// LuaFPictureBox.cpp
//******************************************************************************************