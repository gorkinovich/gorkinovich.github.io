//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFHScrollBar Lua HScrollBar functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFHScrollBar01 HScrollBar functions.
 *  \ingroup LuaFHScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool HScrollBar_CopyFrom (); //!< Copy the actual selected control to be copied.
void HScrollBar_UpdateButton (); //!< Update the central button of the scrollbar.
void HScrollBar_UpdateRects (); //!< Update the internal state of the control.
void HScrollBar_GetButtonRight (); //!< Push into the stack of controls the right button.
void HScrollBar_GetButtonCenter (); //!< Push into the stack of controls the center button.
void HScrollBar_GetButtonLeft (); //!< Push into the stack of controls the left button.
void HScrollBar_SetName (string val); //!< Set the name of the control.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFHScrollBar02 ScrollBar functions.
 *  \ingroup LuaFHScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
int HScrollBar_GetLargeChange (); //!< Get the large change.
int HScrollBar_GetSmallChange (); //!< Get the small change.
int HScrollBar_GetMax (); //!< Get the maximum value.
int HScrollBar_GetMin (); //!< Get the minimum value.
int HScrollBar_GetValue (); //!< Get the alue.
void HScrollBar_SetLargeChange (int val); //!< Set the large change.
void HScrollBar_SetSmallChange (int val); //!< Set the small change.
void HScrollBar_SetMax (int val); //!< Set the maximum value.
void HScrollBar_SetMin (int val); //!< Set the minimum value.
void HScrollBar_SetValue (int val); //!< Set the value.
void HScrollBar_SetAppearance (string themescroll, string skinscroll); //!< Set the appearance.
void HScrollBar_SetAppearance (string themescroll, string skinscroll, string themebutton, string skinbutton); //!< Set the appearance.
void HScrollBar_SetAppearance (string theme, string skinbox, string skinbutton); //!< Set the appearance.
void HScrollBar_SetX (int val); //!< Set the X coordinate.
void HScrollBar_SetY (int val); //!< Set the Y coordinate.
void HScrollBar_SetWidth (int val); //!< Set the width.
void HScrollBar_SetHeight (int val); //!< Set the height.
void HScrollBar_SetRect (int x, int y, int w, int h); //!< Set the rect.
void HScrollBar_SetBackStyle (string val); //!< Set the back style.
void HScrollBar_SetBackStyle (int val); //!< Set the back style.
void HScrollBar_SetBackColor (int val); //!< Set the back color.
void HScrollBar_SetBackColor (int scroll, int button); //!< Set the back color.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFHScrollBar03 Control functions.
 *  \ingroup LuaFHScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool HScrollBar_IsCursorOver (); //!< Is the mouse cursor over the control.
void HScrollBar_GetFocus (); //!< Get the focus.
void HScrollBar_SetKeyDown (); //!< Set the event key down.
void HScrollBar_SetKeyUp (); //!< Set the event key up.
void HScrollBar_SetMouseMotion (); //!< Set the event mouse motion.
void HScrollBar_SetMouseButtonDown (); //!< Set the event mouse button down.
void HScrollBar_SetMouseButtonUp (); //!< Set the event mouse button up.
string HScrollBar_GetName (); //!< Get the name.
int HScrollBar_GetX (); //!< Get the X coordinate.
int HScrollBar_GetY (); //!< Get the Y coordinate.
int HScrollBar_GetWidth (); //!< Get the width.
int HScrollBar_GetHeight (); //!< Get the height.
string HScrollBar_GetBackStyle (); //!< Get the back style.
string HScrollBar_GetAppearance (); //!< Get the appearance.
int HScrollBar_GetBackColor (); //!< Get the back color.
ludata HScrollBar_GetPicture (); //!< Get the picture.
ludata HScrollBar_GetMousePointer (); //!< Get the mouse pointer.
bool HScrollBar_GetEnable (); //!< Get the enable.
bool HScrollBar_GetVisible (); //!< Get the visible.
bool HScrollBar_GetTransparency (); //!< Get the transparency.
string HScrollBar_GetType (); //!< Get the type.
void HScrollBar_SetPicture (string val); //!< Set the picture.
void HScrollBar_SetMousePointer (string val); //!< Set the mouse pointer.
void HScrollBar_SetMousePointer (); //!< Set the mouse pointer.
void HScrollBar_SetEnable (bool val); //!< Set the enable.
void HScrollBar_SetVisible (bool val); //!< Set the visible.
void HScrollBar_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFHScrollBar04 Util functions.
 *  \ingroup LuaFHScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool HScrollBar_CreateNew (); //!< Create new HScrollBar.
/*@}*/

//******************************************************************************************
// LuaFHScrollBar.h
//******************************************************************************************