//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFComboBox Lua ComboBox functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFComboBox01 ComboBox functions.
 *  \ingroup LuaFComboBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ComboBox_CopyFrom (); //!< Copy the actual selected control to be copied.
bool ComboBox_IsCursorOver (); //!< Is the mouse cursor over the control.
void ComboBox_UpdateRects (); //!< Update the internal state of the control.
bool ComboBox_AddListItem (string text); //!< Add a list item.
bool ComboBox_AddListItem (string text, int backcolor); //!< Add a list item.
void ComboBox_DelListItem (int i); //!< Delete a list item.
void ComboBox_ClearListItems (); //!< Clear the list items.
string ComboBox_GetListItemText (int i); //!< Get the text of a list item.
int ComboBox_GetListItemBackColor (int i); //!< Get the back color of a list item.
int ComboBox_GetSelectedItems (int i); //!< Get a selected item.
int ComboBox_GetSelectedItemsSize (); //!< Get the number of selected items.
int ComboBox_GetSelColor (); //!< Get the selection color.
int ComboBox_GetListHeight (); //!< Get the list height.
int ComboBox_GetSelBackColor (); //!< Get the selected back color.
void ComboBox_GetList (); //!< Push into the stack of controls the listbox.
void ComboBox_GetOpenList (); //!< Push into the stack of controls the open button.
void ComboBox_SetListItem (int i, string text); //!< Set a list item.
void ComboBox_SetListItem (int i, string text, int backcolor); //!< Set a list item.
void ComboBox_SetNoSelectedItems (); //!< Set no selected items.
void ComboBox_SetSelColor (int val); //!< Set the selection color.
void ComboBox_SetListHeight (int val); //!< Set the list height.
void ComboBox_SetSelBackColor (int val); //!< Set the selected back color.
void ComboBox_SetFont (string val); //!< Set the font.
void ComboBox_SetName (string val); //!< Set the name.
void ComboBox_SetBackStyle (string val); //!< Set the back style.
void ComboBox_SetBackStyle (int val); //!< Set the back style.
void ComboBox_SetBackColor (int val); //!< Set the back color.
void ComboBox_SetBackColor (int backcolor, int bcvsb); //!< Set the back color.
void ComboBox_SetAppearance (string themebox, string skinbox); //!< Set the appearance.
void ComboBox_SetAppearance (string themebox, string skinbox, string themevsb, string skinvsb, string themebut, string skinbut); //!< Set the appearance.
void ComboBox_SetAppearance (string theme, string skinbox, string skinvsb, string skinbut); //!< Set the appearance.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFComboBox02 ITextControl functions.
 *  \ingroup LuaFComboBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void ComboBox_UpdateWidth (); //!< Update the internal state of the text control.
string ComboBox_GetAlignment (); //!< Get the alignment.
string ComboBox_GetText (); //!< Get the text.
ludata ComboBox_GetFont (); //!< Get the font.
int ComboBox_GetFontHeight (); //!< Get the font height.
int ComboBox_GetMaxWidth (); //!< Get the maximum width.
int ComboBox_GetWidthLastLine (); //!< Get the width of the last line.
int ComboBox_GetMinNumLines (); //!< Get minimum number of lines.
int ComboBox_GetMinNumLines (int sepy); //!< Get minimum number of lines.
int ComboBox_GetMaxNumLines (int x, int y, int w, int h); //!< Get the maximum number of lines.
int ComboBox_GetMaxNumLines (int x, int y, int w, int h, int sepy); //!< Get the maximum number of lines.
void ComboBox_SetAlignment (string val); //!< Set the alignment.
void ComboBox_SetAlignment (int val); //!< Set the alignment.
void ComboBox_SetText (string val); //!< Set the text.
void ComboBox_AddText (string val); //!< Add text.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFComboBox03 Box functions.
 *  \ingroup LuaFComboBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void ComboBox_SetX (int val); //!< Set the X coordinate.
void ComboBox_SetY (int val); //!< Set the Y coordinate.
void ComboBox_SetWidth (int val); //!< Set the width.
void ComboBox_SetHeight (int val); //!< Set the height.
void ComboBox_SetRect (int x, int y, int w, int h); //!< Set the rect.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFComboBox04 Control functions.
 *  \ingroup LuaFComboBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void ComboBox_GetFocus (); //!< Get the focus.
void ComboBox_SetKeyDown (); //!< Set the event key down.
void ComboBox_SetKeyUp (); //!< Set the event key up.
void ComboBox_SetMouseMotion (); //!< Set the event mouse motion.
void ComboBox_SetMouseButtonDown (); //!< Set the event mouse button down.
void ComboBox_SetMouseButtonUp (); //!< Set the event mouse button up.
string ComboBox_GetName (); //!< Get the name.
int ComboBox_GetX (); //!< Get the X coordinate.
int ComboBox_GetY (); //!< Get the Y coordinate.
int ComboBox_GetWidth (); //!< Get the width.
int ComboBox_GetHeight (); //!< Get the height.
string ComboBox_GetBackStyle (); //!< Get the back style.
string ComboBox_GetAppearance (); //!< Get the appearance.
int ComboBox_GetBackColor (); //!< Get the back color.
ludata ComboBox_GetPicture (); //!< Get the picture.
ludata ComboBox_GetMousePointer (); //!< Get the mouse pointer.
bool ComboBox_GetEnable (); //!< Get the enable.
bool ComboBox_GetVisible (); //!< Get the visible.
void ComboBox_GetTransparency (); //!< Get the transparency.
string ComboBox_GetType (); //!< Get the type.
void ComboBox_SetPicture (string val); //!< Set the picture.
void ComboBox_SetMousePointer (string val); //!< Set the mouse pointer.
void ComboBox_SetMousePointer (); //!< Set the mouse pointer.
void ComboBox_SetEnable (bool val); //!< Set the enable.
void ComboBox_SetVisible (bool val); //!< Set the visible.
void ComboBox_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFComboBox05 Util functions.
 *  \ingroup LuaFComboBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ComboBox_CreateNew (); //!< Create new ComboBox.
/*@}*/

//******************************************************************************************
// LuaFComboBox.h
//******************************************************************************************