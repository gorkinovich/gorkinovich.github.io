//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFDialog Lua Dialog functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFDialog01 Dialog functions.
 *  \ingroup LuaFDialog
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Dialog_CopyFrom (); //!< Copy the actual selected control to be copied.
void Dialog_UpdateRects (); //!< Update the internal state of the control.
int Dialog_GetTitleColor (); //!< Get the title color.
void Dialog_GetClose (); //!< Push into the stack of controls the close button.
void Dialog_SetX (int val); //!< Set the X coordinate.
void Dialog_SetY (int val); //!< Set the Y coordinate.
void Dialog_SetWidth (int val); //!< Set the width.
void Dialog_SetHeight (int val); //!< Set the height.
void Dialog_SetRect (int x, int y, int w, int h); //!< Set the rect.
void Dialog_SetTitleColor (int val); //!< Set the title color.
void Dialog_SetName (string val); //!< Set the name.
void Dialog_SetBackStyle (string val); //!< Set the back style.
void Dialog_SetBackStyle (int val); //!< Set the back style.
void Dialog_SetBackColor (int val); //!< Set the back color.
void Dialog_SetBackColor (int dialog, int button); //!< Set the back color.
void Dialog_SetAppearance (string themedlg, string skindlg); //!< Set the appearance.
void Dialog_SetAppearance (string themedlg, string skindlg, string themebut, string skinbut); //!< Set the appearance.
void Dialog_SetAppearance (string theme, string skindlg, string skinbut); //!< Set the appearance.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFDialog02 ITextControl functions.
 *  \ingroup LuaFDialog
 */
//------------------------------------------------------------------------------------------
/*@{*/
void Dialog_UpdateWidth (); //!< Update the internal state of the text control.
string Dialog_GetAlignment (); //!< Get the alignment.
string Dialog_GetText (); //!< Get the text.
ludata Dialog_GetFont (); //!< Get the font.
int Dialog_GetFontHeight (); //!< Get the font height.
int Dialog_GetMaxWidth (); //!< Get the maximum width.
int Dialog_GetWidthLastLine (); //!< Get the width of the last line.
int Dialog_GetMinNumLines (); //!< Get minimum number of lines.
int Dialog_GetMinNumLines (int sepy); //!< Get minimum number of lines.
int Dialog_GetMaxNumLines (int x, int y, int w, int h); //!< Get the maximum number of lines.
int Dialog_GetMaxNumLines (int x, int y, int w, int h, int sepy); //!< Get the maximum number of lines.
void Dialog_SetAlignment (string val); //!< Set the alignment.
void Dialog_SetAlignment (int val); //!< Set the alignment.
void Dialog_SetFont (string val); //!< Set the font.
void Dialog_SetText (string val); //!< Set the text.
void Dialog_AddText (string val); //!< Add text.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFDialog03 Container functions.
 *  \ingroup LuaFDialog
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Dialog_AddControl (); //!< Add a control.
bool Dialog_AddControlRel (); //!< Add a control with relative coordinates.
void Dialog_RemoveControl (string name); //!< Remove a control from the list.
void Dialog_Free (); //!< Delete all the controls from the list and the memory.
void Dialog_GetControl (string name); //!< Get a control.
void Dialog_GetControl (int pos); //!< Get a control.
int Dialog_GetSize (); //!< Get the size of the list.
ludata Dialog_GetMousePointer (); //!< Get the mouse pointer.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFDialog04 Control functions.
 *  \ingroup LuaFDialog
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Dialog_IsCursorOver (); //!< Is the mouse cursor over the control.
void Dialog_GetFocus (); //!< Get the focus.
void Dialog_SetKeyDown (); //!< Set the event key down.
void Dialog_SetKeyUp (); //!< Set the event key up.
void Dialog_SetMouseMotion (); //!< Set the event mouse motion.
void Dialog_SetMouseButtonDown (); //!< Set the event mouse button down.
void Dialog_SetMouseButtonUp (); //!< Set the event mouse button up.
string Dialog_GetName (); //!< Get the name.
int Dialog_GetX (); //!< Get the X coordinate.
int Dialog_GetY (); //!< Get the Y coordinate.
int Dialog_GetWidth (); //!< Get the width.
int Dialog_GetHeight (); //!< Get the height.
string Dialog_GetBackStyle (); //!< Get the back style.
string Dialog_GetAppearance (); //!< Get the appearance.
int Dialog_GetBackColor (); //!< Get the back color.
ludata Dialog_GetPicture (); //!< Get the picture.
bool Dialog_GetEnable (); //!< Get the enable.
bool Dialog_GetVisible (); //!< Get the visible.
void Dialog_GetTransparency (); //!< Get the transparency.
string Dialog_GetType (); //!< Get the type.
void Dialog_SetPicture (string val); //!< Set the picture.
void Dialog_SetMousePointer (string val); //!< Set the mouse pointer.
void Dialog_SetMousePointer (); //!< Set the mouse pointer.
void Dialog_SetEnable (bool val); //!< Set the enable.
void Dialog_SetVisible (bool val); //!< Set the visible.
void Dialog_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFDialog05 Util functions.
 *  \ingroup LuaFDialog
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Dialog_CreateNew (); //!< Create new Dialog.
/*@}*/

//******************************************************************************************
// LuaFDialog.cpp
//******************************************************************************************