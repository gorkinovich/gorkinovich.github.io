//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFPanel Lua Panel functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPanel01 Panel functions.
 *  \ingroup LuaFPanel
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Panel_CopyFrom (); //!< Copy the actual selected control to be copied.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPanel02 Container functions.
 *  \ingroup LuaFPanel
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Panel_AddControl (); //!< Add a control.
bool Panel_AddControlRel (); //!< Add a control with relative coordinates.
void Panel_RemoveControl (string name); //!< Remove a control from the list.
void Panel_Free (); //!< Delete all the controls from the list and the memory.
void Panel_GetControl (string name); //!< Get a control.
void Panel_GetControl (int pos); //!< Get a control.
int Panel_GetSize (); //!< Get the size of the list.
ludata Panel_GetMousePointer (); //!< Get the mouse pointer.
void Panel_SetX (int val); //!< Set the X coordinate.
void Panel_SetY (int val); //!< Set the Y coordinate.
void Panel_SetRect (int x, int y, int w, int h); //!< Set the rect.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPanel03 Control functions.
 *  \ingroup LuaFPanel
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Panel_IsCursorOver (); //!< Is the mouse cursor over the control.
void Panel_GetFocus (); //!< Get the focus.
void Panel_SetKeyDown (); //!< Set the event key down.
void Panel_SetKeyUp (); //!< Set the event key up.
void Panel_SetMouseMotion (); //!< Set the event mouse motion.
void Panel_SetMouseButtonDown (); //!< Set the event mouse button down.
void Panel_SetMouseButtonUp (); //!< Set the event mouse button up.
string Panel_GetName (); //!< Get the name.
int Panel_GetX (); //!< Get the X coordinate.
int Panel_GetY (); //!< Get the Y coordinate.
int Panel_GetWidth (); //!< Get the width.
int Panel_GetHeight (); //!< Get the height.
string Panel_GetBackStyle (); //!< Get the back style.
string Panel_GetAppearance (); //!< Get the appearance.
int Panel_GetBackColor (); //!< Get the back color.
ludata Panel_GetPicture (); //!< Get the picture.
bool Panel_GetEnable (); //!< Get the enable.
bool Panel_GetVisible (); //!< Get the visible.
bool Panel_GetTransparency (); //!< Get the transparency.
string Panel_GetType (); //!< Get the type.
void Panel_SetName (string val); //!< Set the name.
void Panel_SetWidth (int val); //!< Set the width.
void Panel_SetHeight (int val); //!< Set the height.
void Panel_SetBackStyle (string val); //!< Set the back style.
void Panel_SetBackStyle (int val); //!< Set the back style.
void Panel_SetAppearance (string theme, string skin); //!< Set the appearance.
void Panel_SetBackColor (int val); //!< Set the back color.
void Panel_SetPicture (string val); //!< Set the picture.
void Panel_SetMousePointer (string val); //!< Set the mouse pointer.
void Panel_SetMousePointer (); //!< Set the mouse pointer.
void Panel_SetEnable (bool val); //!< Set the enable.
void Panel_SetVisible (bool val); //!< Set the visible.
void Panel_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFPanel04 Util functions.
 *  \ingroup LuaFPanel
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool Panel_CreateNew (); //!< Create new Panel.
/*@}*/

//******************************************************************************************
// LuaFPanel.h
//******************************************************************************************