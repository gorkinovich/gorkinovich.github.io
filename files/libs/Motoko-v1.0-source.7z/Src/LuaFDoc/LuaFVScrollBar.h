//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFVScrollBar Lua VScrollBar functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFVScrollBar01 VScrollBar functions.
 *  \ingroup LuaFVScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool VScrollBar_CopyFrom (); //!< Copy the actual selected control to be copied.
void VScrollBar_UpdateButton (); //!< Update the central button of the scrollbar.
void VScrollBar_UpdateRects (); //!< Update the internal state of the control.
void VScrollBar_GetButtonUp (); //!< Push into the stack of controls the up button.
void VScrollBar_GetButtonCenter (); //!< Push into the stack of controls the center button.
void VScrollBar_GetButtonDown (); //!< Push into the stack of controls the down button.
void VScrollBar_SetName (string val); //!< Set the name of the control.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFVScrollBar02 ScrollBar functions.
 *  \ingroup LuaFVScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
int VScrollBar_GetLargeChange (); //!< Get the large change.
int VScrollBar_GetSmallChange (); //!< Get the small change.
int VScrollBar_GetMax (); //!< Get the maximum value.
int VScrollBar_GetMin (); //!< Get the minimum value.
int VScrollBar_GetValue (); //!< Get the value.
void VScrollBar_SetLargeChange (int val); //!< Set the large change.
void VScrollBar_SetSmallChange (int val); //!< Set the small change.
void VScrollBar_SetMax (int val); //!< Set the maximum value.
void VScrollBar_SetMin (int val); //!< Set the minimum value.
void VScrollBar_SetValue (int val); //!< Set the value.
void VScrollBar_SetAppearance (string themescroll, string skinscroll); //!< Set the appearance.
void VScrollBar_SetAppearance (string themescroll, string skinscroll, string themebutton, string skinbutton); //!< Set the appearance.
void VScrollBar_SetAppearance (string theme, string skinbox, string skinbutton); //!< Set the appearance.
void VScrollBar_SetX (int val); //!< Set the X coordinate.
void VScrollBar_SetY (int val); //!< Set the Y coordinate.
void VScrollBar_SetWidth (int val); //!< Set the width.
void VScrollBar_SetHeight (int val); //!< Set the height.
void VScrollBar_SetRect (int x, int y, int w, int h); //!< Set the rect.
void VScrollBar_SetBackStyle (string val); //!< Set the back style.
void VScrollBar_SetBackStyle (int val); //!< Set the back style.
void VScrollBar_SetBackColor (int val); //!< Set the back color.
void VScrollBar_SetBackColor (int scroll, int button); //!< Set the back color.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFVScrollBar03 Control functions.
 *  \ingroup LuaFVScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool VScrollBar_IsCursorOver (); //!< Is the mouse cursor over the control.
void VScrollBar_GetFocus (); //!< Get the focus.
void VScrollBar_SetKeyDown (); //!< Set the event key down.
void VScrollBar_SetKeyUp (); //!< Set the event key up.
void VScrollBar_SetMouseMotion (); //!< Set the event mouse motion.
void VScrollBar_SetMouseButtonDown (); //!< Set the event mouse button down.
void VScrollBar_SetMouseButtonUp (); //!< Set the event mouse button up.
string VScrollBar_GetName (); //!< Get the name.
int VScrollBar_GetX (); //!< Get the X coordinate.
int VScrollBar_GetY (); //!< Get the Y coordinate.
int VScrollBar_GetWidth (); //!< Get the width.
int VScrollBar_GetHeight (); //!< Get the height.
string VScrollBar_GetBackStyle (); //!< Get the back style.
string VScrollBar_GetAppearance (); //!< Get the appearance.
int VScrollBar_GetBackColor (); //!< Get the back color.
ludata VScrollBar_GetPicture (); //!< Get the picture.
ludata VScrollBar_GetMousePointer (); //!< Get the mouse pointer.
bool VScrollBar_GetEnable (); //!< Get the enable.
bool VScrollBar_GetVisible (); //!< Get the visible.
bool VScrollBar_GetTransparency (); //!< Get the transparency.
string VScrollBar_GetType (); //!< Get the type.
void VScrollBar_SetPicture (string val); //!< Set the picture.
void VScrollBar_SetMousePointer (string val); //!< Set the mouse pointer.
void VScrollBar_SetMousePointer (); //!< Set the mouse pointer.
void VScrollBar_SetEnable (bool val); //!< Set the enable.
void VScrollBar_SetVisible (bool val); //!< Set the visible.
void VScrollBar_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFVScrollBar04 Util functions.
 *  \ingroup LuaFVScrollBar
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool VScrollBar_CreateNew (); //!< Create new VScrollBar.
/*@}*/

//******************************************************************************************
// LuaFVScrollBar.h
//******************************************************************************************