//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFListBox Lua ListBox functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFListBox01 ListBox functions.
 *  \ingroup LuaFListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ListBox_CopyFrom (); //!< Copy the actual selected control to be copied.
void ListBox_UpdateRects (); //!< Update the internal state of the control.
bool ListBox_AddListItem (string text); //!< Add a list item.
bool ListBox_AddListItem (string text, int backcolor); //!< Add a list item.
void ListBox_DelListItem (int i); //!< Delete a list item.
void ListBox_ClearListItems (); //!< Clear the list items.
string ListBox_GetListItemText (int i); //!< Get the text of a list item.
int ListBox_GetListItemBackColor (int i); //!< Get the back color of a list item.
bool ListBox_GetMultiSelect (); //!< Get the multiselect status.
int ListBox_GetSelectedItems (); //!< Get a selected item.
int ListBox_GetSelectedItemsSize (); //!< Get the number of selected items.
int ListBox_GetSelColor (); //!< Get the selection color.
void ListBox_GetVBar (); //!< Push into the stack of controls the vertical scrollbar.
void ListBox_SetListItem (int i, string text); //!< Set a list item.
void ListBox_SetListItem (int i, string text, int backcolor); //!< Set a list item.
void ListBox_SetMultiSelect (bool val); //!< Set the multiselect status.
void ListBox_SetNoSelectedItems (); //!< Set no selected items.
void ListBox_SetSelColor (int val); //!< Set the selection color.
void ListBox_SetText (string val); //!< Set the text.
void ListBox_AddText (string val); //!< Add text.
void ListBox_SetName (string val); //!< Set the name.
void ListBox_SetBackStyle (string val); //!< Set the back style.
void ListBox_SetBackStyle (int val); //!< Set the back style.
void ListBox_SetBackColor (int val); //!< Set the back color.
void ListBox_SetBackColor (int backcolor, int bcvsb); //!< Set the back color.
void ListBox_SetAppearance (string themebox, string skinbox); //!< Set the appearance.
void ListBox_SetAppearance (string themebox, string skinbox, string themevsb, string skinvsb, string themebut, string skinbut); //!< Set the appearance.
void ListBox_SetAppearance (string theme, string skinbox, string skinvsb, string skinbut); //!< Set the appearance.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFListBox02 ITextControl functions.
 *  \ingroup LuaFListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void ListBox_UpdateWidth (); //!< Update the internal state of the text control.
string ListBox_GetAlignment (); //!< Get the alignment.
string ListBox_GetText (); //!< Get the text.
ludata ListBox_GetFont (); //!< Get the font.
int ListBox_GetFontHeight (); //!< Get the font height.
int ListBox_GetMaxWidth (); //!< Get the maximum width.
int ListBox_GetWidthLastLine (); //!< Get the width of the last line.
int ListBox_GetMinNumLines (); //!< Get minimum number of lines.
int ListBox_GetMinNumLines (int sepy); //!< Get minimum number of lines.
int ListBox_GetMaxNumLines (int x, int y, int w, int h); //!< Get the maximum number of lines.
int ListBox_GetMaxNumLines (int x, int y, int w, int h, int sepy); //!< Get the maximum number of lines.
void ListBox_SetAlignment (string val); //!< Set the alignment.
void ListBox_SetAlignment (int val); //!< Set the alignment.
void ListBox_SetFont (string val); //!< Set the font.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFListBox03 Box functions.
 *  \ingroup LuaFListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void ListBox_SetX (int val); //!< Set the X coordinate.
void ListBox_SetY (int val); //!< Set the Y coordinate.
void ListBox_SetWidth (int val); //!< Set the width.
void ListBox_SetHeight (int val); //!< Set the height.
void ListBox_SetRect (int x, int y, int w, int h); //!< Set the rect.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFListBox04 Control functions.
 *  \ingroup LuaFListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ListBox_IsCursorOver (); //!< Is the mouse cursor over the control.
void ListBox_GetFocus (); //!< Get the ocus.
void ListBox_SetKeyDown (); //!< Set the event key down.
void ListBox_SetKeyUp (); //!< Set the event key up.
void ListBox_SetMouseMotion (); //!< Set the event mouse motion.
void ListBox_SetMouseButtonDown (); //!< Set the event mouse button down.
void ListBox_SetMouseButtonUp (); //!< Set the event mouse button up.
string ListBox_GetName (); //!< Get the name.
int ListBox_GetX (); //!< Get the X coordinate.
int ListBox_GetY (); //!< Get the Y coordinate.
int ListBox_GetWidth (); //!< Get the width.
int ListBox_GetHeight (); //!< Get the height.
string ListBox_GetBackStyle (); //!< Get the back style.
string ListBox_GetAppearance (); //!< Get the appearance.
int ListBox_GetBackColor (); //!< Get the back color.
ludata ListBox_GetPicture (); //!< Get the picture.
ludata ListBox_GetMousePointer (); //!< Get the mouse pointer.
bool ListBox_GetEnable (); //!< Get the enable.
bool ListBox_GetVisible (); //!< Get the visible.
void ListBox_GetTransparency (); //!< Get the transparency.
string ListBox_GetType (); //!< Get the type.
void ListBox_SetPicture (string val); //!< Set the picture.
void ListBox_SetMousePointer (string val); //!< Set the mouse pointer.
void ListBox_SetMousePointer (); //!< Set the mouse pointer.
void ListBox_SetEnable (bool val); //!< Set the enable.
void ListBox_SetVisible (bool val); //!< Set the visible.
void ListBox_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFListBox05 Util functions.
 *  \ingroup LuaFListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ListBox_CreateNew (); //!< Create new ListBox.
/*@}*/

//******************************************************************************************
// LuaFListBox.h
//******************************************************************************************