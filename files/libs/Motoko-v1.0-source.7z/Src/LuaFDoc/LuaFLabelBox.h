//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFLabelBox Lua LabelBox functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFLabelBox01 LabelBox functions.
 *  \ingroup LuaFLabelBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool LabelBox_CopyFrom (); //!< Copy the actual selected control to be copied.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFLabelBox02 ITextControl functions.
 *  \ingroup LuaFLabelBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void LabelBox_UpdateWidth (); //!< Update the internal state of the text control.
string LabelBox_GetAlignment (); //!< Get the alignment.
string LabelBox_GetText (); //!< Get the text.
ludata LabelBox_GetFont (); //!< Get the font.
int LabelBox_GetFontHeight (); //!< Get the font height.
int LabelBox_GetMaxWidth (); //!< Get the maximum width.
int LabelBox_GetWidthLastLine (); //!< Get the width of the last line.
int LabelBox_GetMinNumLines (); //!< Get minimum number of lines.
int LabelBox_GetMinNumLines (int sepy); //!< Get minimum number of lines.
int LabelBox_GetMaxNumLines (int x, int y, int w, int h); //!< Get the maximum number of lines.
int LabelBox_GetMaxNumLines (int x, int y, int w, int h, int sepy); //!< Get the maximum number of lines.
void LabelBox_SetAlignment (string val); //!< Set the alignment.
void LabelBox_SetAlignment (int val); //!< Set the alignment.
void LabelBox_SetFont (string val); //!< Set the font.
void LabelBox_SetText (string val); //!< Set the text.
void LabelBox_AddText (string val); //!< Add text.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFLabelBox03 Box functions.
 *  \ingroup LuaFLabelBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void LabelBox_UpdateRects (); //!< Update the internal state of the control.
void LabelBox_SetX (int val); //!< Set the X coordinate.
void LabelBox_SetY (int val); //!< Set the Y coordinate.
void LabelBox_SetWidth (int val); //!< Set the width.
void LabelBox_SetHeight (int val); //!< Set the height.
void LabelBox_SetRect (int x, int y, int w, int h); //!< Set the rect.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFLabelBox04 Control functions.
 *  \ingroup LuaFLabelBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool LabelBox_IsCursorOver (); //!< Is the mouse cursor over the control.
void LabelBox_GetFocus (); //!< Get the focus.
void LabelBox_SetKeyDown (); //!< Set the event key down.
void LabelBox_SetKeyUp (); //!< Set the event key up.
void LabelBox_SetMouseMotion (); //!< Set the event mouse motion.
void LabelBox_SetMouseButtonDown (); //!< Set the event mouse button down.
void LabelBox_SetMouseButtonUp (); //!< Set the event mouse button up.
string LabelBox_GetName (); //!< Get the name.
int LabelBox_GetX (); //!< Get the X coordinate.
int LabelBox_GetY (); //!< Get the Y coordinate.
int LabelBox_GetWidth (); //!< Get the width.
int LabelBox_GetHeight (); //!< Get the height.
string LabelBox_GetBackStyle (); //!< Get the back style.
string LabelBox_GetAppearance (); //!< Get the appearance.
int LabelBox_GetBackColor (); //!< Get the back color.
ludata LabelBox_GetPicture (); //!< Get the picture.
ludata LabelBox_GetMousePointer (); //!< Get the mouse pointer.
bool LabelBox_GetEnable (); //!< Get the enable.
bool LabelBox_GetVisible (); //!< Get the visible.
void LabelBox_GetTransparency (); //!< Get the transparency.
string LabelBox_GetType (); //!< Get the type.
void LabelBox_SetName (string val); //!< Set the name.
void LabelBox_SetBackStyle (string val); //!< Set the back style.
void LabelBox_SetBackStyle (int val); //!< Set the back style.
void LabelBox_SetAppearance (string theme, string skin); //!< Set the appearance.
void LabelBox_SetBackColor (int val); //!< Set the back color.
void LabelBox_SetPicture (string val); //!< Set the picture.
void LabelBox_SetMousePointer (string val); //!< Set the mouse pointer.
void LabelBox_SetMousePointer (); //!< Set the mouse pointer.
void LabelBox_SetEnable (bool val); //!< Set the enable.
void LabelBox_SetVisible (bool val); //!< Set the visible.
void LabelBox_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFLabelBox05 Util functions.
 *  \ingroup LuaFLabelBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool LabelBox_CreateNew (); //!< Create new LabelBox.
/*@}*/

//******************************************************************************************
// LuaFLabelBox.h
//******************************************************************************************