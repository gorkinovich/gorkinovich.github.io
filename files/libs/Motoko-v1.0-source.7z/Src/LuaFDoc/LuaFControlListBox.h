//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// This file is not a cpp file, it's a file to make the documentation in doxygen about the
// lua functions of the motoko library, so don't use this for nothing, except doxygen.
//******************************************************************************************

//******************************************************************************************
/**
 * \defgroup LuaFControlListBox Lua ControlListBox functions
 */
//******************************************************************************************

//------------------------------------------------------------------------------------------
/** \defgroup LuaFControlListBox01 ControlListBox functions.
 *  \ingroup LuaFControlListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ControlListBox_CopyFrom (); //!< Copy the actual selected control to be copied.
void ControlListBox_UpdateRects (); //!< Update the internal state of the control.
bool ControlListBox_AddControl (); //!< Add a control.
void ControlListBox_RemoveControl (string name); //!< Remove a control from the list.
void ControlListBox_Free (); //!< Delete all the controls from the list and the memory.
bool ControlListBox_GetControl (string name); //!< Get a control.
bool ControlListBox_GetControl (int pos); //!< Get a control.
int ControlListBox_GetSize (); //!< Get the size of the list.
ludata ControlListBox_GetMousePointer (); //!< Get the mouse pointer.
bool ControlListBox_GetMultiSelect (); //!< Get the multiselect status.
int ControlListBox_GetSelectedItems (); //!< Get a selected item.
int ControlListBox_GetSelectedItemsSize (); //!< Get the number of selected items.
int ControlListBox_GetSelColor (); //!< Get the selection color.
void ControlListBox_GetVBar (); //!< Push into the stack of controls the vertical scrollbar.
void ControlListBox_SetMultiSelect (bool val); //!< Set the multiselect status.
void ControlListBox_SetNoSelectedItems (); //!< Set no selected items.
void ControlListBox_SetSelColor (int val); //!< Set the selection color.
void ControlListBox_SetName (string val); //!< Set the name.
void ControlListBox_SetBackStyle (string val); //!< Set the back style.
void ControlListBox_SetBackStyle (int val); //!< Set the back style.
void ControlListBox_SetBackColor (int val); //!< Set the back color.
void ControlListBox_SetBackColor (int backcolor, int bcvsb); //!< SetBackColor.
void ControlListBox_SetAppearance (string themebox, string skinbox); //!< Set the appearance.
void ControlListBox_SetAppearance (string themebox, string skinbox, string themevsb, string skinvsb, string themebut, string skinbut); //!< Set the appearance.
void ControlListBox_SetAppearance (string theme, string skinbox, string skinvsb, string skinbut); //!< Set the appearance.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFControlListBox02 Box functions.
 *  \ingroup LuaFControlListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
void ControlListBox_SetX (int val); //!< Set the X coordinate.
void ControlListBox_SetY (int val); //!< Set the Y coordinate.
void ControlListBox_SetWidth (int val); //!< Set the width.
void ControlListBox_SetHeight (int val); //!< Set the height.
void ControlListBox_SetRect (int x, int y, int w, int h); //!< Set the rect.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFControlListBox03 Control functions.
 *  \ingroup LuaFControlListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ControlListBox_IsCursorOver (); //!< Is the mouse cursor over the control.
void ControlListBox_GetFocus (); //!< Get the focus.
void ControlListBox_SetKeyDown (); //!< Set the event key down.
void ControlListBox_SetKeyUp (); //!< Set the event key up.
void ControlListBox_SetMouseMotion (); //!< Set the event mouse motion.
void ControlListBox_SetMouseButtonDown (); //!< Set the event mouse button down.
void ControlListBox_SetMouseButtonUp (); //!< Set the event mouse button up.
string ControlListBox_GetName (); //!< Get the name.
int ControlListBox_GetX (); //!< Get the X coordinate.
int ControlListBox_GetY (); //!< Get the Y coordinate.
int ControlListBox_GetWidth (); //!< Get the width.
int ControlListBox_GetHeight (); //!< Get the height.
string ControlListBox_GetBackStyle (); //!< Get the back style.
string ControlListBox_GetAppearance (); //!< Get the appearance.
int ControlListBox_GetBackColor (); //!< Get the back color.
ludata ControlListBox_GetPicture (); //!< Get the picture.
bool ControlListBox_GetEnable (); //!< Get the enable.
bool ControlListBox_GetVisible (); //!< Get the visible.
void ControlListBox_GetTransparency (); //!< Get the transparency.
string ControlListBox_GetType (); //!< Get the type.
void ControlListBox_SetPicture (string val); //!< Set the picture.
void ControlListBox_SetMousePointer (string val); //!< Set the mouse pointer.
void ControlListBox_SetMousePointer (); //!< Set the mouse pointer.
void ControlListBox_SetEnable (bool val); //!< Set the enable.
void ControlListBox_SetVisible (bool val); //!< Set the visible.
void ControlListBox_SetTransparency (bool val); //!< Set the transparency.
/*@}*/

//------------------------------------------------------------------------------------------
/** \defgroup LuaFControlListBox04 Util functions.
 *  \ingroup LuaFControlListBox
 */
//------------------------------------------------------------------------------------------
/*@{*/
bool ControlListBox_CreateNew (); //!< Create new ControlListBox.
/*@}*/

//******************************************************************************************
// LuaFControlListBox.h
//******************************************************************************************