//******************************************************************************************
//#pragma comment(linker, "/subsystem:windows /entry:main")
//******************************************************************************************
#include "Motoko/Motoko.h"
using namespace Motoko;
//******************************************************************************************
#define APP_NAME "Cutre-Civ"
//******************************************************************************************
Application * AppCutreCiv;
//------------------------------------------------------------------------------------------
PictureBox * Caja01;
PictureBox * Caja02;
LabelBox   * Caja03;
Button     * Caja04;
//VScrollBar * VBar;
//HScrollBar * HBar;
TextBox    * Texto;
//******************************************************************************************
void Ayuda (void)
{
	cout << "//------------------------------------------------------------" << endl;
	cout << "// Ayuda rapida de los controles de la prueba." << endl;
	cout << "//------------------------------------------------------------" << endl << endl;

	cout << "Escape:        Salir." << endl;
	cout << "F1:            Esta ayuda." << endl;
	cout << "Flechas:       Mover la Caja02." << endl;
	cout << "1, 2:          Cambian el RenderBack de Application." << endl;
	cout << "3, 4:          Oculta/Muestra los controles del Panel01." << endl;
	cout << "5:             Muestra el control activo." << endl;
	cout << "6, 7, 8:       Cambia la apariencia de Caja03." << endl;
	cout << "z, x, c:       Cambia el alineamiento del texto de Caja03." << endl;
	cout << "v, b:          Cambia la transparencia de la Caja03." << endl;
	cout << "9, 0:          Cambia la apariencia de Caja04." << endl;
	cout << "q, w, a, s, d: Cambia el arrow de Caja04." << endl;
	cout << "r, t, f, g:    Cambia las scrollbars de Texto." << endl;
	cout << "Espacio:       Muestra los cuadros de dialogo." << endl << endl;

	cout << "Caja01, Caja02: PictureBox." << endl;
	cout << "Caja03:         LabelBox." << endl;
	cout << "Caja04:         Button." << endl;
	cout << "Texto:          TextBox." << endl;
}
//******************************************************************************************
bool TeclaPulsada (void * c, SDL_KeyboardEvent & event)
{
	cout << "Tecla pulsada: " << (int) event.keysym.scancode << "\t"
		<< "Modificadores: " << (int) event.keysym.mod << endl;
	
	if(event.keysym.sym == Teclas::TECLA_F1) Ayuda();

			
	if(CRM32Pro.keystate[Teclas::TECLA_6]) Caja03->SetBackStyle(UseAppearance);
	if(CRM32Pro.keystate[Teclas::TECLA_7]) Caja03->SetBackStyle(UseBackColor);
	if(CRM32Pro.keystate[Teclas::TECLA_8]) Caja03->SetBackStyle(UsePicture);
	if(CRM32Pro.keystate[Teclas::TECLA_Z]) Caja03->SetAlignment(Left);
	if(CRM32Pro.keystate[Teclas::TECLA_X]) Caja03->SetAlignment(Center);
	if(CRM32Pro.keystate[Teclas::TECLA_C]) Caja03->SetAlignment(Right);
	if(CRM32Pro.keystate[Teclas::TECLA_V]) Caja03->SetTransparency(true);
	if(CRM32Pro.keystate[Teclas::TECLA_B]) Caja03->SetTransparency(false);

	
	if(CRM32Pro.keystate[Teclas::TECLA_9]) Caja04->SetBackStyle(UseAppearance);
	if(CRM32Pro.keystate[Teclas::TECLA_0]) Caja04->SetBackStyle(UsePicture);
	if(CRM32Pro.keystate[Teclas::TECLA_Q]) Caja04->SetArrow(NoneArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_W]) Caja04->SetArrow(UpArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_S]) Caja04->SetArrow(DownArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_A]) Caja04->SetArrow(LeftArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_D]) Caja04->SetArrow(RightArrow);

	
	if(CRM32Pro.keystate[Teclas::TECLA_R]) Texto->SetScrollBars(NoneScrollBars);
	if(CRM32Pro.keystate[Teclas::TECLA_T]) Texto->SetScrollBars(BothScrollBars);
	if(CRM32Pro.keystate[Teclas::TECLA_F]) Texto->SetScrollBars(OnlyHScrollBars);
	if(CRM32Pro.keystate[Teclas::TECLA_G]) Texto->SetScrollBars(OnlyVScrollBars);

	if(CRM32Pro.keystate[Teclas::TECLA_SUPRIMIR]) Texto->SetText("");

	return true;
}
//******************************************************************************************
int main (int argc, char* argv[])
{
	//--------------------------------------------------------------------------------------
	// Inicializaci�n de la GUI.
	//--------------------------------------------------------------------------------------
	AppCutreCiv = Application::GetInstance();

	if(AppCutreCiv->InitFromLua("config.lua"))
	{
		cout << "No se pudo inicializar el sistema principal..." << endl;
		cout << "Error: " << AppCutreCiv->Error << endl;
		return 1;
	}

	//ITimeSystem->SetRate(85, 100);

	//--------------------------------------------------------------------------------------
	// Carga de recursos y controles.
	//--------------------------------------------------------------------------------------
	Lua::ExecFile("loadtest.lua");


	//--------------------------------------------------------------------------------------
	// Carga de recursos.
	//--------------------------------------------------------------------------------------
	CRM32Pro_CFont * Font = AppCutreCiv->Resources.GetFont("InputFont");


	ControlSkin * CSBox = AppCutreCiv->Skins.GetSkin("Default", "Box");
	if(CSBox == NULL) cout << "No se encuentra el skin del box..." << endl;

	ControlSkin * CSButton = AppCutreCiv->Skins.GetSkin("Default", "Button");
	if(CSButton == NULL) cout << "No se encuentra el skin del button..." << endl;

	ControlSkin * CSVSB = AppCutreCiv->Skins.GetSkin("Default", "VScroll");
	if(CSVSB == NULL) cout << "No se encuentra el skin del vscroll..." << endl;

	ControlSkin * CSCheck = AppCutreCiv->Skins.GetSkin("Default", "Check");
	if(CSCheck == NULL) cout << "No se encuentra el skin del check..." << endl;

	ControlSkin * CSWin = AppCutreCiv->Skins.GetSkin("Default", "Dialog");
	if(CSWin == NULL) cout << "No se encuentra el skin del dialog..." << endl;


	SDL_Surface * Bicho = AppCutreCiv->Resources.GetTexture("bicho");

	
	SDL_Surface * Boton01 = AppCutreCiv->Resources.GetTexture("boton01");
	SDL_Surface * Boton02 = AppCutreCiv->Resources.GetTexture("boton02");
	SDL_Surface * Boton03 = AppCutreCiv->Resources.GetTexture("boton03");


	//--------------------------------------------------------------------------------------
	// Cambiando parametros de la aplicaci�n.
	//--------------------------------------------------------------------------------------
	AppCutreCiv->SetKeyDown(TeclaPulsada);

	//--------------------------------------------------------------------------------------
	// Panel Panel01.
	//--------------------------------------------------------------------------------------
	Panel * Panel01 = (Panel *) AppCutreCiv->List.GetControl("Panel01");

	Caja01 = (PictureBox *) Panel01->GetControl("Caja01");
	Caja02 = (PictureBox *) Panel01->GetControl("Caja02");
	Caja03 = (LabelBox *)   Panel01->GetControl("Caja03");
	Caja04 = (Button *)     Panel01->GetControl("Caja04");
	Texto  = (TextBox *)    Panel01->GetControl("Texto");

	Dialog * Dialogo  = (Dialog *) AppCutreCiv->DialogList.GetControl("Dialogo");
	Dialog * Dialogo2 = (Dialog *) AppCutreCiv->DialogList.GetControl("Dialogo_Clone");

	//--------------------------------------------------------------------------------------
	// Bucle principal.
	//--------------------------------------------------------------------------------------
	SDL_Rect recta = {700, 500, 50, 50};
	SDL_Rect rectb = {680, 480, 60, 60};

	Motoko::Uint32 tiempo, acum = 0;
	float fps = 0;
	char auxbuff[255];

	Ayuda();

	cout << endl;
	Lua::ExecFile("hello.lua", "Data.dpf");

	while(AppCutreCiv->GetQuit() == false)
	{
		//----------------------------------------------------------------------------------
		// Pintado.
		//----------------------------------------------------------------------------------
		tiempo = AppCutreCiv->GetTime();
		SDL_FillRect(CRM32Pro.screen, NULL, 0x00000088);
		AppCutreCiv->Draw();
		SDL_Delay(1);

		acum += (AppCutreCiv->GetTime() - tiempo);
		if(acum > 500)
		{
			sprintf(auxbuff, "%f", fps);
			acum -= 500;
		}
		Font->PutString(CRM32Pro.screen, 2, 2, auxbuff);

		//----------------------------------------------------------------------------------
		// L�gica.
		//----------------------------------------------------------------------------------
		AppCutreCiv->Update();

		if(CRM32Pro.keystate[Teclas::TECLA_ESC]) AppCutreCiv->Exit();

		Control * Active = AppCutreCiv->GetActiveControl();
		
		if((Active == NULL) || (strcmp(Active->GetType(), "TextBox") != 0))
		{	
			if(CRM32Pro.keystate[Teclas::TECLA_SHIFT_IZUIERDO])
			{
				if(CRM32Pro.keystate[Teclas::TECLA_ARRIBA])    Panel01->SetY(Panel01->GetY() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_ABAJO])     Panel01->SetY(Panel01->GetY() + 1);
				if(CRM32Pro.keystate[Teclas::TECLA_IZQUIERDA]) Panel01->SetX(Panel01->GetX() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_DERECHA])   Panel01->SetX(Panel01->GetX() + 1);
			}
			else
			{
				if(CRM32Pro.keystate[Teclas::TECLA_ARRIBA])    Caja02->SetY(Caja02->GetY() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_ABAJO])     Caja02->SetY(Caja02->GetY() + 1);
				if(CRM32Pro.keystate[Teclas::TECLA_IZQUIERDA]) Caja02->SetX(Caja02->GetX() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_DERECHA])   Caja02->SetX(Caja02->GetX() + 1);
			}

			if(CRM32Pro.keystate[Teclas::TECLA_1]) AppCutreCiv->SetRenderBack(false);
			if(CRM32Pro.keystate[Teclas::TECLA_2]) AppCutreCiv->SetRenderBack(true);

			if(CRM32Pro.keystate[Teclas::TECLA_3]) Panel01->SetVisible(false);
			if(CRM32Pro.keystate[Teclas::TECLA_4]) Panel01->SetVisible(true);
			
			if(CRM32Pro.keystate[Teclas::TECLA_5])
			{
				Control * aux = AppCutreCiv->GetActiveControl();
				if(aux != NULL)
					cout << aux->GetName() << endl;
				else
					cout << AppCutreCiv->GetTitle() << endl;
			}

			if(CRM32Pro.keystate[Teclas::TECLA_ESPACIO])
			{
				if(!Dialogo->GetVisible())
					Dialogo->SetVisible(true);
				else if(!Dialogo2->GetVisible())
					Dialogo2->SetVisible(true);
			}

			if(CRM32Pro.keystate[Teclas::TECLA_F2] || CRM32Pro.keystate[Teclas::TECLA_TABULADOR])
			{
				Dialogo->SetVisible(false);
				Dialogo2->SetVisible(false);
			}
		}

		fps = 1000 / float(AppCutreCiv->GetTime() - tiempo);
	}

	//--------------------------------------------------------------------------------------
	// Finalizaci�n de los recursos.
	//--------------------------------------------------------------------------------------
	AppCutreCiv->Release();

	return 0;
}
//******************************************************************************************