//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_ITEXTCONTROL_H_
#define _MOTOKO_ITEXTCONTROL_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//******************************************************************************************
#define DEFAULT_SEPARATIONX 8
#define DEFAULT_SEPARATIONY 2
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Alignment style of the text.
	//--------------------------------------------------------------------------------------
	enum AlignmentStyle
	{
		Left,   //!< The text is aligned in the left.
		Center, //!< The text is aligned in the center.
		Right   //!< The text is aligned in the right.
	};

	//--------------------------------------------------------------------------------------
	/// Class that represents a generic text control interface.
	//--------------------------------------------------------------------------------------
	class DLLAPI ITextControl
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			inline void DrawString (SDL_Surface * buffer, string & txt, int x, int y,
									SDL_Rect * rect, int sepy, int sepx);
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			AlignmentStyle Alignment;

			string Text;

			CRM32Pro_CFont * Font;


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			int WidthText;

			inline void DrawText (SDL_Surface * buffer, int y, SDL_Rect * rect,
								  int sepy = DEFAULT_SEPARATIONY, int sepx = DEFAULT_SEPARATIONX);
			
			inline void DrawText2 (SDL_Surface * buffer, int y, SDL_Rect * rect,
								   int sepy = DEFAULT_SEPARATIONY, int sepx = DEFAULT_SEPARATIONX);

			inline void DrawTextMultiline (SDL_Surface * buffer, int y, SDL_Rect * rect,
										   int sepy = DEFAULT_SEPARATIONY,
										   int sepx = DEFAULT_SEPARATIONX);

			inline void DrawTextMultiline2 (SDL_Surface * buffer, int x, int y, SDL_Rect * rect,
											int sepy = DEFAULT_SEPARATIONY,
											int sepx = DEFAULT_SEPARATIONX);

			inline void DrawTextCenter (SDL_Surface * buffer, SDL_Rect * rect);

			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ITextControl ();
			ITextControl (const char * text, CRM32Pro_CFont * font, AlignmentStyle alignment = Left);
			ITextControl (const ITextControl & obj);
			virtual ITextControl & operator = (const ITextControl & obj);
			~ITextControl ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual ITextControl & CopyFrom (const ITextControl & obj);
			
			inline void UpdateWidth (void);

			
			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get the alignment of the control.
			inline AlignmentStyle GetAlignment (void) { return Alignment; }

			/// Get the text of the control.
			inline const char * GetText (void) { return Text.c_str(); }

			/// Get the font of the control.
			inline CRM32Pro_CFont * GetFont (void) { return Font; }

			/// Get the height of the font.
			inline int GetFontHeight (void);

			/// Get the max width of the text in a multiline context.
			inline int GetMaxWidth (void);

			/// Get the width of the last line of the text.
			inline int GetWidthLastLine (void);

			/// Get the min number of lines of the text in a multiline context.
			inline int GetMinNumLines (int sepy = DEFAULT_SEPARATIONY);

			/// Get the max number of lines of the text in a multiline context.
			inline int GetMaxNumLines (SDL_Rect * rect, int sepy = DEFAULT_SEPARATIONY);

			
			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the alignment of the control.
			virtual inline void SetAlignment (AlignmentStyle val) { Alignment = val; }

			/// Set the text of the control.
			virtual inline void SetText (const char * val) { Text = val; UpdateWidth(); }

			/// Add text to the control.
			virtual inline void AddText (const char * val) { Text += val; UpdateWidth(); }

			/// Set the text of the control.
			virtual inline void SetText (char val) { Text = val; UpdateWidth(); }

			/// Add text to the control.
			virtual inline void AddText (char val) { Text += val; UpdateWidth(); }

			/// Set the font of the control.
			virtual inline void SetFont (CRM32Pro_CFont * val) { Font = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// ITextControl.h
//******************************************************************************************