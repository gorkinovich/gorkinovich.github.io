//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_BUTTON_H_
#define _MOTOKO_BUTTON_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "ITextControl.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define MAX_BUTTON_SKINRECTS 22
#define MAX_BUTTON_RECTS      9
#define CENTER_BUTTON_RECT    4
#define INI_BUTTON_PRESSED    9
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{	
	//--------------------------------------------------------------------------------------
	/// Style of the button.
	//--------------------------------------------------------------------------------------
	enum ButtonArrow
	{
		NoneArrow  = 0,  //!< The button have no arrow.
		UpArrow    = 21, //!< The button have an up arrow.
		DownArrow  = 20, //!< The button have a down arrow.
		RightArrow = 19, //!< The button have a right arrow.
		LeftArrow  = 18  //!< The button have a left arrow.
	};

	//--------------------------------------------------------------------------------------
	/// Class that represents a generic button.
	//--------------------------------------------------------------------------------------
	class DLLAPI Button : public Control, public ITextControl
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			ButtonArrow Arrow;

			SDL_Surface * PictureOver;
			SDL_Surface * PictureDown;

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			SDL_Rect Rects[MAX_BUTTON_RECTS];

			inline void DrawGraphical (void);
			
			inline void DrawArror (void);

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			Button ();
			Button (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
					ControlSkin * appearance = NULL, SDL_Surface * picture = NULL,
					SDL_Surface * over = NULL, SDL_Surface * down = NULL,
					ButtonArrow arrow = NoneArrow, SDL_Surface * mousepointer = NULL,
					AlignmentStyle alignment = Left, bool transparency = false,
					bool enable = true, bool visible = true);
			Button (const Button & obj);
			virtual Button & operator = (const Button & obj);
			~Button ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual Button & CopyFrom (const Button & obj);

			void UpdateRects (void);


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------
			
			/// Get the arrow of the control.
			inline ButtonArrow GetArrow (void) { return Arrow; }

			/// Get the picture when the mouse is over the control.
			inline SDL_Surface * GetPictureOver (void) { return PictureOver; }

			/// Get the picture when the mouse click the control.
			inline SDL_Surface * GetPictureDown (void) { return PictureDown; }


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the coordinate X of the control.
			virtual inline void SetX (Sint16 val) { Rect.x = val; UpdateRects(); }

			/// Set the coordinate Y of the control.
			virtual inline void SetY (Sint16 val) { Rect.y = val; UpdateRects(); }

			/// Set the width of the control.
			virtual inline void SetWidth (Uint16 val)
			{
				if(val > 2)
				{
					Rect.w = val;
					UpdateRects();
				}
			}

			/// Set the height of the control.
			virtual inline void SetHeight (Uint16 val)
			{
				if(val > 2)
				{
					Rect.h = val;
					UpdateRects();
				}
			}

			/// Set the rect of the control.
			virtual inline void SetRect (SDL_Rect & val) { Rect = val; UpdateRects(); }
			
			/// Set the arrow of the control.
			inline void SetArrow (ButtonArrow val) { Arrow = val; }

			/// Set the picture when the mouse is over the control.
			inline void SetPictureOver (SDL_Surface * val) { PictureOver = val; }

			/// Set the picture when the mouse click the control.
			inline void SetPictureDown (SDL_Surface * val) { PictureDown = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Button.h
//******************************************************************************************