//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_CONTROL_H_
#define _MOTOKO_CONTROL_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Back style of the control.
	//--------------------------------------------------------------------------------------
	enum ControlBackStyle
	{
		UseAppearance, //!< Use the skin stored in Appearance.
		UseBackColor,  //!< Use the color in BackColor.
		UsePicture     //!< Use the surface in Picture
	};

	//--------------------------------------------------------------------------------------
	/// Class that represents a generic control.
	//--------------------------------------------------------------------------------------
	class DLLAPI Control
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			string Name;

			SDL_Rect Rect;

			ControlBackStyle BackStyle;
			ControlSkin *    Appearance;
			Uint32           BackColor;
			SDL_Surface *    Picture;

			SDL_Surface * MousePointer;

			bool Enable;
			bool Visible;

			bool Transparency;

			//------------------------------------------------------------------------------
			// Events
			//------------------------------------------------------------------------------
			SDL_KEY_EVENT         KeyDown;
			SDL_KEY_EVENT         KeyUp;
			SDL_MOUSEMOTION_EVENT MouseMotion;
			SDL_MOUSEBUTTON_EVENT MouseButtonDown;
			SDL_MOUSEBUTTON_EVENT MouseButtonUp;

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			string Type;

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			Control ();
			Control (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					 Uint32 backcolor, ControlSkin * appearance = NULL,
					 SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
					 bool transparency = false, bool enable = true, bool visible = true);
			Control (const Control & obj);
			virtual Control & operator = (const Control & obj);
			~Control ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void) = 0;
			virtual bool Update (SDL_Event & event) = 0;

			virtual Control & CopyFrom (const Control & obj);

			virtual bool IsCursorOver (void);

			void GetFocus (void);


			//------------------------------------------------------------------------------
			// Events
			//------------------------------------------------------------------------------
			
			/// Get the key down function of the control.
			inline SDL_KEY_EVENT GetKeyDown (void) { return KeyDown; }
			
			/// Get the key up function of the control.
			inline SDL_KEY_EVENT GetKeyUp (void) { return KeyUp; }
			
			/// Get the mouse motion function of the control.
			inline SDL_MOUSEMOTION_EVENT GetMouseMotion (void) { return MouseMotion; }
			
			/// Get the mouse button down function of the control.
			inline SDL_MOUSEBUTTON_EVENT GetMouseButtonDown (void) { return MouseButtonDown; }
			
			/// Get the mouse button up function of the control.
			inline SDL_MOUSEBUTTON_EVENT GetMouseButtonUp (void) { return MouseButtonUp; }

			
			/// Set the key down function of the control.
			inline void SetKeyDown (SDL_KEY_EVENT val) { KeyDown = val; }
			
			/// Set the key up function of the control.
			inline void SetKeyUp (SDL_KEY_EVENT val) { KeyUp = val; }
			
			/// Set the mouse motion function of the control.
			inline void SetMouseMotion (SDL_MOUSEMOTION_EVENT val) { MouseMotion = val; }
			
			/// Set the mouse button down function of the control.
			inline void SetMouseButtonDown (SDL_MOUSEBUTTON_EVENT val) { MouseButtonDown = val; }
			
			/// Set the mouse button up function of the control.
			inline void SetMouseButtonUp (SDL_MOUSEBUTTON_EVENT val) { MouseButtonUp = val; }


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------
			
			/// Get the name of the control.
			inline const char * GetName (void) { return Name.c_str(); }

			/// Get the coordinate X of the control.
			inline Sint16 GetX (void) { return Rect.x; }

			/// Get the coordinate Y of the control.
			inline Sint16 GetY (void) { return Rect.y; }

			/// Get the width of the control.
			inline Uint16 GetWidth (void) { return Rect.w; }

			/// Get the height of the control.
			inline Uint16 GetHeight (void) { return Rect.h; }

			/// Get the back style of the control.
			inline ControlBackStyle GetBackStyle (void) { return BackStyle; }

			/// Get the appearance of the control.
			inline ControlSkin * GetAppearance (void) { return Appearance; }

			/// Get the back color of the control.
			inline Uint32 GetBackColor (void) { return BackColor; }

			/// Get the picture of the control.
			inline SDL_Surface * GetPicture (void) { return Picture; }

			/// Get the mouse pointer of the control.
			virtual inline SDL_Surface * GetMousePointer (void) { return MousePointer; }

			/// Get if the control is enable.
			inline bool GetEnable (void) { return Enable; }

			/// Get if the control is visible.
			inline bool GetVisible (void) { return Visible; }

			/// Get if the control is transparent.
			inline bool GetTransparency (void) { return Transparency; }

			/// Get the type of the control.
			inline const char * GetType (void) { return Type.c_str(); }


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------
			
			/// Set the name of the control.
			virtual inline void SetName (const char * val) { Name = val; }

			/// Set the coordinate X of the control.
			virtual inline void SetX (Sint16 val) { Rect.x = val; }

			/// Set the coordinate Y of the control.
			virtual inline void SetY (Sint16 val) { Rect.y = val; }

			/// Set the width of the control.
			virtual inline void SetWidth (Uint16 val) { Rect.w = val; }

			/// Set the height of the control.
			virtual inline void SetHeight (Uint16 val) { Rect.h = val; }

			/// Set the rect of the control.
			virtual inline void SetRect (SDL_Rect & val) { Rect = val; }
			
			/// Set the back style of the control.
			virtual inline void SetBackStyle (ControlBackStyle val) { BackStyle = val; }

			/// Set the appearance of the control.
			virtual inline void SetAppearance (ControlSkin * val) { Appearance = val; }

			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 val) { BackColor = val; }

			/// Set the picture of the control.
			virtual inline void SetPicture (SDL_Surface * val) { Picture = val; }

			/// Set the mouse pointer of the control.
			virtual inline void SetMousePointer (SDL_Surface * val) { MousePointer = val; }
			
			/// Set if the control is enable.
			virtual inline void SetEnable (bool val) { Enable = val; }

			/// Set if the control is visible.
			virtual inline void SetVisible (bool val) { Visible = val; }
			
			/// Set if the control is transparent.
			virtual inline void SetTransparency (bool val) { Transparency = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Control.h
//******************************************************************************************