//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_TEXTBOX_H_
#define _MOTOKO_TEXTBOX_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "Box.h"
#include "ITextControl.h"
#include "HScrollBar.h"
#include "VScrollBar.h"
#include "Button.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define NO_LIMIT        0x7FFFFFFF
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// ScrollBars of the control.
	//--------------------------------------------------------------------------------------
	enum ControlScrollBars
	{
		NoneScrollBars,  //!< The control have no scrollbar.
		BothScrollBars,  //!< The control have the horizontal and the vertical scrollbar.
		OnlyHScrollBars, //!< The control have the horizontal scrollbar.
		OnlyVScrollBars  //!< The control have the vertical scrollbar.
	};

	//--------------------------------------------------------------------------------------
	/// ScrollBars of the control.
	//--------------------------------------------------------------------------------------
	enum KeyboardLanguage
	{
		SpanishLanguage, //!< The keyboard is a spanish keyboard type.
		EnglishLanguage  //!< The keyboard is an english keyboard type.
	};

	//--------------------------------------------------------------------------------------
	/// Class that represents a generic text box.
	//--------------------------------------------------------------------------------------
	class DLLAPI TextBox : public Box, public ITextControl
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			bool Locked;
			bool MultiLine;

			int MaxLength;

			ControlScrollBars ScrollBars;

			KeyboardLanguage Language;

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			HScrollBar * HBar;
			VScrollBar * VBar;

			SDL_Rect TextRect;

			Uint32 Time, TimeAcum;
			bool ShowCursor;

			void UpdateValues (void);

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			TextBox ();
			TextBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					 Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
					 ControlSkin * appearance = NULL, SDL_Surface * picture = NULL,
					 SDL_Surface * mousepointer = NULL, AlignmentStyle alignment = Left,
					 bool locked = false, bool multiline = false, int maxlen = NO_LIMIT,
					 ControlScrollBars scrollbars = NoneScrollBars,
					 KeyboardLanguage language = SpanishLanguage, bool transparency = false,
					 bool enable = true, bool visible = true);
			TextBox (const TextBox & obj);
			virtual TextBox & operator = (const TextBox & obj);
			~TextBox ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual TextBox & CopyFrom (const TextBox & obj);

			virtual void UpdateRects (void);


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get if the control is locked.
			inline bool GetLocked (void) { return Locked; }

			/// Get if the control is multiline.
			inline bool GetMultiLine (void) { return MultiLine; }

			/// Get the max length of the text.
			inline int GetMaxLength (void) { return MaxLength; }
			
			/// Get the visible scrollbars of the control.
			inline ControlScrollBars GetScrollBars (void) { return ScrollBars; }
			
			/// Get the type of keyboard of the control.
			inline KeyboardLanguage GetLanguage (void) { return Language; }

			/// Get the HBar of the control.
			inline HScrollBar * GetHBar (void) { return HBar; }

			/// Get the VBar of the control.
			inline VScrollBar * GetVBar (void) { return VBar; }


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------
			
			/// Set if the control is locked.
			virtual inline void SetLocked (bool val) { Locked = val; }

			/// Set if the control is multiline.
			virtual inline void SetMultiLine (bool val) { MultiLine = val; }

			/// Set the max length of the text.
			virtual inline void SetMaxLength (int val = NO_LIMIT) { MaxLength = val; }

			/// Set the visible scrollbars of the control.
			virtual inline void SetScrollBars (ControlScrollBars val) { ScrollBars = val; UpdateRects(); }
			
			/// Set the type of keyboard of the control.
			virtual inline void SetLanguage (KeyboardLanguage val) { Language = val; }

			/// Set the text of the control.
			virtual inline void SetText (const char * val)
			{
				if(strlen(val) < MaxLength)
				{
					ITextControl::SetText(val);
					UpdateValues();
				}
			}

			/// Add text to the control.
			virtual inline void AddText (const char * val)
			{
				if((Text.size() + strlen(val)) < MaxLength)
				{
					ITextControl::AddText(val);
					UpdateValues();
				}
			}

			/// Set the text of the control.
			virtual inline void SetText (char val)
			{
				if(sizeof(char) < MaxLength)
				{
					ITextControl::SetText(val);
					UpdateValues();
				}
			}

			/// Add text to the control.
			virtual inline void AddText (char val)
			{
				if((Text.size() + sizeof(char)) < MaxLength)
				{
					ITextControl::AddText(val);
					UpdateValues();
				}
			}

			/// Set the name of the control.
			virtual inline void SetName (const char * val)
			{
				Name = val;

				string aux;

				aux = Name + "_HBar"; HBar->SetName(aux.c_str());
				aux = Name + "_VBar"; VBar->SetName(aux.c_str());
			}
			
			/// Set the back style of the control.
			virtual inline void SetBackStyle (ControlBackStyle val)
			{
				BackStyle = val;
				HBar->SetBackStyle(val);
				VBar->SetBackStyle(val);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 box, Uint32 scrolls)
			{
				BackColor = box;
				HBar->SetBackColor(scrolls);
				VBar->SetBackColor(scrolls);
			}

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * box, ControlSkin * vscroll,
									   ControlSkin * hscroll, ControlSkin * button)
			{
				Appearance = box;
				HBar->SetAppearance(hscroll, button);
				VBar->SetAppearance(vscroll, button);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 val) { BackColor = val; }

			/// Set the appearance of the control.
			virtual inline void SetAppearance (ControlSkin * val) { Appearance = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// TextBox.h
//******************************************************************************************