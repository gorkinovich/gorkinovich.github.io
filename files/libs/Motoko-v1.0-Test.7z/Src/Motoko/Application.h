//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_APPLICATION_H_
#define _MOTOKO_APPLICATION_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Keys.h"
#include "Appearance.h"
#include "Control.h"
#include "ListControls.h"
//------------------------------------------------------------------------------------------
#include "Box.h"
#include "TextBox.h"
#include "LabelBox.h"
#include "PictureBox.h"
#include "ComboBox.h"
#include "ListBox.h"
//------------------------------------------------------------------------------------------
#include "Button.h"
#include "CheckButton.h"
//------------------------------------------------------------------------------------------
#include "ScrollBar.h"
#include "VScrollBar.h"
#include "HScrollBar.h"
//------------------------------------------------------------------------------------------
#include "Container.h"
#include "Panel.h"
#include "Dialog.h"
#include "ControlListBox.h"
//------------------------------------------------------------------------------------------
#include "Resources.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define APPLICATION_ERROR_UNDEF          3000
#define APPLICATION_ERROR_CRMINIT        3001
#define APPLICATION_ERROR_SETVIDEOMODE   3002
#define APPLICATION_ERROR_SOUNDINIT      3003
#define APPLICATION_ERROR_LUAOPEN        3004
//------------------------------------------------------------------------------------------
#define DEFAULT_FREQUENCY 22050
#define DEFAULT_FORMAT    AUDIO_S16
#define DEFAULT_NCHANNELS 2
#define DEFAULT_CHUNKSIZE 4096
//------------------------------------------------------------------------------------------
#define DOUBLECLICK_INTERVAL 500
//------------------------------------------------------------------------------------------
#define DOUBLECLICK_STATE_FIRSTCLICK  0
#define DOUBLECLICK_STATE_FIRSTUP     1
#define DOUBLECLICK_STATE_SECONDCLICK 2
#define DOUBLECLICK_STATE_SECONDUP    3
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class to manage the GUI of the application.
	//--------------------------------------------------------------------------------------
	class DLLAPI Application
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			static Application * Instance;

			Application();

			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			SDL_Surface * MousePointer;

			string Title;
			string Icon;

			bool RenderBack;

			SDL_Surface * Picture;
			SDL_Rect    * ActRect;
			Uint32        BackColor;

			//------------------------------------------------------------------------------
			// Events
			//------------------------------------------------------------------------------
			SDL_KEY_EVENT         KeyDown;
			SDL_KEY_EVENT         KeyUp;
			SDL_MOUSEMOTION_EVENT MouseMotion;
			SDL_MOUSEBUTTON_EVENT MouseButtonDown;
			SDL_MOUSEBUTTON_EVENT MouseButtonUp;
			
			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			Control     * ActiveControl;
			SDL_Surface * ActMousePointer;
			lua_State   * LuaVM;

			SDL_Rect MouseRect;
			bool     Quit;

			int DCState;
			Uint32 Time;
			Uint32 Interval;

			SDL_Surface * IconSurface;

			int Width;
			int Height;

			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			//------------------------------------------------------------------------------
			// Objects
			//------------------------------------------------------------------------------
			SkinsManager     Skins;      //!< Object to handle the skins of the controls.
			ListControls     List;       //!< List for the controls (please don't add here the dialogs).
			ListControls     DialogList; //!< List for the dialogs (please don't add other kind of controls).
			ResourcesManager Resources;  //!< Loaded resources of the application.

			int Error;

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			int Init (const char * title);
			int Init (const char * title, Uint16 w, Uint16 h, Uint8 bpp = 32,
					  bool window = true, int frequency = DEFAULT_FREQUENCY,
					  int format = DEFAULT_FORMAT, int nchannels = DEFAULT_NCHANNELS,
					  int chunksize = DEFAULT_CHUNKSIZE);

			int InitFromLua (const char * file, const char * fileDPF = NULL);

			void Release (void);

			void Draw   (void);
			bool Update (void);

			void PushUpDialog (const Dialog * dialog);

			/// Exit the application.
			inline void Exit (void) { Quit = true; }

			static Application * GetInstance (void);


			//------------------------------------------------------------------------------
			// Input
			//------------------------------------------------------------------------------
			inline void HideCursor (void) { ICursor->Hide(); }
			inline void ShowCursor (void) { ICursor->Show(); }

			
			//------------------------------------------------------------------------------
			// Sound
			//------------------------------------------------------------------------------


			//------------------------------------------------------------------------------
			// Time
			//------------------------------------------------------------------------------

			/// Get the number of milliseconds since the library initialization.
			inline Uint32 GetTime (void) { return SDL_GetTicks(); }

			/// Wait a specified number of milliseconds before returning.
			inline void Delay (Uint32 ms) { SDL_Delay(ms); }


			//------------------------------------------------------------------------------
			// Events
			//------------------------------------------------------------------------------
			
			/// Get the key down function of the control.
			inline SDL_KEY_EVENT GetKeyDown (void) { return KeyDown; }
			
			/// Get the key up function of the control.
			inline SDL_KEY_EVENT GetKeyUp (void) { return KeyUp; }
			
			/// Get the mouse motion function of the control.
			inline SDL_MOUSEMOTION_EVENT GetMouseMotion (void) { return MouseMotion; }
			
			/// Get the mouse button down function of the control.
			inline SDL_MOUSEBUTTON_EVENT GetMouseButtonDown (void) { return MouseButtonDown; }
			
			/// Get the mouse button up function of the control.
			inline SDL_MOUSEBUTTON_EVENT GetMouseButtonUp (void) { return MouseButtonUp; }

			
			/// Set the key down function of the control.
			inline void SetKeyDown (SDL_KEY_EVENT val) { KeyDown = val; }
			
			/// Set the key up function of the control.
			inline void SetKeyUp (SDL_KEY_EVENT val) { KeyUp = val; }
			
			/// Set the mouse motion function of the control.
			inline void SetMouseMotion (SDL_MOUSEMOTION_EVENT val) { MouseMotion = val; }
			
			/// Set the mouse button down function of the control.
			inline void SetMouseButtonDown (SDL_MOUSEBUTTON_EVENT val) { MouseButtonDown = val; }
			
			/// Set the mouse button up function of the control.
			inline void SetMouseButtonUp (SDL_MOUSEBUTTON_EVENT val) { MouseButtonUp = val; }


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------
			
			/// Get the mouse pointer of the application.
			inline SDL_Surface * GetMousePointer (void) { return MousePointer; }
			
			/// Get the title of the application.
			inline const char * GetTitle (void) { return Title.c_str(); }
			
			/// Get the icon of the application.
			inline const char * GetIcon (void) { return Icon.c_str(); }
			
			/// Get the render back state of the application.
			inline bool GetRenderBack (void) { return RenderBack; }
			
			/// Get the picture of the application.
			inline SDL_Surface * GetPicture (void) { return Picture; }
			
			/// Get the actual rect of the picture.
			inline SDL_Rect * GetActRect (void) { return ActRect; }
			
			/// Get the back color of the application.
			inline Uint32 GetBackColor (void) { return BackColor; }

			/// Get the quit state of the application.
			inline bool GetQuit (void) { return Quit; }

			/// Get the quit state of the application.
			inline lua_State * GetLua (void) { return LuaVM; }

			/// Get the active control of the application.
			inline Control * GetActiveControl (void) { return ActiveControl; }
			
			/// Get the interval of the application's double click.
			inline Uint32 GetInterval (void) { return Interval; }

			/// Get the width of the application.
			inline int GetWidth (void) { return Width; }

			/// Get the height of the application.
			inline int GetHeight (void) { return Height; }


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------
			
			/// Set the mouse pointer of the application.
			inline void SetMousePointer (SDL_Surface * val) { MousePointer = val; }
			
			/// Set the title of the application.
			inline void SetTitle (const char * val)
			{
				Title = val;
				SDL_WM_SetCaption(Title.c_str(), NULL);
			}
			
			/// Set the icon of the application.
			inline SDL_Surface * SetIcon (const char * val)
			{
				Icon = val;

				if(IconSurface != NULL)
				{
					CRM32Pro.FreeSurface(IconSurface);
					IconSurface = NULL;
				}

				IconSurface = SDL_LoadBMP((char *) val);
				SDL_WM_SetIcon(IconSurface, NULL);
				return IconSurface;
			}
			
			/// Set the icon of the application.
			inline SDL_Surface * SetIcon (const char * dpf, const char * val)
			{
				Icon = val;

				if(IconSurface != NULL)
				{
					CRM32Pro.FreeSurface(IconSurface);
					IconSurface = NULL;
				}

				IconSurface = IImage->Load((char *) dpf, (char *) val);
				SDL_WM_SetIcon(IconSurface, NULL);
				return IconSurface;
			}
			
			/// Set the render back state of the application.
			inline void SetRenderBack (bool val) { RenderBack = val; }
			
			/// Set the picture of the application.
			inline void SetPicture (SDL_Surface * val) { Picture = val; }
			
			/// Set the actual rect of the picture.
			inline void SetActRect (SDL_Rect * val) { ActRect = val; }
			
			/// Set the back color of the application.
			inline void SetBackColor (Uint32 val) { BackColor = val; }
			
			/// Set the interval of the application's double click.
			inline void SetInterval (Uint32 val) { Interval = val; }
			
			/// Set the active control of the application to NULL.
			inline void NoActiveControl (void) { ActiveControl = NULL; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Application.h
//******************************************************************************************