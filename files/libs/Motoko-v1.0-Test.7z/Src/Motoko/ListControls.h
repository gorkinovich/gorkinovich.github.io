//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_LISTCONTROLS_H_
#define _MOTOKO_LISTCONTROLS_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define LISTCONTROLS_ERROR_UNDEF    3000
#define LISTCONTROLS_ERROR_PUSHBACK 3001
#define LISTCONTROLS_ERROR_BADTYPE  3002
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class with a list of controls.
	//--------------------------------------------------------------------------------------
	class DLLAPI ListControls
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			template class DLLAPI std::allocator<Control *>;
			template class DLLAPI std::vector<Control *, std::allocator<Control *> >;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			vector<Control *> Controls;

			int NumComboBox;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ListControls ();
			ListControls (const ListControls & obj);
			virtual ListControls & operator = (const ListControls & obj);
			~ListControls ();

			
			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			int  AddControl    (Control * control);
			void RemoveControl (const char * name);

			void Free (void);
			

			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------
			Control * GetControl (const char * name);

			/// Get the number of controls in the list.
			inline int GetSize (void) { return Controls.size(); }

			/// Get a pointer to a control.
			inline Control * GetControl (int pos) { return Controls[pos]; }


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set a pointer to a control.
			inline void SetControl (int pos, Control * val) { Controls[pos] = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// ListControls.h
//******************************************************************************************