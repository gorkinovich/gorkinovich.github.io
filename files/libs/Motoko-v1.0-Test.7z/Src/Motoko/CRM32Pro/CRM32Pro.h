// --------------------------------------------------------------------------- 
//   						   CRM32Pro Library 
//  				      MegaStorm Systems (c) 2006
//							Roberto Prieto Prieto 
// ---------------------------------------------------------------------------
#ifndef CRM32Pro_H
#define CRM32Pro_H
 
// ------------------------------INCLUDES-------------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "SDL/SDL.h"  
#include "SDL/SDL_thread.h"

// ----------------------------MAGIC LIBRARY STUFF----------------------------
#define RecoverSurf         // By default, auto recover surfaces support is enabled.
#if defined(_WINDOWS) || defined(WIN32) || defined(WIN64) // Is a Windows platform?
     #ifdef WIN64
      #undef RecoverSurf    // In Windows64, auto recover support is not needed.
    #endif
    #ifndef _WINDOWS
      #define _WINDOWS
    #endif
    #ifdef _WINDLL 
	  #define DllHandle __declspec(dllexport)    
	  #define DllExport __declspec(dllexport)
    #endif
    #ifndef _WINDLL
	  #define DllExport
	  #define DllHandle                          // Support static library.
      #ifndef CRM32PRO_STATIC 
        #undef DllHandle
        #define DllHandle __declspec(dllimport)  // Support shared library.
      #endif
    #endif	
#elif defined(__unix__) || defined(__UNIX__) // Otherwise, is a linux platform?
    #define _LINUX
    #define DllHandle  
    #define DllExport  
    #undef RecoverSurf    // In Linux, auto recover support is not needed.
#else                                        // Platform unknown, provocate compiling error.
    #error PLATFORM UNKNOWN - OVERRIDE THIS LINE TO FORCE COMPILING
#endif
  
// ---------------------------------------------------------------------------
/** @defgroup MODULE1 MODULE 1: CRM32Pro main and generic functions (v2.1).
 * This module contains main and generic functions:<br>
 * Init() and Quit(): these are the main functions of the library. They replace to SDL_Init() and SDL_Quit. <br>
 * SetVideoMode() uses Config struct to setup a video mode, it replaces SDL_SetVideoMode(). <br>
 * Update() is the main way to update all systems: graphics,events,timing,etc.It also replace SDL_Flip().<br>
 * XML parser, CRC32 functions, true random number generation and get useful information. <br>
 * Note that you always have to call to CRM32Pro.Init() to initialize the library and CRM32Pro.Quit() to close it. <br>
 * - Created on 10 June 2001
 * - Last modified on 8 May 2006*/
// ---------------------------------------------------------------------------
//! @{  

// -Video backend-
#define RENDER_DEFAULT 1 //!< Used with Config.VideoRender to use default backend. Default setting.
#define RENDER_WINDIB  2 //!< Used with Config.VideoRenderer to use Windib backend. Only for Win32/Win64.
#define RENDER_DIRECTX 4 //!< Used with Config.VideoRenderer to use DirectX backend. Only for Win32.
#define RENDER_X11     8 //!< Used with Config.VideoRenderer to use X11 backend. Only for Linux.
#define RENDER_FBCON  16 //!< Used with Config.VideoRenderer to use Frame Buffer Console backend. Only for Linux.
#define RENDER_DGA    32 //!< Used with Config.VideoRenderer to use DGA backend. Only for Linux.
#define RENDER_OPENGL 64 //!< Used with Config.VideoRenderer to use OpenGL backend. For Win32/Win64 and Linux.

// -Video acceleration mode-
#define ACCEL_SOFTWARE    1 //!< Used with Config.VideoAccel to set software mode with optimizations.
#define ACCEL_HARDSMOOTH  2 //!< Used with Config.VideoAccel to set hardware mode with smooth system (double-buffer).
#define ACCEL_HARDSPEED   3 //!< Used with Config.VideoAccel to set hardware mode at full speed.

// -Customs events-
#define EVENT_LOGICWAIT 30  //!< Event type returned by CRM32Pro.Update() while it is waiting to fulfill the Logic Rate.

//! CRM32Pro
/*! Main library interface.*/ 
class DllExport CRM32Pro_Main 
{
    public:
		// -Constructor-
		CRM32Pro_Main();
		// -Destructor-
		~CRM32Pro_Main();
		// -Init system-	
		int Init(unsigned int flags);  
		// -Quit system-		
		void Quit(void);      
		// -Update sytem-
		int Update(SDL_Event *ev=NULL);
		// -Clean up update system-
		void CleanUp(void);
		// -Set a video mode-
		int SetVideoMode(void);
		// -Blit a surface-
		int Blit(SDL_Surface *src, SDL_Rect *srcrect,SDL_Surface *dst, SDL_Rect *dstrect);
		// -Free a surface (using safe mode)-
		void FreeSurface(SDL_Surface *&);
		// -Set a callback function to blit your graphics at Rendering Frame Rate-
		void SetRenderCallback(void (*myRenderFunc)(void));
		// -Get current logic time-
		float GetLogicTime();

		// -Print version,copyright and compiled date and get string-
		void PrintVersion();       
		char *GetVersion();        
		char *GetCopyright();      
        // -Print useful information- 
		void VideoInfo(); 
		void AudioInfo();
	    void SurfaceInfo(SDL_Surface *surface);

		// -CRC32-
		unsigned int CRC32(char *buffer, int Size); 
		unsigned int CRC32(char *filename);

		// -True random number generator-
		void RandSeed(unsigned int seed); // Random seed
		Uint32 Rand();              // Random number on [0,0xffffffff] interval 
		double RandReal();          // Random number on [0,1] interval

		// -XML parser system-		
		int XMLOpen(char *filename);
		int XMLOpen(char *fileDPF,char *blockname);
		int XMLSave(int id, char *filename);
		int XMLSave(int id, char *fileDPF, char *blockname);
		void XMLClose(int id);

		int XMLNodePointTo(int id,int nparam,char *, ...);
		int XMLNodeFirst(int id);
		int XMLNodeNext(int id);
		int XMLNodeParent(int id);
		int XMLNodeChild(int id);
		int XMLNodeRemove(int id);
		int XMLNodeCreate(int id, char *name);
		int XMLNodeRename(int id, char *name);
		char *XMLNodeGetName(int id);
		
		int XMLAttributeSet(int id,char *name,char *value);
		int XMLAttributeSet(int id,char *name,int value);
		int XMLAttributeSet(int id,char *name,double value);
		int XMLAttributeGet(int id,char *name, char **value);
		int XMLAttributeGet(int id,char *name, int *value);
		int XMLAttributeGet(int id,char *name, double *value);
		int XMLAttributeRemove(int id, char *name);

		char *XMLTextGet(int id);
		int XMLTextSet(int id, char *value);
		int XMLTextRemove(int id);
		
		//! Main config struct. <br>You can manually fill it or using CRM32Pro.LoadConfig() loading an external XML.
		struct sConfig
		{
			// 1.General section
			char *Title;         //!< Title or name of your application. It is usually used as window title.
			SDL_Surface *Icon;   //!< Pointer to surface to assign it as icon.
			char bMTFriendly;    //!< MultiTasks Friendly flag.When it is enabled, it will give execution flow to OS scheduler for at least 1ms each Render Frame. By default is disabled.

			// 2.Video section
			Uint8 VideoRenderer; //!< See RENDER_xxx defines.			
			Uint8 VideoAccel;    //!< See ACCEL_xxx defines.
			Uint8 VideoWindow;   //!< 0 to force fullscreen or 1 to select window mode.
			Uint8 VideoBPP;      //!< Bits Per Pixel, you can choose 8,16 or 32.
			Uint16 VideoWidth;   //!< Video screen width.
			Uint16 VideoHeight;  //!< Video screen height.

			// 3.Audio section
			Uint8 AudioEnable;   //!< 0 to disable or 1 to enable sound system.
			int   AudioFormat;   //!< AUDIO_S8 to 8bits or AUDIO_S16 to 16bits sound resolution.
			int   AudioFreq;     //!< Frequency in Hz (11025,22050,44200).
			int   AudioMode;     //!< 1 for mono, 2 for stereo, 4 for surround and 6 for surround with center and lfe.
			int   AudioBuffer;   //!< Mixing buffer size, a common and good value is 4096.
			Uint8 AudioMusicVol; //!< Music volume.
			Uint8 AudioSoundVol; //!< Sound volume.
		} Config; 
		int LoadConfig(char *filename);
		int SaveConfig(char *filename);

		// -Common vars-
		SDL_Surface *screen;     //!< Main screen surface. You always have to use it to blit your graphics.
        int mouse_x;             //!< Mouse X position. Updated automatically.
        int mouse_y;             //!< Mouse Y position. Updated automatically.
        Uint8 mouse_buttons;     //!< Current state of mouse�s buttons. Updated automatically.
        Uint8 mouse_prevbuttons; //!< Previous state of mouse�s buttons. Updated automatically.
		Uint8 *keystate;         //!< Array of keys state. Updated automatically.
		Uint32 iStartTime;       //!< Store the start ticks(SDL_GetTicks()) when CRM32Pro was initialized.
		Uint8 iAutoSurfRecovery; //!< Flag to set on/off auto surface recovery.It is automatically setup in DirectX hardware mode.

		// -Resources internal control-
        int iNTiles,iNSprites,iNFonts;

	private:
		class cInternalMain *IInternal;	
};
 
 // High optimized memory copy
 extern "C" DllExport void *(*CRM32Pro_memcpy)(void *dest, const void *src, size_t n); //!< Optimized �memcpy()� function for each platform: AMD(K5,K6,K7,K8) and Intel(Pentium MMX,Pentium II, Pentium III,Pentium 4,Pentium M)

//! @}
   

// ---------------------------------------------------------------------------
/** @defgroup MODULE2 MODULE 2: ILogSystem v2.5, log system interface.
 * Log System Interface to log any operation on your application. <br>
 * CRM32Pro use it to print a lot of useful information. <br>
 * All print actions are done internally using Msg(). <br>
 * You should initialize this interface at the beginning of your application if you want to use it. <br>
 * - Created on 18 May 2000
 * - Last modified on 20 December 2005*/
// ---------------------------------------------------------------------------
//! @{
   //---Structs---
   #define LOG_NULL              0  //!< Use with Init() in 'mode' parameter: no output.
   #define LOG_CONSOLE           8  //!< Use with Init() in 'mode' parameter: console only output.
   #define LOG_FILE              2  //!< Use with Init() in 'mode' parameter: file only output.
   #define LOG_CONSOLE_FILE      4  //!< Use with Init() in 'mode' parameter: both console and file output.
   #define LOG_LOW               0  //!< Use with Init() in 'level' parameter: low output log (only high priority messages from CRM32Pro).
   #define LOG_NORMAL            2  //!< Use with Init() in 'level' parameter: normal output log.
   #define LOG_HIGH              5  //!< Use with Init() in 'level' parameter: high output log (more useful messages from CRM32Pro).
   
   //! ILogSystem
   /*! Interface to log your application  */
   class DllExport CRM32Pro_ILogSystem
   {
   public:
	   // -Constructor-
	   CRM32Pro_ILogSystem(void); 	   
	   // -Destructor-
	   ~CRM32Pro_ILogSystem(void);	   
	   // -Init-
	   void Init(char *filename, char mode,char level,char *prgname,char *author=NULL,char *email=NULL,char *web=NULL);       
	   // -Msg-
	   void Msg(char level,char *, ...);   
	   // -Show the time when occurred the event-
	   void ShowTime(char);
	   // -GetState-
	   unsigned char GetState(void); 
	   // -Code block profile begin-
	   void ProfileBegin(char* name);
	   // -Code block profile end-
	   void ProfileEnd(char* name);
	   // -Profiles table show-
	   void ProfileShow(void);

   private:
	   class cInternalLogSystem *IInternal;
    };
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE3 MODULE 3: IStuffDPF v4.2, Data Package Format interface.
 * Interface to manage all operations related to DPF (Data Package Format). <br>
 * It is a secure container to avoid external modification and you can protect your data with a password. <br>
 * Internally, CRM32Pro use it to pack tiles, sprites, fonts, buttons and sound. <br>
 * Very useful and easy to use. <br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it. <br>
 * - Created on 21 June 2001
 * - Last modified on 9 July 2006*/
// ---------------------------------------------------------------------------
//! @{ 
   #define DPFACCESS_NORMAL   0 //!< Used with SetAccessMode(). Fastest access but in case of block corruption, it could omit some blocks. Default setting.
   #define DPFACCESS_LOWLEVEL 1 //!< Used with SetAccessMode(). Slowest access but in case of block corruption, it can read all blocks.

   //! Data block
   typedef struct DPF_BlockData
   {
     char name[32];      //!< Name of block
	 char type[8];       //!< Type of block
	 Uint8 storedmethod; //!< 0 to compress the block, 1 to leave on normal state and 2 to encode it
     Uint32 size;        //!< Size in bytes of data block
	 Uint32 size_packed; //!< Compressed size in bytes of data block. Information purposes only.
	 char *data;	     //!< Pointer to raw data block
   } DPF_BlockData;

   //! IStuffDPF
   /*! Interface to manage DPF.*/ 
   class DllExport CRM32Pro_IStuffDPF
   {
    public:
		// -Constructor-
		CRM32Pro_IStuffDPF(void);   
		// -Destructor-
		~CRM32Pro_IStuffDPF(void);	
		// -Create DPF-
		int Create(char *filename);
		// -Open DPF-
		int Open(char *filename);   
		// -Close a DPF-		
		void Close(int idDPF);		
		// -Add a block of data to DPF-		
		int AddData(int idDPF, DPF_BlockData *info);
		// -Add a block of file to DPF-
		int AddFile(int idDPF, char *filename);
		// -Load a block of specific type-
		int LoadBlock(int idDPF,char *type,char *name,DPF_BlockData *info);
		// -Free a loaded block-
		int FreeBlock(DPF_BlockData *);
		// -Delete a specific block-
		int Delete(int idDPF,DPF_BlockData *info);
		// -Search for a specific block-
		int Search(int idDPF,DPF_BlockData *info);
		// -Find first block-
		int FindFirst(int idDPF,DPF_BlockData *info);
		// -Find next block-
		int FindNext(int idDPF,DPF_BlockData *info);
		// -Set the access mode-
		void SetAccessMode(char mode);
		// -Set the access password-
		void SetPassword(unsigned char *key,unsigned char keylen);
    
		// -Compact DPF-
		int Compact(char *filename);
		// -Protect your DPF with heavy encription-
	    int Protect(char *filename, unsigned char *key,unsigned char keylen);
        // -Unprotect your previously protected DPF with heavy encription-
	    int UnProtect(char *filename, unsigned char *key,unsigned char keylen);

		// -Return total blocks number of given DPF-
		int GetNumBlock(int idDPF);
		// -Return deleted blocks number of given DPF-
		int GetNumDelBlock(int idDPF);
		// -Return fragment percent of given DPF-
		char GetFragment(int idDPF);
		// -Return size of given DPF-
		int GetSize(int idDPF);
        // -Return info from last loaded DPF-
		char *GetName(void);
		char *GetCopyright(void);
		char *GetCreateDate(void);
		char *GetLastModified(void);
		int IsProtected(void);

	private:
		class cInternalStuffDPF *IInternal;		
   };
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE4 MODULE 4: IImage v2.50, Image Package Format interface.
 * IImage allow to manage the load/save images and stores it on DPF. <br>
 * It supports alpha per surface, colorkey and alpha per pixel. <br>
 * We advice to you to use EditorDPF to modify/add/delete image and its features.<br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it. <br>
 * - Created on 7 June 2001
 * - Last modified on 27 January 2006*/
// ---------------------------------------------------------------------------
//! @{
   //! IPF header
   typedef struct sHeaderIPF
   {
	 int TamX;			//!< image size x
	 int TamY;			//!< image size y
	 char bps;          //!< color depth (8,16,24,32)
     int AlphaValue;    //!< alpha channel (0=opaque,255=transparent)
	 int ColorKey;      //!< colorkey
	 char name[32];     //!< image name
	 char reserved[128];
   } sHeaderIPF;

   //! IImage
   /*! Interface to manage images.*/ 
   class DllExport CRM32Pro_IImage
   {
    public:
	   // -Constructor-
	   CRM32Pro_IImage(void);	   
	   // -Destructor-
	   ~CRM32Pro_IImage(void);	
       // -Load a IPF from a DPF-
	   SDL_Surface *Load(char *fileDPF,char *imgname, sHeaderIPF *header=NULL); 
	   // -Save a IPF into a DPF-
	   int Save(char *fileDPF, char *imgname, SDL_Surface *image); 
	   // -Load and save BMP-
	   SDL_Surface *LoadBMP(char *filename);
	   int SaveBMP(char *filename,SDL_Surface *surface);	   
   }; 
//! @}


// ---------------------------------------------------------------------------
/** @defgroup MODULE5 MODULE 5: IPrimitives v3.30, primitives interface system.
 * IPrimitives support all stuff related to primitives draw as <br>
 * points, lines, box, get color values... are independent of depth color.<br>
 * It also has support to pixel level operations as collision, color component conversion, ...<br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it. <br>
 * - Created on 9 July 2001
 * - Last modified on 28 May 2006*/
// ---------------------------------------------------------------------------
//! @{

//! IPrimitives
/*! Primitives interface system.*/
   class DllExport CRM32Pro_IPrimitives
   {    
    public:
		// -Constructor-
		CRM32Pro_IPrimitives(void);   
		// -Destructor-
		~CRM32Pro_IPrimitives(void);  

		// -Test a fast pixel perfect collision between two surfaces-
		unsigned char PixelCollision(SDL_Surface *s1, SDL_Rect *r1,SDL_Surface *s, SDL_Rect *r2,unsigned char debug=0,SDL_Rect *posr1=NULL,SDL_Rect *posr2=NULL); 
		// -Draw a single pixel-
		void PutPixel(SDL_Surface *surf, short x, short y, unsigned int pixel, unsigned char alock=1);  
		// -Draw a pack of 16 pixels (only 32bit depth color version)
		void Put16Pixel(SDL_Surface *surf, short x, short y, unsigned int *arraypixels,unsigned char alock=1); 
		// -Get a single pixel-
		unsigned int GetPixel(SDL_Surface *surf, short x, short y,unsigned char alock=1); 
		// -Get a pack of 16 pixels (only 32bit depth color version)
		void Get16Pixel(SDL_Surface *surf, short x, short y,unsigned int *arraypixels,unsigned char alock=1);
		// -Draw horizontal line-
		void HLine(SDL_Surface *surf, short x1, short x2, short y, unsigned int color);
		// -Draw vertical line-
		void VLine(SDL_Surface *surf, short x, short y1, short y2, unsigned int color);
		// -Draw rect-
		void Rect(SDL_Surface *surf, short x1, short x2, short y1, short y2, unsigned int color);
	    // -Color conversion RGB to HSV-
		void RGBtoHSV(unsigned char r8, unsigned char g8, unsigned char b8, float *h, float *s, float *v);
		// -Color conversion HSV to RGB-
		void HSVtoRGB(float h, float s, float v, unsigned char *r8, unsigned char *g8, unsigned char *b8);	
		// -Lock a surface-
		void Lock(SDL_Surface *);
		// -Unlock a surface-
		void UnLock(SDL_Surface *);
    private:
		class cInternalPrimitives *IInternal;
   };
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE6 MODULE 6: ICursor v2.70, manage cursor actions.
 * ICursor allow to use images as cursors and some extra functionality:<br>
 * store up to 20 cursors, clip region, differents hot spots, change cursor on the fly.<br>
 * It supports special features: alpha per surface, colorkey and alpha per pixel. <br>
 * We advice to you to use EditorDPF to modify/add/delete image cursor and its features. <br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it. <br>
 * - Created on 31 August 2001
 * - Last modified on 11 May 2006*/
// ---------------------------------------------------------------------------
//! @{

#define CTYPE_NORMAL    0  //!< Use with Create() in 'type' parameter: start blit coordinate is (0,0)
#define CTYPE_REVERSEX  1  //!< Use with Create() in 'type' parameter: start blit coordinate is (x cursor size,0)
#define CTYPE_REVERSEY  2  //!< Use with Create() in 'type' parameter: start blit coordinate is (0,y cursor size)
#define CTYPE_REVERSEXY 3  //!< Use with Create() in 'type' parameter: start blit coordinate is (x cursor size,y cursor size)
#define CTYPE_CENTER    4  //!< Use with Create() in 'type' parameter: start blit coordinate is (x cursor size/2, and cursor size/2)

//! ICursor
/*! Interface to manage cursor.*/ 
class DllExport CRM32Pro_ICursor 
{
	friend class CRM32Pro_Main;
	friend class CRM32Pro_CSprite;
	friend class CRM32Pro_CTile;
	friend class CRM32Pro_CFont;
	friend class CRM32Pro_IPrimitives;
    public:
		// -Constructor-
		CRM32Pro_ICursor();
		// -Destructor-
		~CRM32Pro_ICursor();

		// -Init system-	
		void Init(void);		
		// -Close system-		
		void Close(void);		
		// -Create a cursor from a file-		
		char Create(char *imgfile,char type=CTYPE_NORMAL); 
		// -Create a cursor from a surface-		
		char Create(SDL_Surface *surf,char type=CTYPE_NORMAL);
		// -Load a cursor from an IPF stores on DPF-
		char Load(char *fDPF,char *nameIPF,char type=CTYPE_NORMAL); 	    
		// -Delete a cursor-
		void Delete(char id);		
		// -Select a cursor and define it as current cursor-
		void Select(char id);		
		// -Invalidate next background autorestore-
		void Invalidate(void);   
		// -Hide current cursor-
		void Hide(void);
		// -Show current cursor-
		void Show(void);
		// -Define a valid clip region-
		void ClipRegion(int xi,int yi,int xf,int yf);
		// -Enable/Disable autorestore background
		void AutoRestore(char value);
		// -Enable/Disable smooth movement-
		void SetSmooth(char value);
		// -Change the type of cursor-
		void ChangeType(char id, char type);
		// -Print a lot of useful information about cursor interface-
		void Info();

	private:
		//! Private members to update and save cursor. Called internally by CRM32Pro.Update()
		void Update(void);
		void SaveCoordinates(int x,int y);
		//! Private members used internally by CFont,CSprite and CTile
        int RestoreBG(SDL_Rect *r=NULL);
		void CopyBG();		
		class cInternalCursor *IInternal;	
};
//! @}


// ---------------------------------------------------------------------------
/** @defgroup MODULE7 MODULE 7: CTile v1.90, tile engine class.
 * CTile supports all stuff related to manage and draw tiles: <br>
 * tiles of any size, tile sets and movement(without animation) <br>
 * It supports special features: alpha per surface, colorkey and alpha per pixel. <br>
 * We advice to you to use EditorDPF to modify/add/delete tiles and its features.<br>
 * - Created on 23 June 2001
 * - Last modified on 20 January 2006*/
// ---------------------------------------------------------------------------
//! @{

//! CTile
/*! Tile engine class.*/
class DllExport CRM32Pro_CTile
   {
    public:
		// -Constructor-
		CRM32Pro_CTile(void);  
		// -Destructor-
		~CRM32Pro_CTile(void);	
		// -Create tile from a BMP-		
		unsigned char Create(char *filebmp,char *nametile);
		// -Create tile from a surface-
		unsigned char Create(SDL_Surface *surf,char *nametile);
		// -Load tile from DPF-
		unsigned char Load(char *fileDPF,char *name,char *typeblock="TILE");	
        // -Get the surface of tile-
        SDL_Surface *GetSurface();
		// -Save tile to DPF-
		unsigned char Save(char *fileDPF,char *typeblock="TILE");
		// -Set position on screen of tile-
		void SetPosition(int x, int y);
		// -Get x size-
		int GetSizeX(void);
		// -Get y size-
		int GetSizeY(void);
		// -Get x position-
		int GetPosX();
		// -Get y position-
		int GetPosY();
		// -Get offset of tileset-
		int GetOffset();
		// -Get the name of tile-
		char *GetName();
		// -Set a colorkey using RGB values-
		void SetColorKey(char r,char g,char b);		
		// -Set a colorkey using packed integer-
		// Note: 0 turns off the colorkey
		void SetColorKey(int CKey);
		// -Set alpha channel-
		void SetAlpha(int shade);
		// -Draw tile-
		int Draw(SDL_Surface *dumpto=NULL,int selTS=0);
		// -Conversion from a tile to tileset and reverse-
		unsigned char SetTileSet(int isTS,int offset);	
		// -Print a lot of useful tile information-
		void Info();
	
    private:
		class cInternalTile *IInternal;
   };
//! @}


// ---------------------------------------------------------------------------
/** @defgroup MODULE8 MODULE 8: CFont v2.50, font engine class.
 * CFont support all stuff related to manage and draw fonts. <br>
 * You can use any external font. It supports alpha per surface and alpha per pixel <br>
 * We advice to you to use EditorDPF to modify/add/delete fonts and its features.<br>
 * - Created on 30 July 2001
 * - Last modified on 12 June 2006*/
// ---------------------------------------------------------------------------
//! @{
// ! " # $ % & ' ( ) * + , - . / 0 1 2 3 4 5 6 7 8 9 : ; < = > ? @ A B C D E F G H I J K L M N O P Q R S T U V W X Y Z [ \ ] ^ _ ` a b c d e f g h i j k l m n o p q r s t u v w x y z { | } ~ 

//! CFont
/*! Font engine class.*/
class DllExport CRM32Pro_CFont
{
    public:
		// -Constructor-
		CRM32Pro_CFont(); 
		// -Destructor-
		~CRM32Pro_CFont();
		// -Create a font from a surface or BMP-
		unsigned char Create(SDL_Surface *surface);
		unsigned char Create(char *filebmp);
		// -Load a font from DPF-
		unsigned char Load(char *fileDPF, char *fontname);
		// -Save this font to a DPF-
		unsigned char Save(char *fileDPF,char *fontname);
		// -Test if a given surface or BMP can be converted to a font-
		unsigned char Test(char *filebmp);
		unsigned char Test(SDL_Surface *);
		// -Print a lot of useful info-
		void Info();
	    // -Draw a string using the font-
	    void PutString(SDL_Surface *Surface, int x, int y, char *str, SDL_Rect *clip=NULL);	    
		// -Draw a string using the font with cursor-
		void PutStringWithCursor(SDL_Surface *Surface, int x, int y, char *str, int cursPos, SDL_Rect *clip=NULL, unsigned char showCurs=1);
		// -Get the size of the given string (in pixels)-
		int StringWidth(char *str);
		// -Render a X centered string-
		void PutStringXCenter(SDL_Surface *Surface, int y,  char *str, SDL_Rect* clip=NULL);		
		// -Render a Y centered string-
		void PutStringYCenter(SDL_Surface *Surface, int x,  char *str, SDL_Rect* clip=NULL);		
		// -Set the cursor position-
		int SetCursorAt(char *str,int px);	
		// -Set alpha per surface-
		void SetAlpha(int shade);
	    // -Get alpha per surface-
		int GetAlpha();
		// -Get the surface of font-
		SDL_Surface *GetSurface();

	private:
		class cInternalFont *IInternal;
};
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE9 MODULE 9: IScreenFX v4.20, screen FX interface.
 * IScreenFX has members to do simples special effects on screen surface as: <br>
 * greyscales,negative,black&white,wind,red,blue,green... <br>
 * And it also has complex effects as: <br> fade(from and to, white and black),gamma,blur,noise, scaled...<br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it. <br>
 * - Created on 9 July 2001
 * - Last modified on 13 March 2006*/
// ---------------------------------------------------------------------------
//! @{
   #define FXSCREEN_NULL       0 //!< Switch off any kind of effect
   #define FXSCREEN_COLOR      1 //!< Color threshold effect Color threshold effect
   #define FXSCREEN_WIGGLE     2 //!< Wiggle effect
   #define FXSCREEN_ZOOM       3 //!< Progressive zoom effect
   #define FXSCREEN_VIDEO      4 //!< Video effect
   #define FXSCREEN_WIND       5 //!< Wind effect
   #define FXSCREEN_NEGATIVE   6 //!< Negative color effect
   #define FXSCREEN_GREY       7 //!< Grey effect
   #define FXSCREEN_GREYREAL   8 //!< Accurate grey effect
   #define FXSCREEN_BLACKWHITE 9 //!< Black/White effect
   #define FXSCREEN_RED       10 //!< Red effect
   #define FXSCREEN_GREEN     11 //!< Green effect
   #define FXSCREEN_BLUE      12 //!< Blue effect

   //! IScreenFX
   /*! Screen FX interface system.*/
   class DllExport CRM32Pro_IScreenFX
   {
    
    public:	  
		// -Construct-
		CRM32Pro_IScreenFX(void);
		// -Destructor-
		~CRM32Pro_IScreenFX(void);
		// -Add noise to given surface(very slow)-
		int Noise(SDL_Surface *surface, int noise_pct);
		// -Add blur to given surface(very slow)-
		int Blur(SDL_Surface *surface, int blur_pct);
		// -Set gamma to given surface-
		int GammaCorrect(SDL_Surface *surface,int r,int g,int b);
		// -Fade current screen surface to given color-
		int FadeToColor(unsigned char r,unsigned char g,unsigned char b,unsigned int ms,SDL_Rect *rdst=NULL);           
		// -Fade to given surface from current screen surface-
		int FadeToImage(SDL_Surface *surface,unsigned int ms,SDL_Rect *rdst=NULL,SDL_Rect *rsrc=NULL);
		// -Scale surface-
		SDL_Surface *Scale(SDL_Surface *surface, double scalex, double scaley,int smooth);
		// -Render simple special fx-
		void RenderFX(SDL_Surface *src,SDL_Surface *dst,int effect);
 
	private:
		class cInternalScreenFX *IInternal;
		char deInitIPrimitives; // Internal var
   };
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE10 MODULE 10: IButton v3.20, GUI interface.
 * IButton support all stuff related to GUI multilayer system with these kind of buttons: <br>
 * normal,input box,4-state,check,slider and progress bar. <br>
 * It supports special features: alpha per surface or alpha per pixel. <br>
 * Internally, it uses CTile to store/load the images.<br>
 * We advice to you to use EditorDPF to modify/add/delete tiles and its features.<br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it. <br>
 * - Created on 10 June 2001
 * - Last modified on 9 February 2006*/
// ---------------------------------------------------------------------------
   
   //! @{
   #define B_NORMAL 1  //!< State of button: normal                                                
   #define B_SELECT 2  //!< State of button: selected                                                
   #define B_PRESS 4   //!< State of button: pressed
   #define B_ACTION 8  //!< State of button: click
   #define B_OFF 16    //!< State of button: desactivated

   #define B_TYPE_NORMAL 1    //!< Used in IButtonNew.type: to create a normal button.
   #define B_TYPE_ICON   2    //!< Used in IButtonNew.type: deprecated, only for back compatibility.The same behaviour as NORMAL.
   #define B_TYPE_COMPLEX 4   //!< Used in IButtonNew.type: to create a complex button.
   #define B_TYPE_SLIDER 8    //!< Used in IButtonNew.type: to create a slider.
   #define B_TYPE_PROGRESS 16 //!< Used in IButtonNew.type: to create a progress bar.
   #define B_TYPE_CHECK 32    //!< Used in IButtonNew.type: to create a check button.
   #define B_TYPE_INPUT 64    //!< Used in IButtonNew.type: to create an input box.

   //! External button struct used to create new buttons
   typedef struct IButtonNew                                       
	{                                                                  
	 void (*ButtonFunc)(void); //!< Pointer to function to call when click                                       
	 Uint16 key;               //!< Key associated to button
	 Uint8 type;               //!< Type of button. See B_TYPE_xxx defines
  	 Uint32 color_select;      //!< Color of select rectangle
	 Uint16 posx, posy;        //!< (X,Y) position
	 short int range;          //!< Range
	 char bVisible;            //!< 0=invisible and 1=visible
	 char bClon;               //!< Am I a clone? 0=no 1=yes
	 int cvalue;               //!< Current value.
   } IButtonNew;    
    
   //! IButton
   /*! Button interface system.*/
   class DllExport CRM32Pro_IButton
   {    
	   friend class CRM32Pro_Main;
    public:
		// -Constructor-
		CRM32Pro_IButton(void);   
		// -Destructor-
		~CRM32Pro_IButton(void);                                                       
		// -Add new button to current layer-                                    
		int Create(struct IButtonNew *button,char *tilename,unsigned char master,char *fDPF);  
        // -Load a button from DPF file-
		int Load(char *fDPF,char *butname,unsigned char master=0); 
		// -Load only the header of button from a DPF file-
		unsigned char LoadHeader(char *fDPF,char *butname, IButtonNew *info);
		// -Delete a button from a DPF file-
		unsigned char Delete(char *butname, char *fDPF);
		// -Save a button to DPF file-
		unsigned char Save(char *fDPF,char *butname,IButtonNew *button);
		// -Draw buttons of current layer-
		int Draw(void);            
		// -Get ID of selected button-
		int WhoIsSelected(void);     
		// -Remove button of given ID-
		void Remove(int id);  
		// -Remove all button of current layer-
		void RemoveAll(void); 
		// -Force a state of given ID button-
		void SetState(int id,char s);     
		// -Set colorkey using RGB-
        void SetColorKey(int id,char r,char g,char b); 
		// -Set colorkey using packed integer-
		// Note: 0 means turn off colorkey
		void SetColorKey(int id,int CKey );
		// -Set alpha-
		void SetAlpha(int id,int a);
		// -Set working layer-
		void SetLayer(char n);
		// -Set visibility of given layer-
        void SetLayerVisibility(char n,char v);
		// -Set visibility of given ID button-
		void SetVisible(int id,unsigned char value);  
		// -Clone a given ID button-
		int  Clone(int id);
		// -Set position of given ID button-
		void SetPosition(int id,int x,int y);
		// -Set a font, only works with InputText button-
		void SetTextFont(int id,CRM32Pro_CFont *font);
		// -Set text rect area, only works with InputText button-
		void SetTextRect(int id,SDL_Rect *);
		// -Set text, only works with InputText button-
		void SetText(int id,char *);
		// -Get current text, only works with InputText button-
        char *GetText(int id);
		// -Get total number of buttons-
		int GetNum(void);            
		// -Get the range of slider or progress-
		int GetRange(int id);        
		// -Get current value of slider or progress-
		int GetCurrentValue(int id); 
		// -Set current value of slider or progress-
		void SetCurrentValue(int id, int value);
		// -Get current state of given ID button-
		int GetState(int id);        
		// -Get surface of given ID button and its state
		SDL_Surface *GetSurface(int id,int state);
		// -Force to draw all buttons on visible layer on next call to Draw()-
		void ForceDraw(void);        
		// -Set a function for a given ID button-
		void SetFunction(int id, void (*ButtonFunc)(void));		
		// -Print a lot of information about button interface-
		int Info(int m);  	

	private:
		//! Private member to update GUI system. Called internally by CRM32Pro.Update()
		void Update();
		class cInternalButton *IInternal;
   };
//! @}


// ---------------------------------------------------------------------------
/** @defgroup MODULE11 MODULE 11: ITimeSystem v1.70, timer system interface
 * ITimeSystem has the control of timer, Rendering Frame Rate, Logic Frame Rate. <br>
 * If you want to use it, you need to call to Init() after CRM32Pro.Init(). <br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it.  <br>
 * - Created on 28 September 2002
 * - Last modified on 6 May 2006*/
// ---------------------------------------------------------------------------
//! @{
#define TIMER_INIT   0  //!< Used with Init(). It always initializes the timer system. 
#define TIMER_RESET  1  //!< Used with Init(). If it was already initialized, it will cause a reset of the timer system holding desired rates.

//! ITimeSystem
/*! Time system interface class.*/
class DllExport CRM32Pro_ITimeSystem
   {
	   friend class CRM32Pro_Main;
    public:
		// -Constructor-
		CRM32Pro_ITimeSystem(); 
		// -Destructor-
		~CRM32Pro_ITimeSystem(); 
		// -Initialize timer system-
		void Init(int mode=TIMER_INIT);  
		// -Set desired Rendering and Logic Frame Rates-
		void SetRate(unsigned int r, unsigned int l);
		// -Print a lot of useful information about cursor interface-
		void Info();
		// -Get desired Logic Frame Rate-
		int GetDesiredLFR();
		// -Get desired Rendering Frame Rate-
		int GetDesiredRFR();
		// -Get current Rendering Frame Rate (in real time)-
		unsigned int GetCurrentRFR();
		// -Get current Logic Frame Rate (in real time)-
		unsigned int GetCurrentLFR();
		// -Get average of Rendering Frame Rate-
		float GetRFR();
		// -Get average of Rendering Frame Rate-
		float GetLFR();
		// -Get total Rendered frames until now-
		unsigned int GetRenderedFrames();
		// -Get total Logic frames until now-
		unsigned int GetLogicFrames();
		// -Get execution time (in seconds)-
		float GetSeconds();
		// -Get current time (in ticks)-
		unsigned int GetTime();
   private:
	   // -Private members used internally by CRM32Pro.Update()-
	   void Update(); 
	   void IncRF();
	   void IncLF();
	   class cInternalTimer *IInternal;
   };
//! @}


// ---------------------------------------------------------------------------
/** @defgroup MODULE12 MODULE 12: CSprite v2.70, sprite engine class.
 * CSprite support all stuff related to manage and draw sprites: <br>
 * sprite of any size, each animation with its features, each frame with its features, movement and auto-animation. <br>
 * It supports special features: alpha per surface, colorkey and alpha per pixel.<br>
 * We advice to you to use EditorDPF to modify/add/delete sprites and its features.<br>
 * - Created on 15 September 2001
 * - Last modified on 11 May 2006*/
// ---------------------------------------------------------------------------
//! @{

   // Sprite states
   // It used 16bit, high byte set type and low byte set subtype
   // Macro to get type and subtype
   #define SPRSTATE_NORMAL      0x8000 //!< Sprite state: normal     (10000000-00000000) 
   #define SPRSTATE_UP          0x4000 //!< Sprite state: up         (01000000-00000000)
   #define SPRSTATE_DOWN        0x2000 //!< Sprite state: down       (00100000-00000000)
   #define SPRSTATE_LEFT        0x1000 //!< Sprite state: left       (00010000-00000000)
   #define SPRSTATE_RIGHT       0x0800 //!< Sprite state: right      (00001000-00000000)
   #define SPRSTATE_UPLEFT      0x0400 //!< Sprite state: up-left    (00000100-00000000)
   #define SPRSTATE_UPRIGHT     0x0200 //!< Sprite state: up-right   (00000010-00000000)
   #define SPRSTATE_DOWNLEFT    0x0100 //!< Sprite state: down-left  (00000001-00000000)
   #define SPRSTATE_DOWNRIGHT   0xC000 //!< Sprite state: down-right (11000000-00000000)

   #define GetSpriteState(x)    (x & ~0x00FF) //!< Macro to get sprite state type. See above SPRSTATE_xx
   #define GetSpriteSubState(x) (x & ~0xFF00) //!< Macro to get sprite substate type. Defined by user.

   #define SPRANIM_LOOP       2 //!< Animation type: loop
   #define SPRANIM_PINGPONG   4 //!< Animation type: ping-pong
   #define SPRANIM_ONESHOT    8 //!< Animation type: one shot
   
   //! CSprite
   /*! Sprite engine class.*/
   class DllExport CRM32Pro_CSprite
   {
    public:
		// -Constructor-
		CRM32Pro_CSprite(void);   
		// -Destructor-
		~CRM32Pro_CSprite(void);
	
		// -Create a new sprite set from a BMP file-
		int Create(char *spritebmp,char *namespr,int OffX,int OffY);
		// -Create a new sprite set from a given surface-
		int Create(SDL_Surface *surf,char *namespr,int OffX,int OffY);		
		// -Clone a sprite-
        int Clone(CRM32Pro_CSprite *pSpr);
		// -Turn off/on auto background restore-
        void AutoRestore(char value);
		// -Set a colorkey using RGB values-
		void SetColorKey(char r,char g,char b);		
		// -Set a colorkey using packed integer-
		// Note: 0 turns off the colorkey
		void SetColorKey(int CKey);
		// -Set alpha per surface-
		void SetAlpha(int shade);
		// -Set animation factor speed-
		void SetAnimFactor(float fRs);
        // -Get surface-
        SDL_Surface *GetSurface();
		// -Set position-
		void SetPosition(int x, int y);
		// -Move to a new position-
		void MoveTo(int x,int y);
		// -Save a sprite to DPF-		
		unsigned char Save(char *fileDPF,char *typeblock="SPR");
		// -Load a sprite-		
		int Load(char *fileDPF,char *namespr,char *typeblock="SPR");
		// -Get X position-
		int GetPosX();
		// -Get Y position-
		int GetPosY();
		// -Draw sprite-
		int Draw(SDL_Surface *dump=NULL);		
		// -Check collision with another sprite-
		int Collision(CRM32Pro_CSprite *spr,short spr_x=-1,short spr_y=-1,short this_x=-1,short this_y=-1,unsigned char debug=0);
		// -Check collision with a surface-
		int Collision(SDL_Surface *surf,SDL_Rect *rect, short this_x=-1,short this_y=-1,unsigned char debug=0);
		// -Print a lot of useful info-
		void Info();
		// -Pause animation-
		void Pause();
		// -Resume animation-
		void Resume();
		// -Is finished the animation?-
		unsigned char IsFinished();
		// -Select an animation-
		unsigned char SelectAnim(int status);
		// -Select a frame-
		unsigned char SelectFrame(int iFrame);
		// -Set anim properties-
		unsigned char SetAnim(int iAnim,int iType,int iStatus);
		// -Set frame properties-
		unsigned char SetFrame(int iAnim,int iFrame,int iMs);
	
		// -Get OffX and OffY (used by DPF-Editor)-
        void GetOffset(int *,int*);
		// -Get anim properties (used by DPF-Editor)-
		void GetAnim(int,unsigned short *,unsigned short *,int *);
		// -Get frame properties (used by DPF-Editor)-
		int GetAnimFrame(int,int);

    private:
		class cInternalSprite *IInternal;
   };
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE13 MODULE 13: INetwork v3.00, network interface
 * INetwork manages TCP/IP client and server architecture. <br>
 * It has support for 16 clients, login password and powerfull error system. <br>
 * With TCP: auto ping each seconds. Detect DN unhandled and has a DN reception queue.<br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it.  <br>
 * - Created on 23 March 2004
 * - Last modified on 20 December 2005*/
// ---------------------------------------------------------------------------
//! @{
   
   #define INETWORK_NEWCLIENT    4  //!< System Datanet: new client signal. It sends its name.
   #define INETWORK_QUITCLIENT   8  //!< System Datanet: quit client signal. It sends its name.
   #define INETWORK_CLOSE       16  //!< System Datanet: close signal.
   #define INETWORK_PING        40  //!< System Datanet: automatic ping to check if the client-server connection is up.
   #define INETWORK_ERROR       48  //!< System Datanet: error signal or connection lost.
   #define INETWORK_DATA        64  //!< User Datanet: data user signal. It sends the data. 

   //! INetwork 
   /*! Network interface.*/
   class DllExport CRM32Pro_INetwork
   {
   public:
	   // -Constructor-
	   CRM32Pro_INetwork(void);	   
	   // -Destructor-
	   ~CRM32Pro_INetwork(void); 
	   // -Initialize system-
	   unsigned char Init(char m_log); 
	   // -Close system-
	   void Quit();
	   // -Create a server- 
	   unsigned char CreateServer(unsigned short port,unsigned int passwd,unsigned char dedicated);

   	   // -Connect to server-
	   unsigned char ConnectTo(char *host,unsigned short port,char *user,unsigned int passwd); 
	   // -Send data to clients-
	   unsigned char SendData(char *buff,int size); 
	   // -Received data of others clients-
	   unsigned char ReceiveData(char **buf,unsigned int *size);
	   // -Free previous received data-
	   void FreeData(char *buf);
	   // Query to close server (and all clients)
	   unsigned char QueryKillServer(); 
	   // Query to kill this client
	   unsigned char QueryKillClient();  
	   // Query to list all clients
	   unsigned char QueryListClients();    
   };
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE14 MODULE 14: IVideo v2.20, player video interface
 * IVideo allow to play MPEG-1 video and music stream. <br>
 * It supports smoothing and deblocking video stream, scaled, centered or defined position video play back,<br>
 * set any of the FXSCREEN_xx (see IScreenFX for further information) and set a function call each frame.<br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it.  <br>
 * - Created on 30 August 2001
 * - Last modified on 11 January 2006*/
// ---------------------------------------------------------------------------
//! @{

#define VIDEO_FILTER_NULL    0 //!< Switch off any kind of filter (only MPEG)
#define VIDEO_FILTER_SMOOTH  1 //!< Switch on smooth video stream (only MPEG)
#define VIDEO_FILTER_DEBLOCK 2 //!< Switch on deblocking video stream (only MPEG)
#define VIDEO_PLAY_CENTER   -1 //!< Dump video stream centered on screen (only MPEG). Read more on SetPosition().

//! IVideo
/*! Player MPEG interface.*/
class DllExport CRM32Pro_IVideo
{
    public:
		// -Constructor-
		CRM32Pro_IVideo();
		// -Destructor-
		~CRM32Pro_IVideo();
		// -Play a MPEG-1-
		char PlayMPEG(char *file,char bSound=1, char bFilter=VIDEO_FILTER_NULL);  
		// -Set a scaled size to play the video-
		void SetScale(int width,int height);
		// -Set position to play the video-
		void SetPosition(int x,int y);
		// -Set special fx for video-
		void SetFX(int);
		// -Set a function for each frame update-
		void SetFunction(void (*MyFunction)(int kPressed));
};
//! @}

// ---------------------------------------------------------------------------
/** @defgroup MODULE15 MODULE 15: ISoundFX v4.00, sound,music and FX effects interface
 * ISoundFX allow to play sound and music tracks. Basically, it is a wrapper built on top of SDL_mixer <br>
 * with some changes and improvements. It supports XM,S3M,MOD,IT,WAV,VOC,AIFF and Vorbis OGG. <br>
 * We recommend you to use EditorDPF to add/delete sound and music tracks. <br>
 * If you want to use it, you need to call Init() after CRM32Pro.Init(). <br>
 * CRM32Pro.Init() builds this interface and CRM32Pro.Quit() removes it.  <br>
 * - Created on 3 August 2001
 * - Last modified on 8 October 2005*/
// ---------------------------------------------------------------------------
//! @{
#define ISOUNDFX_CHANNELS 8
#define ISOUNDFX_DEFAULT_FREQUENCY	22050
#if SDL_BYTEORDER == SDL_LIL_ENDIAN
 #define ISOUNDFX_DEFAULT_FORMAT	AUDIO_S16LSB
#else
 #define ISOUNDFX_DEFAULT_FORMAT	AUDIO_S16MSB
#endif
#define ISOUNDFX_DEFAULT_CHANNELS	2
#define ISOUNDFX_MAX_VOLUME		128	

//! Audio type struct
typedef struct sAudioType
{
	char type[5];     //!< Wav Aiff Ogg Voc S3M XM Mod IT
	Uint8 channels;   //!< 1->mono 2->stereo
	Uint16 format;    //!< 8bit or 16bits	
	Uint32 freq;      //!< Frequency (11025,22050 or 44100)
	Uint32 size;      //!< Size (bytes)
} sAudioType;

//! ISoundFX
/*! Sound,music and FX effects interface.*/
class DllExport CRM32Pro_ISoundFX
{   
    public:
		// -Constructor-
		CRM32Pro_ISoundFX();
		// -Destructor-
		~CRM32Pro_ISoundFX();

        // -Initialize sound system-
		unsigned char Init(int frequency, unsigned short format, int channels,int chunksize);
		// -Try to initialize sound system according to CRM32Pro.Config-
		unsigned char Init();
        
		//! Turn off sound output
		void NoInit();
		//! Close sound system
		void Quit(void); 
		//! Was sound system activated?
		/*! \return 0 if is not active or 1 if is active*/
		int Initialized();

		// -Query sound system features-
	    void QuerySpec(int *freq,unsigned short *format,int *ch);
		
		//! Dinamic change of channels
		void AllocateChannels(int nch);

		// -IO operations with music-
		int MusicLoad(const char *f);		
		int MusicLoad(char *fileDPF,char *musname);		        
		unsigned char MusicImport(char *fileDPF,char *namemus,char *filemus);
        unsigned char MusicInfo(char *fileDPF,char *namemus,sAudioType *mustype);
		void MusicFree(int hndMusic);

		// -IO operations with sound-
		int SoundLoad(const char *f);
		int SoundLoad(char *fileDPF,char *namesnd);				
		unsigned char SoundImport(char *fileDPF,char *namesnd,char *filesnd);
		unsigned char SoundInfo(char *fileDPF,char *namesnd,sAudioType *sndtype); 				
        void SoundFree(int hndSound);		

		// -Exporting audio-
		unsigned char Export(char *fileDPF,char *namesnd,char m,char *s=NULL); 

        // -Playing functions-
		void SoundPlay(int ch,int hndSound,int loops);
        int MusicPlay(int hndMusic,int loops); 

		//! Channel stop 
		/*! \param ch channel to stop*/
		void ChannelStop(int ch);
		//! Music stop
		void MusicStop(void);
		//! Channel pause 
		/*! \param ch channel to pause*/
        void ChannelPause(int ch);
		//! Channel resume 
		/*! \param ch channel to resume*/
		void ChannelResume(int ch);
        //! Query if a channel is paused 
		/*! \param ch channel to query its state
		\return 1 means a paused channel,otherwise is playing*/
		int ChannelIsPaused(int ch);
		//! Pause music
		void MusicPause(void);
		//! Resume music
		void MusicResume(void);
		//! Rewind music
		void MusicRewind(void);
        //! Query if music is paused 
		/*! \return 1 means a paused music,otherwise is playing*/  
        int MusicIsPaused(void);

		// -Volume control-
		void ChannelVolume(int ch,int vol);
		void SoundVolume(int hndSound,int vol);
		void MusicVolume(int vol);

		// -Fades In and Out-
		int ChannelFadeOut(int ch,int ms);
		int MusicFadeOut(int ms);
		int ChannelFadeIn(int ch, int hndSound,int loops,int ms);
		int MusicFadeIn(int hndMusic,int loops,int ms);

        // -Check playback-
        int IsPlaying(void);
		int IsPlaying(int ch);	
private:
		int IsSound;
};
//! @}

// ----------------External public interfaces declarations--------------------
extern CRM32Pro_Main         DllHandle   CRM32Pro;
extern CRM32Pro_ILogSystem   DllHandle   ILogSystem;
extern CRM32Pro_IStuffDPF    DllHandle   *IStuffDPF;
extern CRM32Pro_IImage       DllHandle   *IImage;
extern CRM32Pro_ICursor      DllHandle   *ICursor;
extern CRM32Pro_IPrimitives  DllHandle   *IPrimitives; 
extern CRM32Pro_IButton      DllHandle   *IButton; 
extern CRM32Pro_IScreenFX    DllHandle   *IScreenFX;
extern CRM32Pro_ITimeSystem  DllHandle   *ITimeSystem;
extern CRM32Pro_INetwork     DllHandle   *INetwork;
extern CRM32Pro_IVideo       DllHandle   *IVideo;
extern CRM32Pro_ISoundFX     DllHandle   *ISoundFX;

// -------------------------END OF CRM32Pro HEADER ----------------------------
#endif
