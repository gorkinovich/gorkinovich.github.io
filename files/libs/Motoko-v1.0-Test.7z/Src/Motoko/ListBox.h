//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_LISTBOX_H_
#define _MOTOKO_LISTBOX_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "Box.h"
#include "ITextControl.h"
#include "VScrollBar.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Struct with information of an item.
	//--------------------------------------------------------------------------------------
	struct ListBoxItem
	{
		string Text;      //!< Text of the item.
		Uint32 BackColor; //!< Back color of the item.
	};

	//--------------------------------------------------------------------------------------
	/// Class that represents a generic list box.
	//--------------------------------------------------------------------------------------
	class DLLAPI ListBox : public Box, public ITextControl
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			template class DLLAPI std::allocator<ListBoxItem *>;
			template class DLLAPI std::vector<ListBoxItem *, std::allocator<ListBoxItem *> >;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			vector<ListBoxItem *> List;
			bool MultiSelect;

			list<int> SelectedItems;

			Uint32 SelColor;


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			VScrollBar * VBar;

			SDL_Rect TextRect;

			int FirstSelect;

			int GetItemPressed (Uint16 x, Uint16 y);

			void UpdateValues (void);

			void DrawList (void);


		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ListBox ();
			ListBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					  Uint32 backcolor, const char * text, CRM32Pro_CFont * font,
					  ControlSkin * appearance = NULL, SDL_Surface * picture = NULL,
					  SDL_Surface * mousepointer = NULL, AlignmentStyle alignment = Left, 
					  bool transparency = false, Uint32 selcolor = 0x00000000,
					  bool multisel = false, bool enable = true, bool visible = true);
			ListBox (const ListBox & obj);
			virtual ListBox & operator = (const ListBox & obj);
			~ListBox ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual ListBox & CopyFrom (const ListBox & obj);

			virtual void UpdateRects (void);

			
			bool AddListItem (string text);
			bool AddListItem (string text, Uint32 color);
			void DelListItem (int i);
			
			/// Erase all the items in the list.
			inline void ClearListItems (void) { List.erase(List.begin(), List.end()); }


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get an item of the list.
			inline ListBoxItem * GetListItem (int i) { return List[i]; }

			/// Get if the control is multiselect.
			inline bool GetMultiSelect (void) { return MultiSelect; }

			/// Get the selected items of the list.
			inline list<int> * GetSelectedItems (void) { return &SelectedItems; }

			/// Get the color of selection of the list.
			inline Uint32 GetSelColor (void) { return SelColor; }

			/// Get the VBar of the control.
			inline VScrollBar * GetVBar (void) { return VBar; }
			

			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set an item of the list.
			virtual inline void SetListItem (int i, ListBoxItem * val)
			{
				List[i] = val;
				UpdateValues();
			}

			/// Set an item of the list.
			virtual inline void SetListItem (int i, string text, Uint32 color)
			{
				List[i]->Text      = text;
				List[i]->BackColor = color;
				UpdateValues();
			}

			/// Set an item of the list.
			virtual inline void SetListItem (int i, string text)
			{
				List[i]->Text      = text;
				List[i]->BackColor = BackColor;
				UpdateValues();
			}
			
			/// Set if the control is multiselect.
			virtual inline void SetMultiSelect (bool val) { MultiSelect = val; }

			/// Set no selected items of the list.
			virtual inline void SetNoSelectedItems (void) { SelectedItems.clear(); }

			/// Set the color of selection of the list.
			virtual inline void SetSelColor (Uint32 val) { SelColor = val; }

			/// Set the text of the control.
			virtual inline void SetText (const char * val) { UpdateValues(); }

			/// Add text to the control.
			virtual inline void AddText (const char * val) { UpdateValues(); }

			/// Set the text of the control.
			virtual inline void SetText (char val) { UpdateValues(); }

			/// Add text to the control.
			virtual inline void AddText (char val) { UpdateValues(); }

			/// Set the name of the control.
			virtual inline void SetName (const char * val)
			{
				Name = val;

				string aux;

				aux = Name + "_VBar"; VBar->SetName(aux.c_str());
			}
			
			/// Set the back style of the control.
			virtual inline void SetBackStyle (ControlBackStyle val)
			{
				BackStyle = val;
				VBar->SetBackStyle(val);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 box, Uint32 scrolls)
			{
				BackColor = box;
				VBar->SetBackColor(scrolls);
			}

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * box, ControlSkin * vscroll, ControlSkin * button)
			{
				Appearance = box;
				VBar->SetAppearance(vscroll, button);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 val) { BackColor = val; }

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * val) { Appearance = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// ListBox.h
//******************************************************************************************