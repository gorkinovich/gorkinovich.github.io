//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_DIALOG_H_
#define _MOTOKO_DIALOG_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Container.h"
#include "ITextControl.h"
#include "Button.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define MAX_DIALOG_RECTS    12
#define CENTER1_DIALOG_RECT  3
#define CENTER2_DIALOG_RECT  7
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic dialog.
	//--------------------------------------------------------------------------------------
	class DLLAPI Dialog : public Container, public ITextControl
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			Uint32 TitleColor;

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			SDL_Rect Rects[MAX_DIALOG_RECTS];

			Button * Close;

			bool Pressed;

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			Dialog ();
			Dialog (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					Uint32 backcolor, Uint32 titlecolor, const char * text,
					CRM32Pro_CFont * font, ControlSkin * appearance = NULL,
					SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
					AlignmentStyle alignment = Left, bool transparency = false,
					bool enable = true, bool visible = true);
			Dialog (const Dialog & obj);
			virtual Dialog & operator = (const Dialog & obj);
			~Dialog ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual Dialog & CopyFrom (const Dialog & obj);

			virtual void UpdateRects (void);
			

			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get the title color of the control.
			inline Uint32 GetTitleColor (void) { return TitleColor; }

			/// Get the close button of the control.
			inline Button * GetClose (void) { return Close; }


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the coordinate X of the control.
			virtual inline void SetX (Sint16 val) { Container::SetX(val); UpdateRects(); }

			/// Set the coordinate Y of the control.
			virtual inline void SetY (Sint16 val) { Container::SetY(val); UpdateRects(); }

			/// Set the width of the control.
			virtual inline void SetWidth (Uint16 val) { Container::SetWidth(val); UpdateRects(); }

			/// Set the height of the control.
			virtual inline void SetHeight (Uint16 val) { Container::SetHeight(val); UpdateRects(); }

			/// Set the rect of the control.
			virtual inline void SetRect (SDL_Rect & val) { Container::SetRect(val); UpdateRects(); }

			/// Set the title color of the control.
			virtual inline void SetTitleColor (Uint32 val) { TitleColor = val; }

			/// Set the name of the control.
			virtual inline void SetName (const char * val)
			{
				Name = val;

				string aux;

				aux = Name + "_Close"; Close->SetName(aux.c_str());
			}
			
			/// Set the back style of the control.
			virtual inline void SetBackStyle (ControlBackStyle val)
			{
				BackStyle = val;
				Close->SetBackStyle(val);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 dialog, Uint32 button)
			{
				BackColor = dialog;
				Close->SetBackColor(button);
			}

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * dialog, ControlSkin * button)
			{
				Appearance = dialog;
				Close->SetAppearance(button);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 val) { BackColor = val; }

			/// Set the appearance of the control.
			virtual inline void SetAppearance (ControlSkin * val) { Appearance = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Dialog.h
//******************************************************************************************