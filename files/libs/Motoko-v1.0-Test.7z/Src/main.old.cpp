//******************************************************************************************
//#pragma comment(linker, "/subsystem:windows /entry:main")
//******************************************************************************************
#include "Motoko/Motoko.h"
using namespace Motoko;
//******************************************************************************************
#define APP_NAME "Cutre-Civ"
//******************************************************************************************
Application * AppCutreCiv;
//------------------------------------------------------------------------------------------
PictureBox * Caja01;
PictureBox * Caja02;
LabelBox   * Caja03;
Button     * Caja04;
VScrollBar * VBar;
HScrollBar * HBar;
TextBox    * Texto;
//******************************************************************************************
void Ayuda (void)
{
	cout << "//------------------------------------------------------------" << endl;
	cout << "// Ayuda rapida de los controles de la prueba." << endl;
	cout << "//------------------------------------------------------------" << endl << endl;

	cout << "Escape:        Salir." << endl;
	cout << "F1:            Esta ayuda." << endl;
	cout << "Flechas:       Mover la Caja02." << endl;
	cout << "1, 2:          Cambian el RenderBack de Application." << endl;
	cout << "3, 4:          Oculta/Muestra los controles del Panel01." << endl;
	cout << "5:             Muestra el control activo." << endl;
	cout << "6, 7, 8:       Cambia la apariencia de Caja03." << endl;
	cout << "z, x, c:       Cambia el alineamiento del texto de Caja03." << endl;
	cout << "v, b:          Cambia la transparencia de la Caja03." << endl;
	cout << "9, 0:          Cambia la apariencia de Caja04." << endl;
	cout << "q, w, a, s, d: Cambia el arrow de Caja04." << endl;
	cout << "r, t, f, g:    Cambia las scrollbars de Texto." << endl;
	cout << "Espacio:       Muestra los cuadros de dialogo." << endl << endl;

	cout << "Caja01, Caja02: PictureBox." << endl;
	cout << "Caja03:         LabelBox." << endl;
	cout << "Caja04:         Button." << endl;
	cout << "VBar:           VScrollBar." << endl;
	cout << "HBar:           HScrollBar." << endl;
	cout << "Texto:          TextBox." << endl;
}
//******************************************************************************************
bool TeclaPulsada (void * c, SDL_KeyboardEvent & event)
{
	cout << "Tecla pulsada: " << (int) event.keysym.scancode << "\t"
		<< "Modificadores: " << (int) event.keysym.mod << endl;
	
	if(event.keysym.sym == Teclas::TECLA_F1) Ayuda();

			
	if(CRM32Pro.keystate[Teclas::TECLA_6]) Caja03->SetBackStyle(UseAppearance);
	if(CRM32Pro.keystate[Teclas::TECLA_7]) Caja03->SetBackStyle(UseBackColor);
	if(CRM32Pro.keystate[Teclas::TECLA_8]) Caja03->SetBackStyle(UsePicture);
	if(CRM32Pro.keystate[Teclas::TECLA_Z]) Caja03->SetAlignment(Left);
	if(CRM32Pro.keystate[Teclas::TECLA_X]) Caja03->SetAlignment(Center);
	if(CRM32Pro.keystate[Teclas::TECLA_C]) Caja03->SetAlignment(Right);
	if(CRM32Pro.keystate[Teclas::TECLA_V]) Caja03->SetTransparency(true);
	if(CRM32Pro.keystate[Teclas::TECLA_B]) Caja03->SetTransparency(false);

	
	if(CRM32Pro.keystate[Teclas::TECLA_9]) Caja04->SetBackStyle(UseAppearance);
	if(CRM32Pro.keystate[Teclas::TECLA_0]) Caja04->SetBackStyle(UsePicture);
	if(CRM32Pro.keystate[Teclas::TECLA_Q]) Caja04->SetArrow(NoneArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_W]) Caja04->SetArrow(UpArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_S]) Caja04->SetArrow(DownArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_A]) Caja04->SetArrow(LeftArrow);
	if(CRM32Pro.keystate[Teclas::TECLA_D]) Caja04->SetArrow(RightArrow);

	
	if(CRM32Pro.keystate[Teclas::TECLA_R]) Texto->SetScrollBars(NoneScrollBars);
	if(CRM32Pro.keystate[Teclas::TECLA_T]) Texto->SetScrollBars(BothScrollBars);
	if(CRM32Pro.keystate[Teclas::TECLA_F]) Texto->SetScrollBars(OnlyHScrollBars);
	if(CRM32Pro.keystate[Teclas::TECLA_G]) Texto->SetScrollBars(OnlyVScrollBars);

	if(CRM32Pro.keystate[Teclas::TECLA_SUPRIMIR]) Texto->SetText("");

	return true;
}
//******************************************************************************************
void DobleClick (void * c)
{
	Control * control = (Control *) c;

	cout << control->GetName() << " -> DoubleClick" << endl;
}
//******************************************************************************************
void Caja_ButtonDown (void * c, SDL_MouseButtonEvent & event)
{
	Control * control = (Control *) c;
	char buffer[255];

	switch(event.button)
	{
	case SDL_BUTTON_LEFT:
		if(AppCutreCiv->GetActiveControl() != control) control->GetFocus();
		sprintf(buffer, "io.write(\"%s %s pulsado BI...\\n\")", control->GetType(), control->GetName());
		break;
		
	case SDL_BUTTON_MIDDLE:
		sprintf(buffer, "io.write(\"%s %s pulsado BC...\\n\")", control->GetType(), control->GetName());
		break;
		
	case SDL_BUTTON_RIGHT:
		sprintf(buffer, "io.write(\"%s %s pulsado BD...\\n\")", control->GetType(), control->GetName());
		break;

	case SDL_BUTTON_WHEELUP:
		sprintf(buffer, "io.write(\"%s %s pulsado WU...\\n\")", control->GetType(), control->GetName());
		break;

	case SDL_BUTTON_WHEELDOWN:
		sprintf(buffer, "io.write(\"%s %s pulsado WD...\\n\")", control->GetType(), control->GetName());
		break;
	}

	Lua::ExecString(buffer);
}
//******************************************************************************************
void Caja_ButtonUp (void * c, SDL_MouseButtonEvent & event)
{
	Control * control = (Control *) c;
	char buffer[255];

	switch(event.button)
	{
	case SDL_BUTTON_LEFT:
		sprintf(buffer, "io.write(\"%s %s despulsado BI...\\n\")", control->GetType(), control->GetName());
		break;
		
	case SDL_BUTTON_MIDDLE:
		sprintf(buffer, "io.write(\"%s %s despulsado BC...\\n\")", control->GetType(), control->GetName());
		break;
		
	case SDL_BUTTON_RIGHT:
		sprintf(buffer, "io.write(\"%s %s despulsado BD...\\n\")", control->GetType(), control->GetName());
		break;

	case SDL_BUTTON_WHEELUP:
		sprintf(buffer, "io.write(\"%s %s despulsado WU...\\n\")", control->GetType(), control->GetName());
		break;

	case SDL_BUTTON_WHEELDOWN:
		sprintf(buffer, "io.write(\"%s %s despulsado WD...\\n\")", control->GetType(), control->GetName());
		break;
	}

	Lua::ExecString(buffer);
}
//******************************************************************************************
int main (int argc, char* argv[])
{
	//--------------------------------------------------------------------------------------
	// Inicializaci�n de la GUI.
	//--------------------------------------------------------------------------------------
	AppCutreCiv = Application::GetInstance();

	CRM32Pro.Config.VideoRenderer = RENDER_DEFAULT;
	CRM32Pro.Config.VideoAccel    = ACCEL_HARDSPEED;

	int error = AppCutreCiv->Init(APP_NAME, 800, 600);
	if(error != 0)
	{
		cout << "No se pudo inicializar el sistema principal..." << endl;
		return 1;
	}

	//--------------------------------------------------------------------------------------
	// Carga de recursos.
	//--------------------------------------------------------------------------------------
	CRM32Pro_CFont * Font = AppCutreCiv->Resources.LoadFont("InputFont", "gfx.dpf"); // InputFont, InfoFont, MyFont
	if(Font == NULL) cout << "Error al cargar la fuente..." << endl;


	SDL_Surface * cursor  = AppCutreCiv->Resources.LoadTexture("cursor", "Data.dpf");
	SDL_Surface * cursor2 = AppCutreCiv->Resources.LoadTexture("cursor2", "Data.dpf");


	if(AppCutreCiv->Skins.AddTheme("Default.dpf"))
		cout << "No se logra cargar el tema..." << endl;

	ControlSkin * CSBox = AppCutreCiv->Skins.GetSkin("Default", "Box");
	if(CSBox == NULL) cout << "No se encuentra el skin del box..." << endl;

	ControlSkin * CSButton = AppCutreCiv->Skins.GetSkin("Default", "Button");
	if(CSButton == NULL) cout << "No se encuentra el skin del button..." << endl;

	ControlSkin * CSVSB = AppCutreCiv->Skins.GetSkin("Default", "VScroll");
	if(CSVSB == NULL) cout << "No se encuentra el skin del vscroll..." << endl;

	ControlSkin * CSHSB = AppCutreCiv->Skins.GetSkin("Default", "HScroll");
	if(CSHSB == NULL) cout << "No se encuentra el skin del vscroll..." << endl;

	ControlSkin * CSCheck = AppCutreCiv->Skins.GetSkin("Default", "Check");
	if(CSCheck == NULL) cout << "No se encuentra el skin del check..." << endl;

	ControlSkin * CSWin = AppCutreCiv->Skins.GetSkin("Default", "Dialog");
	if(CSWin == NULL) cout << "No se encuentra el skin del dialog..." << endl;


	SDL_Surface * Bicho = AppCutreCiv->Resources.LoadTexture("bicho", "Data.dpf");
	if(Bicho == NULL) cout << "No se pudo cargar el bicho..." << endl;

	
	SDL_Surface * Boton01 = AppCutreCiv->Resources.LoadTexture("boton01", "Data.dpf");
	SDL_Surface * Boton02 = AppCutreCiv->Resources.LoadTexture("boton02", "Data.dpf");
	SDL_Surface * Boton03 = AppCutreCiv->Resources.LoadTexture("boton03", "Data.dpf");


	SDL_Surface * Icono = AppCutreCiv->SetIcon("icon.bmp");

	//--------------------------------------------------------------------------------------
	// Cambiando parametros de la aplicaci�n.
	//--------------------------------------------------------------------------------------
	AppCutreCiv->SetMousePointer(cursor);
	AppCutreCiv->SetTitle("Jarl!!!");
	AppCutreCiv->SetBackColor(0x00C0C0C0);
	AppCutreCiv->SetKeyDown(TeclaPulsada);

	//--------------------------------------------------------------------------------------
	// PictureBox Caja01.
	//--------------------------------------------------------------------------------------
	Caja01 = GetNewPictureBox("Caja01", 50, 50, 50, 50, UseAppearance, CSBox, 0x000000FF, Bicho);

	Caja01->SetMousePointer(NULL);
	Caja01->SetTransparency(true);

	Caja01->SetMouseButtonDown(Caja_ButtonDown);
	Caja01->SetMouseButtonUp(Caja_ButtonUp);
	Caja01->SetDoubleClick(DobleClick);

	//--------------------------------------------------------------------------------------
	// PictureBox Caja02.
	//--------------------------------------------------------------------------------------
	Caja02 = GetNewPictureBox("Caja02", 250, 50, 68, 100, UseAppearance, CSBox, 0x000000FF, Bicho);
	
	Caja02->SetMousePointer(cursor2);
	
	Caja02->SetMouseButtonDown(Caja_ButtonDown);
	Caja02->SetMouseButtonUp(Caja_ButtonUp);
	Caja02->SetDoubleClick(DobleClick);

	//--------------------------------------------------------------------------------------
	// LabelBox Caja03.
	//--------------------------------------------------------------------------------------
	Caja03 = GetNewLabelBox("Caja03", 10, 450, 400, 130, UseAppearance, CSBox, 0x00CCFFFF, Font);

	Caja03->SetMousePointer(cursor2);
	Caja03->SetPicture(Bicho);

	Caja03->SetText("ABCDEFGHIJKLMNOPQRSTUVWXYZ\n");
	Caja03->AddText("abcdefghijklmnopqrstuvwxyz\n");
	Caja03->AddText("0123456789\n");
	Caja03->AddText(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~\n");
	Caja03->AddText("Hola mundo cruel maldito!");
	
	Caja03->SetMouseButtonDown(Caja_ButtonDown);
	Caja03->SetMouseButtonUp(Caja_ButtonUp);

	//--------------------------------------------------------------------------------------
	// LabelBox Caja04.
	//--------------------------------------------------------------------------------------
	Caja04 = GetNewButton("Caja04", 50, 300, 100, 50, UseAppearance, CSButton, 0x00C0C0C0, Font, "Hola");

	Caja04->SetMouseButtonDown(Caja_ButtonDown);
	Caja04->SetMouseButtonUp(Caja_ButtonUp);
	
	Caja04->SetPicture(Boton01);
	Caja04->SetPictureOver(Boton02);
	Caja04->SetPictureDown(Boton03);
	
	//--------------------------------------------------------------------------------------
	// VScrollBar VBar.
	//--------------------------------------------------------------------------------------
	VBar = GetNewVScrollBar("VBar", 300, 200, 20, 200, UseAppearance, CSVSB, CSButton,
							0x00C0C0C0, 0, 40, 0, 1, 10);
	
	//--------------------------------------------------------------------------------------
	// HScrollBar HBar.
	//--------------------------------------------------------------------------------------
	HBar = GetNewHScrollBar("HBar", 50, 400, 200, 20, UseAppearance, CSHSB, CSButton,
							0x00C0C0C0, 0, 74, 0, 1, 10);

	//--------------------------------------------------------------------------------------
	// TextBox Texto.
	//--------------------------------------------------------------------------------------
	Texto = GetNewTextBox("Texto", 400, 10, 390, 130, UseAppearance, CSBox, CSVSB, CSHSB,
						  CSButton, 0x00FFFFFF, 0x00C0C0C0, Font, true, false, BothScrollBars);

	Texto->SetText("Hola mundo cruel maldito jarl jarl jarl jarl jarl");
	Texto->AddText("\n\n\n\nJe je je jej\n\n\n\n");
	Texto->AddText("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!");

	//--------------------------------------------------------------------------------------
	// ListBox Lista.
	//--------------------------------------------------------------------------------------
	ListBox * Lista = GetNewListBox("Lista", 400, 150, 390, 130, UseAppearance, CSBox, CSVSB,
									CSButton, 0x00FFFFFF, 0x00C0C0C0, 0x00000000, Font, true);
	
	Lista->AddListItem("Hola", 0x0011BB11);
	Lista->AddListItem("Adios", 0x00999999);
	Lista->AddListItem("Juan", 0x0011BB11);
	Lista->AddListItem("Pepe", 0x00999999);
	Lista->AddListItem("Jose", 0x0011BB11);
	Lista->AddListItem("Hamperdine", 0x00999999);
	Lista->AddListItem("Lalalalalalalalalalalalalalalalalalalalalalalalalalalalala", 0x0011BB11);
	Lista->AddListItem("Yukino", 0x00999999);
	Lista->AddListItem("Yoko", 0x0011BB11);
	Lista->AddListItem("Kaori", 0x00999999);

	//--------------------------------------------------------------------------------------
	// ControlListBox CLista.
	//--------------------------------------------------------------------------------------
	ControlListBox * CLista = GetNewControlListBox("Lista", 420, 450, 360, 130, UseAppearance,
												   CSBox, CSVSB, CSButton, 0x00FFFFFF, 0x00C0C0C0,
												   0x00FF0000, true);
	CLista->SetMousePointer(cursor2);

	CLista->SetMouseButtonDown(Caja_ButtonDown);
	CLista->SetMouseButtonUp(Caja_ButtonUp);

	
	PictureBox * Caja101 = new PictureBox();
	Caja101->CopyFrom(*Caja01);
	Caja101->SetBackStyle(UsePicture);
	Caja101->SetTransparency(false);
	Caja101->SetAppearance(NULL);

	if(CLista->AddControl(Caja101))
		cout << "Error addcontrol Caja101..." << endl;
	
	PictureBox * Caja102 = new PictureBox[20];

	for(int k = 0; k < 20; ++k)
	{
		Caja102[k].CopyFrom(*Caja101);
		
		if(CLista->AddControl(&(Caja102[k])))
			cout << "Error addcontrol Caja102..." << endl;
	}

	//--------------------------------------------------------------------------------------
	// ComboBox Combo.
	//--------------------------------------------------------------------------------------
	ComboBox * Combo = GetNewComboBox("Combo", 400, 360, 390, 30, 130, UseAppearance, CSBox,
									  CSVSB, CSButton, 0x00FFFFFF, 0x00C0C0C0, 0x00FFFFFF, Font);

	Combo->AddListItem("Hola");
	Combo->AddListItem("Adios");
	Combo->AddListItem("Juan");
	Combo->AddListItem("Pepe");
	Combo->AddListItem("Jose");
	Combo->AddListItem("Hamperdine");
	Combo->AddListItem("Lalalalalalalalalala");
	Combo->AddListItem("Yukino");
	Combo->AddListItem("Yoko");
	Combo->AddListItem("Kaori");

	Combo->SetText("Hola juan, hola pepito, hola jose, hola david...");

	//--------------------------------------------------------------------------------------
	// ComboBox Combo.
	//--------------------------------------------------------------------------------------
	ComboBox * Combo2 = GetNewComboBox("Combo2", 400, 400, 390, 30, 130, UseAppearance, CSBox,
									   CSVSB, CSButton, 0x00FFFFFF, 0x00C0C0C0, 0x00FFFFFF, Font);

	Combo2->AddListItem("Hola", 0x00AA0000);
	Combo2->AddListItem("Adios", 0x0000AA00);
	Combo2->AddListItem("Juan", 0x000000AA);
	Combo2->AddListItem("Pepe");
	Combo2->AddListItem("Jose");
	Combo2->AddListItem("Hamperdine");
	Combo2->AddListItem("Lalalalalalalalalala");
	Combo2->AddListItem("Yukino");
	Combo2->AddListItem("Yoko");
	Combo2->AddListItem("Kaori");

	//--------------------------------------------------------------------------------------
	// CheckButton Check.
	//--------------------------------------------------------------------------------------
	CheckButton * Check = GetNewCheckButton("Check", 400, 300, 390, 30, UseAppearance, CSCheck,
											0x00C0C0C0, Font, "Esto es un CheckButton");
	
	//--------------------------------------------------------------------------------------
	// Panel Panel01.
	//--------------------------------------------------------------------------------------
	Panel * Panel01 = GetNewPanel("Panel01", 0, 0, 800, 600, NULL, 0x00C0C0C0, true);

	//--------------------------------------------------------------------------------------
	// ComboBox Combo3.
	//--------------------------------------------------------------------------------------
	ComboBox * Combo3 = GetNewComboBox("ComboDialog", 10, 350, 200, 30, 200, UseAppearance, CSBox,
									   CSVSB, CSButton, 0x00FFFFFF, 0x00C0C0C0, 0x00FFFFFF, Font);

	Combo3->AddListItem("Facil");
	Combo3->AddListItem("Normal");
	Combo3->AddListItem("Dificil");

	
	ComboBox * Combo4 = new ComboBox();
	Combo4->CopyFrom(*Combo3);

	//--------------------------------------------------------------------------------------
	// LabelBox Caja05.
	//--------------------------------------------------------------------------------------
	Button * Caja05 = GetNewButton("Caja05", 50, 200, 100, 50, UseAppearance, CSButton, 0x00C0C0C0, Font, "Adios");

	Caja05->SetMouseButtonDown(Caja_ButtonDown);
	Caja05->SetMouseButtonUp(Caja_ButtonUp);
	
	Caja05->SetPicture(Boton01);
	Caja05->SetPictureOver(Boton02);
	Caja05->SetPictureDown(Boton03);

	
	Button * Caja06 = new Button();
	Caja06->CopyFrom(*Caja05);
	
	//--------------------------------------------------------------------------------------
	// Dialog Dialogo.
	//--------------------------------------------------------------------------------------
	Dialog * Dialogo = GetNewDialog("Dialogo", 150, 100, 300, 400, UseAppearance, CSWin,
									CSButton, 0x00000055, 0x00C0C0C0, Font, "Mi cuadro de dialogo");


	Dialog * Dialogo2 = new Dialog();
	Dialogo2->CopyFrom(*Dialogo);
	Dialogo2->SetX(350);
	Dialogo2->SetText("Mi cuadro de dialogo 2");


	if(Dialogo->AddControlRel(Caja05))
		cout << "Error addcontrol Caja05..." << endl;
	
	if(Dialogo2->AddControlRel(Caja06))
		cout << "Error addcontrol Caja06..." << endl;


	if(Dialogo->AddControlRel(Combo3))
		cout << "Error addcontrol Combo3..." << endl;
	
	if(Dialogo2->AddControlRel(Combo4))
		cout << "Error addcontrol Combo4..." << endl;

	//--------------------------------------------------------------------------------------
	// A�adiendo los controles.
	//--------------------------------------------------------------------------------------
	if(Panel01->AddControl(Caja01))
		cout << "Error addcontrol Caja01..." << endl;

	if(Panel01->AddControl(Caja02))
		cout << "Error addcontrol Caja02..." << endl;

	if(Panel01->AddControl(Caja03))
		cout << "Error addcontrol Caja03..." << endl;

	if(Panel01->AddControl(Caja04))
		cout << "Error addcontrol Caja04..." << endl;

	if(Panel01->AddControl(VBar))
		cout << "Error addcontrol VBar..." << endl;

	if(Panel01->AddControl(HBar))
		cout << "Error addcontrol HBar..." << endl;

	if(Panel01->AddControl(Texto))
		cout << "Error addcontrol Texto..." << endl;

	if(Panel01->AddControl(Lista))
		cout << "Error addcontrol Lista..." << endl;

	if(AppCutreCiv->List.AddControl(CLista))
		cout << "Error addcontrol CLista..." << endl;

	if(AppCutreCiv->List.AddControl(Combo))
		cout << "Error addcontrol Combo..." << endl;

	if(AppCutreCiv->List.AddControl(Combo2))
		cout << "Error addcontrol Combo2..." << endl;

	if(Panel01->AddControl(Check))
		cout << "Error addcontrol Check..." << endl;

	if(AppCutreCiv->List.AddControl(Panel01))
		cout << "Error addcontrol Panel01..." << endl;
	

	if(AppCutreCiv->DialogList.AddControl(Dialogo))
		cout << "Error addcontrol Dialogo..." << endl;
	

	if(AppCutreCiv->DialogList.AddControl(Dialogo2))
		cout << "Error addcontrol Dialogo2..." << endl;

	//--------------------------------------------------------------------------------------
	// Bucle principal.
	//--------------------------------------------------------------------------------------
	SDL_Rect recta = {700, 500, 50, 50};
	SDL_Rect rectb = {680, 480, 60, 60};

	Uint32 tiempo, acum = 0;
	float fps = 0;
	char auxbuff[255];

	Ayuda();

	cout << endl;
	Lua::ExecFile("hello.lua", "Data.dpf");

	while(AppCutreCiv->GetQuit() == false)
	{
		//----------------------------------------------------------------------------------
		// Pintado.
		//----------------------------------------------------------------------------------
		tiempo = AppCutreCiv->GetTime();
		SDL_FillRect(CRM32Pro.screen, NULL, 0x00000088);
		AppCutreCiv->Draw();

		acum += (AppCutreCiv->GetTime() - tiempo);
		if(acum > 500)
		{
			sprintf(auxbuff, "%f", fps);
			acum -= 500;
		}
		Font->PutString(CRM32Pro.screen, 2, 2, auxbuff);

		//----------------------------------------------------------------------------------
		// L�gica.
		//----------------------------------------------------------------------------------
		AppCutreCiv->Update();

		if(CRM32Pro.keystate[Teclas::TECLA_ESC]) AppCutreCiv->Exit();

		Control * Active = AppCutreCiv->GetActiveControl();
		
		if((Active == NULL) || (strcmp(Active->GetType(), "TextBox") != 0))
		{	
			if(CRM32Pro.keystate[Teclas::TECLA_SHIFT_IZUIERDO])
			{
				if(CRM32Pro.keystate[Teclas::TECLA_ARRIBA])    Panel01->SetY(Panel01->GetY() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_ABAJO])     Panel01->SetY(Panel01->GetY() + 1);
				if(CRM32Pro.keystate[Teclas::TECLA_IZQUIERDA]) Panel01->SetX(Panel01->GetX() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_DERECHA])   Panel01->SetX(Panel01->GetX() + 1);
			}
			else
			{
				if(CRM32Pro.keystate[Teclas::TECLA_ARRIBA])    Caja02->SetY(Caja02->GetY() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_ABAJO])     Caja02->SetY(Caja02->GetY() + 1);
				if(CRM32Pro.keystate[Teclas::TECLA_IZQUIERDA]) Caja02->SetX(Caja02->GetX() - 1);
				if(CRM32Pro.keystate[Teclas::TECLA_DERECHA])   Caja02->SetX(Caja02->GetX() + 1);
			}

			if(CRM32Pro.keystate[Teclas::TECLA_1]) AppCutreCiv->SetRenderBack(false);
			if(CRM32Pro.keystate[Teclas::TECLA_2]) AppCutreCiv->SetRenderBack(true);

			if(CRM32Pro.keystate[Teclas::TECLA_3]) Panel01->SetVisible(false);
			if(CRM32Pro.keystate[Teclas::TECLA_4]) Panel01->SetVisible(true);
			
			if(CRM32Pro.keystate[Teclas::TECLA_5])
			{
				Control * aux = AppCutreCiv->GetActiveControl();
				if(aux != NULL)
					cout << aux->GetName() << endl;
				else
					cout << AppCutreCiv->GetTitle() << endl;
			}

			if(CRM32Pro.keystate[Teclas::TECLA_ESPACIO])
			{
				if(!Dialogo->GetVisible())
					Dialogo->SetVisible(true);
				else if(!Dialogo2->GetVisible())
					Dialogo2->SetVisible(true);
			}

			if(CRM32Pro.keystate[Teclas::TECLA_F2] || CRM32Pro.keystate[Teclas::TECLA_TABULADOR])
			{
				Dialogo->SetVisible(false);
				Dialogo2->SetVisible(false);
			}
		}

		fps = 1000 / float(AppCutreCiv->GetTime() - tiempo);
	}

	//--------------------------------------------------------------------------------------
	// Finalizaci�n de los recursos.
	//--------------------------------------------------------------------------------------
	CRM32Pro.FreeSurface(Icono);
	AppCutreCiv->Release();

	return 0;
}
//******************************************************************************************