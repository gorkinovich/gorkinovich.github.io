//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Base.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _BASE_H_
#define _BASE_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#ifdef WIN32
	#define WIN32_LEAN_AND_MEAN
	#include <windows.h>
#else
	typedef unsigned long int UINT;
#endif
//------------------------------------------------------------------------------------------
#include "SDL/SDL.h"
//------------------------------------------------------------------------------------------
#include <iostream>
#include <string>
#include <vector>
#include <list>
//------------------------------------------------------------------------------------------
using namespace std;
//******************************************************************************************
// Macros
//******************************************************************************************
#ifndef YUKINO_EXPORTS // The VC++ defines this constant in the proyect settings.
	#define DLLAPI __declspec (dllimport) // Import the functions from the dll.
#else
	#define DLLAPI __declspec (dllexport) // Export the functions to the dll.
#endif
//------------------------------------------------------------------------------------------
#define _DOC_IN_ENGLISH_
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Simple data types
	//--------------------------------------------------------------------------------------
	typedef signed char      sbyte;  /**< Entero con signo de 8 bits (Sint8). */
	typedef signed short int sword;  /**< Entero con signo de 16 bits (Sint16). */
	typedef signed long int  sdword; /**< Entero con signo de 32 bits (Sint32). */
	
	typedef unsigned char      byte;  /**< Entero sin signo de 8 bits (Uint8). */
	typedef unsigned short int word;  /**< Entero sin signo de 16 bits (Uint16). */
	typedef unsigned long int  dword; /**< Entero sin signo de 32 bits (Uint32). */

	//--------------------------------------------------------------------------------------
	// Standar Errors
	//--------------------------------------------------------------------------------------
	const UINT EVERYTHING_ALL_RIGHT = 0; /**< Si una funci�n lo devuelve, es que todo ha ido bien. */
	
	//--------------------------------------------------------------------------------------
	// SDL constants
	//--------------------------------------------------------------------------------------
	const int FAIL    = -1; /**< Simboliza el fallo en casi todas las funciones de la SDL. */
	const int STR_EQU =  0; /**< Simboliza que dos cadenas son iguales en la funci�n strcmp. */
	

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Tipo b�sico para definir un area.
	/**
	 *  Este tipo de dato equivale a la estructura SDL_Rect que se encuentra en la librer�a
	 *  SDL. Su principal proposito es definir un area del plano 2D, y con ello poder
	 *  realizar todo tipo de operaciones con imagenes contenidas en una Surface.
	 */
	//--------------------------------------------------------------------------------------
	typedef struct
	{
		sword x; /**< Coordenada x de la regi�n. */
		sword y; /**< Coordenada y de la regi�n. */
		word  w; /**< Ancho de la regi�n. */
		word  h; /**< Alto de la regi�n. */
	} Rect;
#else
	//--------------------------------------------------------------------------------------
	/// Basic type to define an area.
	/**
	 *  This data type is equivalent to the SDL_Rect structure that is in library SDL. Its
	 *  main intention is to define an area of the plane 2D, and with it to be able to make
	 *  all type of operations with contained images in a Surface.
	 */
	//--------------------------------------------------------------------------------------
	typedef struct
	{
		sword x; /**< Coordinate x of the region. */
		sword y; /**< Coordinate y of the region. */
		word  w; /**< Width of the region. */
		word  h; /**< Height x of the region. */
	} Rect;
#endif
}
//******************************************************************************************
#endif
//******************************************************************************************
// Base.h
//******************************************************************************************