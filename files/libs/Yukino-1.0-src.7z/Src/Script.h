//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Script.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _SCRIPT_H_
#define _SCRIPT_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//------------------------------------------------------------------------------------------
extern "C"
{
#include "Lua/lua.h"
#include "Lua/lualib.h"
#include "Lua/lauxlib.h"
}
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Script Errors
	//--------------------------------------------------------------------------------------
	const UINT SCRIPT_ERROR_UNDEF   = 800; /**< Error indefinido en las funciones de Script. */
	const UINT SCRIPT_ERROR_LUAOPEN = 801; /**< Error al iniciar el LUA. */

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase que gestiona el sistema de scripts.
	/**
	 *  La clase Input gestiona los temas relacionados con el sistema de scripts con Lua.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class that manages the scripts system.
	/**
	 *  The Input class manages the subjects related to the system of scripts with Lua.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Script
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			static Script * Instance;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			lua_State * LuaVM;

			Script ();
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para inicializar el objeto Script.
			/**
			 *  Esta funci�n sirve para inicializar el objeto Script.
			 *  @see Release().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SCRIPT_ERROR_LUAOPEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to initialize the object Script.
			/**
			 *  This function serves to initialize the object Script.
			 *  @see Release().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SCRIPT_ERROR_LUAOPEN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Init (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para finalizar el objeto Script.
			/**
			 *  Esta funci�n sirve para finalizar el objeto Script.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to finalize the object Script.
			/**
			 *  This function serves to finalize the object Script.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#endif
			void Release (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la cima de la pila.
			/**
			 *  @return La cima de la pila.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the top of the stack.
			/**
			 *  @return The top of the stack.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetTop (void)
			{
				return lua_gettop(LuaVM);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el tipo de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return LUA_TNIL, LUA_TNUMBER, LUA_TBOOLEAN, LUA_TSTRING, LUA_TTABLE,
			 *          LUA_TFUNCTION, LUA_TUSERDATA, LUA_TTHREAD, LUA_TLIGHTUSERDATA.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the type of a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return LUA_TNIL, LUA_TNUMBER, LUA_TBOOLEAN, LUA_TSTRING, LUA_TTABLE,
			 *          LUA_TFUNCTION, LUA_TUSERDATA, LUA_TTHREAD, LUA_TLIGHTUSERDATA.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int Type (int index)
			{
				return lua_type(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un NULL una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a NULL.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsNil (int index)
			{
				return lua_isnil(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un booleano una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a boolean.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsBool (int index)
			{
				return lua_isboolean(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un n�mero una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a number.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsNumber (int index)
			{
				return lua_isnumber(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una cadena una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a string.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsString (int index)
			{
				return lua_isstring(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una tabla una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a table.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsTable (int index)
			{
				return lua_istable(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una funci�n una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a function.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsFunction (int index)
			{
				return lua_isfunction(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una funci�n de C una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a C function.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsCFunction (int index)
			{
				return lua_iscfunction(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un UserData una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is an UserData.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsUserData (int index)
			{
				return lua_isuserdata(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un UserData una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is an UserData.
			/**
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsLightUserData (int index)
			{
				return lua_islightuserdata(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un tipo de dato en una cadena.
			/**
			 *  @param type Tipo de dato.
			 *  @return Una cadena con el tipo de dato en texto.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a type of data into a string.
			/**
			 *  @param type Type of data.
			 *  @return A string with the data type in text.
			 */
			//------------------------------------------------------------------------------
#endif
			inline const char * TypeName (int type)
			{
				return lua_typename(LuaVM, type);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un booleano de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a boolean from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetBool (int index)
			{
				return lua_toboolean(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un n�mero de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a number from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline lua_Number GetNumber (int index)
			{
				return lua_tonumber(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener una cadena de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a string from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline const char * GetString (int index)
			{
				return lua_tostring(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el tama�o de una cadena de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El tama�o de una cadena.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the size of a string from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The size of a string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline size_t GetStrLen (int index)
			{
				return lua_strlen(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener una funci�n de C de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a C function from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline lua_CFunction GetCFunction (int index)
			{
				return lua_tocfunction(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un UserData de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain an UserData from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void * GetUserData (int index)
			{
				return lua_touserdata(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un hilo de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a thread from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline lua_State * GetThread (int index)
			{
				return lua_tothread(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un puntero de una posici�n de la pila.
			/**
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a pointer from a position of the stack.
			/**
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline const void * GetPointer (int index)
			{
				return lua_topointer(LuaVM, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un booleano en la pila.
			/**
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a boolean in the stack.
			/**
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushBool (int val)
			{
				lua_pushboolean(LuaVM, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un n�mero en la pila.
			/**
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a number in the stack.
			/**
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushNumber (lua_Number val)
			{
				lua_pushnumber(LuaVM, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter una cadena en la pila.
			/**
			 *  @param val El valor del dato.
			 *  @param len Tama�o de la cadena.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a string in the stack.
			/**
			 *  @param val The value of the data.
			 *  @param len Size of the string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushString (const char * val, size_t len)
			{
				lua_pushlstring(LuaVM, val, len);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter una cadena en la pila.
			/**
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a string in the stack.
			/**
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushString (const char * val)
			{
				lua_pushstring(LuaVM, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un NULL en la pila.
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a NULL in the stack.
			//------------------------------------------------------------------------------
#endif
			inline void PushNil (void)
			{
				lua_pushnil(LuaVM);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter una funci�n de C en la pila.
			/**
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a C function in the stack.
			/**
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushCFunction (lua_CFunction val)
			{
				lua_pushcfunction(LuaVM, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un UserData en la pila.
			/**
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a UserData in the stack.
			/**
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushLightUserData (void * val)
			{
				lua_pushlightuserdata(LuaVM, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar un fichero de Lua.
			/**
			 *  @param file Ruta del fichero.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a file of Lua.
			/**
			 *  @param file Path of the file.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecFile (const char * file)
			{
				luaL_dofile(LuaVM, file);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar un fichero de Lua.
			/**
			 *  @param file Ruta del fichero.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a file of Lua.
			/**
			 *  @param file Path of the file.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecFile (const string & file)
			{
				luaL_dofile(LuaVM, file.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar una cadena de texto de Lua.
			/**
			 *  @param str Cadena de texto.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a text string of Lua.
			/**
			 *  @param str Text string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecString (const char * str)
			{
				luaL_dostring(LuaVM, str);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar una cadena de texto de Lua.
			/**
			 *  @param str Cadena de texto.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a text string of Lua.
			/**
			 *  @param str Text string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecString (const string & str)
			{
				luaL_dostring(LuaVM, str.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para registrar una funci�n de C en Lua.
			/**
			 *  @param name Nombre en Lua de la funci�n.
			 *  @param func Puntero a la funci�n en C.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to register a C function in Lua.
			/**
			 *  @param name Name in Lua of the function.
			 *  @param func Pointer to the function in C.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void Register (const char * name, lua_CFunction func)
			{
				lua_register(LuaVM, name, func);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para registrar una funci�n de C en Lua.
			/**
			 *  @param name Nombre en Lua de la funci�n.
			 *  @param func Puntero a la funci�n en C.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to register a C function in Lua.
			/**
			 *  @param name Name in Lua of the function.
			 *  @param func Pointer to the function in C.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void Register (const string & name, lua_CFunction func)
			{
				lua_register(LuaVM, name.c_str(), func);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la cima de la pila.
			/**
			 *  @param L Estado de Lua.
			 *  @return La cima de la pila.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the top of the stack.
			/**
			 *  @param L Lua state.
			 *  @return The top of the stack.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetTop (lua_State * L)
			{
				return lua_gettop(L);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el tipo de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return LUA_TNIL, LUA_TNUMBER, LUA_TBOOLEAN, LUA_TSTRING, LUA_TTABLE,
			 *          LUA_TFUNCTION, LUA_TUSERDATA, LUA_TTHREAD, LUA_TLIGHTUSERDATA.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the type of a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return LUA_TNIL, LUA_TNUMBER, LUA_TBOOLEAN, LUA_TSTRING, LUA_TTABLE,
			 *          LUA_TFUNCTION, LUA_TUSERDATA, LUA_TTHREAD, LUA_TLIGHTUSERDATA.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int Type (lua_State * L, int index)
			{
				return lua_type(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un NULL una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a NULL.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsNil (lua_State * L, int index)
			{
				return lua_isnil(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un booleano una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a boolean.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsBool (lua_State * L, int index)
			{
				return lua_isboolean(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un n�mero una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a number.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsNumber (lua_State * L, int index)
			{
				return lua_isnumber(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una cadena una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a string.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsString (lua_State * L, int index)
			{
				return lua_isstring(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una tabla una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a table.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsTable (lua_State * L, int index)
			{
				return lua_istable(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una funci�n una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a function.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsFunction (lua_State * L, int index)
			{
				return lua_isfunction(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es una funci�n de C una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is a C function.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsCFunction (lua_State * L, int index)
			{
				return lua_iscfunction(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un UserData una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is an UserData.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsUserData (lua_State * L, int index)
			{
				return lua_isuserdata(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener si es un UserData una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return Si es verdad devuelve 1, sino devuelve 0.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain if a position of the stack is an UserData.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return If it's true returns 1, on errors returns 0.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int IsLightUserData (lua_State * L, int index)
			{
				return lua_islightuserdata(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un booleano de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a boolean from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetBool (lua_State * L, int index)
			{
				return lua_toboolean(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un n�mero de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a number from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline lua_Number GetNumber (lua_State * L, int index)
			{
				return lua_tonumber(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener una cadena de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a string from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline const char * GetString (lua_State * L, int index)
			{
				return lua_tostring(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el tama�o de una cadena de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El tama�o de una cadena.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the size of a string from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The size of a string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline size_t GetStrLen (lua_State * L, int index)
			{
				return lua_strlen(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener una funci�n de C de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a C function from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline lua_CFunction GetCFunction (lua_State * L, int index)
			{
				return lua_tocfunction(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un UserData de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain an UserData from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void * GetUserData (lua_State * L, int index)
			{
				return lua_touserdata(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un hilo de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a thread from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline lua_State * GetThread (lua_State * L, int index)
			{
				return lua_tothread(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un puntero de una posici�n de la pila.
			/**
			 *  @param L     Estado de Lua.
			 *  @param index Posici�n dentro de la pila.
			 *  @return El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain a pointer from a position of the stack.
			/**
			 *  @param L     Lua state.
			 *  @param index Position inside the stack.
			 *  @return The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline const void * GetPointer (lua_State * L, int index)
			{
				return lua_topointer(L, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un booleano en la pila.
			/**
			 *  @param L   Estado de Lua.
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a boolean in the stack.
			/**
			 *  @param L   Lua state.
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushBool (lua_State * L, int val)
			{
				lua_pushboolean(L, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un n�mero en la pila.
			/**
			 *  @param L   Estado de Lua.
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a number in the stack.
			/**
			 *  @param L   Lua state.
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushNumber (lua_State * L, lua_Number val)
			{
				lua_pushnumber(L, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter una cadena en la pila.
			/**
			 *  @param L   Estado de Lua.
			 *  @param val El valor del dato.
			 *  @param len Tama�o de la cadena.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a string in the stack.
			/**
			 *  @param L   Lua state.
			 *  @param val The value of the data.
			 *  @param len Size of the string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushString (lua_State * L, const char * val, size_t len)
			{
				lua_pushlstring(L, val, len);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter una cadena en la pila.
			/**
			 *  @param L   Estado de Lua.
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a string in the stack.
			/**
			 *  @param L   Lua state.
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushString (lua_State * L, const char * val)
			{
				lua_pushstring(L, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un NULL en la pila.
			/**
			 *  @param L Estado de Lua.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a NULL in the stack.
			/**
			 *  @param L Lua state.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushNil (lua_State * L)
			{
				lua_pushnil(L);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter una funci�n de C en la pila.
			/**
			 *  @param L   Estado de Lua.
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a C function in the stack.
			/**
			 *  @param L   Lua state.
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushCFunction (lua_State * L, lua_CFunction val)
			{
				lua_pushcfunction(L, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para meter un UserData en la pila.
			/**
			 *  @param L   Estado de Lua.
			 *  @param val El valor del dato.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to push a UserData in the stack.
			/**
			 *  @param L   Lua state.
			 *  @param val The value of the data.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PushLightUserData (lua_State * L, void * val)
			{
				lua_pushlightuserdata(L, val);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar un fichero de Lua.
			/**
			 *  @param L    Estado de Lua.
			 *  @param file Ruta del fichero.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a file of Lua.
			/**
			 *  @param L    Lua state.
			 *  @param file Path of the file.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecFile (lua_State * L, const char * file)
			{
				luaL_dofile(L, file);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar un fichero de Lua.
			/**
			 *  @param L    Estado de Lua.
			 *  @param file Ruta del fichero.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a file of Lua.
			/**
			 *  @param L    Lua state.
			 *  @param file Path of the file.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecFile (lua_State * L, const string & file)
			{
				luaL_dofile(L, file.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar una cadena de texto de Lua.
			/**
			 *  @param L   Estado de Lua.
			 *  @param str Cadena de texto.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a text string of Lua.
			/**
			 *  @param L   Lua state.
			 *  @param str Text string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecString (lua_State * L, const char * str)
			{
				luaL_dostring(L, str);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para ejecutar una cadena de texto de Lua.
			/**
			 *  @param L   Estado de Lua.
			 *  @param str Cadena de texto.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to excecute a text string of Lua.
			/**
			 *  @param L   Lua state.
			 *  @param str Text string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ExecString (lua_State * L, const string & str)
			{
				luaL_dostring(L, str.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para registrar una funci�n de C en Lua.
			/**
			 *  @param L    Estado de Lua.
			 *  @param name Nombre en Lua de la funci�n.
			 *  @param func Puntero a la funci�n en C.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to register a C function in Lua.
			/**
			 *  @param L    Lua state.
			 *  @param name Name in Lua of the function.
			 *  @param func Pointer to the function in C.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void Register (lua_State * L, const char * name, lua_CFunction func)
			{
				lua_register(L, name, func);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para registrar una funci�n de C en Lua.
			/**
			 *  @param L    Estado de Lua.
			 *  @param name Nombre en Lua de la funci�n.
			 *  @param func Puntero a la funci�n en C.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to register a C function in Lua.
			/**
			 *  @param L    Lua state.
			 *  @param name Name in Lua of the function.
			 *  @param func Pointer to the function in C.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void Register (lua_State * L, const string & name, lua_CFunction func)
			{
				lua_register(L, name.c_str(), func);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el estado de Lua.
			/**
			 *  @return Un puntero al estado de Lua.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the Lua state.
			/**
			 *  @return A pointer to the Lua state.
			 */
			//------------------------------------------------------------------------------
#endif
			inline lua_State * GetLuaState (void)
			{
				return LuaVM;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la instancia de Script.
			/**
			 *  Esta funci�n crea una instancia de Script, en caso de no estar creada, y
			 *  devuelve un puntero a esta si tiene exito pidiendo memoria.
			 *  @return Devuelve un puntero al objeto Script si todo ha ido bien, en caso de
			 *          no haber memoria para el objeto devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the instance of Script.
			/**
			 *  This function creates an instance of Script, in case of not being created,
			 *  and gives back a pointer of this if memory is successful requesting.
			 *  @return It gives back to a pointer to the object Script if everything has
			 *          gone well, if there is no memory for the object, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			static Script * GetInstance (void);
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Script.h
//******************************************************************************************