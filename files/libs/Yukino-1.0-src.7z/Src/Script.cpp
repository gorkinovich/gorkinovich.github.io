//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Script.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "Script.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Global static members of the script class.
	//--------------------------------------------------------------------------------------
	Script * Script::Instance = NULL;

	//--------------------------------------------------------------------------------------
	// Script constructor.
	//--------------------------------------------------------------------------------------
	Script::Script ()
	{
		LuaVM = NULL;
	}
	
	//--------------------------------------------------------------------------------------
	// This function initializes the script object.
	//--------------------------------------------------------------------------------------
	UINT Script::Init (void)
	{
		LuaVM = lua_open();

		if(LuaVM == NULL)
		{
			return SCRIPT_ERROR_LUAOPEN;
		}

		luaL_openlibs(LuaVM);

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function releases the script object.
	//--------------------------------------------------------------------------------------
	void Script::Release (void)
	{
		if(LuaVM != NULL)
		{
			lua_close(LuaVM);
			LuaVM = NULL;
		}
	}

	//--------------------------------------------------------------------------------------
	// The core class GetInstance function.
	//--------------------------------------------------------------------------------------
	Script * Script::GetInstance (void)
	{
		if(Script::Instance == NULL)
			Script::Instance = new Script();

		return Script::Instance;
	}
}
//******************************************************************************************
// Script.cpp
//******************************************************************************************