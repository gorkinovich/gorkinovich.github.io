//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Font.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _FONT_H_
#define _FONT_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//------------------------------------------------------------------------------------------
#include "SDL/SDL_ttf.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Font Errors
	//--------------------------------------------------------------------------------------
	const UINT FONT_ERROR_UNDEF = 700; /**< Error indefinido en las funciones de Font. */
	const UINT FONT_ERROR_OPEN  = 701; /**< Error indefinido en las funciones de Font. */
	
#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase para almacenar una fuente.
	/**
	 *  La clase Font sirve para almacenar en memoria un tipo de fuente True-Type.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class to store one font.
	/**
	 *  The Font class serves to store in memory a type of True-Type font.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Font
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			TTF_Font * Buffer;

			string File;
			int    Size;
			long   Index;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Font.
			/**
			 *  Constructor por defecto de la clase Font.
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Font class.
			/**
			 *  Constructor by defect of the Font class. 
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#endif
			Font ();
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Font.
			/**
			 *  Constructor de la clase Font, que carga un fichero.
			 *  @param file   Ruta del fichero.
			 *  @param ptsize Tama�o de la fuente.
			 *  @param index  Indice de la fuente.
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Font class.
			/**
			 *  Constructor of the Font class, that loads a file.
			 *  @param file   Path of the file.
			 *  @param ptsize Size of the font.
			 *  @param index  Index of the font.
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#endif
			Font (const char * file, int ptsize, long index = 0);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Font.
			/**
			 *  Constructor de la clase Font, que carga un fichero.
			 *  @param file   Ruta del fichero.
			 *  @param ptsize Tama�o de la fuente.
			 *  @param index  Indice de la fuente.
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Font class.
			/**
			 *  Constructor of the Font class, that loads a file.
			 *  @param file   Path of the file.
			 *  @param ptsize Size of the font.
			 *  @param index  Index of the font.
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#endif
			Font (const string & file, int ptsize, long index = 0);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor copia de la clase Font.
			/**
			 *  @param obj Objeto Font a copiar.
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Copy constructor of the Font class.
			/**
			 *  @param obj Font object to copy.
			 *  @see operator=(), ~Font().
			 */
			//------------------------------------------------------------------------------
#endif
			Font (const Font & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Operador = de la clase Font.
			/**
			 *  Copia el objeto obj en el objeto actual, y este es devuelto.
			 *  @see Font(), ~Font().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Operator = of the Font class.
			/**
			 *  The obj object is copied in the actual object, and this is given back.
			 *  @see Font(), ~Font().
			 */
			//------------------------------------------------------------------------------
#endif
			Font & operator = (Font & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Destructor de la clase Font.
			/**
			 *  @see Font(), operator=().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Destructor of the Font class.
			/**
			 *  @see Font(), operator=().
			 */
			//------------------------------------------------------------------------------
#endif
			~Font ();
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar un fuente de un fichero.
			/**
			 *  Esta funci�n sirve para cargar un fuente de un fichero.
			 *  @param file   Ruta del fichero.
			 *  @param ptsize Tama�o de la fuente.
			 *  @param index  Indice de la fuente.
			 *  @see Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          FONT_ERROR_OPEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a font from a file.
			/**
			 *  This function serves to load a font from a file.
			 *  @param file   Path of the file.
			 *  @param ptsize Size of the font.
			 *  @param index  Index of the font.
			 *  @see Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          FONT_ERROR_OPEN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Load (const char * file, int ptsize, long index = 0);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar un fuente de un fichero.
			/**
			 *  Esta funci�n sirve para cargar un fuente de un fichero.
			 *  @param file   Ruta del fichero.
			 *  @param ptsize Tama�o de la fuente.
			 *  @param index  Indice de la fuente.
			 *  @see Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          FONT_ERROR_OPEN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a font from a file.
			/**
			 *  This function serves to load a font from a file.
			 *  @param file   Path of the file.
			 *  @param ptsize Size of the font.
			 *  @param index  Index of the font.
			 *  @see Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          FONT_ERROR_OPEN.
			 */
			//------------------------------------------------------------------------------
#endif
			inline UINT Load (const string & file, int ptsize, long index = 0)
			{
				return Load(file.c_str(), ptsize, index);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para liberar los datos del objeto Font.
			/**
			 *  Esta funci�n sirve para liberar el contenido del objeto Font.
			 *  @see Load().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to release the data of the Font object.
			/**
			 *  This function serves to release the content of the Font object.
			 *  @see Load().
			 */
			//------------------------------------------------------------------------------
#endif
			void Free (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el estilo de la fuente.
			/**
			 *  Esta funci�n sirve para obtener el estilo de la fuente.
			 *  @see SetStyle().
			 *  @return TTF_STYLE_BOLD, TTF_STYLE_ITALIC, TTF_STYLE_UNDERLINE,
			 *          TTF_STYLE_NORMAL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the style of the font.
			/**
			 *  This function serves to obtain the style of the font.
			 *  @see SetStyle().
			 *  @return TTF_STYLE_BOLD, TTF_STYLE_ITALIC, TTF_STYLE_UNDERLINE,
			 *          TTF_STYLE_NORMAL.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetStyle (void)
			{
				return TTF_GetFontStyle(Buffer);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el estilo de la fuente.
			/**
			 *  Esta funci�n sirve para cambiar el estilo de la fuente.
			 *  @param style Estilo de la fuente.
			 *  @see GetStyle().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the style of the font.
			/**
			 *  This function serves to change the style of the font.
			 *  @param style Style of the font.
			 *  @see GetStyle().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void SetStyle (int style)
			{
				TTF_SetFontStyle(Buffer, style);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el alto de la fuente.
			/**
			 *  Esta funci�n sirve para obtener el alto de la fuente.
			 *  @return El alto de la fuente.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the height of the font.
			/**
			 *  This function serves to obtain the height of the font.
			 *  @return The height of the font. 
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetHeight (void)
			{
				return TTF_FontHeight(Buffer);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el ascendente de la fuente.
			/**
			 *  Esta funci�n sirve para obtener el ascendente de la fuente.
			 *  @see GetDescent().
			 *  @return El ascendente de la fuente.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the ascent of the font.
			/**
			 *  This function serves to obtain the ascent of the font.
			 *  @see GetDescent().
			 *  @return The ascent of the font. 
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetAscent (void)
			{
				return TTF_FontAscent(Buffer);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el descendente de la fuente.
			/**
			 *  Esta funci�n sirve para obtener el descendente de la fuente.
			 *  @see GetAscent().
			 *  @return El descendente de la fuente.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the descent of the font.
			/**
			 *  This function serves to obtain the descent of the font.
			 *  @see GetAscent().
			 *  @return The descent of the font.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetDescent (void)
			{
				return TTF_FontDescent(Buffer);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la distancia del salto de linea de la fuente.
			/**
			 *  Esta funci�n sirve para obtener la distancia del salto de linea.
			 *  @return La distancia del salto de linea.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the distance between two lines of the font.
			/**
			 *  This function serves to obtain the distance between two lines.
			 *  @return The distance between two lines.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetLineSkip (void)
			{
				return TTF_FontLineSkip(Buffer);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el tama�o de la fuente.
			/**
			 *  Esta funci�n sirve para obtener el tama�o de la fuente.
			 *  @return El tama�o de la fuente.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the size of the font.
			/**
			 *  This function serves to obtain the size of the font.
			 *  @return The size of the font.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetSize (void)
			{
				return Size;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el tama�o de una cadena de texto renderizada.
			/**
			 *  Esta funci�n sirve para obtener el tama�o de un texto renderizado.
			 *  @return El tama�o de una cadena de texto.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the size of a string.
			/**
			 *  This function serves to obtain the size of a rendered string.
			 *  @return The size of a rendered string.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetSizeText (const char * text, int * w = NULL, int * h = NULL)
			{
				return TTF_SizeText(Buffer, text, w, h);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para renderizar una cadena de texto.
			/**
			 *  Esta funci�n sirve para renderizar una cadena de texto con un color.
			 *  @param text Cadena a renderizar.
			 *  @param fc   Color de la cadena.
			 *  @see RenderText2(), RenderUNICODE(), RenderUNICODE2().
			 *  @return Devuelve un puntero a un SDL_Surface si todo ha ido bien, en
			 *          caso de no haber memoria para el buffer devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to render a string.
			/**
			 *  This function serves to render a string with a color.
			 *  @param text String to render.
			 *  @param fc   Color of the string.
			 *  @see RenderText2(), RenderUNICODE(), RenderUNICODE2().
			 *  @return It gives back to a pointer to a SDL_Surface if everything has
			 *          gone well, if there is no memory for the buffer, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			inline SDL_Surface * RenderText (const char * text, dword fc)
			{
				SDL_Color color = {0, 0, 0, 0};

				color.r = (fc & 0x00FF0000) / 0x00010000;
				color.g = (fc & 0x0000FF00) / 0x00000100;
				color.b = (fc & 0x000000FF);

				return TTF_RenderText_Solid(Buffer, text, color);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para renderizar una cadena de texto.
			/**
			 *  Esta funci�n sirve para renderizar una cadena de texto con un color.
			 *  @param text  Cadena a renderizar.
			 *  @param color Color de la cadena.
			 *  @see RenderText(), RenderUNICODE(), RenderUNICODE2().
			 *  @return Devuelve un puntero a un SDL_Surface si todo ha ido bien, en
			 *          caso de no haber memoria para el buffer devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to render a string.
			/**
			 *  This function serves to render a string with a color.
			 *  @param text  String to render.
			 *  @param color Color of the string.
			 *  @see RenderText(), RenderUNICODE(), RenderUNICODE2().
			 *  @return It gives back to a pointer to a SDL_Surface if everything has
			 *          gone well, if there is no memory for the buffer, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			inline SDL_Surface * RenderText2 (const char * text, SDL_Color color)
			{
				return TTF_RenderText_Solid(Buffer, text, color);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para renderizar una cadena de texto.
			/**
			 *  Esta funci�n sirve para renderizar una cadena de texto con un color.
			 *  @param text Cadena a renderizar.
			 *  @param fc   Color de la cadena.
			 *  @see RenderText(), RenderText2(), RenderUNICODE2().
			 *  @return Devuelve un puntero a un SDL_Surface si todo ha ido bien, en
			 *          caso de no haber memoria para el buffer devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to render a string.
			/**
			 *  This function serves to render a string with a color.
			 *  @param text String to render.
			 *  @param fc   Color of the string.
			 *  @see RenderText(), RenderText2(), RenderUNICODE2().
			 *  @return It gives back to a pointer to a SDL_Surface if everything has
			 *          gone well, if there is no memory for the buffer, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			inline SDL_Surface * RenderUNICODE (const word * text, dword fc)
			{
				SDL_Color color = {0, 0, 0, 0};

				color.r = (fc & 0x00FF0000) / 0x00010000;
				color.g = (fc & 0x0000FF00) / 0x00000100;
				color.b = (fc & 0x000000FF);

				return TTF_RenderUNICODE_Solid(Buffer, text, color);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para renderizar una cadena de texto.
			/**
			 *  Esta funci�n sirve para renderizar una cadena de texto con un color.
			 *  @param text  Cadena a renderizar.
			 *  @param color Color de la cadena.
			 *  @see RenderText(), RenderText2(), RenderUNICODE().
			 *  @return Devuelve un puntero a un SDL_Surface si todo ha ido bien, en
			 *          caso de no haber memoria para el buffer devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to render a string.
			/**
			 *  This function serves to render a string with a color.
			 *  @param text  String to render.
			 *  @param color Color of the string.
			 *  @see RenderText(), RenderText2(), RenderUNICODE().
			 *  @return It gives back to a pointer to a SDL_Surface if everything has
			 *          gone well, if there is no memory for the buffer, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			inline SDL_Surface * RenderUNICODE2 (const word * text, SDL_Color color)
			{
				return TTF_RenderUNICODE_Solid(Buffer, text, color);
			}


			friend class Graphics;
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Font.h
//******************************************************************************************