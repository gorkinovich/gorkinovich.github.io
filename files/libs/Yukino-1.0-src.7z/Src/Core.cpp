//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Core.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifdef WIN32
	#pragma comment (lib, "kernel32.lib")
	#pragma comment (lib, "user32.lib")
	#pragma comment (lib, "SDL.lib")
	#pragma comment (lib, "SDLmain.lib")
#endif
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Core.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Global static members of the core class.
	//--------------------------------------------------------------------------------------
	Core * Core::Instance = NULL;

	//--------------------------------------------------------------------------------------
	// Core constructor.
	//--------------------------------------------------------------------------------------
	Core::Core ()
	{
		AppName = string();

		AppGraphics = Graphics::GetInstance();
		AppInput    = Input::GetInstance();
		AppAudio    = Audio::GetInstance();
		AppScript   = Script::GetInstance();
	}
	
	//--------------------------------------------------------------------------------------
	// Init Core function.
	//--------------------------------------------------------------------------------------
	UINT Core::Init (const char * name)
	{
		AppName = name;

		if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_TIMER) == FAIL)
		{
			SDL_Quit();
			return CORE_ERROR_SDLINIT;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// Init Core function.
	//--------------------------------------------------------------------------------------
	UINT Core::InitAll (const char * name, int w, int h, int bpp, bool winmode,
						int frequency, word format, int channels, int chunksize)
	{
		UINT error = Init(name);

		if(error != EVERYTHING_ALL_RIGHT) return error;

		error = AppGraphics->Init(w, h, bpp, winmode);
		
		if(error != EVERYTHING_ALL_RIGHT) return error;

		AppGraphics->SetTitle(name, NULL);

		error = AppInput->Init();
		
		if(error != EVERYTHING_ALL_RIGHT) return error;

		error = AppAudio->Init(frequency, format, channels, chunksize);
		
		if(error != EVERYTHING_ALL_RIGHT) return error;

		error = AppScript->Init();
		
		if(error != EVERYTHING_ALL_RIGHT) return error;

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// End Core function.
	//--------------------------------------------------------------------------------------
	void Core::Release (void)
	{
		SDL_Quit();
	}

	//--------------------------------------------------------------------------------------
	// End Core function.
	//--------------------------------------------------------------------------------------
	void Core::ReleaseAll (void)
	{
		AppScript->Release();
		AppAudio->Release();
		AppInput->Release();
		AppGraphics->Release();
		Release();
	}

	//--------------------------------------------------------------------------------------
	// The core class GetInstance function.
	//--------------------------------------------------------------------------------------
	Core * Core::GetInstance (void)
	{
		if(Core::Instance == NULL)
			Core::Instance = new Core();

		return Core::Instance;
	}
}
//******************************************************************************************
// Core.cpp
//******************************************************************************************