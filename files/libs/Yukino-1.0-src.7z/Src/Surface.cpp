//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Surface.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifdef WIN32
	#pragma comment (lib, "SDL_image.lib")
#endif
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Surface.h"
//------------------------------------------------------------------------------------------
#include "SDL/SDL_image.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Surface constructor.
	//--------------------------------------------------------------------------------------
	Surface::Surface ()
	{
		Buffer = NULL;
	}

	//--------------------------------------------------------------------------------------
	// Surface constructor that create a new blank buffer.
	//--------------------------------------------------------------------------------------
	Surface::Surface (int w, int h, int bpp)
	{
		Buffer = NULL;
		Create(w, h, bpp);
	}

	//--------------------------------------------------------------------------------------
	// Surface constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Surface::Surface (const string & file)
	{
		Buffer = NULL;
		Load(file.c_str());
	}

	//--------------------------------------------------------------------------------------
	// Surface constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Surface::Surface (const char * file)
	{
		Buffer = NULL;
		Load(file);
	}

	//--------------------------------------------------------------------------------------
	// Surface constructor that receives an image.
	//--------------------------------------------------------------------------------------
	Surface::Surface (SDL_Surface * surface)
	{
		Buffer = surface;
	}

	//--------------------------------------------------------------------------------------
	// Surface copy constructor.
	//--------------------------------------------------------------------------------------
	Surface::Surface (const Surface & obj)
	{
		Buffer = NULL;

		if(!Create(obj.Buffer->w, obj.Buffer->h, obj.Buffer->format->BitsPerPixel))
		{
			Copy(obj);
		}
	}

	//--------------------------------------------------------------------------------------
	// Surface operator =, that copies one object in other.
	//--------------------------------------------------------------------------------------
	Surface & Surface::operator = (Surface & obj)
	{
		Free();

		if(!Create(obj.Buffer->w, obj.Buffer->h, obj.Buffer->format->BitsPerPixel))
		{
			Copy(obj);
		}

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	// Surface destructor.
	//--------------------------------------------------------------------------------------
	Surface::~Surface ()
	{
		Free();
	}

	//--------------------------------------------------------------------------------------
	// This function creates a new blank buffer in the object.
	//--------------------------------------------------------------------------------------
	UINT Surface::Create (int w, int h, int bpp)
	{
		Uint32 rmask, gmask, bmask, amask, flags;

		#if SDL_BYTEORDER == SDL_BIG_ENDIAN
			rmask = 0xFF000000;
			gmask = 0x00FF0000;
			bmask = 0x0000FF00;
			amask = 0x000000FF;
		#else
			rmask = 0x000000FF;
			gmask = 0x0000FF00;
			bmask = 0x00FF0000;
			amask = 0xFF000000;
		#endif

		flags = (SDL_HWSURFACE); // Get a surface in the video ram.

		Buffer = SDL_CreateRGBSurface(flags, w, h, bpp, rmask, gmask, bmask, amask);
		if(Buffer == NULL)
		{
			flags = (SDL_SWSURFACE); // Get a surface in the normal ram.

			Buffer = SDL_CreateRGBSurface(flags, w, h, bpp, rmask, gmask, bmask, amask);
			if(Buffer == NULL)
			{
				return SURFACE_ERROR_CREATESURF;
			}
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function sets the color key in the surface.
	//--------------------------------------------------------------------------------------
	UINT Surface::SetColorKey (Uint32 color)
	{
		if(SDL_SetColorKey(Buffer, SDL_SRCCOLORKEY, color) == FAIL)
		{
			return SURFACE_ERROR_SETCOLORKEY;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function transforms the buffer in the same screen buffer's format.
	//--------------------------------------------------------------------------------------
	UINT Surface::Transform (void)
	{
		SDL_Surface * auxbuf = SDL_DisplayFormat(Buffer);

		if(auxbuf == NULL)
		{
			return SURFACE_ERROR_DISPLAYFORMAT;
		}

		SDL_FreeSurface(Buffer);

		Buffer = auxbuf;

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function fills with a color, a rectangle in the surface.
	//--------------------------------------------------------------------------------------
	UINT Surface::Fill (Uint32 color, Rect * rect)
	{
		if(SDL_FillRect(Buffer, (SDL_Rect *) rect, color) == FAIL)
		{
			return SURFACE_ERROR_FILLRECT;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function loads an image from a file.
	//--------------------------------------------------------------------------------------
	UINT Surface::Load (const char * file)
	{
		SDL_RWops * Raw;
		char ext[4];

		strcpy(ext, (file + strlen(file) - 3));
		strupr(ext);

		if(!strcmp(ext, "BMP"))
		{
			Buffer = SDL_LoadBMP(file);
		}
		else
		{
			Raw = SDL_RWFromFile(file, "rb");

			if(Raw == NULL)
			{
				return SURFACE_ERROR_RWFROMFILE;
			}

			if(!strcmp(ext, "PNG"))
			{
				Buffer = IMG_LoadPNG_RW(Raw);
			}
			else if(!strcmp(ext, "TGA"))
			{
				Buffer = IMG_LoadTGA_RW(Raw);
			}
			else if(!strcmp(ext, "JPG"))
			{
				Buffer = IMG_LoadJPG_RW(Raw);
			}
			else if(!strcmp(ext, "PCX"))
			{
				Buffer = IMG_LoadPCX_RW(Raw);
			}
			else if(!strcmp(ext, "GIF"))
			{
				Buffer = IMG_LoadGIF_RW(Raw);
			}
			else if(!strcmp(ext, "TIF"))
			{
				Buffer = IMG_LoadTIF_RW(Raw);
			}
			else if(!strcmp(ext, "PNM"))
			{
				Buffer = IMG_LoadPNM_RW(Raw);
			}
			else if(!strcmp(ext, "XPM"))
			{
				Buffer = IMG_LoadXPM_RW(Raw);
			}
			else if(!strcmp(ext, "XCF"))
			{
				Buffer = IMG_LoadXCF_RW(Raw);
			}
			else if(!strcmp(ext, "LBM"))
			{
				Buffer = IMG_LoadLBM_RW(Raw);
			}
			else
			{
				Buffer = NULL;
				SDL_FreeRW(Raw);
				return SURFACE_ERROR_UNKOWNFORMAT;
			}
			
			SDL_FreeRW(Raw);
		}

		if(Buffer == NULL)
			return SURFACE_ERROR_LOADINGFILE;
		else
			return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function saves an image in a file.
	//--------------------------------------------------------------------------------------
	UINT Surface::Save (const char * file)
	{
		if(SDL_SaveBMP(Buffer, file) == FAIL)
		{
			return SURFACE_ERROR_SAVINGFILE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function unloads the surface's buffer.
	//--------------------------------------------------------------------------------------
	void Surface::Free (void)
	{
		if(Buffer != NULL)
		{
			SDL_FreeSurface(Buffer);
			Buffer = NULL;
		}
	}

	//--------------------------------------------------------------------------------------
	// This function copies a source surface into the object.
	//--------------------------------------------------------------------------------------
	UINT Surface::Copy (const Surface & objsrc, Rect * dst, Rect * src)
	{
		if(SDL_BlitSurface(objsrc.Buffer, (SDL_Rect *) src, Buffer, (SDL_Rect *) dst) == FAIL)
		{
			return SURFACE_ERROR_COPY;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies a source surface into the object.
	//--------------------------------------------------------------------------------------
	UINT Surface::Copy (const Surface & objsrc, int x, int y, Rect * src)
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = objsrc.Buffer->w;
			dst.h = objsrc.Buffer->h;
		}

		if(SDL_BlitSurface(objsrc.Buffer, (SDL_Rect *) src, Buffer, &dst) == FAIL)
		{
			return SURFACE_ERROR_COPY;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the object into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Surface::Paste (Surface & objdst, Rect * dst, Rect * src) const
	{
		if(SDL_BlitSurface(Buffer, (SDL_Rect *) src, objdst.Buffer, (SDL_Rect *) dst) == FAIL)
		{
			return SURFACE_ERROR_PASTE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the object into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Surface::Paste (Surface & objdst, int x, int y, Rect * src) const
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = objdst.Buffer->w;
			dst.h = objdst.Buffer->h;
		}

		if(SDL_BlitSurface(Buffer, (SDL_Rect *) src, objdst.Buffer, &dst) == FAIL)
		{
			return SURFACE_ERROR_PASTE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies a source surface into the object.
	//--------------------------------------------------------------------------------------
	UINT Surface::Copy (SDL_Surface * srfsrc, Rect * dst, Rect * src)
	{
		if(SDL_BlitSurface(srfsrc, (SDL_Rect *) src, Buffer, (SDL_Rect *) dst) == FAIL)
		{
			return SURFACE_ERROR_COPY;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies a source surface into the object.
	//--------------------------------------------------------------------------------------
	UINT Surface::Copy (SDL_Surface * srfsrc, int x, int y, Rect * src)
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = srfsrc->w;
			dst.h = srfsrc->h;
		}

		if(SDL_BlitSurface(srfsrc, (SDL_Rect *) src, Buffer, &dst) == FAIL)
		{
			return SURFACE_ERROR_COPY;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the object into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Surface::Paste (SDL_Surface * srfdst, Rect * dst, Rect * src) const
	{
		if(SDL_BlitSurface(Buffer, (SDL_Rect *) src, srfdst, (SDL_Rect *) dst) == FAIL)
		{
			return SURFACE_ERROR_PASTE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the object into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Surface::Paste (SDL_Surface * srfdst, int x, int y, Rect * src) const
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = srfdst->w;
			dst.h = srfdst->h;
		}

		if(SDL_BlitSurface(Buffer, (SDL_Rect *) src, srfdst, &dst) == FAIL)
		{
			return SURFACE_ERROR_PASTE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

}
//******************************************************************************************
// Surface.cpp
//******************************************************************************************