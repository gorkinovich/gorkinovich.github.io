//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Surface.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _SURFACE_H_
#define _SURFACE_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Surface Errors
	//--------------------------------------------------------------------------------------
	const UINT SURFACE_ERROR_UNDEF         = 200; /**< Error indefinido en las funciones de Surface. */
	const UINT SURFACE_ERROR_CREATESURF    = 201; /**< Error al crear una superficie vac�a. */
	const UINT SURFACE_ERROR_SETCOLORKEY   = 202; /**< Error al establecer el color clave para las transparencias. */
	const UINT SURFACE_ERROR_DISPLAYFORMAT = 203; /**< Error al convertir la superficie al formato del buffer de pantalla. */
	const UINT SURFACE_ERROR_FILLRECT      = 204; /**< Error al rellenar una regi�n con un color. */
	const UINT SURFACE_ERROR_RWFROMFILE    = 205; /**< Error al leer un fichero con una imagen. */
	const UINT SURFACE_ERROR_UNKOWNFORMAT  = 206; /**< Error de formato de fichero desconocido. */
	const UINT SURFACE_ERROR_LOADINGFILE   = 207; /**< Error al tratar de cargar en la superficie los datos de la imagen. */
	const UINT SURFACE_ERROR_SAVINGFILE    = 208; /**< Error al tratar de salvar una superficie en un fichero. */
	const UINT SURFACE_ERROR_COPY          = 209; /**< Error al copiar una superficie a otra. */
	const UINT SURFACE_ERROR_PASTE         = 210; /**< Error al pegar una superficie en otra. */

	//--------------------------------------------------------------------------------------
	// Other constants
	//--------------------------------------------------------------------------------------
	const Uint32 COLOR_PINK = 0x00FF00FF;

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase para almacenar una imagen.
	/**
	 *  La clase Surface sirve para almacenar en memoria una imagen contenida en un fichero
	 *	BMP, PNG, TGA, JPG, PCX, GIF, TIF, PNM, XPM, XCF o LBM. Una vez almacenada podemos
	 *  manejarla para copiar regiones de una Surface a otra. Y a�adir algunos efectos.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class to store an image.
	/**
	 *  The Surface class serves to store in memory an image contained in a file BMP, PNG,
	 *  TGA, JPG, PCX, GIF, TIF, PNM, XPM, XCF or LBM. Once stored we can handle it to copy
	 *  regions from a Surface to another one. And to add some effects.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Surface
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			SDL_Surface * Buffer;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Surface.
			/**
			 *  Constructor por defecto de la clase Surface.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Surface class.
			/**
			 *  Constructor by defect of the Surface class. 
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#endif
			Surface ();
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Surface.
			/**
			 *  Constructor de la clase Surface, que crea una imagen en blanco.
			 *  @param w   Ancho de la imagen.
			 *  @param h   Alto de la imagen.
			 *  @param bpp Profundidad de color de la imagen.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Surface class.
			/**
			 *  Constructor of the Surface class, that creates a blank image.
			 *  @param w   Width of the image.
			 *  @param h   Height of the image.
			 *  @param bpp Depth of color of the image.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#endif
			Surface (int w, int h, int bpp);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Surface.
			/**
			 *  Constructor de la clase Surface, que carga un fichero.
			 *  @param file Ruta del fichero.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Surface class.
			/**
			 *  Constructor of the Surface class, that loads a file.
			 *  @param file Path of the file.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#endif
			Surface (const string & file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Surface.
			/**
			 *  Constructor de la clase Surface, que carga un fichero.
			 *  @param file Ruta del fichero.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Surface class.
			/**
			 *  Constructor of the Surface class, that loads a file.
			 *  @param file Path of the file.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#endif
			Surface (const char * file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Surface.
			/**
			 *  Constructor de la clase Surface, que recive una imagen.
			 *  @param surface La imagen.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Surface class.
			/**
			 *  Constructor of the Surface class, that receives an image.
			 *  @param surface The image.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#endif
			Surface (SDL_Surface * surface);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor copia de la clase Surface.
			/**
			 *  @param obj Objeto Surface a copiar.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Copy constructor of the Surface class.
			/**
			 *  @param obj Surface object to copy.
			 *  @see operator=(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#endif
			Surface (const Surface & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Operador = de la clase Surface.
			/**
			 *  Copia el objeto obj en el objeto actual, y este es devuelto.
			 *  @see Surface(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Operator = of the Surface class.
			/**
			 *  The obj object is copied in the actual object, and this is given back.
			 *  @see Surface(), ~Surface().
			 */
			//------------------------------------------------------------------------------
#endif
			virtual Surface & operator = (Surface & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Destructor de la clase Surface.
			/**
			 *  @see Surface(), operator=().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Destructor of the Surface class.
			/**
			 *  @see Surface(), operator=().
			 */
			//------------------------------------------------------------------------------
#endif
			~Surface ();
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para crear una imagen en blanco en la Surface.
			/**
			 *  Esta funci�n sirve para crear una imagen en blanco en la Surface.
			 *  @param w   Ancho de la imagen.
			 *  @param h   Alto de la imagen.
			 *  @param bpp Profundidad de color de la imagen.
			 *  @see Load(), Save(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_CREATESURF.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to create an image in target in the Surface.
			/**
			 *  This function serves to create a blank image in the Surface.
			 *  @param w   Width of the image.
			 *  @param h   Height of the image.
			 *  @param bpp Depth of color of the image.
			 *  @see Load(), Save(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_CREATESURF.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Create (int w, int h, int bpp);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner un color de transparencia a la imagen.
			/**
			 *  Esta funci�n sirve para que la imagen pueda tener transparencia.
			 *  @param color Color clave.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_SETCOLORKEY.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put a color of transparency to the image.
			/**
			 *  This function serves so that the image can have transparency.
			 *  @param color Key color.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_SETCOLORKEY.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT SetColorKey (Uint32 color = COLOR_PINK);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para transformar el formato de la imagen al de la pantalla.
			/**
			 *  Esta funci�n sirve para transformar el formato de la imagen almacenada en
			 *  la Surface, al mismo formato que tiene el buffer de pantalla.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_DISPLAYFORMAT.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to transform the format of the image to the one of the screen.
			/**
			 *  This function serves to transform the format of the stored image into the
			 *  Surface, to the same format that has the screen buffer.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_DISPLAYFORMAT.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Transform (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para rellenar con un color una regi�n de la imagen.
			/**
			 *  Esta funci�n sirve para rellenar una regi�n de la imagen, con un color.
			 *  @param color Color de relleno.
			 *  @param rect  Regi�n destino a rellenar.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_FILLRECT.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to fill up with a color a region of the image.
			/**
			 *  This function serves to fill up a region of the image, with a color.
			 *  @param color Fill color.
			 *  @param rect  Destination area to fill.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_FILLRECT.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Fill (Uint32 color, Rect * rect = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar una Surface de un fichero.
			/**
			 *  Esta funci�n sirve para cargar una Surface de un fichero.
			 *  @param file Ruta del fichero.
			 *  @see Create(), Save(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_RWFROMFILE, SURFACE_ERROR_UNKOWNFORMAT,
			 *          SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a Surface from a file.
			/**
			 *  This function serves to load a Surface from a file.
			 *  @param file Path of the file.
			 *  @see Create(), Save(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_RWFROMFILE, SURFACE_ERROR_UNKOWNFORMAT,
			 *          SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual UINT Load (const char * file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar una Surface de un fichero.
			/**
			 *  Esta funci�n sirve para cargar una Surface de un fichero.
			 *  @param file Ruta del fichero.
			 *  @see Create(), Save(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_RWFROMFILE, SURFACE_ERROR_UNKOWNFORMAT,
			 *          SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a Surface from a file.
			/**
			 *  This function serves to load a Surface from a file.
			 *  @param file Path of the file.
			 *  @see Create(), Save(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_RWFROMFILE, SURFACE_ERROR_UNKOWNFORMAT,
			 *          SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual inline UINT Load (const string & file)
			{
				return Load(file.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para salvar una Surface en un fichero BMP.
			/**
			 *  Esta funci�n sirve para salvar la Surface en un fichero BMP.
			 *  @param file Ruta del fichero.
			 *  @see Create(), Load(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to save a Surface in a file BMP.
			/**
			 *  This function serves to save the Surface in a file BMP.
			 *  @param file Path of the file.
			 *  @see Create(), Load(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual UINT Save (const char * file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para salvar una Surface en un fichero BMP.
			/**
			 *  Esta funci�n sirve para salvar la Surface en un fichero BMP.
			 *  @param file Ruta del fichero.
			 *  @see Create(), Load(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to save a Surface in a file BMP.
			/**
			 *  This function serves to save the Surface in a file BMP.
			 *  @param file Path of the file.
			 *  @see Create(), Load(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual inline UINT Save (const string & file)
			{
				return Save(file.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para liberar los datos del objeto Surface.
			/**
			 *  Esta funci�n sirve para liberar el contenido del objeto Surface.
			 *  @see Create(), Load(), Save().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to release the data of the Surface object.
			/**
			 *  This function serves to release the content of the Surface object.
			 *  @see Create(), Load(), Save().
			 */
			//------------------------------------------------------------------------------
#endif
			virtual void Free (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en la imagen una regi�n de una Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en una regi�n tambi�n determinada de la imagen.
			 *  @param objsrc Imagen origen.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in the image a region of a Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  region also determined of the image.
			 *  @param objsrc Source image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Copy (const Surface & objsrc, Rect * dst = NULL, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en la imagen una regi�n de una Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en unas coordenadas de la imagen.
			 *  @param objsrc Imagen origen.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in the image a region of a Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  coordinates of the image.
			 *  @param objsrc Source image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Copy (const Surface & objsrc, int x, int y, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la imagen en una Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la imagen, en
			 *  una regi�n tambi�n determinada de una imagen destino.
			 *  @param objdst Imagen destino.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the image in a Surface.
			/**
			 *  This function serves to copy a determined area of the image, in a region
			 *  also determined of a destination image.
			 *  @param objdst Destination image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (Surface & objdst, Rect * dst = NULL, Rect * src = NULL) const;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la imagen en una Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la imagen, en
			 *  unas coordenadas de una imagen destino.
			 *  @param objdst Imagen destino.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the image in a Surface.
			/**
			 *  This function serves to copy a determined area of the image, in a
			 *  coordinates of a destination image.
			 *  @param objdst Destination image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (Surface & objdst, int x, int y, Rect * src = NULL) const;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en la imagen una regi�n de una SDL_Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en una regi�n tambi�n determinada de la imagen.
			 *  @param srfsrc Imagen origen.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in the image a region of a SDL_Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  region also determined of the image.
			 *  @param srfsrc Source image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Copy (SDL_Surface * srfsrc, Rect * dst = NULL, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner en la imagen una regi�n de una SDL_Surface.
			/**
			 *  Esta funci�n sirve para poner una regi�n determinada de una imagen origen,
			 *  en unas coordenadas de la imagen.
			 *  @param srfsrc Imagen origen.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to put in the image a region of a SDL_Surface.
			/**
			 *  This function serves to put a region determined of an image origin, in a
			 *  coordinates of the image.
			 *  @param srfsrc Source image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_COPY.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Copy (SDL_Surface * srfsrc, int x, int y, Rect * src = NULL);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la imagen en una SDL_Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la imagen, en
			 *  una regi�n tambi�n determinada de una imagen destino.
			 *  @param srfdst Imagen destino.
			 *  @param dst    Regi�n destino.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the image in a SDL_Surface.
			/**
			 *  This function serves to copy a determined area of the image, in a region
			 *  also determined of a destination image.
			 *  @param srfdst Destination image.
			 *  @param dst    Destination area.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (SDL_Surface * srfdst, Rect * dst = NULL, Rect * src = NULL) const;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para copiar una regi�n de la imagen en una SDL_Surface.
			/**
			 *  Esta funci�n sirve para copiar una regi�n determinada de la imagen, en
			 *  unas coordenadas de una imagen destino.
			 *  @param srfdst Imagen destino.
			 *  @param x      Coordenada x.
			 *  @param y      Coordenada y.
			 *  @param src    Regi�n origen.
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to copy a region of the image in a SDL_Surface.
			/**
			 *  This function serves to copy a determined area of the image, in a
			 *  coordinates of a destination image.
			 *  @param srfdst Destination image.
			 *  @param x      Coordinate x.
			 *  @param y      Coordinate y.
			 *  @param src    Source area.
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_PASTE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Paste (SDL_Surface * srfdst, int x, int y, Rect * src = NULL) const;


			friend class Graphics;
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Surface.h
//******************************************************************************************