//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Input.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _INPUT_H_
#define _INPUT_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Keys.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Input Errors
	//--------------------------------------------------------------------------------------
	const UINT INPUT_ERROR_UNDEF       = 400; /**< Error indefinido en las funciones de Input. */
	const UINT INPUT_ERROR_GETKEYSTATE = 401; /**< Error al obtener el estado de las teclas. */

	//--------------------------------------------------------------------------------------
	// Mouse Buttons
	//--------------------------------------------------------------------------------------
	const int LEFT_BUTTON   = 1; /**< Bot�n izquierdo del rat�n. */
	const int MIDDLE_BUTTON = 2; /**< Bot�n central del rat�n. */
	const int RIGHT_BUTTON  = 3; /**< Bot�n derecho del rat�n. */
	const int WHEEL_UP      = 4; /**< La rueda del rat�n se mueve hacia arriba. */
	const int WHEEL_DOWN    = 5; /**< La rueda del rat�n se mueve hacia abajo. */

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase que gestiona el sistema de entrada.
	/**
	 *  La clase Input gestiona los temas relacionados con el sistema de entrada. Estos
	 *  basicamente son, manejar y controlar el teclado y el rat�n.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class that manages the input system.
	/**
	 *  The Input class manages the subjects related to the entrance system. These
	 *  basically are, to handle and to control the keyboard and the mouse.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Input
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			static Input * Instance;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			byte * Keyboard;

			int  X;  // Mouse's X coordinate.
			int  Y;  // Mouse's Y coordinate.
			int  RX; // Mouse's relative X coordinate.
			int  RY; // Mouse's relative Y coordinate
			bool LB; // Left button's state.
			bool MB; // Middle button's state.
			bool RB; // Right button's state.
			bool WU; // Wheel up.
			bool WD; // Wheel down.

			Input ();
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para inicializar el objeto Input.
			/**
			 *  Esta funci�n sirve para inicializar el objeto Input.
			 *  @see Release().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          INPUT_ERROR_GETKEYSTATE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to initialize the object Input.
			/**
			 *  This function serves to initialize the object Input.
			 *  @see Release().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          INPUT_ERROR_GETKEYSTATE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Init (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para finalizar el objeto Input.
			/**
			 *  Esta funci�n sirve para finalizar el objeto Input.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to finalize the object Input.
			/**
			 *  This function serves to finalize the object Input.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#endif
			void Release (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para actualizar el estado de la entrada.
			/**
			 *  Esta funci�n sirve para actualizar el estado de la entrada.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to update the state of the input.
			/**
			 *  This function serves to update the state of the input.
			 */
			//------------------------------------------------------------------------------
#endif
			void Update (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si una tecla est� pulsada.
			/**
			 *  Esta funci�n sirve para preguntar si una tecla est� pulsada.
			 *  @param key La tecla en cuesti�n.
			 *  @see KbHit().
			 *  @return Si devuelve true, es que la tecla est� pulsada.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if a key is pressed.
			/**
			 *  This function serves to ask if a key is pressed.
			 *  @param key The key to ask.
			 *  @see KbHit().
			 *  @return If it gives back true, the key is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool GetKey (int key) const
			{
				return (Keyboard[key] == 1);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si el teclado est� pulsado.
			/**
			 *  Esta funci�n sirve para preguntar si el teclado est� pulsado.
			 *  @see GetKey().
			 *  @return Si devuelve true, es que la teclado est� pulsado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if the keyboard is pressed.
			/**
			 *  This function serves to ask if the keyboard is pressed.
			 *  @see GetKey().
			 *  @return If it gives back true, the keyboard is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			bool KbHit (void) const;
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para activar la repetici�n de pulsaciones.
			/**
			 *  Esta funci�n sirve para activar la repetici�n de pulsaciones.
			 *  @param delay    Tiempo en ms de espera para empezar las repeticiones.
			 *  @param interval Tiempo en ms entre repetici�n y repetici�n.
			 *  @see DisableKeyRepeat().
			 *  @return Si todo va bien devuelve true, sino devuelve false.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to activate the repetition of pulsations.
			/**
			 *  This function serves to activate the repetition of pulsations.
			 *  @param delay    Time in ms of delay to begin the repetitions.
			 *  @param interval Time in ms between repetition and repetition.
			 *  @see DisableKeyRepeat().
			 *  @return If everything goes well returns true, on errors returns false.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool EnableKeyRepeat (int delay, int interval)
			{
				return (SDL_EnableKeyRepeat(delay, interval) != FAIL);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para desactivar la repetici�n de pulsaciones.
			/**
			 *  Esta funci�n sirve para desactivar la repetici�n de pulsaciones.
			 *  @see EnableKeyRepeat().
			 *  @return Si todo va bien devuelve true, sino devuelve false.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to deactivate the repetition of pulsations.
			/**
			 *  This function serves to deactivate the repetition of pulsations.
			 *  @see EnableKeyRepeat().
			 *  @return If everything goes well returns true, on errors returns false.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool DisableKeyRepeat (void)
			{
				return (SDL_EnableKeyRepeat(0, 0) != FAIL);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la coordenada X del rat�n.
			/**
			 *  Esta funci�n sirve para obtener la coordenada X del rat�n.
			 *  @see GetMouseY(), GetMouseRelX(), GetMouseRelY().
			 *  @return La coordenada X del rat�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the coordinate X of the mouse.
			/**
			 *  This function serves to obtain the coordinate X of the mouse.
			 *  @see GetMouseY(), GetMouseRelX(), GetMouseRelY().
			 *  @return The coordinate X of the mouse.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetMouseX (void) const
			{
				return X;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la coordenada Y del rat�n.
			/**
			 *  Esta funci�n sirve para obtener la coordenada Y del rat�n.
			 *  @see GetMouseX(), GetMouseRelX(), GetMouseRelY().
			 *  @return La coordenada Y del rat�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the coordinate Y of the mouse.
			/**
			 *  This function serves to obtain the coordinate Y of the mouse.
			 *  @see GetMouseX(), GetMouseRelX(), GetMouseRelY().
			 *  @return The coordinate Y of the mouse.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetMouseY (void) const
			{
				return Y;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la coordenada relativa X del rat�n.
			/**
			 *  Esta funci�n sirve para obtener la coordenada relativa X del rat�n.
			 *  @see GetMouseX(), GetMouseY(), GetMouseRelY().
			 *  @return La coordenada relativa X del rat�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the relative coordinate X of the mouse.
			/**
			 *  This function serves to obtain the relative coordinate X of the mouse.
			 *  @see GetMouseX(), GetMouseY(), GetMouseRelY().
			 *  @return The relative coordinate X of the mouse.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetMouseRelX (void) const
			{
				return RX;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la coordenada relativa Y del rat�n.
			/**
			 *  Esta funci�n sirve para obtener la coordenada relativa Y del rat�n.
			 *  @see GetMouseX(), GetMouseY(), GetMouseRelX().
			 *  @return La coordenada relativa Y del rat�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the relative coordinate Y of the mouse.
			/**
			 *  This function serves to obtain the relative coordinate Y of the mouse.
			 *  @see GetMouseX(), GetMouseY(), GetMouseRelX().
			 *  @return The relative coordinate Y of the mouse.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetMouseRelY (void) const
			{
				return RY;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si un bot�n del rat�n est� pulsado.
			/**
			 *  Esta funci�n sirve para preguntar si un bot�n del rat�n est� pulsado.
			 *  @param button El bot�n en cuesti�n.
			 *  @see LeftButton(), MiddleButton(), RightButton(), WheelUp(), WheelDown().
			 *  @return Si devuelve true, es que el bot�n est� pulsado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if a button of the mouse is pressed.
			/**
			 *  This function serves to ask if a button of the mouse is pressed.
			 *  @param button The button to ask.
			 *  @see LeftButton(), MiddleButton(), RightButton(), WheelUp(), WheelDown().
			 *  @return If it gives back true, the button is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool MouseButton (int button) const
			{
				switch(button)
				{
				case LEFT_BUTTON:
					return LB;

				case MIDDLE_BUTTON:
					return MB;

				case RIGHT_BUTTON:
					return RB;

				case WHEEL_UP:
					return WU;

				case WHEEL_DOWN:
					return WD;
				}

				return false;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si el bot�n izquierdo del rat�n est� pulsado.
			/**
			 *  Esta funci�n sirve para preguntar si el bot�n izquierdo est� pulsado.
			 *  @see MouseButton(), MiddleButton(), RightButton(), WheelUp(), WheelDown().
			 *  @return Si devuelve true, es que el bot�n est� pulsado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if the left button of the mouse is pressed.
			/**
			 *  This function serves to ask if the left button of the mouse is pressed.
			 *  @see MouseButton(), MiddleButton(), RightButton(), WheelUp(), WheelDown().
			 *  @return If it gives back true, the button is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool LeftButton (void) const
			{
				return LB;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si el bot�n central del rat�n est� pulsado.
			/**
			 *  Esta funci�n sirve para preguntar si el bot�n central est� pulsado.
			 *  @see MouseButton(), LeftButton(), RightButton(), WheelUp(), WheelDown().
			 *  @return Si devuelve true, es que el bot�n est� pulsado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if the middle button of the mouse is pressed.
			/**
			 *  This function serves to ask if the middle button of the mouse is pressed.
			 *  @see MouseButton(), LeftButton(), RightButton(), WheelUp(), WheelDown().
			 *  @return If it gives back true, the button is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool MiddleButton (void) const
			{
				return MB;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si el bot�n derecho del rat�n est� pulsado.
			/**
			 *  Esta funci�n sirve para preguntar si el bot�n derecho est� pulsado.
			 *  @see MouseButton(), LeftButton(), MiddleButton(), WheelUp(), WheelDown().
			 *  @return Si devuelve true, es que el bot�n est� pulsado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if the right button of the mouse is pressed.
			/**
			 *  This function serves to ask if the right button of the mouse is pressed.
			 *  @see MouseButton(), LeftButton(), MiddleButton(), WheelUp(), WheelDown().
			 *  @return If it gives back true, the button is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool RightButton (void) const
			{
				return RB;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si el WheelUp del rat�n est� pulsado.
			/**
			 *  Esta funci�n sirve para preguntar si el WheelUp del rat�n est� pulsado.
			 *  @see MouseButton(), LeftButton(), MiddleButton(), RightButton(), WheelDown().
			 *  @return Si devuelve true, es que el bot�n est� pulsado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if the WheelUp of the mouse is pressed.
			/**
			 *  This function serves to ask if the WheelUp of the mouse is pressed.
			 *  @see MouseButton(), LeftButton(), MiddleButton(), RightButton(), WheelDown().
			 *  @return If it gives back true, the button is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool WheelUp (void) const
			{
				return WU;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si el WheelDown del rat�n est� pulsado.
			/**
			 *  Esta funci�n sirve para preguntar si el WheelDown del rat�n est� pulsado.
			 *  @see MouseButton(), LeftButton(), MiddleButton(), RightButton(), WheelUp().
			 *  @return Si devuelve true, es que el bot�n est� pulsado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if the WheelDown of the mouse is pressed.
			/**
			 *  This function serves to ask if the WheelDown of the mouse is pressed.
			 *  @see MouseButton(), LeftButton(), MiddleButton(), RightButton(), WheelUp().
			 *  @return If it gives back true, the button is pressed.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool WheelDown (void) const
			{
				return WD;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si el rat�n est� en una regi�n.
			/**
			 *  Esta funci�n sirve para preguntar si el rat�n est� en una regi�n.
			 *  @param rect La regi�n en cuesti�n.
			 *  @return Si devuelve true, es que el rat�n est� en la regi�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if the mouse is inside a region.
			/**
			 *  This function serves to ask if the mouse is inside a region.
			 *  @param rect The region to ask.
			 *  @return If it gives back true, the mouse is inside that region.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool MouseInRect (Rect * rect)
			{
				return (rect->x <= X) && (X <= (rect->x + rect->w - 1)) &&
					   (rect->y <= Y) && (Y <= (rect->y + rect->h - 1));
			}

#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la instancia de Input.
			/**
			 *  Esta funci�n crea una instancia de Input, en caso de no estar creada, y
			 *  devuelve un puntero a esta si tiene exito pidiendo memoria.
			 *  @return Devuelve un puntero al objeto Input si todo ha ido bien, en caso de
			 *          no haber memoria para el objeto devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the instance of Input.
			/**
			 *  This function creates an instance of Input, in case of not being created,
			 *  and gives back a pointer of this if memory is successful requesting.
			 *  @return It gives back to a pointer to the object Input if everything has
			 *          gone well, if there is no memory for the object, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			static Input * GetInstance (void);
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Input.h
//******************************************************************************************