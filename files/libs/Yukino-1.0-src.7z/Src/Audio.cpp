//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Audio.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifdef WIN32
	#pragma comment (lib, "SDL_mixer.lib")
#endif
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Audio.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Global static members of the audio class.
	//--------------------------------------------------------------------------------------
	Audio * Audio::Instance = NULL;
	
	//--------------------------------------------------------------------------------------
	// Audio constructor.
	//--------------------------------------------------------------------------------------
	Audio::Audio ()
	{
		Frequency   = 0;
		Format      = 0;
		NumChannels = 0;
	}

	//--------------------------------------------------------------------------------------
	// This function initializes the audio object.
	//--------------------------------------------------------------------------------------
	UINT Audio::Init (int frequency, word format, int channels, int chunksize)
	{
		if(Mix_OpenAudio(frequency, format, channels, chunksize) == FAIL)
		{
			return AUDIO_ERROR_OPEN;
		}

		if(Mix_QuerySpec(&Frequency, &Format, &NumChannels) == 0)
		{
			return AUDIO_ERROR_QUERYSPEC;
		}

		if((frequency != Frequency) || (format != Format) || (channels != NumChannels))
		{
			return AUDIO_ERROR_NOTEQU;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function releases the audio object.
	//--------------------------------------------------------------------------------------
	void Audio::Release (void)
	{
		Mix_CloseAudio();
	}

	//--------------------------------------------------------------------------------------
	// This function sets the number of channels.
	//--------------------------------------------------------------------------------------
	UINT Audio::SetNumChannels (int channels)
	{
		NumChannels = Mix_AllocateChannels(channels);

		if(NumChannels != channels)
		{
			return AUDIO_ERROR_ALLOCATE;
		}
		
		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function sets the volume.
	//--------------------------------------------------------------------------------------
	UINT SetVolume (int volume)
	{
		if(Mix_Volume(NO_CHANNEL, volume) != volume)
		{
			return AUDIO_ERROR_SETVOLUME;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function sets the channel's volume.
	//--------------------------------------------------------------------------------------
	UINT Audio::SetChannelVolume (int channel, int volume)
	{
		if(Mix_Volume(channel, volume) != volume)
		{
			return AUDIO_ERROR_SETVOLUME;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function sets the channel's panning.
	//--------------------------------------------------------------------------------------
	UINT Audio::SetChannelPan (int channel, byte left, byte right)
	{
		if(Mix_SetPanning(channel, left, right) == 0)
		{
			return AUDIO_ERROR_SETPAN;
		}

		return EVERYTHING_ALL_RIGHT;
	}
		
	//--------------------------------------------------------------------------------------
	// This function deletes the channel's panning.
	//--------------------------------------------------------------------------------------
	UINT Audio::DelChannelPan (int channel)
	{
		if(Mix_SetPanning(channel, PAN_LOUD, PAN_LOUD) == 0)
		{
			return AUDIO_ERROR_SETPAN;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function plays the sound.
	//--------------------------------------------------------------------------------------
	UINT Audio::PlaySound (Sound & snd, int loops)
	{
		snd.Channel = Mix_PlayChannel(RANDOM_CHANNEL, snd.Buffer, loops);

		if(snd.Channel == NO_CHANNEL)
		{
			return AUDIO_ERROR_PLAYSOUND;
		}
		
		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function plays the sound.
	//--------------------------------------------------------------------------------------
	UINT Audio::PlaySound (Sound & snd, int channel, int loops)
	{
		snd.Channel = Mix_PlayChannel(channel, snd.Buffer, loops);

		if(snd.Channel == NO_CHANNEL)
		{
			return AUDIO_ERROR_PLAYSOUND;
		}
		
		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function fades in the sound.
	//--------------------------------------------------------------------------------------
	UINT Audio::FadeInSound (Sound & snd, int ms, int loops)
	{
		snd.Channel = Mix_FadeInChannel(RANDOM_CHANNEL, snd.Buffer, loops, ms);

		if(snd.Channel == NO_CHANNEL)
		{
			return AUDIO_ERROR_FADEINSOUND;
		}
		
		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function fades in the sound.
	//--------------------------------------------------------------------------------------
	UINT Audio::FadeInSound (Sound & snd, int ms, int channel, int loops)
	{
		snd.Channel = Mix_FadeInChannel(channel, snd.Buffer, loops, ms);

		if(snd.Channel == NO_CHANNEL)
		{
			return AUDIO_ERROR_FADEINSOUND;
		}
		
		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// The audio class GetInstance function.
	//--------------------------------------------------------------------------------------
	Audio * Audio::GetInstance (void)
	{
		if(Audio::Instance == NULL)
			Audio::Instance = new Audio();

		return Audio::Instance;
	}
}
//******************************************************************************************
// Audio.cpp
//******************************************************************************************