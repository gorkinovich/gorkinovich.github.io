//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Sprite.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "Sprite.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// tSpriteHeader struct.
	//--------------------------------------------------------------------------------------
	typedef struct
	{
		char  FileID[14]; // "YUKINO_SPRITE"
		char  TexName[255];
		dword FPS;
		int   NumFrames;
	} tSpriteHeader;

	//--------------------------------------------------------------------------------------
	// Sprite constructor.
	//--------------------------------------------------------------------------------------
	Sprite::Sprite () : Surface()
	{
		Frames.assign(0);

		ActualFrame = 0;
		MaxTime     = 0;
		ActTime     = 0;
		FPS         = 0;
	}

	//--------------------------------------------------------------------------------------
	// Sprite constructor that create a new blank buffer.
	//--------------------------------------------------------------------------------------
	Sprite::Sprite (int w, int h, int bpp, dword fps, int cols, int rows)
	{
		Frames.assign(0);

		Create(w, h, bpp, fps, cols, rows);
	}

	//--------------------------------------------------------------------------------------
	// Sprite constructor that create a new blank buffer.
	//--------------------------------------------------------------------------------------
	Sprite::Sprite (int w, int h, int bpp, dword fps, vector<RectAux> & frames)
	{
		Frames.assign(0);

		Create(w, h, bpp, fps, frames);
	}

	//--------------------------------------------------------------------------------------
	// Sprite constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Sprite::Sprite (const string & file)
	{
		Frames.assign(0);

		Sprite::Load(file.c_str());
	}

	//--------------------------------------------------------------------------------------
	// Sprite constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Sprite::Sprite (const char * file)
	{
		Frames.assign(0);

		Sprite::Load(file);
	}

	//--------------------------------------------------------------------------------------
	// Sprite constructor.
	//--------------------------------------------------------------------------------------
	Sprite::Sprite (const Sprite & obj)
	{
		//----------------------------------------------------------------------------------
		// Surface data.
		//----------------------------------------------------------------------------------
		Buffer = NULL;

		if(!Surface::Create(obj.Buffer->w, obj.Buffer->h, obj.Buffer->format->BitsPerPixel))
		{
			Copy(obj);
		}
		
		//----------------------------------------------------------------------------------
		// Sprite data.
		//----------------------------------------------------------------------------------
		Frames = obj.Frames;

		ActualFrame = obj.ActualFrame;
		MaxTime     = obj.MaxTime;
		ActTime     = obj.ActTime;
		FPS         = obj.FPS;
	}

	//--------------------------------------------------------------------------------------
	// Sprite operator =, that copies one object in other.
	//--------------------------------------------------------------------------------------
	Sprite & Sprite::operator = (Sprite & obj)
	{
		//----------------------------------------------------------------------------------
		// Surface data.
		//----------------------------------------------------------------------------------
		Free();

		if(!Surface::Create(obj.Buffer->w, obj.Buffer->h, obj.Buffer->format->BitsPerPixel))
		{
			Copy(obj);
		}

		//----------------------------------------------------------------------------------
		// Sprite data.
		//----------------------------------------------------------------------------------
		Frames = obj.Frames;

		ActualFrame = obj.ActualFrame;
		MaxTime     = obj.MaxTime;
		ActTime     = obj.ActTime;
		FPS         = obj.FPS;

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	// Sprite destructor.
	//--------------------------------------------------------------------------------------
	Sprite::~Sprite ()
	{
		Free();
	}
	
	//--------------------------------------------------------------------------------------
	// This function initializes de Frames vector.
	//--------------------------------------------------------------------------------------
	inline void Sprite::InitFrames (void)
	{
		Rect aux = {0, 0, 0, 0};

		for(int i = 0; i < Frames.size(); ++i)
		{
			Frames[i] = aux;
		}
	}

	//--------------------------------------------------------------------------------------
	// This function creates a new blank buffer.
	//--------------------------------------------------------------------------------------
	UINT Sprite::Create (int w, int h, int bpp, dword fps, int cols, int rows)
	{
		SetNumFrames(cols, rows);
		InitFrames();

		SetActFrame(0);
		ResetTime();
		SetFPS(fps);

		return Surface::Create(w, h, bpp);
	}

	//--------------------------------------------------------------------------------------
	// This function creates a new blank buffer.
	//--------------------------------------------------------------------------------------
	UINT Sprite::Create (int w, int h, int bpp, dword fps, vector<RectAux> & frames)
	{
		SetFrames(frames);

		SetActFrame(0);
		ResetTime();
		SetFPS(fps);

		return Surface::Create(w, h, bpp);
	}

	//--------------------------------------------------------------------------------------
	// This function loads a sprite from a file.
	//--------------------------------------------------------------------------------------
	UINT Sprite::Load (const char * file)
	{
		//----------------------------------------------------------------------------------
		// Open the file.
		//----------------------------------------------------------------------------------
		FILE * f = fopen(file, "rb");

		if(f == NULL)
		{
			return SPRITE_ERROR_FOPEN;
		}

		//----------------------------------------------------------------------------------
		// Read the header of the file.
		//----------------------------------------------------------------------------------
		tSpriteHeader header;

		if(fread(&header, sizeof(header), 1, f) == 0)
		{
			fclose(f);
			return SPRITE_ERROR_READHEADER;
		}

		//----------------------------------------------------------------------------------
		// Test if the file ID is the same.
		//----------------------------------------------------------------------------------
		if(strcmp(header.FileID, SPRITE_FILEID) != STR_EQU)
		{
			fclose(f);
			return SPRITE_ERROR_WRONGFID;
		}

		//----------------------------------------------------------------------------------
		// Read the frames of the sprite.
		//----------------------------------------------------------------------------------
		SetNumFrames(header.NumFrames);

		for(int i = 0; i < Frames.size(); ++i)
		{
			Rect rect;
			fread(&rect, sizeof(rect), 1, f);

			Frames[i].rect = rect;
		}

		//----------------------------------------------------------------------------------
		// Set the FPS.
		//----------------------------------------------------------------------------------
		SetFPS(header.FPS);

		fclose(f);

		//----------------------------------------------------------------------------------
		// Load the surface.
		//----------------------------------------------------------------------------------
		return Surface::Load(header.TexName);
	}

	//--------------------------------------------------------------------------------------
	// This function saves a sprite in a file.
	//--------------------------------------------------------------------------------------
	UINT Sprite::Save (const char * file, const char * texture)
	{
		//----------------------------------------------------------------------------------
		// Open the file.
		//----------------------------------------------------------------------------------
		FILE * f = fopen(file, "wb");

		if(f == NULL)
		{
			return SPRITE_ERROR_FOPEN;
		}

		//----------------------------------------------------------------------------------
		// Write the header in the file.
		//----------------------------------------------------------------------------------
		tSpriteHeader header;

		strcpy(header.FileID, SPRITE_FILEID);
		strcpy(header.TexName, texture);

		header.NumFrames = Frames.size();
		header.FPS       = FPS;
		
		if(fwrite(&header, sizeof(header), 1, f) == 0)
		{
			fclose(f);
			return SPRITE_ERROR_WRITEHEADER;
		}

		//----------------------------------------------------------------------------------
		// Write the frames in the file.
		//----------------------------------------------------------------------------------
		for(int i = 0; i < Frames.size(); ++i)
		{
			Rect rect;

			rect = Frames[i].rect;

			fwrite(&rect, sizeof(rect), 1, f);

		}

		fclose(f);

		//----------------------------------------------------------------------------------
		// Save the surface.
		//----------------------------------------------------------------------------------
		return Surface::Save(file);
	}

	//--------------------------------------------------------------------------------------
	// This function unloads the sprite.
	//--------------------------------------------------------------------------------------
	void Sprite::Free (void)
	{
		Frames.clear();

		ActualFrame = 0;
		MaxTime     = 0;
		ActTime     = 0;
		FPS         = 0;

		Surface::Free();
	}
}
//******************************************************************************************
// Sprite.cpp
//******************************************************************************************