//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Yukino.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _YUKINO_H_
#define _YUKINO_H_
//******************************************************************************************
#ifdef WIN32
	#pragma comment (lib, "kernel32.lib")
	#pragma comment (lib, "user32.lib")
	#pragma comment (lib, "SDL.lib")
	#pragma comment (lib, "SDLmain.lib")
	#pragma comment (lib, "SDL_Mixer.lib")
#endif
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Surface.h"
#include "Sprite.h"
#include "Font.h"
#include "Graphics.h"
#include "Input.h"
#include "Sound.h"
#include "Audio.h"
#include "Script.h"
#include "Core.h"
//******************************************************************************************
#endif
//******************************************************************************************
// Yukino.h
//******************************************************************************************