//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Audio.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _AUDIO_H_
#define _AUDIO_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Sound.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Audio Errors
	//--------------------------------------------------------------------------------------
	const UINT AUDIO_ERROR_UNDEF       = 500; /**< Error indefinido en las funciones de Audio. */
	const UINT AUDIO_ERROR_OPEN        = 501; /**< Error al abrir los canales de audio. */
	const UINT AUDIO_ERROR_QUERYSPEC   = 502; /**< Error al preguntar las propiedades del audio. */
	const UINT AUDIO_ERROR_NOTEQU      = 503; /**< Error las propiedades finales del audio no son las deseadas. */
	const UINT AUDIO_ERROR_ALLOCATE    = 504; /**< Error al intentar reservar nuevos canales de audio. */
	const UINT AUDIO_ERROR_PLAYSOUND   = 505; /**< Error al reproducir un sonido. */
	const UINT AUDIO_ERROR_SETVOLUME   = 506; /**< Error al cambiar el volumen del audio. */
	const UINT AUDIO_ERROR_SETPAN      = 507; /**< Error al cambiar el panning de un canal. */
	const UINT AUDIO_ERROR_FADEINSOUND = 508; /**< Error al hacer un fade in de un sonido. */

	//--------------------------------------------------------------------------------------
	// Audio constants
	//--------------------------------------------------------------------------------------
	const int  DEFAULT_FREQUENCY22  = 22050;     /**< Frecuencia de 22050 Hz. */
	const int  DEFAULT_FREQUENCY44  = 44100;     /**< Frecuencia de 44100 Hz. */
	const word DEFAULT_FORMAT       = AUDIO_S16; /**< Formato de audio por defecto. */
	const int  DEFAULT_NUM_CHANNELS = 2;         /**< N�mero de canales por defecto. */
	const int  DEFAULT_CHUNKSIZE    = 4096;      /**< Tama�o por defecto del buffer de audio. */

	const int MAX_VOLUME = 128; /**< Volumen m�ximo. */
	const int MIN_VOLUME =   0; /**< Volumen m�nimo. */

	const byte PAN_SILENCE =   0; /**< Panning m�nimo. */
	const byte PAN_LOUD    = 255; /**< Panning m�ximo. */
	
	const int INFINITE_LOOPS = -1; /**< Para reproducir un sonido infinitas veces. */
	const int PLAY_ONCE      =  0; /**< Para reproducir un sonido una sola vez. */
	const int RANDOM_CHANNEL = -1; /**< Para reproducir un sonido en una canal aleatorio. */

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase que gestiona el sistema de audio.
	/**
	 *  La clase Audio gestiona los temas relacionados con el sistema de audio, tales como
	 *  manejar los canales de la aplicaci�n. Pudiendo reproducir, pausar o parar sonidos
	 *  en dichos canales, y otros efectos como el fade in y el fade out.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class that manages the audio system.
	/**
	 *  The Audio class manages the subjects related to the system of audio, such as to
	 *  handle the channels of the application. Being able to reproduce, to pause or to
	 *  stop sounds in these channels, and other effects like fade in and fade out.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Audio
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			static Audio * Instance;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			int  Frequency;
			word Format;
			int  NumChannels;

			Audio ();
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para inicializar el objeto Audio.
			/**
			 *  Esta funci�n sirve para inicializar el objeto Audio, pas�ndole la
			 *  frecuencia, el formato, el n�mero de canales y el tama�o del buffer.
			 *  @param frequency Frecuencia del audio.
			 *  @param format    Formato del audio.
			 *  @param channels  N�mero de canales del audio.
			 *  @param chunksize Tama�o del buffer del audio.
			 *  @see Release().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_OPEN, AUDIO_ERROR_QUERYSPEC, AUDIO_ERROR_NOTEQU.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to initialize the object Audio.
			/**
			 *  This function serves to initialize the object Audio, passing to him the
			 *  frequency, the format, the number of channels and the buffer's size.
			 *  @param frequency Audio's frequency.
			 *  @param format    Audio's format.
			 *  @param channels  Audio's channels's number.
			 *  @param chunksize Audio's buffer's size.
			 *  @see Release().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_OPEN, AUDIO_ERROR_QUERYSPEC, AUDIO_ERROR_NOTEQU.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Init (int frequency, word format, int channels, int chunksize);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para finalizar el objeto Audio.
			/**
			 *  Esta funci�n sirve para finalizar el objeto Audio.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to finalize the object Audio.
			/**
			 *  This function serves to finalize the object Audio.
			 *  @see Init().
			 */
			//------------------------------------------------------------------------------
#endif
			void Release (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el n�mero de canales del audio.
			/**
			 *  Esta funci�n sirve para cambiar el n�mero de canales del audio.
			 *  @param channels Nuevo n�mero de canales.
			 *  @see GetNumChannels().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_ALLOCATE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the number of channels of the audio.
			/**
			 *  This function serves to change the number of channels of the audio.
			 *  @param channels Number of new channels.
			 *  @see GetNumChannels().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_ALLOCATE.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT SetNumChannels (int channels);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el n�mero de canales del audio.
			/**
			 *  Esta funci�n sirve para obtener el n�mero de canales del audio.
			 *  @see SetNumChannels().
			 *  @return El n�mero de canales del audio.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the number of channels of the audio.
			/**
			 *  This function serves to obtain the number of channels of the audio.
			 *  @see SetNumChannels().
			 *  @return The number of channels of the audio.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetNumChannels (void)
			{
				return NumChannels;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el formato del audio.
			/**
			 *  Esta funci�n sirve para obtener el formato del audio.
			 *  @return El formato del audio.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the format of the audio.
			/**
			 *  This function serves to obtain the format of the audio.
			 *  @return The format of the audio.
			 */
			//------------------------------------------------------------------------------
#endif
			inline word GetFormat (void)
			{
				return Format;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la frecuencia del audio.
			/**
			 *  Esta funci�n sirve para obtener la frecuencia del audio.
			 *  @return La frecuencia del audio.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the frequency of the audio.
			/**
			 *  This function serves to obtain the frequency of the audio.
			 *  @return The frequency of the audio.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetFrequency (void)
			{
				return Frequency;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el volumen del audio.
			/**
			 *  Esta funci�n sirve para cambiar el volumen del audio.
			 *  @param volume Nuevo volumen.
			 *  @see GetVolume().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_SETVOLUME.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the volume of the audio.
			/**
			 *  This function serves to change the volume of the audio.
			 *  @param volume New volume.
			 *  @see GetVolume().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_SETVOLUME.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT SetVolume (int volume);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el volumen del audio.
			/**
			 *  Esta funci�n sirve para obtener el volumen del audio.
			 *  @see SetVolume().
			 *  @return El volumen del audio.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the volume of the audio.
			/**
			 *  This function serves to obtain the volume of the audio.
			 *  @see SetVolume().
			 *  @return The volume of the audio.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetVolume (void)
			{
				return Mix_Volume(NO_CHANNEL, -1);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el volumen de un canal.
			/**
			 *  Esta funci�n sirve para cambiar el volumen de un canal.
			 *  @param channel N�mero de canal.
			 *  @param volume  Nuevo volumen.
			 *  @see GetChannelVolume().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_SETVOLUME.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the volume of a channel.
			/**
			 *  This function serves to change the volume of a channel.
			 *  @param channel Channel number.
			 *  @param volume  New volume.
			 *  @see GetChannelVolume().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_SETVOLUME.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT SetChannelVolume (int channel, int volume);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el volumen de un canal.
			/**
			 *  Esta funci�n sirve para obtener el volumen de un canal.
			 *  @param channel N�mero de canal.
			 *  @see SetChannelVolume().
			 *  @return El volumen de un canal.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the volume of a channel.
			/**
			 *  This function serves to obtain the volume of a channel.
			 *  @param channel Channel number.
			 *  @see SetChannelVolume().
			 *  @return The volume of a channel.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetChannelVolume (int channel)
			{
				return Mix_Volume(channel, -1);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el panning de un canal.
			/**
			 *  Esta funci�n sirve para cambiar el panning de un canal.
			 *  @param channel N�mero de canal.
			 *  @param left    Nivel en la izquierda.
			 *  @param right   Nivel en la derecha.
			 *  @see DelChannelPan().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_SETPAN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the panning of a channel.
			/**
			 *  This function serves to change the panning of a channel.
			 *  @param channel Channel number.
			 *  @param left    Level in the left.
			 *  @param right   Level in the right.
			 *  @see DelChannelPan().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_SETPAN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT SetChannelPan (int channel, byte left, byte right);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para borrar el panning de un canal.
			/**
			 *  Esta funci�n sirve para borrar el panning de un canal.
			 *  @param channel N�mero de canal.
			 *  @see SetChannelPan().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_SETPAN.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to delete the panning of a channel.
			/**
			 *  This function serves to delete the panning of a channel.
			 *  @param channel Channel number.
			 *  @see SetChannelPan().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_SETPAN.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT DelChannelPan (int channel);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para reproducir un sonido en un canal.
			/**
			 *  Esta funci�n sirve para reproducir un sonido en un canal.
			 *  @param snd   Sonido para reproducir.
			 *  @param loops N�mero de repeticiones.
			 *  @see FadeInSound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_PLAYSOUND.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to play a sound in a channel.
			/**
			 *  This function serves to play a sound in a channel.
			 *  @param snd   Sound to play.
			 *  @param loops Number of loops.
			 *  @see FadeInSound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_PLAYSOUND.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT PlaySound (Sound & snd, int loops = PLAY_ONCE);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para reproducir un sonido en un canal.
			/**
			 *  Esta funci�n sirve para reproducir un sonido en un canal.
			 *  @param snd     Sonido para reproducir.
			 *  @param channel N�mero de canal.
			 *  @param loops   N�mero de repeticiones.
			 *  @see FadeInSound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_PLAYSOUND.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to play a sound in a channel.
			/**
			 *  This function serves to play a sound in a channel.
			 *  @param snd     Sound to play.
			 *  @param channel Channel number.
			 *  @param loops   Number of loops.
			 *  @see FadeInSound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_PLAYSOUND.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT PlaySound (Sound & snd, int channel, int loops);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para reproducir un sonido en un canal con fade in.
			/**
			 *  Esta funci�n sirve para reproducir un sonido en un canal con fade in.
			 *  @param snd   Sonido para reproducir.
			 *  @param ms    N�mero de milisegundos para el fade in.
			 *  @param loops N�mero de repeticiones.
			 *  @see PlaySound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_FADEINSOUND.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to play a sound in a channel with fade in.
			/**
			 *  This function serves to play a sound in a channel with fade in.
			 *  @param snd   Sound to play.
			 *  @param ms    Number of milliseconds for fade in.
			 *  @param loops Number of loops.
			 *  @see PlaySound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_FADEINSOUND.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT FadeInSound (Sound & snd, int ms, int loops = PLAY_ONCE);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para reproducir un sonido en un canal con fade in.
			/**
			 *  Esta funci�n sirve para reproducir un sonido en un canal con fade in.
			 *  @param snd     Sonido para reproducir.
			 *  @param ms      N�mero de milisegundos para el fade in.
			 *  @param channel N�mero de canal.
			 *  @param loops   N�mero de repeticiones.
			 *  @see PlaySound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          AUDIO_ERROR_FADEINSOUND.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to play a sound in a channel with fade in.
			/**
			 *  This function serves to play a sound in a channel with fade in.
			 *  @param snd     Sound to play.
			 *  @param ms      Number of milliseconds for fade in.
			 *  @param channel Channel number.
			 *  @param loops   Number of loops.
			 *  @see PlaySound(), PauseSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          AUDIO_ERROR_FADEINSOUND.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT FadeInSound (Sound & snd, int ms, int channel, int loops);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para pausar un sonido de un canal.
			/**
			 *  Esta funci�n sirve para pausar un sonido de un canal.
			 *  @param snd Sonido para pausar.
			 *  @see PlaySound(), FadeInSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to pause a sound of a channel.
			/**
			 *  This function serves to pause a sound of a channel.
			 *  @param snd Sound to pause.
			 *  @see PlaySound(), FadeInSound(), ResumeSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PauseSound (Sound & snd)
			{
				Mix_Pause(snd.Channel);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para pausar un canal.
			/**
			 *  Esta funci�n sirve para pausar un canal.
			 *  @param channel Canal para pausar.
			 *  @see ResumeChannel(), StopChannel(), FadeOutChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to pause a channel.
			/**
			 *  This function serves to pause a channel.
			 *  @param channel Channel to pause.
			 *  @see ResumeChannel(), StopChannel(), FadeOutChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PauseChannel (int channel)
			{
				Mix_Pause(channel);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para pausar el audio.
			/**
			 *  Esta funci�n sirve para pausar el audio.
			 *  @see ResumeAudio(), StopAudio(), FadeOutAudio().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to pause the audio.
			/**
			 *  This function serves to pause the audio.
			 *  @see ResumeAudio(), StopAudio(), FadeOutAudio().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void PauseAudio (void)
			{
				Mix_Pause(NO_CHANNEL);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para resumir un sonido de un canal.
			/**
			 *  Esta funci�n sirve para resumir un sonido de un canal.
			 *  @param snd Sonido para resumir.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to resume a sound of a channel.
			/**
			 *  This function serves to resume a sound of a channel.
			 *  @param snd Sound to resume.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), StopSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ResumeSound (Sound & snd)
			{
				Mix_Resume(snd.Channel);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para resumir un canal.
			/**
			 *  Esta funci�n sirve para resumir un canal.
			 *  @param channel Canal para resumir.
			 *  @see PauseChannel(), StopChannel(), FadeOutChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to resume a channel.
			/**
			 *  This function serves to resume a channel.
			 *  @param channel Channel to resume.
			 *  @see PauseChannel(), StopChannel(), FadeOutChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ResumeChannel (int channel)
			{
				Mix_Resume(channel);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para resumir el audio.
			/**
			 *  Esta funci�n sirve para resumir el audio.
			 *  @see PauseAudio(), StopAudio(), FadeOutAudio().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to resume the audio.
			/**
			 *  This function serves to resume the audio.
			 *  @see PauseAudio(), StopAudio(), FadeOutAudio().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ResumeAudio (void)
			{
				Mix_Resume(NO_CHANNEL);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para parar un sonido de un canal.
			/**
			 *  Esta funci�n sirve para parar un sonido de un canal.
			 *  @param snd Sonido para parar.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to stop a sound of a channel.
			/**
			 *  This function serves to stop a sound of a channel.
			 *  @param snd Sound to stop.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       FadeOutSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void StopSound (Sound & snd)
			{
				Mix_HaltChannel(snd.Channel);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para parar un canal.
			/**
			 *  Esta funci�n sirve para parar un canal.
			 *  @param channel Canal para parar.
			 *  @see PauseChannel(), ResumeChannel(), FadeOutChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to stop a channel.
			/**
			 *  This function serves to stop a channel.
			 *  @param channel Channel to stop.
			 *  @see PauseChannel(), ResumeChannel(), FadeOutChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void StopChannel (int channel)
			{
				Mix_HaltChannel(channel);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para parar el audio.
			/**
			 *  Esta funci�n sirve para parar el audio.
			 *  @see PauseAudio(), ResumeAudio(), FadeOutAudio().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to stop the audio.
			/**
			 *  This function serves to stop the audio.
			 *  @see PauseAudio(), ResumeAudio(), FadeOutAudio().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void StopAudio (void)
			{
				Mix_HaltChannel(NO_CHANNEL);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para parar un sonido de un canal con fade out.
			/**
			 *  Esta funci�n sirve para parar un sonido de un canal con fade out.
			 *  @param snd Sonido para parar.
			 *  @param ms  N�mero de milisegundos para el fade out.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       StopSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to stop a sound of a channel with fade out.
			/**
			 *  This function serves to stop a sound of a channel with fade out.
			 *  @param snd Sound to stop.
			 *  @param ms  Number of milliseconds for fade out.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       StopSound(), IsPlayingSound(), IsPausedSound().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void FadeOutSound (Sound & snd, int ms)
			{
				Mix_FadeOutChannel(snd.Channel, ms);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para parar un canal con fade out.
			/**
			 *  Esta funci�n sirve para parar un canal con fade out.
			 *  @param channel Canal para parar.
			 *  @param ms      N�mero de milisegundos para el fade out.
			 *  @see PauseChannel(), ResumeChannel(), StopChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to stop a channel with fade out.
			/**
			 *  This function serves to stop a channel with fade out.
			 *  @param channel Channel to stop.
			 *  @param ms      Number of milliseconds for fade out.
			 *  @see PauseChannel(), ResumeChannel(), StopChannel(), IsPlayingChannel(),
			 *       IsPausedChannel().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void FadeOutChannel (int channel, int ms)
			{
				Mix_FadeOutChannel(channel, ms);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para parar el audio con fade out.
			/**
			 *  Esta funci�n sirve para parar el audio con fade out.
			 *  @param ms N�mero de milisegundos para el fade out.
			 *  @see PauseAudio(), ResumeAudio(), StopAudio().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to stop the audio with fade out.
			/**
			 *  This function serves to stop the audio with fade out.
			 *  @param ms Number of milliseconds for fade out.
			 *  @see PauseAudio(), ResumeAudio(), StopAudio().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void FadeOutAudio (int ms)
			{
				Mix_FadeOutChannel(NO_CHANNEL, ms);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si un sonido est� reproduciendose.
			/**
			 *  Esta funci�n sirve para preguntar si un sonido est� reproduciendose.
			 *  @param snd Sonido en cuesti�n.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       StopSound(), FadeOutSound(), IsPausedSound().
			 *  @return Si devuelve true, es que �st� siendo reproducido.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if a sound is playing.
			/**
			 *  This function serves to ask if a sound is playing.
			 *  @param snd Sound to ask.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       StopSound(), FadeOutSound(), IsPausedSound().
			 *  @return If it gives back true, the sound is playing.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool IsPlayingSound (Sound & snd)
			{
				return (Mix_Playing(snd.Channel) != 0) && (Mix_Paused(snd.Channel) == 0) &&
					   (Mix_GetChunk(snd.Channel) == snd.Buffer);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si un canal est� reproduciendose.
			/**
			 *  Esta funci�n sirve para preguntar si un canal est� reproduciendose.
			 *  @param channel Canal en cuesti�n.
			 *  @see PauseChannel(), ResumeChannel(), StopChannel(), FadeOutChannel(),
			 *       IsPausedChannel().
			 *  @return Si devuelve true, es que �st� siendo reproducido.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if a channel is playing.
			/**
			 *  This function serves to ask if a channel is playing.
			 *  @param channel Channel to ask.
			 *  @see PauseChannel(), ResumeChannel(), StopChannel(), FadeOutChannel(),
			 *       IsPausedChannel().
			 *  @return If it gives back true, the channel is playing.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool IsPlayingChannel (int channel)
			{
				return (Mix_Playing(channel) != 0) && (Mix_Paused(channel) == 0);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si un sonido est� pausado.
			/**
			 *  Esta funci�n sirve para preguntar si un sonido est� pausado.
			 *  @param snd Sonido en cuesti�n.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       StopSound(), FadeOutSound(), IsPlayingSound().
			 *  @return Si devuelve true, es que �st� pausado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if a sound is paused.
			/**
			 *  This function serves to ask if a sound is paused.
			 *  @param snd Sound to ask.
			 *  @see PlaySound(), FadeInSound(), PauseSound(), ResumeSound(),
			 *       StopSound(), FadeOutSound(), IsPlayingSound().
			 *  @return If it gives back true, the sound is paused.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool IsPausedSound (Sound & snd)
			{
				return (Mix_Paused(snd.Channel) != 0) && (Mix_GetChunk(snd.Channel) == snd.Buffer);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para preguntar si un canal est� pausado.
			/**
			 *  Esta funci�n sirve para preguntar si un canal est� pausado.
			 *  @param channel Canal en cuesti�n.
			 *  @see PauseChannel(), ResumeChannel(), StopChannel(), FadeOutChannel(),
			 *       IsPlayingChannel().
			 *  @return Si devuelve true, es que �st� pausado.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to ask if a channel is paused.
			/**
			 *  This function serves to ask if a channel is paused.
			 *  @param channel Channel to ask.
			 *  @see PauseChannel(), ResumeChannel(), StopChannel(), FadeOutChannel(),
			 *       IsPlayingChannel().
			 *  @return If it gives back true, the channel is paused.
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool IsPausedChannel (int channel)
			{
				return (Mix_Paused(channel) != 0);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener la instancia de Audio.
			/**
			 *  Esta funci�n crea una instancia de Audio, en caso de no estar creada, y
			 *  devuelve un puntero a esta si tiene exito pidiendo memoria.
			 *  @return Devuelve un puntero al objeto Audio si todo ha ido bien, en caso de
			 *          no haber memoria para el objeto devuelve NULL.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the instance of Audio.
			/**
			 *  This function creates an instance of Audio, in case of not being created,
			 *  and gives back a pointer of this if memory is successful requesting.
			 *  @return It gives back to a pointer to the object Audio if everything has
			 *          gone well, if there is no memory for the object, gives back NULL.
			 */
			//------------------------------------------------------------------------------
#endif
			static Audio * GetInstance (void);
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Audio.h
//******************************************************************************************