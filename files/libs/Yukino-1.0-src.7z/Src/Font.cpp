//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Font.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "Font.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Font constructor.
	//--------------------------------------------------------------------------------------
	Font::Font ()
	{
		Buffer = NULL;

		File  = "";
		Size  = 0;
		Index = 0;
	}

	//--------------------------------------------------------------------------------------
	// Font constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Font::Font (const char * file, int ptsize, long index)
	{
		Buffer = NULL;

		Load(file, ptsize, index);
	}

	//--------------------------------------------------------------------------------------
	// Font constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Font::Font (const string & file, int ptsize, long index)
	{
		Buffer = NULL;

		Load(file.c_str(), ptsize, index);
	}

	//--------------------------------------------------------------------------------------
	// Font copy constructor.
	//--------------------------------------------------------------------------------------
	Font::Font (const Font & obj)
	{
		Buffer = NULL;

		File  = obj.File;
		Size  = obj.Size;
		Index = obj.Index;
		
		Load(File.c_str(), Size, Index);
	}

	//--------------------------------------------------------------------------------------
	// Font operator =, that copies one object in other.
	//--------------------------------------------------------------------------------------
	Font & Font::operator = (Font & obj)
	{
		Buffer = NULL;

		File  = obj.File;
		Size  = obj.Size;
		Index = obj.Index;
		
		Load(File.c_str(), Size, Index);

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	// Font destructor.
	//--------------------------------------------------------------------------------------
	Font::~Font ()
	{
		Free();
	}

	//--------------------------------------------------------------------------------------
	// This function loads a font from a file.
	//--------------------------------------------------------------------------------------
	UINT Font::Load (const char * file, int ptsize, long index)
	{
		File  = file;
		Size  = ptsize;
		Index = index;

		Buffer = TTF_OpenFontIndex(file, ptsize, index);
		if(Buffer == NULL)
		{
			return FONT_ERROR_OPEN;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function unloads the font's buffer.
	//--------------------------------------------------------------------------------------
	void Font::Free (void)
	{
		if(Buffer != NULL)
		{
			TTF_CloseFont(Buffer);
			Buffer = NULL;
		}
	}

}
//******************************************************************************************
// Font.cpp
//******************************************************************************************