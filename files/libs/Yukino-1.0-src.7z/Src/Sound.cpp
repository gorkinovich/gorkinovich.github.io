//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Sound.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "Sound.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Sound constructor.
	//--------------------------------------------------------------------------------------
	Sound::Sound ()
	{
		Channel  = NO_CHANNEL;
		Buffer   = NULL;
		FileName = string();
	}

	//--------------------------------------------------------------------------------------
	// Sound constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Sound::Sound (const char * file)
	{
		Channel  = NO_CHANNEL;
		Buffer   = NULL;
		FileName = string();

		Load(file);
	}

	//--------------------------------------------------------------------------------------
	// Sound constructor that loads a file.
	//--------------------------------------------------------------------------------------
	Sound::Sound (const string & file)
	{
		Channel  = NO_CHANNEL;
		Buffer   = NULL;
		FileName = string();

		Load(file.c_str());
	}

	//--------------------------------------------------------------------------------------
	// Sound copy constructor.
	//--------------------------------------------------------------------------------------
	Sound::Sound (const Sound & obj)
	{
		Channel  = NO_CHANNEL;
		Buffer   = NULL;
		FileName = string();

		Load(obj.FileName.c_str());
	}

	//--------------------------------------------------------------------------------------
	// Sound operator =, that copies one object in other.
	//--------------------------------------------------------------------------------------
	Sound & Sound::operator = (Sound & obj)
	{
		Free();
		
		Load(obj.FileName.c_str());

		return (*this);
	}

	//--------------------------------------------------------------------------------------
	// Sound destructor.
	//--------------------------------------------------------------------------------------
	Sound::~Sound ()
	{
		Free();
	}

	//--------------------------------------------------------------------------------------
	// This function loads a sound from a file.
	//--------------------------------------------------------------------------------------
	UINT Sound::Load (const char * file)
	{
		FileName = file;
		Buffer   = Mix_LoadWAV(file);

		if(Buffer == NULL)
		{
			return SOUND_ERROR_LOAD;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function unloads the sound's buffer.
	//--------------------------------------------------------------------------------------
	void Sound::Free (void)
	{
		if(Buffer != NULL)
		{
			Mix_FreeChunk(Buffer);

		    Channel  = NO_CHANNEL;
			Buffer   = NULL;
		    FileName = string();
		}
	}

	//--------------------------------------------------------------------------------------
	// This function sets the sound's volume.
	//--------------------------------------------------------------------------------------
	UINT Sound::SetVolume (int vol)
	{
		int prev = Buffer->volume;

		if(Mix_VolumeChunk(Buffer, vol) != prev)
		{
			return SOUND_ERROR_SETVOLUME;
		}

		return EVERYTHING_ALL_RIGHT;
	}
}
//******************************************************************************************
// Sound.cpp
//******************************************************************************************