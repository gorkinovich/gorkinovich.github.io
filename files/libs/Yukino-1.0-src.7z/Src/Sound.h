//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Sound.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _SOUND_H_
#define _SOUND_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//------------------------------------------------------------------------------------------
#include "SDL/SDL_mixer.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Sound Errors
	//--------------------------------------------------------------------------------------
	const UINT SOUND_ERROR_UNDEF     = 600; /**< Error indefinido en las funciones de Sound. */
	const UINT SOUND_ERROR_LOAD      = 601; /**< Error al cargar un sonido desde un fichero. */
	const UINT SOUND_ERROR_SETVOLUME = 602; /**< Error al cambiar el volumen de un sonido. */

	//--------------------------------------------------------------------------------------
	// Sound constants
	//--------------------------------------------------------------------------------------
	const int NO_CHANNEL = -1; /**< Indicador de que no hay ning�n canal usado por el sonido. */

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase para almacenar un sonido.
	/**
	 *  La clase Sound sirve para almacenar en memoria un sonido contenido en un fichero.
	 *  Este puede ser un fichero WAV u OGG. Y se puede manipular el volumen de este.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class to store one sound.
	/**
	 *  The Sound class serves to store in memory a sound contained in a file. This it can
	 *  be a file WAV or OGG. And the volume of the sound can be manipulated.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Sound
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			Mix_Chunk * Buffer;
			string FileName;
			int Channel;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sound.
			/**
			 *  Constructor por defecto de la clase Sound.
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sound class.
			/**
			 *  Constructor by defect of the Sound class. 
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#endif
			Sound ();
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sound.
			/**
			 *  Constructor de la clase Sound, que carga un fichero.
			 *  @param file Ruta del fichero.
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sound class.
			/**
			 *  Constructor of the Sound class, that loads a file.
			 *  @param file Path of the file.
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#endif
			Sound (const char * file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sound.
			/**
			 *  Constructor de la clase Sound, que carga un fichero.
			 *  @param file Ruta del fichero.
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sound class.
			/**
			 *  Constructor of the Sound class, that loads a file.
			 *  @param file Path of the file.
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#endif
			Sound (const string & file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor copia de la clase Sound.
			/**
			 *  @param obj Objeto Sound a copiar.
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Copy constructor of the Sound class.
			/**
			 *  @param obj Sound object to copy.
			 *  @see operator=(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#endif
			Sound (const Sound & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Operador = de la clase Sound.
			/**
			 *  Copia el objeto obj en el objeto actual, y este es devuelto.
			 *  @see Sound(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Operator = of the Sound class.
			/**
			 *  The obj object is copied in the actual object, and this is given back.
			 *  @see Sound(), ~Sound().
			 */
			//------------------------------------------------------------------------------
#endif
			Sound & operator = (Sound & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Destructor de la clase Sound.
			/**
			 *  @see Sound(), operator=().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Destructor of the Sound class.
			/**
			 *  @see Sound(), operator=().
			 */
			//------------------------------------------------------------------------------
#endif
			~Sound ();
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar un sonido de un fichero.
			/**
			 *  Esta funci�n sirve para cargar un sonido de un fichero.
			 *  @param file Ruta del fichero.
			 *  @see Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SOUND_ERROR_LOAD.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a sound from a file.
			/**
			 *  This function serves to load a sound from a file.
			 *  @param file Path of the file.
			 *  @see Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SOUND_ERROR_LOAD.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Load (const char * file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar un sonido de un fichero.
			/**
			 *  Esta funci�n sirve para cargar un sonido de un fichero.
			 *  @param file Ruta del fichero.
			 *  @see Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SOUND_ERROR_LOAD.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a sound from a file.
			/**
			 *  This function serves to load a sound from a file.
			 *  @param file Path of the file.
			 *  @see Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SOUND_ERROR_LOAD.
			 */
			//------------------------------------------------------------------------------
#endif
			inline UINT Load (const string & file)
			{
				return Load(file.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para liberar los datos del objeto Sound.
			/**
			 *  Esta funci�n sirve para liberar el contenido del objeto Sound.
			 *  @see Load().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to release the data of the Sound object.
			/**
			 *  This function serves to release the content of the Sound object.
			 *  @see Load().
			 */
			//------------------------------------------------------------------------------
#endif
			void Free (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el volumen actual del sonido.
			/**
			 *  Esta funci�n sirve para cambiar el volumen actual del sonido.
			 *  @param vol Volumen del sonido.
			 *  @see GetVolume().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SOUND_ERROR_SETVOLUME.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the actual volume of the sound.
			/**
			 *  This function serves to change the actual volume of the sound.
			 *  @param vol Volume of the sound.
			 *  @see GetVolume().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SOUND_ERROR_SETVOLUME.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT SetVolume (int vol);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el volumen actual del sonido.
			/**
			 *  Esta funci�n sirve para obtener el volumen actual del sonido.
			 *  @see SetVolume().
			 *  @return El volumen actual.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the actual volume of the sound.
			/**
			 *  This function serves to obtain the actual volume of the sound.
			 *  @see SetVolume().
			 *  @return The actual volume.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetVolume (void) const
			{
				return Buffer->volume;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el canal actual del sonido.
			/**
			 *  Esta funci�n sirve para obtener el canal actual del sonido.
			 *  @return El canal actual.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the actual channel of the sound.
			/**
			 *  This function serves to obtain the actual channel of the sound.
			 *  @return The actual channel.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetChannel (void) const
			{
				return Channel;
			}


			friend class Audio;
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Sound.h
//******************************************************************************************