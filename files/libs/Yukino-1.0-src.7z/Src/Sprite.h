//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Sprite.h is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _SPRITE_H_
#define _SPRITE_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Surface.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Class RectAux
	//--------------------------------------------------------------------------------------
	class DLLAPI RectAux
	{
		public:
			Rect rect;

			RectAux () { rect.x = 0; rect.y = 0; rect.w = 0; rect.h = 0; }

			bool operator < (const RectAux & obj) const
			{
				return (rect.x < obj.rect.x) && (rect.y < obj.rect.y) &&
					   (rect.w < obj.rect.w) && (rect.h < obj.rect.h);
			}

			bool operator == (const RectAux & obj) const
			{
				return (rect.x == obj.rect.x) && (rect.y == obj.rect.y) &&
					   (rect.w == obj.rect.w) && (rect.h == obj.rect.h);;
			}
			
			RectAux & operator = (const RectAux & obj)
			{
				rect = obj.rect;
				return (*this);
			}
			
			RectAux & operator = (const Rect & obj)
			{
				rect = obj;
				return (*this);
			}
	};

	//--------------------------------------------------------------------------------------
	// Sprite Errors
	//--------------------------------------------------------------------------------------
	const UINT SPRITE_ERROR_UNDEF       = 300; /**< Error indefinido en las funciones de Sprite. */
	const UINT SPRITE_ERROR_FOPEN       = 301; /**< Error al abrir el fichero de sprite. */
	const UINT SPRITE_ERROR_READHEADER  = 302; /**< Error al leer la cabecera del fichero de sprite. */
	const UINT SPRITE_ERROR_WRONGFID    = 303; /**< Error por leer un fichero que no es de sprite. */
	const UINT SPRITE_ERROR_WRITEHEADER = 304; /**< Error al escribir la cabecera del fichero de sprite. */

	//--------------------------------------------------------------------------------------
	// Sprite constants
	//--------------------------------------------------------------------------------------
	#define SPRITE_FILEID "YUKINO_SPRITE"

#ifndef _DOC_IN_ENGLISH_
	//--------------------------------------------------------------------------------------
	/// Clase para almacenar una sprite animado.
	/**
	 *  La clase Sprite sirve para almacenar en memoria un sprite animado, contenida la
	 *  informaci�n de este en dos ficheros. Uno de especificaci�n de los frames de la
	 *  animaci�n, y otro con la imagen donde est�n los frames.
	 */
	//--------------------------------------------------------------------------------------
#else
	//--------------------------------------------------------------------------------------
	/// Class to store one sprite animated.
	/**
	 *  The Sprite class serves to store in memory sprite animated, contained the
	 *  information of this in two files. One of specification of frames of the animation,
	 *  and another one with the image where they are frames.
	 */
	//--------------------------------------------------------------------------------------
#endif
	class DLLAPI Sprite : public Surface
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			void InitFrames (void);
			
			template class DLLAPI std::allocator<RectAux>;
			template class DLLAPI std::vector<RectAux, std::allocator<RectAux> >;

		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			vector<RectAux> Frames;
			dword ActualFrame;
			dword MaxTime;
			dword ActTime;
			dword FPS;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sprite.
			/**
			 *  Constructor por defecto de la clase Sprite.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sprite class.
			/**
			 *  Constructor by defect of the Sprite class. 
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#endif
			Sprite ();
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sprite.
			/**
			 *  Constructor de la clase Sprite, que crea un sprite en blanco.
			 *  @param w    Ancho del sprite.
			 *  @param h    Alto del sprite.
			 *  @param bpp  Profundidad de color del sprite.
			 *  @param fps  Frames por segundo del sprite.
			 *  @param cols Columnas del sprite.
			 *  @param rows Filas del sprite.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sprite class.
			/**
			 *  Constructor of the Sprite class, that creates a blank sprite.
			 *  @param w    Width of the sprite.
			 *  @param h    Height of the sprite.
			 *  @param bpp  Depth of color of the sprite.
			 *  @param fps  Frames per second of the sprite.
			 *  @param cols Columns of the sprite.
			 *  @param rows Rows of the sprite.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#endif
			Sprite (int w, int h, int bpp, dword fps, int cols, int rows = 1);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sprite.
			/**
			 *  Constructor de la clase Sprite, que crea un sprite en blanco.
			 *  @param w      Ancho del sprite.
			 *  @param h      Alto del sprite.
			 *  @param bpp    Profundidad de color del sprite.
			 *  @param fps    Frames por segundo del sprite.
			 *  @param frames Especificaci�n de los frames.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sprite class.
			/**
			 *  Constructor of the Sprite class, that creates a blank sprite.
			 *  @param w      Width of the sprite.
			 *  @param h      Height of the sprite.
			 *  @param bpp    Depth of color of the sprite.
			 *  @param fps    Frames per second of the sprite.
			 *  @param frames Specification of the frames.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#endif
			Sprite (int w, int h, int bpp, dword fps, vector<RectAux> & frames);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sprite.
			/**
			 *  Constructor de la clase Sprite, que carga un fichero.
			 *  @param file Ruta del fichero.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sprite class.
			/**
			 *  Constructor of the Sprite class, that loads a file.
			 *  @param file Path of the file.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#endif
			Sprite (const string & file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor de la clase Sprite.
			/**
			 *  Constructor de la clase Sprite, que carga un fichero.
			 *  @param file Ruta del fichero.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Constructor of the Sprite class.
			/**
			 *  Constructor of the Sprite class, that loads a file.
			 *  @param file Path of the file.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#endif
			Sprite (const char * file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Constructor copia de la clase Sprite.
			/**
			 *  @param obj Objeto Sprite a copiar.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Copy constructor of the Sprite class.
			/**
			 *  @param obj Sprite object to copy.
			 *  @see operator=(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#endif
			Sprite (const Sprite & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Operador = de la clase Sprite.
			/**
			 *  Copia el objeto obj en el objeto actual, y este es devuelto.
			 *  @see Sprite(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Operator = of the Sprite class.
			/**
			 *  The obj object is copied in the actual object, and this is given back.
			 *  @see Sprite(), ~Sprite().
			 */
			//------------------------------------------------------------------------------
#endif
			virtual Sprite & operator = (Sprite & obj);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Destructor de la clase Sprite.
			/**
			 *  @see Sprite(), operator=().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Destructor of the Sprite class.
			/**
			 *  @see Sprite(), operator=().
			 */
			//------------------------------------------------------------------------------
#endif
			~Sprite ();			
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para crear un sprite en blanco en el Sprite.
			/**
			 *  Esta funci�n sirve para crear un sprite en blanco en la Sprite.
			 *  @param w    Ancho de la imagen.
			 *  @param h    Alto de la imagen.
			 *  @param bpp  Profundidad de color de la imagen.
			 *  @param fps  Frames por segundo del sprite.
			 *  @param cols Columnas del sprite.
			 *  @param rows Filas del sprite.
			 *  @see Load(), Save(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_CREATESURF.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to create a blank sprite in the Sprite.
			/**
			 *  This function serves to create a blank sprite in the Sprite.
			 *  @param w    Width of the image.
			 *  @param h    Height of the image.
			 *  @param bpp  Depth of color of the image.
			 *  @param fps  Frames per second of the sprite.
			 *  @param cols Columns of the sprite.
			 *  @param rows Rows of the sprite.
			 *  @see Load(), Save(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_CREATESURF.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Create (int w, int h, int bpp, dword fps, int cols, int rows = 1);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para crear un sprite en blanco en el Sprite.
			/**
			 *  Esta funci�n sirve para crear un sprite en blanco en la Sprite.
			 *  @param w      Ancho de la imagen.
			 *  @param h      Alto de la imagen.
			 *  @param bpp    Profundidad de color de la imagen.
			 *  @param fps    Frames por segundo del sprite.
			 *  @param frames Especificaci�n de los frames.
			 *  @see Load(), Save(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SURFACE_ERROR_CREATESURF.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to create a blank sprite in the Sprite.
			/**
			 *  This function serves to create a blank sprite in the Sprite.
			 *  @param w      Width of the sprite.
			 *  @param h      Height of the sprite.
			 *  @param bpp    Depth of color of the sprite.
			 *  @param fps    Frames per second of the sprite.
			 *  @param frames Specification of the frames.
			 *  @see Load(), Save(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SURFACE_ERROR_CREATESURF.
			 */
			//------------------------------------------------------------------------------
#endif
			UINT Create (int w, int h, int bpp, dword fps, vector<RectAux> & frames);		
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar un sprite de un fichero.
			/**
			 *  Esta funci�n sirve para cargar un sprite de un fichero.
			 *  @param file Ruta del fichero.
			 *  @see Create(), Save(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_READHEADER, 
			 *          SPRITE_ERROR_WRONGFID, SURFACE_ERROR_RWFROMFILE,
			 *          SURFACE_ERROR_UNKOWNFORMAT, SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a sprite from a file.
			/**
			 *  This function serves to load a sprite from a file.
			 *  @param file Path of the file.
			 *  @see Create(), Save(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_READHEADER, 
			 *          SPRITE_ERROR_WRONGFID, SURFACE_ERROR_RWFROMFILE,
			 *          SURFACE_ERROR_UNKOWNFORMAT, SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual UINT Load (const char * file);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cargar un sprite de un fichero.
			/**
			 *  Esta funci�n sirve para cargar un sprite de un fichero.
			 *  @param file Ruta del fichero.
			 *  @see Create(), Save(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_READHEADER,
			 *          SPRITE_ERROR_WRONGFID, SURFACE_ERROR_RWFROMFILE,
			 *          SURFACE_ERROR_UNKOWNFORMAT, SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to load a sprite from a file.
			/**
			 *  This function serves to load a sprite from a file.
			 *  @param file Path of the file.
			 *  @see Create(), Save(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_READHEADER,
			 *          SPRITE_ERROR_WRONGFID, SURFACE_ERROR_RWFROMFILE,
			 *          SURFACE_ERROR_UNKOWNFORMAT, SURFACE_ERROR_LOADINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual inline UINT Load (const string & file)
			{
				return Load(file.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para salvar un sprite en un fichero.
			/**
			 *  Esta funci�n sirve para salvar un sprite en un fichero.
			 *  @param file    Ruta del fichero.
			 *  @param texture Ruta del fichero imagen.
			 *  @see Create(), Load(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_WRITEHEADER,
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to save a sprite in a file.
			/**
			 *  This function serves to save a sprite in a file.
			 *  @param file    Path of the file.
			 *  @param texture Path of the image file.
			 *  @see Create(), Load(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_READHEADER,
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual UINT Save (const char * file, const char * texture);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para salvar un sprite en un fichero.
			/**
			 *  Esta funci�n sirve para salvar un sprite en un fichero.
			 *  @param file    Ruta del fichero.
			 *  @param texture Ruta del fichero imagen.
			 *  @see Create(), Load(), Free().
			 *  @return Si todo va bien devuelve 0, sino devuelve los siguientes errores:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_WRITEHEADER,
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to save a sprite in a file.
			/**
			 *  This function serves to save a sprite in a file.
			 *  @param file    Path of the file.
			 *  @param texture Path of the image file.
			 *  @see Create(), Load(), Free().
			 *  @return If everything goes well returns 0, on errors returns:
			 *          SPRITE_ERROR_FOPEN, SPRITE_ERROR_READHEADER,
			 *          SURFACE_ERROR_SAVINGFILE.
			 */
			//------------------------------------------------------------------------------
#endif
			virtual inline UINT Save (const string & file, const string & texture)
			{
				return Save(file.c_str(), texture.c_str());
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para liberar los datos del objeto Sprite.
			/**
			 *  Esta funci�n sirve para liberar el contenido del objeto Sprite.
			 *  @see Create(), Load(), Save().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to release the data of the Sprite object.
			/**
			 *  This function serves to release the content of the Sprite object.
			 *  @see Create(), Load(), Save().
			 */
			//------------------------------------------------------------------------------
#endif
			virtual void Free (void);
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el n�mero de frames por segundo.
			/**
			 *  Esta funci�n sirve para obtener la velocidad de la animaci�n.
			 *  @see SetFPS().
			 *  @return La velocidad de la animaci�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the number of frames per second.
			/**
			 *  This function serves to obtain the speed of the animation.
			 *  @see SetFPS().
			 *  @return The speed of the animation.
			 */
			//------------------------------------------------------------------------------
#endif
			inline dword GetFPS (void)
			{
				return FPS;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el n�mero de frames por segundo.
			/**
			 *  Esta funci�n sirve para cambiar la velocidad de la animaci�n.
			 *  @param fps Frames por segundo del sprite.
			 *  @see GetFPS().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the number of frames per second.
			/**
			 *  This function serves to change the speed of the animation.
			 *  @param fps Frames per second of the sprite.
			 *  @see GetFPS().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void SetFPS (dword fps)
			{
				MaxTime = (dword) (1000 / fps);
				FPS     = fps;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el n�mero de frames de la animaci�n.
			/**
			 *  Esta funci�n sirve para cambiar el n�mero de frames de la animaci�n.
			 *  @param cols Columnas del sprite.
			 *  @param rows Filas del sprite.
			 *  @see GetNumFrames().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the number of frames of the animation.
			/**
			 *  This function serves to change the number of frames of the animation.
			 *  @param cols Columns of the sprite.
			 *  @param rows Rows of the sprite.
			 *  @see GetNumFrames().
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool SetNumFrames (int cols, int rows)
			{
				Frames.resize(rows * cols);
				
				return (Frames.size() == (rows * cols));
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el n�mero de frames de la animaci�n.
			/**
			 *  Esta funci�n sirve para cambiar el n�mero de frames de la animaci�n.
			 *  @param numframes N�mero de frames.
			 *  @see GetNumFrames().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the number of frames of the animation.
			/**
			 *  This function serves to change the number of frames of the animation.
			 *  @param numframes Number of frames.
			 *  @see GetNumFrames().
			 */
			//------------------------------------------------------------------------------
#endif
			inline bool SetNumFrames (int numframes)
			{
				Frames.resize(numframes);

				return (Frames.size() == numframes);
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el n�mero de frames de la animaci�n.
			/**
			 *  Esta funci�n sirve para obtener el n�mero de frames de la animaci�n.
			 *  @see SetNumFrames().
			 *  @return El n�mero de frames.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the number of frames of the animation.
			/**
			 *  This function serves to obtain the number of frames of the animation.
			 *  @see SetNumFrames().
			 *  @return The number of frames.
			 */
			//------------------------------------------------------------------------------
#endif
			inline int GetNumFrames (void) const
			{
				return Frames.size();
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar los frames de la animaci�n.
			/**
			 *  Esta funci�n sirve para cambiar los frames de la animaci�n.
			 *  @param frames Frames de la animaci�n.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the frames of the animation.
			/**
			 *  This function serves to change the frames of the animation.
			 *  @param frames Frames of the animation.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void SetFrames (vector<RectAux> & frames)
			{
				Frames = frames;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar un frame de la animaci�n.
			/**
			 *  Esta funci�n sirve para cambiar un frame de la animaci�n.
			 *  @param i N�mero del frame.
			 *  @param x Coordenada x del frame.
			 *  @param y Coordenada y del frame.
			 *  @param w Ancho del frame.
			 *  @param h Alto del frame.
			 *  @see GetFrame().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change one frame of the animation.
			/**
			 *  This function serves to change one frame of the animation.
			 *  @param i Number of the frame.
			 *  @param x Coordinate x of the frame.
			 *  @param y Coordinate y of the frame.
			 *  @param w Width of the frame.
			 *  @param h Height of the frame.
			 *  @see GetFrame().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void SetFrame (word i, sword x, sword y, word w, word h)
			{
				Frames[i].rect.x = x;
				Frames[i].rect.y = y;
				Frames[i].rect.w = w;
				Frames[i].rect.h = h;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar un frame de la animaci�n.
			/**
			 *  Esta funci�n sirve para cambiar un frame de la animaci�n.
			 *  @param i     N�mero del frame.
			 *  @param frame Propiedades del frame.
			 *  @see GetFrame().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change one frame of the animation.
			/**
			 *  This function serves to change one frame of the animation.
			 *  @param i     Number of the frame.
			 *  @param frame Properties of the frame.
			 *  @see GetFrame().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void SetFrame (word i, const Rect * frame)
			{
				Frames[i].rect.x = frame->x;
				Frames[i].rect.y = frame->y;
				Frames[i].rect.w = frame->w;
				Frames[i].rect.h = frame->h;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener un frame de la animaci�n.
			/**
			 *  Esta funci�n sirve para obtener un frame de la animaci�n.
			 *  @param i     N�mero del frame.
			 *  @param frame Propiedades del frame.
			 *  @see SetFrame().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain one frame of the animation.
			/**
			 *  This function serves to obtain one frame of the animation.
			 *  @param i     Number of the frame.
			 *  @param frame Properties of the frame.
			 *  @see SetFrame().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void GetFrame (word i, Rect * frame) const
			{
				frame->x = Frames[i].rect.x;
				frame->y = Frames[i].rect.y;
				frame->w = Frames[i].rect.w;
				frame->h = Frames[i].rect.h;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para cambiar el frame actual de la animaci�n.
			/**
			 *  Esta funci�n sirve para cambiar el frame actual de la animaci�n.
			 *  @param frame Frame actual.
			 *  @see GetActFrame().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to change the actual frame of the animation.
			/**
			 *  This function serves to change the actual frame of the animation.
			 *  @param frame Actual frame.
			 *  @see GetActFrame().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void SetActFrame (dword frame)
			{
				ActualFrame = frame;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para obtener el frame actual de la animaci�n.
			/**
			 *  Esta funci�n sirve para obtener el frame actual de la animaci�n.
			 *  @see SetActFrame().
			 *  @return El frame actual.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to obtain the actual frame of the animation.
			/**
			 *  This function serves to obtain the actual frame of the animation.
			 *  @see SetActFrame().
			 *  @return The actual frame.
			 */
			//------------------------------------------------------------------------------
#endif
			inline dword GetActFrame (void) const
			{
				return ActualFrame;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para pasar al siguiente frame de la animaci�n.
			/**
			 *  Esta funci�n sirve para pasar al siguiente frame de la animaci�n.
			 *  @see Update().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to pass to the next frame of the animation.
			/**
			 *  This function serves to pass to the next frame of the animation.
			 *  @see Update().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void NextActFrame (void)
			{
				ActualFrame++;
				if(ActualFrame >= Frames.size()) ActualFrame = 0;
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para actualizar el frame actual de la animaci�n.
			/**
			 *  Esta funci�n sirve para actualizar el frame actual de la animaci�n.
			 *  @param time Tiempo transcurrido.
			 *  @see NextActFrame().
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to update the actual frame of the animation.
			/**
			 *  This function serves to update the actual frame of the animation.
			 *  @param time Passed time.
			 *  @see NextActFrame().
			 */
			//------------------------------------------------------------------------------
#endif
			inline void Update (dword time)
			{
				ActTime += time;

				while(ActTime >= MaxTime)
				{
					NextActFrame();
					ActTime -= MaxTime;
				}
			}
			
#ifndef _DOC_IN_ENGLISH_
			//------------------------------------------------------------------------------
			/// Funci�n para poner a cero el tiempo trancurrido.
			/**
			 *  Esta funci�n sirve para poner a cero el tiempo trancurrido.
			 */
			//------------------------------------------------------------------------------
#else
			//------------------------------------------------------------------------------
			/// Function to reset the passed time.
			/**
			 *  This function serves to reset the passed time.
			 */
			//------------------------------------------------------------------------------
#endif
			inline void ResetTime (void)
			{
				ActTime = 0;
			}


			friend class Graphics;
	};
}

//******************************************************************************************
#endif
//******************************************************************************************
// Sprite.h
//******************************************************************************************