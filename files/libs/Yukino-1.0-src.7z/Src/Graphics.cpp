//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Graphics.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifdef WIN32
	#pragma comment (lib, "SDL_ttf.lib")
#endif
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Graphics.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Global static members of the graphics class.
	//--------------------------------------------------------------------------------------
	Graphics * Graphics::Instance = NULL;
	
	//--------------------------------------------------------------------------------------
	// Graphics constructor.
	//--------------------------------------------------------------------------------------
	Graphics::Graphics ()
	{
		BufferVideo = NULL;
	}

	//--------------------------------------------------------------------------------------
	// This function initializes the graphics object.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Init (int w, int h, int bpp, bool winmode)
	{
		Uint32 flags;

		if(winmode)
			flags = (SDL_HWSURFACE|SDL_DOUBLEBUF);
		else
			flags = (SDL_HWSURFACE|SDL_DOUBLEBUF|SDL_FULLSCREEN);

		if(SDL_VideoModeOK(w, h, bpp, flags) == 0)
		{
			return GRAPHICS_ERROR_VIDEOMODEOK;
		}

		BufferVideo = SDL_SetVideoMode(w, h, bpp, flags);

		if(BufferVideo == NULL)
		{
			return GRAPHICS_ERROR_SETVIDEOMODE;
		}

		if(!TTF_WasInit() && TTF_Init() == FAIL)
		{
			return GRAPHICS_ERROR_TTFINIT;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function releases the graphics object.
	//--------------------------------------------------------------------------------------
	void Graphics::Release (void)
	{
		if(BufferVideo != NULL)
		{
			SDL_FreeSurface(BufferVideo);
			BufferVideo = NULL;
		}

		if(TTF_WasInit())
			TTF_Quit();
	}

	//--------------------------------------------------------------------------------------
	// This function sets the window caption.
	//--------------------------------------------------------------------------------------
	void Graphics::SetTitle (const char * title, const char * icon)
	{
		SDL_WM_SetCaption(title, icon);
	}

	//--------------------------------------------------------------------------------------
	// This function hides the mouse cursor.
	//--------------------------------------------------------------------------------------
	void Graphics::HideCursor (void)
	{
		SDL_ShowCursor(SDL_DISABLE);
	}

	//--------------------------------------------------------------------------------------
	// This function shows the mouse cursor.
	//--------------------------------------------------------------------------------------
	void Graphics::ShowCursor (void)
	{
		SDL_ShowCursor(SDL_ENABLE);
	}

	//--------------------------------------------------------------------------------------
	// This function updates the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Update (void)
	{
		if(SDL_Flip(BufferVideo) == FAIL)
		{
			return GRAPHICS_ERROR_UPDATE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function fills with a color, a rectangle in the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Fill (Uint32 color, Rect * rect)
	{
		if(SDL_FillRect(BufferVideo, (SDL_Rect *) rect, color) == FAIL)
		{
			return GRAPHICS_ERROR_FILLRECT;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a source surface into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Blit (const Surface & objsrc, Rect * dst, Rect * src)
	{
		if(SDL_BlitSurface(objsrc.Buffer, (SDL_Rect *) src, BufferVideo, (SDL_Rect *) dst) == FAIL)
		{
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a source surface into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Blit (const Surface & objsrc, int x, int y, Rect * src)
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = objsrc.Buffer->w;
			dst.h = objsrc.Buffer->h;
		}

		if(SDL_BlitSurface(objsrc.Buffer, (SDL_Rect *) src, BufferVideo, &dst) == FAIL)
		{
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a source surface into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Blit (SDL_Surface * srfsrc, Rect * dst, Rect * src)
	{
		if(SDL_BlitSurface(srfsrc, (SDL_Rect *) src, BufferVideo, (SDL_Rect *) dst) == FAIL)
		{
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a source surface into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Blit (SDL_Surface * srfsrc, int x, int y, Rect * src)
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = srfsrc->w;
			dst.h = srfsrc->h;
		}

		if(SDL_BlitSurface(srfsrc, (SDL_Rect *) src, BufferVideo, &dst) == FAIL)
		{
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a source surface into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Blit (const Sprite & objsrc, Rect * dst)
	{
		SDL_Rect * src = (SDL_Rect *) &(objsrc.Frames[objsrc.ActualFrame].rect);

		if(SDL_BlitSurface(objsrc.Buffer, src, BufferVideo, (SDL_Rect *) dst) == FAIL)
		{
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a source surface into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Blit (const Sprite & objsrc, int x, int y)
	{	
		SDL_Rect * src = (SDL_Rect *) &(objsrc.Frames[objsrc.ActualFrame].rect);

		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		dst.w = objsrc.Buffer->w;
		dst.h = objsrc.Buffer->h;

		if(SDL_BlitSurface(objsrc.Buffer, src, BufferVideo, &dst) == FAIL)
		{
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the screen into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Paste (Surface & objdst, Rect * dst, Rect * src) const
	{
		if(SDL_BlitSurface(BufferVideo, (SDL_Rect *) src, objdst.Buffer, (SDL_Rect *) dst) == FAIL)
		{
			return GRAPHICS_ERROR_COPYSCREEN;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the screen into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Paste (Surface & objdst, int x, int y, Rect * src) const
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = objdst.Buffer->w;
			dst.h = objdst.Buffer->h;
		}

		if(SDL_BlitSurface(BufferVideo, (SDL_Rect *) src, objdst.Buffer, &dst) == FAIL)
		{
			return GRAPHICS_ERROR_COPYSCREEN;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the screen into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Paste (SDL_Surface * srfdst, Rect * dst, Rect * src) const
	{
		if(SDL_BlitSurface(BufferVideo, (SDL_Rect *) src, srfdst, (SDL_Rect *) dst) == FAIL)
		{
			return GRAPHICS_ERROR_COPYSCREEN;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function copies the screen into a destination surface.
	//--------------------------------------------------------------------------------------
	UINT Graphics::Paste (SDL_Surface * srfdst, int x, int y, Rect * src) const
	{
		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		if(src != NULL)
		{
			dst.w = src->w;
			dst.h = src->h;
		}
		else
		{
			dst.w = srfdst->w;
			dst.h = srfdst->h;
		}

		if(SDL_BlitSurface(BufferVideo, (SDL_Rect *) src, srfdst, &dst) == FAIL)
		{
			return GRAPHICS_ERROR_COPYSCREEN;
		}

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a text into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::PutText (Font & font, const char * text, dword fc, Rect * dst)
	{
		SDL_Surface * srfsrc = font.RenderText(text, fc);

		if(srfsrc == NULL)
		{
			return GRAPHICS_ERROR_RENDERTEXT;
		}

		if(SDL_BlitSurface(srfsrc, NULL, BufferVideo, (SDL_Rect *) dst) == FAIL)
		{
			SDL_FreeSurface(srfsrc);
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		SDL_FreeSurface(srfsrc);

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a text into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::PutText (Font & font, const char * text, dword fc, int x, int y)
	{
		SDL_Surface * srfsrc = font.RenderText(text, fc);

		if(srfsrc == NULL)
		{
			return GRAPHICS_ERROR_RENDERTEXT;
		}

		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		dst.w = srfsrc->w;
		dst.h = srfsrc->h;

		if(SDL_BlitSurface(srfsrc, NULL, BufferVideo, &dst) == FAIL)
		{
			SDL_FreeSurface(srfsrc);
			return GRAPHICS_ERROR_BLITSURFACE;
		}
		
		SDL_FreeSurface(srfsrc);

		return EVERYTHING_ALL_RIGHT;
	}
	
	//--------------------------------------------------------------------------------------
	// This function puts a text into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::PutUNICODE (Font & font, const word * text, dword fc, Rect * dst)
	{
		SDL_Surface * srfsrc = font.RenderUNICODE(text, fc);

		if(srfsrc == NULL)
		{
			return GRAPHICS_ERROR_RENDERTEXT;
		}

		if(SDL_BlitSurface(srfsrc, NULL, BufferVideo, (SDL_Rect *) dst) == FAIL)
		{
			SDL_FreeSurface(srfsrc);
			return GRAPHICS_ERROR_BLITSURFACE;
		}

		SDL_FreeSurface(srfsrc);

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function puts a text into the screen.
	//--------------------------------------------------------------------------------------
	UINT Graphics::PutUNICODE (Font & font, const word * text, dword fc, int x, int y)
	{
		SDL_Surface * srfsrc = font.RenderUNICODE(text, fc);

		if(srfsrc == NULL)
		{
			return GRAPHICS_ERROR_RENDERTEXT;
		}

		SDL_Rect dst;

		dst.x = x;
		dst.y = y;

		dst.w = srfsrc->w;
		dst.h = srfsrc->h;

		if(SDL_BlitSurface(srfsrc, NULL, BufferVideo, &dst) == FAIL)
		{
			SDL_FreeSurface(srfsrc);
			return GRAPHICS_ERROR_BLITSURFACE;
		}
		
		SDL_FreeSurface(srfsrc);

		return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// The graphics class GetInstance function.
	//--------------------------------------------------------------------------------------
	Graphics * Graphics::GetInstance (void)
	{
		if(Graphics::Instance == NULL)
			Graphics::Instance = new Graphics();

		return Graphics::Instance;
	}
}
//******************************************************************************************
// Graphics.cpp
//******************************************************************************************