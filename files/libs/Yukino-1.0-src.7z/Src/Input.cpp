//******************************************************************************************
// Yukino, a 2D game library.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// Input.cpp is part of Yukino.
//
// Yukino is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// Yukino is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with Yukino; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************

//******************************************************************************************
// Includes
//******************************************************************************************
#include "Input.h"
//******************************************************************************************
// Namespace Yukino
//******************************************************************************************
namespace Yukino
{
	//--------------------------------------------------------------------------------------
	// Global static members of the input class.
	//--------------------------------------------------------------------------------------
	Input * Input::Instance = NULL;
	
	//--------------------------------------------------------------------------------------
	// Input constructor.
	//--------------------------------------------------------------------------------------
	Input::Input ()
	{
		Keyboard = NULL;

		X  = 0;
		Y  = 0;
		RX = 0;
		RY = 0;

		LB = false;
		MB = false;
		RB = false;
		WU = false;
		WD = false;
	}

	//--------------------------------------------------------------------------------------
	// This function initializes the input object.
	//--------------------------------------------------------------------------------------
	UINT Input::Init (void)
	{
		SDL_PumpEvents();
		Keyboard = SDL_GetKeyState(NULL);

		if(Keyboard == NULL)
			return INPUT_ERROR_GETKEYSTATE;
		else
			return EVERYTHING_ALL_RIGHT;
	}

	//--------------------------------------------------------------------------------------
	// This function releases the input object.
	//--------------------------------------------------------------------------------------
	void Input::Release (void)
	{
		Keyboard = NULL;
	}

	//--------------------------------------------------------------------------------------
	// This function updates the input.
	//--------------------------------------------------------------------------------------
	void Input::Update (void)
	{
		Uint8 buttons;

		SDL_PumpEvents();

		buttons = SDL_GetMouseState(&X, &Y);
		SDL_GetRelativeMouseState(&RX, &RY);

		//SDL_BUTTON(X) -> (SDL_PRESSED<<(X-1))
		LB = ((buttons & SDL_BUTTON(1)) == 1); //SDL_BUTTON_LEFT      1
		MB = ((buttons & SDL_BUTTON(2)) == 1); //SDL_BUTTON_MIDDLE    2
		RB = ((buttons & SDL_BUTTON(3)) == 1); //SDL_BUTTON_RIGHT     3
		WU = ((buttons & SDL_BUTTON(4)) == 1); //SDL_BUTTON_WHEELUP   4
		WD = ((buttons & SDL_BUTTON(5)) == 1); //SDL_BUTTON_WHEELDOWN 5
	}

	//--------------------------------------------------------------------------------------
	// This function returns if some key is pressed.
	//--------------------------------------------------------------------------------------
	bool Input::KbHit (void) const
	{
		for(int i = 0; i < 130; i++)
			if((i != Keys::KEY_SCROLLOCK) && (i != Keys::KEY_CAPSLOCK) && (i != Keys::KEY_NUMLOCK))
				if(Keyboard[i] == 1)
					return true;

		return false;
	}

	//--------------------------------------------------------------------------------------
	// The input class GetInstance function.
	//--------------------------------------------------------------------------------------
	Input * Input::GetInstance (void)
	{
		if(Input::Instance == NULL)
			Input::Instance = new Input();

		return Input::Instance;
	}
}
//******************************************************************************************
// Input.cpp
//******************************************************************************************