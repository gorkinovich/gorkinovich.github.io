 ---------------------------------------------------------------------------
                                   CRM32Pro SDK
                            MegaStorm Systems (c) 2006
                              Roberto  Prieto Prieto
 ---------------------------------------------------------------------------

     CRM32Pro is a multimedia and cross-platform (Win32 and Linux) software 
development kit(SDK) written in C++ and built on top of SDL.
It is used as a framework for games, emulators, multimedia applications, etc.


   Platforms supports:

    - Any Windows x86 or x86-64 version. Compilers supported:       
      > Visual Studio (from 6.0 to 2005)
      > GNU GCC (from 3.x to 4.x). Also, you can use mingw32/devc++.

    - Any Linux x86 or x86-64 distribution. Compilers supported:      
      > GNU GCC (from 3.x to 4.x).

   Modules:
    1. Main and generics functions.
    2. ILogSystem
    3. IStuffDPF
    4. Image Package Format
    5. ICursor
    6. CTileEngine
    7. IPrimitives
    8. CFont
    9. IScreenFX
    10. CButton
    11. ITimerSystem
    12. CSpriteEngine     
    13. INetwork
    14. IVideo player
    15. ISoundFX

   It uses the following projects:
    � Simple DirectMedia Layer 1.2.10   - www.libsdl.org
    � SMPEG 0.4.5 CVS (MPEG)            - www.icculus.org/smpeg/
    � UCL 1.03 (UCL)                    - www.oberhumer.com/opensource/ucl/
    � SDL_Mixer 1.2.7 CVS               - www.libsdl.org/projects/SDL_mixer
    � MikMod 3.1.9a                     - mikmod.raphnet.net/
    � LibVorbis 1.1.2 and LibOgg 1.1.3  - www.vorbis.com/
    � SDL_net 1.2.5                     - www.libsdl.org/projects/SDL_net
    � Mersenne Twister number generator - www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/emt.html
    � TinyXml v2.4.1                    - www.sourceforge.net/projects/tinyxml
   
   CRM32Pro SDK is a free library under copyright, you can use it to develop
any application or game without restrictions, you only must to include 
this file, a reference in your product to this library and very 
important: licenses files of above projects. Due to this software
is licensed free of charge, there is no warranty for its use.

Author:   Roberto Prieto Prieto
Email:    megastorm@mi.madritel.es
Web page: http://www.megastormsystems.com

MegaStorm Systems (c) 2006

