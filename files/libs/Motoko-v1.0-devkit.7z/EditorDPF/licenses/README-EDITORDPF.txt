 ---------------------------------------------------------------------------
                                     EDITOR DPF
                            MegaStorm Systems (c) 2006
                              Roberto  Prieto Prieto
 ---------------------------------------------------------------------------
    
     EditorDPF is a resource editor to use with CRM32Pro. You can store, 
 change and manipulate all the resources of your application coded with CRM32Pro
 without recompile your application. It will maintain packed in compact files all
 yours resources and it will prevent that they will be easily modified.
  
 Features:
 
  - Stores images with proprietary format, import and export to BMP/PNG.
  - Stores tiles and its features: colorkey, alpha, tileset, etc.
  - Stores sprites and its features: colorkey, alpha, animation, states, etc.
  - Stores fonts with propietary format, import any type of existing fonts.
  - Stores buttons and its features: colorkey, alpha,position,type,etc.
  - Stores sound and music resources.
  - Stores XML or any kind of data files.

   Platform support:
    - Any Windows x86 or x86-64 version.

   It uses the following projects:
    � CRM32Pro 4.xx                      - http://www.megastormsystems.com
    � Libpng 1.2.8                       - http://www.libpng.org
    � zlib 1.2.2                         - http://www.zlib.org
   
     
   EditorDPF is a free tool under copyright, but you can use it 
for your software without restrictions and you only must to include 
this file, a reference in your software to this tool and very 
important: licenses files of GNU libraries. Because this software
is licensed free of charge,there is no warranty for its use.

Author:   Roberto Prieto Prieto
Email:    megastorm@mi.madritel.es
Web page: http://www.megastormsystems.com

MegaStorm Systems (c) 2006  