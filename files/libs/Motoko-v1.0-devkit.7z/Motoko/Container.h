//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_CONTAINER_H_
#define _MOTOKO_CONTAINER_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "ListControls.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic container.
	//--------------------------------------------------------------------------------------
	class DLLAPI Container : public Control
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			ListControls List;

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			inline void UpdateIncX (Sint16 inc);
			inline void UpdateIncY (Sint16 inc);

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			Container ();
			Container (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
					   Uint32 backcolor, ControlSkin * appearance = NULL,
					   SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
					   bool transparency = false, bool enable = true, bool visible = true);
			Container (const Container & obj);
			virtual Container & operator = (const Container & obj);
			~Container ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void) = 0;
			virtual bool Update (SDL_Event & event) = 0;

			virtual Container & CopyFrom (const Container & obj);

			/// Add a control in the container.
			inline int AddControl (Control * control);

			/// Add a control in the container.
			inline int AddControlRel (Control * control);

			/// Remove a control in the container.
			inline void RemoveControl (const char * name) { List.RemoveControl(name); }

			/// Remove all the controls in the container
			inline void Free (void) { List.Free(); }
			

			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get a control in the list.
			inline Control * GetControl (const char * name) { return List.GetControl(name); }

			/// Get the number of controls in the list.
			inline int GetSize (void) { return List.GetSize(); }

			/// Get a pointer to a control.
			inline Control * GetControl (int pos) { return List.GetControl(pos); }

			/// Get the mouse pointer of the control.
			virtual inline SDL_Surface * GetMousePointer (void);


			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the coordinate X of the control.
			virtual inline void SetX (Sint16 val)
			{
				UpdateIncX(val - Rect.x);
				Rect.x = val;
			}

			/// Set the coordinate Y of the control.
			virtual inline void SetY (Sint16 val)
			{
				UpdateIncY(val - Rect.y);
				Rect.y = val;
			}

			/// Set the rect of the control.
			virtual inline void SetRect (SDL_Rect & val)
			{
				UpdateIncX(val.x - Rect.x);
				UpdateIncY(val.y - Rect.y);
				Rect = val;
			}
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Container.h
//******************************************************************************************