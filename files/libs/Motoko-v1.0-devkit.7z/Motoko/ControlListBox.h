//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_CONTROLLISTBOX_H_
#define _MOTOKO_CONTROLLISTBOX_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "Box.h"
#include "VScrollBar.h"
#include "ListControls.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic control list box.
	//--------------------------------------------------------------------------------------
	class DLLAPI ControlListBox : public Box
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			//------------------------------------------------------------------------------
			// Properties
			//------------------------------------------------------------------------------
			ListControls List;
			bool MultiSelect;

			list<int> SelectedItems;

			Uint32 SelColor;


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			VScrollBar * VBar;

			int MaxWidth;
			int MaxHeight;

			int NumCols;
			int NumRows;

			int FirstSelect;

			void UpdateValues (void);

			void DrawList (void);


		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ControlListBox ();
			ControlListBox (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
							Uint32 backcolor, ControlSkin * appearance = NULL,
							SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
							bool transparency = false, Uint32 selcolor = 0x00000000,
							bool multisel = false, bool enable = true, bool visible = true);
			ControlListBox (const ControlListBox & obj);
			virtual ControlListBox & operator = (const ControlListBox & obj);
			~ControlListBox ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual ControlListBox & CopyFrom (const ControlListBox & obj);

			virtual void UpdateRects (void);

			/// Add a control in the container.
			int AddControl (Control * control);

			/// Remove a control in the container.
			inline void RemoveControl (const char * name) { List.RemoveControl(name); }

			/// Remove all the controls in the container
			inline void Free (void) { List.Free(); MaxWidth = 0; MaxHeight = 0; UpdateValues(); }


			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get a control in the list.
			inline Control * GetControl (const char * name) { return List.GetControl(name); }

			/// Get the number of controls in the list.
			inline int GetSize (void) { return List.GetSize(); }

			/// Get a pointer to a control.
			inline Control * GetControl (int pos) { return List.GetControl(pos); }

			/// Get the mouse pointer of the control.
			virtual inline SDL_Surface * GetMousePointer (void);

			/// Get if the control is multiselect.
			inline bool GetMultiSelect (void) { return MultiSelect; }

			/// Get the selected items of the list.
			inline list<int> * GetSelectedItems (void) { return &SelectedItems; }

			/// Get the color of selection of the list.
			inline Uint32 GetSelColor (void) { return SelColor; }

			/// Get the VBar of the control.
			inline VScrollBar * GetVBar (void) { return VBar; }
			

			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------
			
			/// Set if the control is multiselect.
			virtual inline void SetMultiSelect (bool val) { MultiSelect = val; }

			/// Set no selected items of the list.
			virtual inline void SetNoSelectedItems (void) { SelectedItems.clear(); }

			/// Set the color of selection of the list.
			virtual inline void SetSelColor (Uint32 val) { SelColor = val; }

			/// Set the name of the control.
			virtual inline void SetName (const char * val)
			{
				Name = val;

				string aux;

				aux = Name + "_VBar"; VBar->SetName(aux.c_str());
			}
			
			/// Set the back style of the control.
			virtual inline void SetBackStyle (ControlBackStyle val)
			{
				BackStyle = val;
				VBar->SetBackStyle(val);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 box, Uint32 scrolls)
			{
				BackColor = box;
				VBar->SetBackColor(scrolls);
			}

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * box, ControlSkin * vscroll, ControlSkin * button)
			{
				Appearance = box;
				VBar->SetAppearance(vscroll, button);
			}
			
			/// Set the back color of the control.
			virtual inline void SetBackColor (Uint32 val) { BackColor = val; }

			/// Set the appearance of the control.
			inline void SetAppearance (ControlSkin * val) { Appearance = val; }
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// ControlListBox.h
//******************************************************************************************