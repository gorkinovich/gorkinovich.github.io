//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_H_
#define _MOTOKO_H_
//******************************************************************************************
#ifdef WIN32
	#pragma comment (lib, "CRM32Pro.lib")
	#pragma comment (lib, "sdlmain.lib")
	#pragma comment (lib, "Lua.lib")
	#pragma comment (lib, "Motoko.lib")
#endif
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Keys.h"
#include "Appearance.h"
#include "Control.h"
#include "ListControls.h"
#include "ITextControl.h"
//------------------------------------------------------------------------------------------
#include "Box.h"
#include "TextBox.h"
#include "LabelBox.h"
#include "PictureBox.h"
#include "ComboBox.h"
#include "ListBox.h"
//------------------------------------------------------------------------------------------
#include "Button.h"
#include "CheckButton.h"
//------------------------------------------------------------------------------------------
#include "ScrollBar.h"
#include "VScrollBar.h"
#include "HScrollBar.h"
//------------------------------------------------------------------------------------------
#include "Container.h"
#include "Panel.h"
#include "Dialog.h"
#include "ControlListBox.h"
//------------------------------------------------------------------------------------------
#include "Resources.h"
#include "Application.h"
//******************************************************************************************
#endif
//******************************************************************************************
// Motoko.h
//******************************************************************************************