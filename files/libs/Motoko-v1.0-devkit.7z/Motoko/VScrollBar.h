//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_VSCROLLBAR_H_
#define _MOTOKO_VSCROLLBAR_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
#include "Appearance.h"
#include "Control.h"
#include "Button.h"
#include "ScrollBar.h"
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Class that represents a generic vertical scrollbar.
	//--------------------------------------------------------------------------------------
	class DLLAPI VScrollBar : public ScrollBar
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:

		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			VScrollBar ();
			VScrollBar (const char * name, SDL_Rect rect, ControlBackStyle backstyle,
						Uint32 backcolor, ControlSkin * appearance = NULL,
						int min = 0, int max = 1, int value = 0, int large = 1, int small = 1,
						SDL_Surface * picture = NULL, SDL_Surface * mousepointer = NULL,
						bool transparency = false, bool enable = true, bool visible = true);
			VScrollBar (const VScrollBar & obj);
			virtual VScrollBar & operator = (const VScrollBar & obj);
			~VScrollBar ();


			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			virtual void Draw   (void);
			virtual bool Update (SDL_Event & event);

			virtual VScrollBar & CopyFrom (const VScrollBar & obj);

			virtual void UpdateButton (void);
			virtual void UpdateRects (void);
			

			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------

			/// Get the Button01 of the control.
			inline Button * GetButtonUp (void) { return Button01; }

			/// Get the Button02 of the control.
			inline Button * GetButtonCenter (void) { return Button02; }

			/// Get the Button03 of the control.
			inline Button * GetButtonDown (void) { return Button03; }

			
			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the name of the control.
			virtual inline void SetName (const char * val)
			{
				Name = val;

				string aux;

				aux = Name + "_Up";     Button01->SetName(aux.c_str());
				aux = Name + "_Center"; Button02->SetName(aux.c_str());
				aux = Name + "_Down";   Button03->SetName(aux.c_str());
			}
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// VScrollBar.h
//******************************************************************************************