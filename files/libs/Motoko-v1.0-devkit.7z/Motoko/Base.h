//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_BASE_H_
#define _MOTOKO_BASE_H_
//******************************************************************************************
#ifdef WIN32
	#pragma comment (lib, "CRM32Pro.lib")
	#pragma comment (lib, "sdlmain.lib")
	#pragma comment (lib, "Lua.lib")
#endif
//******************************************************************************************
// Includes
//******************************************************************************************
#include "CRM32Pro/CRM32Pro.h"
//------------------------------------------------------------------------------------------
extern "C"
{
#include "Lua/lua.h"
#include "Lua/lualib.h"
#include "Lua/lauxlib.h"
}
//------------------------------------------------------------------------------------------
#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <stack>
//------------------------------------------------------------------------------------------
using namespace std;
//******************************************************************************************
// Macros
//******************************************************************************************
#ifndef MOTOKO_EXPORTS // The VC++ defines this constant in the proyect settings.
	#define DLLAPI __declspec (dllimport) // Import the functions from the dll.
#else
	#define DLLAPI __declspec (dllexport) // Export the functions to the dll.
#endif
//******************************************************************************************
// Constants
//******************************************************************************************
#define EVERYTHING_ALL_RIGHT 0
#define RESULT_OK            0
//------------------------------------------------------------------------------------------
#define CRMFAIL  0
#define SDLFAIL -1
#define STR_EQU  0
//------------------------------------------------------------------------------------------
#define CONTROL_GET_FOCUS   1
#define CONTROL_DOUBLECLICK 2
//------------------------------------------------------------------------------------------
#define CHAR_DELETE 8
//******************************************************************************************
/// Namespace Motoko.
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	// STL stuff
	//--------------------------------------------------------------------------------------
	template class DLLAPI std::allocator<int>;
	template class DLLAPI std::list<int, std::allocator<int> >;

	//--------------------------------------------------------------------------------------
	// Simple data types
	//--------------------------------------------------------------------------------------
	typedef signed char      sbyte;  //!< Signed type of 1 byte (8 bits).
	typedef signed short int sword;  //!< Signed type of 2 byte (16 bits).
	typedef signed long int  sdword; //!< Signed type of 4 byte (32 bits).
	
	typedef unsigned char      byte;  //!< Unsigned type of 1 byte (8 bits).
	typedef unsigned short int word;  //!< Unsigned type of 2 byte (16 bits).
	typedef unsigned long int  dword; //!< Unsigned type of 4 byte (32 bits).

	
	typedef signed char      Sint8;  //!< Signed type of 1 byte (8 bits).
	typedef signed short int Sint16; //!< Signed type of 2 byte (16 bits).
	typedef signed long int  Sint32; //!< Signed type of 4 byte (32 bits).
	
	typedef unsigned char      Uint8;  //!< Unsigned type of 1 byte (8 bits).
	typedef unsigned short int Uint16; //!< Unsigned type of 2 byte (16 bits).
	typedef unsigned long int  Uint32; //!< Unsigned type of 4 byte (32 bits).


	//--------------------------------------------------------------------------------------
	// Pointer functions
	//--------------------------------------------------------------------------------------
	typedef bool (*SDL_KEY_EVENT)         (void * control, SDL_KeyboardEvent & event);    //!< Key event prototype function.
	typedef bool (*SDL_MOUSEMOTION_EVENT) (void * control, SDL_MouseMotionEvent & event); //!< Mouse motion event prototype function.
	typedef void (*SDL_MOUSEBUTTON_EVENT) (void * control, SDL_MouseButtonEvent & event); //!< Mouse button event prototype function.
	typedef void (*SDL_DOUBLECLICK_EVENT) (void * control);                               //!< Double-click event prototype function.
	
	//--------------------------------------------------------------------------------------
	// Functions
	//--------------------------------------------------------------------------------------
	void DLLAPI BlitWithResize (SDL_Surface * src, SDL_Rect * srcrect,
								SDL_Surface * dst, SDL_Rect * dstrect);

	void DLLAPI FillSurface (dword color, SDL_Rect * rect, SDL_Surface * dst, SDL_Rect * limits);

	char DLLAPI GetSpanishKBChar (SDL_keysym & event);
	char DLLAPI GetEnglishKBChar (SDL_keysym & event);
}
//******************************************************************************************
#endif
//******************************************************************************************
// Base.h
//******************************************************************************************