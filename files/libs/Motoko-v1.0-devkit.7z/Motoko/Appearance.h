//******************************************************************************************
// Motoko, a 2D GUI for games.
// Copyright (C) 2006  Gorka Su�rez Garc�a
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//******************************************************************************************
#ifndef _MOTOKO_APPEARANCE_H_
#define _MOTOKO_APPEARANCE_H_
//******************************************************************************************
// Includes
//******************************************************************************************
#include "Base.h"
//******************************************************************************************
// Constants
//******************************************************************************************
#define THEMESKIN_ERROR_UNDEF       1000
#define THEMESKIN_ERROR_XMLOPEN     1001
#define THEMESKIN_ERROR_XMLTYPE     1002
//------------------------------------------------------------------------------------------
#define SKINSMANAGER_ERROR_UNDEF    2000
#define SKINSMANAGER_ERROR_NEWTHEME 2001
#define SKINSMANAGER_ERROR_PUSHBACK 2002
//******************************************************************************************
// Namespace Motoko
//******************************************************************************************
namespace Motoko
{
	//--------------------------------------------------------------------------------------
	/// Struct with information of a control's skin.
	//--------------------------------------------------------------------------------------
	struct ControlSkin
	{
		string        Name;     //!< Name of the skin.
		SDL_Surface * Texture;  //!< Texture of the skin.
		int           NumRects; //!< Number of rects in the texture.
		SDL_Rect *    Rects;    //!< Rects inside the texture.
	};

	//--------------------------------------------------------------------------------------
	/// Class with all the skins of a theme.
	//--------------------------------------------------------------------------------------
	class DLLAPI ThemeSkin
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			template class DLLAPI std::allocator<ControlSkin *>;
			template class DLLAPI std::vector<ControlSkin *, std::allocator<ControlSkin *> >;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			vector<ControlSkin *> Skins;

			string Name;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			ThemeSkin ();
			ThemeSkin (const ThemeSkin & obj);
			virtual ThemeSkin & operator = (const ThemeSkin & obj);
			~ThemeSkin ();

			
			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			int  Load (const char * fileDPF, const char * fileXML = "skinconfig.xml");
			void Free (void);
			

			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------
			ControlSkin * GetSkin (const char * name);

			/// Get the name of the theme.
			inline const char * GetName (void) { return Name.c_str(); }
			

			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------

			/// Set the name of the theme.
			inline void SetName (const char * val) { Name = val; }
	};

	//--------------------------------------------------------------------------------------
	/// Manager of all the application's themes.
	//--------------------------------------------------------------------------------------
	class DLLAPI SkinsManager
	{
		//----------------------------------------------------------------------------------
		// Private members
		//----------------------------------------------------------------------------------
		private:
			template class DLLAPI std::allocator<ThemeSkin *>;
			template class DLLAPI std::vector<ThemeSkin *, std::allocator<ThemeSkin *> >;
			
		//----------------------------------------------------------------------------------
		// Protected members
		//----------------------------------------------------------------------------------
		protected:
			vector<ThemeSkin *> Skins;
			
		//----------------------------------------------------------------------------------
		// Public members
		//----------------------------------------------------------------------------------
		public:
			SkinsManager ();
			SkinsManager (const SkinsManager & obj);
			virtual SkinsManager & operator = (const SkinsManager & obj);
			~SkinsManager ();
			

			//------------------------------------------------------------------------------
			// Logic
			//------------------------------------------------------------------------------
			int  AddTheme    (const char * fileDPF, const char * fileXML = "skinconfig.xml");
			int  AddTheme    (ThemeSkin * theme);
			void RemoveTheme (const char * theme);

			void Free (void);
			

			//------------------------------------------------------------------------------
			// Gets
			//------------------------------------------------------------------------------
			ControlSkin * GetSkin (const char * theme, const char * name);
			

			//------------------------------------------------------------------------------
			// Sets
			//------------------------------------------------------------------------------
			void SetThemeName (const char * theme, const char * name);
	};
}
//******************************************************************************************
#endif
//******************************************************************************************
// Appearance.h
//******************************************************************************************